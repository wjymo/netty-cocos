"use strict";
cc._RF.push(module, 'b959c5jWaxClrV2I6mL83rC', 'FightScene');
// script/xiaojingling/FightScene.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MsgSender_1 = require("../../msg/MsgSender");
var AllHandler_1 = require("../../resultHandler/AllHandler");
var WebUtil_1 = require("./WebUtil");
var mod_GameMsgProcotol = require("../../msg/GameMsgProtocol");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var heroName = "Huolong";
var FightScene = /** @class */ (function (_super) {
    __extends(FightScene, _super);
    function FightScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._oMyHreo = null;
        return _this;
    }
    // onLoad () {}
    FightScene.prototype.start = function () {
        var _this = this;
        var collisionManager = cc.director.getCollisionManager();
        collisionManager.enabled = true;
        collisionManager.enabledDebugDraw = true;
        collisionManager.enabledDrawBoundingBox = true;
        console.log('collisionManager', collisionManager);
        var colliders = collisionManager['_colliders'];
        console.log('colliders', colliders);
        MsgSender_1.default.getInstance().connect(function () {
            var oAllHandler = new AllHandler_1.default();
            MsgSender_1.default.getInstance().onMsgReceived = function (nMsgCode, oMsgBody) {
                oAllHandler.handle(nMsgCode, oMsgBody);
            };
            var userId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            var heroAvatar = WebUtil_1.default.getQueryParam("heroAvatar");
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_ENTRY_CMD, mod_GameMsgProcotol.msg.UserEntryCmd.create({
                userId: userId,
                heroAvatar: heroAvatar
            }));
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.WHO_ELSE_IS_HERE_CMD, mod_GameMsgProcotol.msg.WhoElseIsHereCmd.create({}));
        });
        // HeroFactory.createAsync(heroName, (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     // heroNode.x = 300 * Math.random();
        //     // heroNode.y = 300 * Math.random();
        //     heroNode.x = -200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Xiyi", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 0;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Gui", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        cc.Canvas.instance.node.on(cc.Node.EventType.MOUSE_UP, function (event) {
            switch (event['getButton']()) {
                case 0: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    // cc.find('Canvas/Huolong').getComponent(MyHuolong).attk(oMoveToV2.x,oMoveToV2.y);
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).attk(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.attk(oMoveToV2.x, oMoveToV2.y);
                    break;
                }
                case 2: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).moveTo(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.moveTo(oMoveToV2.x, oMoveToV2.y);
                    MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_MOVE_TO_CMD, mod_GameMsgProcotol.msg.UserMoveToCmd.create({
                        // moveFromPosX:this._oMyHreo.node.x,
                        // moveFromPosY:this._oMyHreo.node.y,
                        moveToPosX: oMoveToV2.x,
                        moveToPosY: oMoveToV2.y,
                    }));
                    break;
                }
            }
            // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
            // let traceEntry = skeleton.setAnimation(1,'skill01',false);
            // skeleton.setTrackCompleteListener(traceEntry,function () {
            //     skeleton.clearTrack(1);
            // })
        });
    };
    FightScene.prototype.update = function (dt) {
        //
    };
    FightScene = __decorate([
        ccclass
    ], FightScene);
    return FightScene;
}(cc.Component));
exports.default = FightScene;

cc._RF.pop();