"use strict";
cc._RF.push(module, 'e7d6c5P7VBHVa9cf53adggG', 'UserQuitResultHandler');
// resultHandler/UserQuitResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserQuitResultHandler = /** @class */ (function () {
    function UserQuitResultHandler() {
    }
    UserQuitResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.quitUserId + "\u79BB\u573A");
        var myHeroComp = UserManager_1.default.getMyHeroComp(oResult.quitUserId);
    };
    return UserQuitResultHandler;
}());
exports.default = UserQuitResultHandler;

cc._RF.pop();