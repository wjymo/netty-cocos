"use strict";
cc._RF.push(module, '9f8efav/TRDiIt8ruVLlakl', 'AllHandler');
// resultHandler/AllHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProtocol = require("../msg/GameMsgProtocol");
var UserEntryResultHandler_1 = require("./UserEntryResultHandler");
var WhoElseIsHereHandler_1 = require("./WhoElseIsHereHandler");
var UserQuitResultHandler_1 = require("./UserQuitResultHandler");
var UserMoveToResultHandler_1 = require("./UserMoveToResultHandler");
var AllHandler = /** @class */ (function () {
    function AllHandler() {
        this._oHandlerMap = {};
        var oMsgCode = mod_GameMsgProtocol.msg.MsgCode;
        this._oHandlerMap[oMsgCode.USER_ENTRY_RESULT] = new UserEntryResultHandler_1.default();
        this._oHandlerMap[oMsgCode.WHO_ELSE_IS_HERE_RESULT] = new WhoElseIsHereHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_MOVE_TO_RESULT] = new UserMoveToResultHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_QUIT_RESULT] = new UserQuitResultHandler_1.default();
    }
    AllHandler.prototype.handle = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || oMsgBody == null) {
            return;
        }
        var oHandler = this._oHandlerMap[nMsgCode];
        if (oHandler == null) {
            cc.error("nMsgCode:" + nMsgCode + "\u627E\u4E0D\u5230\u5BF9\u5E94handler");
            return;
        }
        oHandler.handle(oMsgBody);
    };
    return AllHandler;
}());
exports.default = AllHandler;

cc._RF.pop();