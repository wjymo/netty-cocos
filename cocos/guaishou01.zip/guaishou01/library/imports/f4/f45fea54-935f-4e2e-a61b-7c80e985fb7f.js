"use strict";
cc._RF.push(module, 'f45fepUk19OLqYbfIDphft/', 'HeroFactory');
// script/xiaojingling/HeroFactory.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Async_1 = require("./Async");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BUNDLE_NAME = "prefab";
var HeroFacyor = /** @class */ (function (_super) {
    __extends(HeroFacyor, _super);
    function HeroFacyor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // onLoad () {}
    HeroFacyor.prototype.start = function () {
    };
    HeroFacyor.createAsync = function (heroName, funCallback) {
        if (heroName == null) {
            return;
        }
        var loadBundle = cc.assetManager.getBundle(BUNDLE_NAME);
        var loadPrefab = null;
        Async_1.default.seriez(function (funYesContinue) {
            if (loadBundle != null) {
                funYesContinue();
                return;
            }
            cc.assetManager.loadBundle(BUNDLE_NAME, function (error, bundle) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                loadBundle = bundle;
                funYesContinue();
            });
        }, function (funYesContinue) {
            loadPrefab = loadBundle.get(heroName, cc.Prefab);
            if (null != loadPrefab) {
                funYesContinue();
                return;
            }
            loadBundle.load(heroName, cc.Prefab, function (error, prefab) {
                if (error != null) {
                    cc.error("heroName:" + heroName + "\u627E\u4E0D\u5230\u5BF9\u5E94\u9884\u5236\u4F53", error);
                    return;
                }
                loadPrefab = prefab;
                funYesContinue();
            });
        }, function (funYesContinue) {
            var mainBundle = cc.assetManager.getBundle("main");
            mainBundle.preloadDir("spine/xiaojingling/" + heroName, function (error) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                funYesContinue();
            });
        }, function (funYesContinue) {
            if (loadPrefab == null) {
                cc.error("loadPrefab\u4E3A\u7A7A\uFF0C\u540D\u5B57\uFF1A" + heroName);
                return;
            }
            var heroNode = cc.instantiate(loadPrefab);
            funCallback(heroNode);
        });
        // if(loadBundle==null){
        //     cc.assetManager.loadBundle(BUNDLE_NAME,(error:Error,bundle:cc.AssetManager.Bundle)=>{
        //         if(error!=null){
        //             cc.error(error);
        //             return;
        //         }
        //         let loadPrefab = bundle.get(heroName,cc.Prefab);
        //         if(null==loadPrefab){
        //             bundle.load(heroName,cc.Prefab,(error:Error,prefab:cc.Prefab)=>{
        //                 if(error!=null){
        //                     cc.error(error);
        //                     return;
        //                 }
        //                 let mainBundle = cc.assetManager.getBundle("main");
        //                 mainBundle.preloadDir(`spine/${heroName}`,(error:Error)=>{
        //                     if(error!=null){
        //                         cc.error(error);
        //                         return;
        //                     }
        //                     let heroNode = cc.instantiate(prefab);
        //                     funCallback(heroNode)
        //                 })
        //             });
        //         }
        //     });
        // }
    };
    HeroFacyor = __decorate([
        ccclass
    ], HeroFacyor);
    return HeroFacyor;
}(cc.Component));
exports.default = HeroFacyor;

cc._RF.pop();