"use strict";
cc._RF.push(module, '74180Tk7FlDB4Y11ms3KYN6', 'Eyu');
// script/xiaojingling/Eyu.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
var speed = 120;
var customScaleX = 0.8;
var MyHuuolong = /** @class */ (function (_super) {
    __extends(MyHuuolong, _super);
    function MyHuuolong() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._bIsMoving = false;
        _this._oMoveDirection = null;
        _this._oMoveTo = null;
        return _this;
    }
    // onLoad () {}
    MyHuuolong.prototype.start = function () {
    };
    MyHuuolong.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
    };
    MyHuuolong.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    MyHuuolong.prototype.attk = function (nPosX, nPosY) {
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
        });
    };
    MyHuuolong.prototype.die = function () {
    };
    MyHuuolong = __decorate([
        ccclass
    ], MyHuuolong);
    return MyHuuolong;
}(cc.Component));
exports.default = MyHuuolong;

cc._RF.pop();