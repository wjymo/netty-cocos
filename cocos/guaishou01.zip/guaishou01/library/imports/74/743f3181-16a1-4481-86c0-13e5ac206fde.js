"use strict";
cc._RF.push(module, '743f3GBFqFEgYbAE+WsIG/e', 'UserMoveToResultHandler');
// resultHandler/UserMoveToResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserMoveToResultHandler = /** @class */ (function () {
    function UserMoveToResultHandler() {
    }
    UserMoveToResultHandler.prototype.handle = function (oResult) {
        if (oResult == null) {
            return;
        }
        var userId = oResult.moveUserId;
        var oHreoComp = UserManager_1.default.getMyHeroComp(userId);
        // let oHreoComp =find();
        oHreoComp.moveTo(oResult.moveToPosX, oResult.moveToPosY);
    };
    return UserMoveToResultHandler;
}());
exports.default = UserMoveToResultHandler;

cc._RF.pop();