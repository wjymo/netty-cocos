"use strict";
cc._RF.push(module, '173416YXH9KiY/sjR5VNENm', 'MsgEncoder');
// msg/MsgEncoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_protobuf = require("./protobuf");
var MsgEncoder = /** @class */ (function () {
    function MsgEncoder() {
    }
    MsgEncoder.prototype.encode = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        var oWriter = mod_protobuf.Writer.create();
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        var oByteAttay = oMsgBody.constructor.encode(oMsgBody, oWriter).finish();
        var nMsgLen = oByteAttay.byteLength = 2;
        oByteAttay[0] = nMsgLen >> 8 & 0xff;
        oByteAttay[1] = nMsgLen & 0xff;
        oByteAttay[2] = nMsgCode >> 8 & 0xff;
        oByteAttay[3] = nMsgCode & 0xff;
        return oByteAttay;
    };
    return MsgEncoder;
}());
exports.default = MsgEncoder;

cc._RF.pop();