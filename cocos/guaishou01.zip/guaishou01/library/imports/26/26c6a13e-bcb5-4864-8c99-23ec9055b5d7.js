"use strict";
cc._RF.push(module, '26c6aE+vLVIZIyZI+yQVbXX', 'WhoElseIsHereHandler');
// resultHandler/WhoElseIsHereHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var Common_1 = require("../script/xiaojingling/Common");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var WhoElseIsHereHandler = /** @class */ (function () {
    function WhoElseIsHereHandler() {
    }
    WhoElseIsHereHandler.prototype.handle = function (oResult) {
        var oUserInfoArray = oResult.userInfo;
        var _loop_1 = function (oUserInfo) {
            if (oUserInfo == null) {
                return "continue";
            }
            var heroAvatar = oUserInfo.heroAvatar;
            HeroFactory_1.default.createAsync(heroAvatar, function (heroNode) {
                if (heroNode == null) {
                    return;
                }
                cc.Canvas.instance.node.addChild(heroNode);
                // heroNode.x = 300 * Math.random();
                // heroNode.y = 300 * Math.random();
                // heroNode.x = -200;
                // heroNode.y = 0;
                // heroNode.active = true;
                var skeleton = heroNode.getComponent(sp.Skeleton);
                skeleton.setAnimation(1, 'stand', true);
                UserManager_1.default.putMyHeroComp(oUserInfo.userId, heroNode.getComponent(Common_1.default));
            });
        };
        for (var _i = 0, oUserInfoArray_1 = oUserInfoArray; _i < oUserInfoArray_1.length; _i++) {
            var oUserInfo = oUserInfoArray_1[_i];
            _loop_1(oUserInfo);
        }
    };
    return WhoElseIsHereHandler;
}());
exports.default = WhoElseIsHereHandler;

cc._RF.pop();