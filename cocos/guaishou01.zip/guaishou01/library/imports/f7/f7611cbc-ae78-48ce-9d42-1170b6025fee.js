"use strict";
cc._RF.push(module, 'f7611y8rnhIzp1CEXC2Al/u', 'MsgDecoder');
// msg/MsgDecoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProcotol = require("./GameMsgProtocol");
var MsgDecoder = /** @class */ (function () {
    function MsgDecoder() {
    }
    MsgDecoder.prototype.getMsgCode = function (oUint8Array) {
        if (oUint8Array == null || oUint8Array.byteLength < 4) {
            return -1;
        }
        var nMsgCode = 0;
        nMsgCode |= (oUint8Array[2] & 0xFF) << 8;
        nMsgCode |= (oUint8Array[3] & 0xFF);
        return nMsgCode;
    };
    MsgDecoder.prototype.decode = function (nMsgCode, oUint8Array) {
        if (nMsgCode < 0 || null == oUint8Array || oUint8Array.byteLength <= 0) {
            return;
        }
        var strMsgName = mod_GameMsgProcotol.msg.MsgCode[nMsgCode];
        if (strMsgName == null) {
            console.log("nMsgCode:" + nMsgCode + "\u5BF9\u5E94msg\u540D\u79F0\u4E0D\u5B58\u5728");
        }
        var oTempArray = strMsgName.split("_");
        strMsgName = "";
        for (var _i = 0, oTempArray_1 = oTempArray; _i < oTempArray_1.length; _i++) {
            var strTemp = oTempArray_1[_i];
            strMsgName += strTemp.charAt(0) + strTemp.substr(1).toLowerCase();
        }
        var oMsgClazz = mod_GameMsgProcotol.msg[strMsgName];
        if (null == oMsgClazz || typeof (oMsgClazz['decode']) != "function") {
            console.log("strMsgName:" + strMsgName + " \u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7684\u7C7B");
            return;
        }
        return oMsgClazz.decode(oUint8Array);
    };
    return MsgDecoder;
}());
exports.default = MsgDecoder;

cc._RF.pop();