"use strict";
cc._RF.push(module, '34a19lm1H9JGbAT609CM1c5', 'UserEntryResultHandler');
// resultHandler/UserEntryResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var WebUtil_1 = require("../script/xiaojingling/WebUtil");
var Common_1 = require("../script/xiaojingling/Common");
var FightScene_1 = require("../script/xiaojingling/FightScene");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserEntryResultHandler = /** @class */ (function () {
    function UserEntryResultHandler() {
    }
    UserEntryResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.heroAvatar + ",id=" + oResult.userId + "\u5165\u573A");
        HeroFactory_1.default.createAsync(oResult.heroAvatar, function (heroNode) {
            if (heroNode == null) {
                return;
            }
            var nMyUserId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            //oResult是后台传的英雄对象，nMyUserId是url地址里写的用户id，oMyHeroComp是通过后台传入的oResult的名称加载出来的预制体
            var oMyHeroComp = heroNode.getComponent(Common_1.default);
            if (oResult.userId == nMyUserId) {
                cc.Canvas.instance.node.getComponent(FightScene_1.default)._oMyHreo = oMyHeroComp;
            }
            cc.Canvas.instance.node.addChild(heroNode);
            // heroNode.x = 300 * Math.random();
            // heroNode.y = 300 * Math.random();
            // heroNode.x = -200;
            // heroNode.y = 0;
            // heroNode.active = true;
            var skeleton = heroNode.getComponent(sp.Skeleton);
            skeleton.setAnimation(1, 'stand', true);
            UserManager_1.default.putMyHeroComp(oResult.userId, oMyHeroComp);
        });
    };
    return UserEntryResultHandler;
}());
exports.default = UserEntryResultHandler;

cc._RF.pop();