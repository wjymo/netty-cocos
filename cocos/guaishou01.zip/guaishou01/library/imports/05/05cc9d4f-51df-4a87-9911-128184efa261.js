"use strict";
cc._RF.push(module, '05cc91PUd9Kh5kREoGE76Jh', 'WebUtil');
// script/xiaojingling/WebUtil.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var WebUtil = /** @class */ (function () {
    function WebUtil() {
    }
    WebUtil.getQueryParam = function (strName) {
        if (strName == null) {
            return null;
        }
        var oResult = window.location.search.match(new RegExp("[\?\&]" + strName + "=([^\&]+)", "i"));
        if (null == oResult || oResult.length < 1) {
            return null;
        }
        return oResult[1];
    };
    return WebUtil;
}());
exports.default = WebUtil;

cc._RF.pop();