"use strict";
cc._RF.push(module, 'db8e8qijfhLu5qRq3LZHeRc', 'MsgSender');
// msg/MsgSender.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MsgEncoder_1 = require("./MsgEncoder");
var MsgDecoder_1 = require("./MsgDecoder");
var MsgSender = /** @class */ (function () {
    function MsgSender() {
        this._oWebsocket = null;
        this._oMsgEncoder = new MsgEncoder_1.default();
        this._oMsgDecoder = new MsgDecoder_1.default();
    }
    /**
     * 获取单例对象
     */
    MsgSender.getInstance = function () {
        return MsgSender._oInstance;
    };
    MsgSender.prototype.connect = function (funCallback) {
        var _this = this;
        if (funCallback === void 0) { funCallback = null; }
        var url = 'ws://192.168.1.63:6666/websocket';
        var oWebsocket = new WebSocket(url);
        oWebsocket.binaryType = "arraybuffer";
        oWebsocket.onopen = function () {
            cc.log("\u5DF2\u8FDE\u63A5\u670D\u52A1\u5668\uFF0Curl=" + url);
            _this._oWebsocket = oWebsocket;
            if (null != funCallback) {
                funCallback();
            }
        };
        oWebsocket.onclose = function () {
            cc.log("\u670D\u52A1\u5668\u5173\u95ED\u8FDE\u63A5");
            _this._oWebsocket = null;
        };
        oWebsocket.onmessage = function (oEvent) {
            console.log("onmessage进入");
            if (oEvent == null || null == oEvent.data) {
                return;
            }
            var uint8Array = new Uint8Array(oEvent.data);
            var nMsgCode = _this._oMsgDecoder.getMsgCode(uint8Array);
            var decode = _this._oMsgDecoder.decode(nMsgCode, uint8Array.slice(4));
            console.log("decode", decode);
            if (_this.onMsgReceived != null) {
                _this.onMsgReceived(nMsgCode, decode);
            }
        };
    };
    MsgSender.prototype.sendMsg = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        if (null == this._oWebsocket) {
            return;
        }
        var uint8Array = this._oMsgEncoder.encode(nMsgCode, oMsgBody);
        if (uint8Array == null) {
            return;
        }
        console.log('发送消息，消息编号：', nMsgCode);
        this._oWebsocket.send(uint8Array);
    };
    MsgSender.prototype.onMsgReceived = function (nMsgCode, oMsgBody) {
    };
    MsgSender._oInstance = new MsgSender();
    return MsgSender;
}());
exports.default = MsgSender;

cc._RF.pop();