"use strict";
cc._RF.push(module, '8cc52LoIFNAy65yLLiKdbrw', 'Common');
// script/xiaojingling/Common.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var speed = 120;
var customScaleX = 0.7;
var Common = /** @class */ (function (_super) {
    __extends(Common, _super);
    function Common() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.rangeAttack = null;
        /**
         * 是否在移动
         */
        _this._bIsMoving = false;
        /**
         * 移动方向
         */
        _this._oMoveDirection = null;
        /**
         * 目标位置
         */
        _this._oMoveTo = null;
        /**
         *可以攻击的目标集合
         */
        _this._oAttkableObjSet = null;
        /**
         * 当前血量
         */
        _this._nCurrHp = 0;
        /**
         * 是否正在攻击
         */
        _this._bIsAttacking = false;
        return _this;
    }
    Common_1 = Common;
    // onLoad () {}
    Common.prototype.start = function () {
        this._nCurrHp = 100;
        // let oCurrHero = this.node;
        // let skeleton=oCurrHero.getComponent(sp.Skeleton);
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
        // oCurrHero.anchorY=100;
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
    };
    Common.prototype.onCollisionEnter = function (oAnotherBox, self) {
        cc.log("\u81EA\u5DF1\u7684\u540D\u5B57\uFF1A" + self.node["_name"] + ",\u5F53\u524Dnode\u540D\u5B57\uFF1A" + this.node.name + ",\u78B0\u5230\u5176\u5B83\u7269\u4F53,name=" + oAnotherBox.node.name);
        if (null != oAnotherBox) {
            var oAnotherBoxName = oAnotherBox.node.name;
            if (oAnotherBoxName.indexOf("_") != -1) {
                console.log("被碰撞的是攻击盒子");
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子
                var strings = oAnotherBoxName.split("_");
                // console.log(`oAnotherBoxName的前缀：${strings[0]}`);
                var heroName = strings[0];
                if (heroName === self.node["_name"]) {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）等于当前节点的名称，说明这个攻击盒子属于当前节点，不做操作
                    return;
                }
                else {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）不等于当前节点的名称，说明这个攻击盒子不属于当前节点
                    //那么要找到这个攻击盒子的父节点a，将当前节点加入a的碰撞set中
                    var parent = oAnotherBox.node.parent;
                    console.log("\u653B\u51FB\u76D2\u5B50\u7684\u7236\u8282\u70B9\u7684\u7EC4\u4EF6:", parent.getComponent(Common_1));
                    var fuCommon = parent.getComponent(Common_1);
                    fuCommon._oAttkableObjSet = fuCommon._oAttkableObjSet || new Set();
                    fuCommon._oAttkableObjSet.add(self.node);
                    console.log('component._oAttkableObjSet', fuCommon._oAttkableObjSet);
                    return;
                }
            }
            else {
                console.log("被碰撞的是人物");
                this._oAttkableObjSet = this._oAttkableObjSet || new Set();
                this._oAttkableObjSet.add(oAnotherBox.node);
            }
        }
        // 碰撞系统会计算出碰撞组件在世界坐标系下的相关的值，并放到 world 这个属性里面
        // var world = self.world;
        // let points = self.points;
        // console.log(`${this.node.name},points`,points);
        // for (let i = 0; i < points.length; i++) {
        //     let point = points[i];
        //     console.log(`${this.node.name},point`,point);
        // }
        // // 碰撞组件的 aabb 碰撞框
        // var aabb = world.aabb;
        // console.log('aabb',aabb);
        //
        // // 上一次计算的碰撞组件的 aabb 碰撞框
        // var preAabb = world.preAabb;
        //
        // // 碰撞框的世界矩阵
        // var t = world.transform;
        //
        // // 以下属性为圆形碰撞组件特有属性
        // var r = world.radius;
        // var p = world.position;
        //
        // // 以下属性为 矩形 和 多边形 碰撞组件特有属性
        // var ps = world.points;
    };
    Common.prototype.onCollisionExit = function (oAnotherBox, self) {
        var oAnotherBoxName = oAnotherBox.node.name;
        cc.log("\u79BB\u5F00\u5176\u5B83\u7269\u4F53,name=" + oAnotherBoxName);
        if (null != oAnotherBox) {
            if (oAnotherBoxName.indexOf("_") != -1) {
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子，那么要找到他的父节点，从父节点中移除self的节点
                console.log("被离开碰撞的是攻击盒子");
                var parent = oAnotherBox.node.parent;
                var fuCommon = parent.getComponent(Common_1);
                console.log('【离开】攻击盒子的父节点的Common', fuCommon);
                if (fuCommon._oAttkableObjSet != null) {
                    fuCommon._oAttkableObjSet.delete(self.node);
                }
            }
            else {
                console.log("被离开碰撞的是英雄的盒子");
                if (null != this._oAttkableObjSet) {
                    this._oAttkableObjSet.delete(oAnotherBox.node);
                }
            }
        }
    };
    /**
     * 节点销毁时，清空集合，避免内存谢落
     */
    Common.prototype.onDestroy = function () {
        if (null != this._oAttkableObjSet) {
            this._oAttkableObjSet.clear();
        }
    };
    Common.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
        // console.log(this.node,"oCurrHero",oCurrHero.zIndex);
    };
    Common.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        //正在攻击的话，不让他移动，避免R闪
        if (this._bIsAttacking) {
            return;
        }
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    Common.prototype.attk = function (nPosX, nPosY) {
        var _this = this;
        if (this._bIsAttacking) {
            return;
        }
        this._bIsAttacking = true;
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        var self = this;
        var components = self.node['_components'];
        console.log('components', components);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
            self._bIsAttacking = false;
        });
        if (this._oAttkableObjSet == null || this._oAttkableObjSet.size <= 0) {
            return;
        }
        this._oAttkableObjSet.forEach(function (oAttkableObj) {
            if (oAttkableObj == null) {
                return;
            }
            var name = oAttkableObj.name;
            var suffix = name.split("_")[1];
            //如果要攻击的物体为被攻击方的碰撞盒子，直接return
            if (suffix === 'RangeAttack') {
                return;
            }
            //上下位置差太多，打不到对方
            if (Math.abs(_this.node.zIndex - oAttkableObj.zIndex) > 64) {
                return;
            }
            //双方左右位置相反，并有一段距离，打不到对方
            if (((oAttkableObj.x - _this.node.x) <= -64 && _this.node.scale > 0) ||
                ((oAttkableObj.x - _this.node.x) >= 64 && _this.node.scale < 0)) {
                return;
            }
            oAttkableObj.getComponent(Common_1).subtractHp(40);
        });
    };
    /**
     * 被打减血时
     * @param nVal
     */
    Common.prototype.subtractHp = function (nVal) {
        if (nVal < 0) {
            return;
        }
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        //减血效果要延时一下，因为每个小精灵的攻击都需要1秒以上
        var self = this;
        this.schedule(function () {
            //减血时开启被打的动画
            skeleton.setAnimation(1, 'hurt', false);
            self._nCurrHp = Math.max(self._nCurrHp - nVal, 0);
            var oSubBlood = cc.find("SubBlood", self.node);
            oSubBlood = cc.instantiate(oSubBlood);
            oSubBlood.getComponent(cc.Label).string = nVal.toString();
            oSubBlood.active = true;
            // console.log("当前node的名字",self.node.name)
            self.node.addChild(oSubBlood);
            cc.tween(oSubBlood)
                .to(0.0, { scale: 3.2 })
                .to(0.2, { scale: 1.0 })
                .by(0.4, { y: 64, opacity: -128 })
                .start();
            self.schedule(function () {
                oSubBlood.destroy();
            }, 0.6);
            if (self._nCurrHp <= 0) {
                self.die();
            }
        }, 1.2, 0, 0);
    };
    Common.prototype.die = function () {
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        skeleton.schedule(function () {
            // 这里的 this 指向 component
            skeleton.setAnimation(1, 'dead', false);
        }, 1, 0, 0);
    };
    var Common_1;
    __decorate([
        property(cc.Prefab)
    ], Common.prototype, "rangeAttack", void 0);
    Common = Common_1 = __decorate([
        ccclass
    ], Common);
    return Common;
}(cc.Component));
exports.default = Common;

cc._RF.pop();