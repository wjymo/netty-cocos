"use strict";
cc._RF.push(module, '08b99EkpNdBM6ZRPy2yEff1', 'UserManager');
// script/xiaojingling/UserManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager = /** @class */ (function () {
    function UserManager() {
    }
    UserManager.putMyHeroComp = function (nUserId, oMyHeroComp) {
        UserManager._oMyHeroCompMap[nUserId] = oMyHeroComp;
    };
    UserManager.getMyHeroComp = function (nUserId) {
        return UserManager._oMyHeroCompMap[nUserId];
    };
    UserManager._oMyHeroCompMap = {};
    return UserManager;
}());
exports.default = UserManager;

cc._RF.pop();