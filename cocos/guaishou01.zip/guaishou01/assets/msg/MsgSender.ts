import MsgEncoder from './MsgEncoder';
import MsgDecoder from './MsgDecoder';

export default class MsgSender /*extends cc.Component*/ {

    private static readonly _oInstance:MsgSender =new MsgSender();

    private _oWebsocket:WebSocket=null;

    private readonly _oMsgEncoder:MsgEncoder=new MsgEncoder();
    private readonly _oMsgDecoder:MsgDecoder=new MsgDecoder();
    private constructor() {
    }

    /**
     * 获取单例对象
     */
    public static getInstance():MsgSender{
        return MsgSender._oInstance;
    }
    connect(funCallback:()=>void=null):void{
        let url='ws://192.168.1.63:6666/websocket';
        let oWebsocket=new WebSocket(url);
        oWebsocket.binaryType="arraybuffer";

        oWebsocket.onopen=():void=>{
            cc.log(`已连接服务器，url=${url}`)
            this._oWebsocket=oWebsocket;
            if(null!=funCallback){
                funCallback();
            }
        }

        oWebsocket.onclose=():void=>{
            cc.log(`服务器关闭连接`)
            this._oWebsocket=null;
        }

        oWebsocket.onmessage=(oEvent:MessageEvent):void =>{
            console.log("onmessage进入");
            if(oEvent==null||null==oEvent.data){
                return;
            }
            let uint8Array = new Uint8Array(oEvent.data);
            let nMsgCode = this._oMsgDecoder.getMsgCode(uint8Array);

            let decode = this._oMsgDecoder.decode(nMsgCode,uint8Array.slice(4));
            console.log("decode",decode);

            if (this.onMsgReceived != null) {
                this.onMsgReceived(nMsgCode,decode);
            }
        }
    }

    sendMsg(nMsgCode:number,oMsgBody:any):void{
        if(nMsgCode<0||null==oMsgBody){
            return;
        }
        if(null==this._oWebsocket){
            return;
        }
        let uint8Array = this._oMsgEncoder.encode(nMsgCode,oMsgBody);
        if(uint8Array==null){
            return;
        }
        console.log('发送消息，消息编号：',nMsgCode);
        this._oWebsocket.send(uint8Array);
    }

    onMsgReceived(nMsgCode:number,oMsgBody:any):void{

    }
}
