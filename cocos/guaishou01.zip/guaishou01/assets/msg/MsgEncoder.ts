import mod_protobuf =require("./protobuf");


export default class MsgEncoder  {
    encode(nMsgCode:number,oMsgBody:any):Uint8Array{
        if(nMsgCode<0||null==oMsgBody){
            return;
        }

        let oWriter=mod_protobuf.Writer.create();
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);

        let oByteAttay=oMsgBody.constructor.encode(oMsgBody,oWriter).finish();

        let nMsgLen=oByteAttay.byteLength=2;
        oByteAttay[0]=nMsgLen >> 8 & 0xff;
        oByteAttay[1]=nMsgLen  & 0xff;
        oByteAttay[2]=nMsgCode >> 8 & 0xff;
        oByteAttay[3]=nMsgCode  & 0xff;
        return oByteAttay;
    }

}
