import mod_GameMsgProcotol=require("./GameMsgProtocol");


export default class MsgDecoder  {
    getMsgCode(oUint8Array:Uint8Array):number{
        if(oUint8Array==null||oUint8Array.byteLength<4){
            return -1;
        }

        let nMsgCode=0;
        nMsgCode|=(oUint8Array[2]&0xFF) <<8;
        nMsgCode|=(oUint8Array[3]&0xFF) ;

        return nMsgCode;
    }

    decode(nMsgCode:number,oUint8Array:Uint8Array):any{
        if(nMsgCode<0||null==oUint8Array||oUint8Array.byteLength<=0){
            return;
        }
        let strMsgName=mod_GameMsgProcotol.msg.MsgCode[nMsgCode];
        if (strMsgName == null) {
            console.log(`nMsgCode:${nMsgCode}对应msg名称不存在`);
        }
        let oTempArray = strMsgName.split("_");
        strMsgName="";
        for (let strTemp of oTempArray) {
            strMsgName+=strTemp.charAt(0)+strTemp.substr(1).toLowerCase();
        }
        let oMsgClazz=mod_GameMsgProcotol.msg[strMsgName];
        if(null==oMsgClazz||typeof(oMsgClazz['decode'])!="function" ){
            console.log(`strMsgName:${strMsgName} 没有找到对应的类`)
            return;
        }
        return oMsgClazz.decode(oUint8Array);
    }
}
