// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
const speed=120;
cc.Class({
    extends: cc.Component,

    properties: {
        _bIsMoving:false,
        _oMoveDirection:null,
        _oMoveTo:null
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        cc.Canvas.instance.node.on(cc.Node.EventType.TOUCH_END,function (event) {
            let nMoveToX = event['getLocationX']();
            let nMoveToY = event['getLocationY']();
            let oMoveToV2=cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX,nMoveToY));

            // console.log("nMoveToX",nMoveToX)
            // console.log('oMoveToV2',oMoveToV2);
            // console.log('oMoveToV2.x',oMoveToV2.x);

            this._oMoveDirection={_nX:0,_nY:0};
            //
            let oCurrHero = cc.find('Canvas/Huolong');

            console.log('oCurrHero',oCurrHero);
            this._oMoveDirection._nX=(oCurrHero.x<=oMoveToV2.x)?1:-1;
            this._oMoveDirection._nY=(oCurrHero.y<=oMoveToV2.y)?1:-1;
            console.log('this._oMoveDirection',this._oMoveDirection);
            //
            this._oMoveTo={
                _nX:oMoveToV2.x,
                _nY:oMoveToV2.y,
            };

            let oSkeleton=oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1,'walk',true);




            // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
            // let traceEntry = skeleton.setAnimation(1,'skill01',false);
            // skeleton.setTrackCompleteListener(traceEntry,function () {
            //     skeleton.clearTrack(1);
            // })
        });
    },

    update (dt) {
        let oCurrHero = cc.find('Canvas/Huolong');
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        // if((oCurrHero.x<=this._oMoveTo._nX&&this._oMoveDirection._nX<0)||
        //     (oCurrHero.x>=this._oMoveTo._nX&&this._oMoveDirection._nX>0)){
        //     this._oMoveDirection._nX=0
        // }
        // if((oCurrHero.y<=this._oMoveTo._nY&&this._oMoveDirection._nY<0)||
        //     (oCurrHero.y>=this._oMoveTo._nY&&this._oMoveDirection._nY>0)){
        //     this._oMoveDirection._nY=0
        // }
        // if(this._oMoveDirection._nX==0&&this._oMoveDirection._nY==0){
        //     return;
        // }
        //
        // oCurrHero.x+=this._oMoveDirection._nX*120*dt;
        // oCurrHero.y+=this._oMoveDirection._nY*120*dt;
    //
    },
});
