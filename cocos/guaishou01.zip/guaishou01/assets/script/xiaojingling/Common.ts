// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;
const speed=120;
const customScaleX=0.7;
@ccclass
export default class Common extends cc.Component {

    @property(cc.Prefab)
    rangeAttack: cc.Prefab = null;
    /**
     * 是否在移动
     */
    _bIsMoving:boolean=false;

    /**
     * 移动方向
     */
    _oMoveDirection:{_nX:number,_nY:number}=null;

    /**
     * 目标位置
     */
    _oMoveTo:{_nX:number,_nY:number}=null;

    /**
     *可以攻击的目标集合
     */
    _oAttkableObjSet:Set<cc.Node>=null;

    /**
     * 当前血量
     */
    _nCurrHp:number=0;

    /**
     * 是否正在攻击
     */
    _bIsAttacking:boolean=false;

    // onLoad () {}

    start () {
        this._nCurrHp=100;
        // let oCurrHero = this.node;
        // let skeleton=oCurrHero.getComponent(sp.Skeleton);
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
        // oCurrHero.anchorY=100;
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
    }

    onCollisionEnter(oAnotherBox:cc.BoxCollider,self):void{
        cc.log(`自己的名字：${self.node["_name"]},当前node名字：${this.node.name},碰到其它物体,name=${oAnotherBox.node.name}`)
        if(null!=oAnotherBox){
            let oAnotherBoxName = oAnotherBox.node.name;
            if(oAnotherBoxName.indexOf("_")!=-1){
                console.log("被碰撞的是攻击盒子");
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子
                let strings = oAnotherBoxName.split("_");
                // console.log(`oAnotherBoxName的前缀：${strings[0]}`);
                let heroName = strings[0];
                if(heroName===self.node["_name"]){
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）等于当前节点的名称，说明这个攻击盒子属于当前节点，不做操作
                    return;
                }else {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）不等于当前节点的名称，说明这个攻击盒子不属于当前节点
                    //那么要找到这个攻击盒子的父节点a，将当前节点加入a的碰撞set中
                    let parent = oAnotherBox.node.parent;
                    console.log(`攻击盒子的父节点的组件:`,parent.getComponent(Common))
                    let fuCommon = parent.getComponent(Common);
                    fuCommon._oAttkableObjSet=fuCommon._oAttkableObjSet || new Set<cc.Node>();
                    fuCommon._oAttkableObjSet.add(self.node);
                    console.log('component._oAttkableObjSet',fuCommon._oAttkableObjSet)
                    return;
                }
            }else {
                console.log("被碰撞的是人物");
                this._oAttkableObjSet=this._oAttkableObjSet||new Set<cc.Node>();
                this._oAttkableObjSet.add(oAnotherBox.node);
            }
        }

        // 碰撞系统会计算出碰撞组件在世界坐标系下的相关的值，并放到 world 这个属性里面
        // var world = self.world;
        // let points = self.points;
        // console.log(`${this.node.name},points`,points);
        // for (let i = 0; i < points.length; i++) {
        //     let point = points[i];
        //     console.log(`${this.node.name},point`,point);
        // }
        // // 碰撞组件的 aabb 碰撞框
        // var aabb = world.aabb;
        // console.log('aabb',aabb);
        //
        // // 上一次计算的碰撞组件的 aabb 碰撞框
        // var preAabb = world.preAabb;
        //
        // // 碰撞框的世界矩阵
        // var t = world.transform;
        //
        // // 以下属性为圆形碰撞组件特有属性
        // var r = world.radius;
        // var p = world.position;
        //
        // // 以下属性为 矩形 和 多边形 碰撞组件特有属性
        // var ps = world.points;
    }
    onCollisionExit(oAnotherBox:cc.BoxCollider,self):void{
        let oAnotherBoxName = oAnotherBox.node.name;
        cc.log(`离开其它物体,name=${oAnotherBoxName}`)
        if(null!=oAnotherBox){
            if(oAnotherBoxName.indexOf("_")!=-1){
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子，那么要找到他的父节点，从父节点中移除self的节点
                console.log("被离开碰撞的是攻击盒子");
                let parent = oAnotherBox.node.parent;
                let fuCommon = parent.getComponent(Common);
                console.log('【离开】攻击盒子的父节点的Common',fuCommon)
                if(fuCommon._oAttkableObjSet!=null){
                    fuCommon._oAttkableObjSet.delete(self.node);
                }
            }else {
                console.log("被离开碰撞的是英雄的盒子");
                if(null!=this._oAttkableObjSet){
                    this._oAttkableObjSet.delete(oAnotherBox.node);
                }
            }
        }
    }

    /**
     * 节点销毁时，清空集合，避免内存谢落
     */
    onDestroy():void{
        if(null!=this._oAttkableObjSet){
            this._oAttkableObjSet.clear();
        }
    }

    update (dt) {
        if(!this._bIsMoving){
            return;
        }

        let oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if((oCurrHero.x<=this._oMoveTo._nX&&this._oMoveDirection._nX<0)||
            (oCurrHero.x>=this._oMoveTo._nX&&this._oMoveDirection._nX>0)){
            this._oMoveDirection._nX=0
        }
        if((oCurrHero.y<=this._oMoveTo._nY&&this._oMoveDirection._nY<0)||
            (oCurrHero.y>=this._oMoveTo._nY&&this._oMoveDirection._nY>0)){
            this._oMoveDirection._nY=0
        }
        if(this._oMoveDirection._nX==0&&this._oMoveDirection._nY==0){
            this._bIsMoving=false;
            let skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1,'stand',true);
            return;
        }

        oCurrHero.x+=this._oMoveDirection._nX*speed*dt;
        oCurrHero.y+=this._oMoveDirection._nY*speed*dt;

        oCurrHero.zIndex=-oCurrHero.y;
        // console.log(this.node,"oCurrHero",oCurrHero.zIndex);
    }

    moveTo(nPosX:number,nPosY:number):void{
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        //正在攻击的话，不让他移动，避免R闪
        if(this._bIsAttacking){
            return;
        }
        this._oMoveDirection={_nX:0,_nY:0};
        //
        let oCurrHero = this.node;

        console.log('oCurrHero',oCurrHero);
        this._oMoveDirection._nX=(oCurrHero.x<=nPosX)?1:-1;
        this._oMoveDirection._nY=(oCurrHero.y<=nPosY)?1:-1;
        console.log('this._oMoveDirection',this._oMoveDirection);
        //

        oCurrHero.scaleX=this._oMoveDirection._nX*customScaleX;
        this._oMoveTo={
            _nX:nPosX,
            _nY:nPosY,
        };
        if(!this._bIsMoving){
            let oSkeleton=oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1,'walk',true);
            this._bIsMoving=true;
        }
    }

    attk(nPosX:number,nPosY:number):void{
        if(this._bIsAttacking){
            return;
        }


        this._bIsAttacking=true;
        let oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }

        let skeleton=oCurrHero.getComponent(sp.Skeleton);
        let traceEntry = skeleton.setAnimation(2,'skill01',false);
        let self=this;

        let components = self.node['_components'];
        console.log('components',components);



        skeleton.setTrackCompleteListener(traceEntry,function () {
            skeleton.clearTrack(2);
            self._bIsAttacking=false;

        });
        if(this._oAttkableObjSet==null||this._oAttkableObjSet.size<=0){
            return;
        }
        this._oAttkableObjSet.forEach((oAttkableObj)=>{
           if(oAttkableObj==null){
               return;
           }
           let name = oAttkableObj.name;
           let suffix = name.split("_")[1];
           //如果要攻击的物体为被攻击方的碰撞盒子，直接return
           if(suffix==='RangeAttack'){
                return;
           }
           //上下位置差太多，打不到对方
           if(Math.abs(this.node.zIndex-oAttkableObj.zIndex)>64){
               return;
           }
           //双方左右位置相反，并有一段距离，打不到对方
           if(((oAttkableObj.x-this.node.x)<=-64&&this.node.scale>0)||
               ((oAttkableObj.x-this.node.x)>=64&&this.node.scale<0)){
               return;
           }
           oAttkableObj.getComponent(Common).subtractHp(40);
        });


    }

    /**
     * 被打减血时
     * @param nVal
     */
    subtractHp(nVal:number):void{
        if(nVal<0){
            return;
        }
        let oCurrHero = this.node;
        let skeleton=oCurrHero.getComponent(sp.Skeleton);

        //减血效果要延时一下，因为每个小精灵的攻击都需要1秒以上
        let self=this;
        this.schedule(function() {
            //减血时开启被打的动画
            skeleton.setAnimation(1,'hurt',false);

            self._nCurrHp=Math.max(self._nCurrHp-nVal,0);
            let oSubBlood = cc.find("SubBlood",self.node);
            oSubBlood=cc.instantiate(oSubBlood);
            oSubBlood.getComponent(cc.Label).string=nVal.toString();
            oSubBlood.active=true;
            // console.log("当前node的名字",self.node.name)
            self.node.addChild(oSubBlood);
            cc.tween(oSubBlood)
                .to(0.0,{scale:3.2})
                .to(0.2,{scale:1.0})
                .by(0.4,{y:64,opacity:-128})
                .start();

            self.schedule(()=>{
                oSubBlood.destroy();
            },0.6);


            if(self._nCurrHp<=0){
                self.die();
            }
        }, 1.2,0,0);
    }
    die():void{
        let oCurrHero = this.node;
        let skeleton=oCurrHero.getComponent(sp.Skeleton);
        skeleton.schedule(function() {
            // 这里的 this 指向 component
            skeleton.setAnimation(1,'dead',false);
        }, 1,0,0);
    }
}
