// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
import MyHuolong from "./MyHuolong";
import Eyu from "./Eyu";
import Common from "./Common";
import HeroFactory from "./HeroFactory";
import MsgSender from "../../msg/MsgSender";
import AllHandler from "../../resultHandler/AllHandler";
import WebUtil from "./WebUtil";
import mod_GameMsgProcotol=require("../../msg/GameMsgProtocol");


const {ccclass, property} = cc._decorator;
const heroName = "Huolong";
@ccclass
export default class FightScene extends cc.Component {

    _oMyHreo:Common=null;


    // onLoad () {}

    start() {
        let collisionManager = cc.director.getCollisionManager();
        collisionManager.enabled=true;
        collisionManager.enabledDebugDraw=true;
        collisionManager.enabledDrawBoundingBox =true;
        console.log('collisionManager',collisionManager);
        let colliders = collisionManager['_colliders'];
        console.log('colliders',colliders);

        MsgSender.getInstance().connect(()=>{
            let oAllHandler = new AllHandler();
            MsgSender.getInstance().onMsgReceived=(nMsgCode,oMsgBody)=>{
                oAllHandler.handle(nMsgCode,oMsgBody);
            }

            let userId=Number.parseInt(WebUtil.getQueryParam("userId"));
            let heroAvatar=WebUtil.getQueryParam("heroAvatar");

            MsgSender.getInstance().sendMsg(
                mod_GameMsgProcotol.msg.MsgCode.USER_ENTRY_CMD,
                mod_GameMsgProcotol.msg.UserEntryCmd.create({
                    userId:userId,
                    heroAvatar:heroAvatar
                })
            );
            MsgSender.getInstance().sendMsg(
                mod_GameMsgProcotol.msg.MsgCode.WHO_ELSE_IS_HERE_CMD,
                mod_GameMsgProcotol.msg.WhoElseIsHereCmd.create({})
            );
        });


        // HeroFactory.createAsync(heroName, (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     // heroNode.x = 300 * Math.random();
        //     // heroNode.y = 300 * Math.random();
        //     heroNode.x = -200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Xiyi", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 0;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Gui", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });

        cc.Canvas.instance.node.on(cc.Node.EventType.MOUSE_UP, (event: cc.Event) => {
            switch (event['getButton']()) {
                case 0: {
                    let nMoveToX = event['getLocationX']();
                    let nMoveToY = event['getLocationY']();
                    let oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));

                    // cc.find('Canvas/Huolong').getComponent(MyHuolong).attk(oMoveToV2.x,oMoveToV2.y);
                    if(this._oMyHreo==null){
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).attk(oMoveToV2.x, oMoveToV2.y);
                    this._oMyHreo.attk(oMoveToV2.x, oMoveToV2.y);
                    break;
                }
                case 2: {
                    let nMoveToX = event['getLocationX']();
                    let nMoveToY = event['getLocationY']();
                    let oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    if(this._oMyHreo==null){
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).moveTo(oMoveToV2.x, oMoveToV2.y);
                    this._oMyHreo.moveTo(oMoveToV2.x, oMoveToV2.y);
                    MsgSender.getInstance().sendMsg(
                        mod_GameMsgProcotol.msg.MsgCode.USER_MOVE_TO_CMD,
                        mod_GameMsgProcotol.msg.UserMoveToCmd.create({
                            // moveFromPosX:this._oMyHreo.node.x,
                            // moveFromPosY:this._oMyHreo.node.y,
                            moveToPosX:oMoveToV2.x,
                            moveToPosY:oMoveToV2.y,

                        })
                    );

                    break;
                }
            }


            // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
            // let traceEntry = skeleton.setAnimation(1,'skill01',false);
            // skeleton.setTrackCompleteListener(traceEntry,function () {
            //     skeleton.clearTrack(1);
            // })
        });
    }

    update(dt): void {

        //
    }
}
