// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

type YesContinue =()=>void;
type CustomFun=(funYesContinue:YesContinue)=>void;


@ccclass
export default class Async{

   private constructor() {
   }

    static seriez(...funArry:Array<CustomFun>):void{
       if(null==funArry||funArry.length<=0){
           return;
       }

       let  funYesContinue=():void=>{
           if(funArry.length<0){
               return;
           }
           let funCurr = funArry.shift();
            if("function"==typeof(funCurr)){
                funCurr(funYesContinue);
            }else {
                funYesContinue();
            }
       }
       funYesContinue();
    }
}
