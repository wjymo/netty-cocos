// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass,} = cc._decorator;
const speed=120;
const customScaleX=0.7;
@ccclass
export default class MyHuuolong extends cc.Component {

    _bIsMoving:boolean=false;

    _oMoveDirection:{_nX:number,_nY:number}=null;

    _oMoveTo:{_nX:number,_nY:number}=null;

    // onLoad () {}

    start () {

    }

    update (dt) {
        if(!this._bIsMoving){
            return;
        }

        let oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if((oCurrHero.x<=this._oMoveTo._nX&&this._oMoveDirection._nX<0)||
            (oCurrHero.x>=this._oMoveTo._nX&&this._oMoveDirection._nX>0)){
            this._oMoveDirection._nX=0
        }
        if((oCurrHero.y<=this._oMoveTo._nY&&this._oMoveDirection._nY<0)||
            (oCurrHero.y>=this._oMoveTo._nY&&this._oMoveDirection._nY>0)){
            this._oMoveDirection._nY=0
        }
        if(this._oMoveDirection._nX==0&&this._oMoveDirection._nY==0){
            this._bIsMoving=false;
            let skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1,'stand',true);
            return;
        }

        oCurrHero.x+=this._oMoveDirection._nX*speed*dt;
        oCurrHero.y+=this._oMoveDirection._nY*speed*dt;

        oCurrHero.zIndex=-oCurrHero.y;
    }

    moveTo(nPosX:number,nPosY:number):void{
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);

        this._oMoveDirection={_nX:0,_nY:0};
        //
        let oCurrHero = this.node;

        console.log('oCurrHero',oCurrHero);
        this._oMoveDirection._nX=(oCurrHero.x<=nPosX)?1:-1;
        this._oMoveDirection._nY=(oCurrHero.y<=nPosY)?1:-1;
        console.log('this._oMoveDirection',this._oMoveDirection);
        //

        oCurrHero.scaleX=this._oMoveDirection._nX*customScaleX;
        this._oMoveTo={
            _nX:nPosX,
            _nY:nPosY,
        };
        if(!this._bIsMoving){
            let oSkeleton=oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1,'walk',true);
            this._bIsMoving=true;
        }
    }

    attk(nPosX:number,nPosY:number):void{
        let oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }

        let skeleton=oCurrHero.getComponent(sp.Skeleton);
        let traceEntry = skeleton.setAnimation(2,'skill01',false);
        skeleton.setTrackCompleteListener(traceEntry,function () {
            skeleton.clearTrack(2);
        });
    }
    die():void{

    }
}
