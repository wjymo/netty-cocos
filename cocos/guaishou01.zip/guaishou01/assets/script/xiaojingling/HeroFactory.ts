// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import Async from "./Async"

const {ccclass, property} = cc._decorator;
const BUNDLE_NAME="prefab";
@ccclass
export default class HeroFacyor extends cc.Component {


    // onLoad () {}

    start () {

    }

    static createAsync(heroName:string,funCallback:(heroNode:cc.Node)=>void):void{
        if (heroName == null) {
            return;
        }

        let loadBundle = cc.assetManager.getBundle(BUNDLE_NAME);
        let loadPrefab=null;
        Async.seriez(
            (funYesContinue)=>{
                if(loadBundle!=null){
                    funYesContinue();
                    return;
                }
                cc.assetManager.loadBundle(BUNDLE_NAME,(error:Error,bundle:cc.AssetManager.Bundle)=>{
                    if(error!=null){
                        cc.error(error);
                        return;
                    }
                    loadBundle=bundle;
                    funYesContinue();
                });
            },
            (funYesContinue)=>{
                loadPrefab = loadBundle.get(heroName,cc.Prefab);
                if(null!=loadPrefab){
                    funYesContinue();
                    return;
                }
                loadBundle.load(heroName,cc.Prefab,(error:Error,prefab:cc.Prefab)=>{
                    if(error!=null){
                        cc.error(`heroName:${heroName}找不到对应预制体`,error);
                        return;
                    }
                    loadPrefab=prefab;
                    funYesContinue();
                });
            },
            (funYesContinue)=>{
                let mainBundle = cc.assetManager.getBundle("main");
                mainBundle.preloadDir(`spine/xiaojingling/${heroName}`,(error:Error)=>{
                    if(error!=null){
                        cc.error(error);
                        return;
                    }
                    funYesContinue();
                });
            },
            (funYesContinue)=>{
                if(loadPrefab==null){
                    cc.error(`loadPrefab为空，名字：${heroName}`)
                    return;
                }
                let heroNode = cc.instantiate(loadPrefab);
                funCallback(heroNode);
            }
        )







        // if(loadBundle==null){
        //     cc.assetManager.loadBundle(BUNDLE_NAME,(error:Error,bundle:cc.AssetManager.Bundle)=>{
        //         if(error!=null){
        //             cc.error(error);
        //             return;
        //         }
        //         let loadPrefab = bundle.get(heroName,cc.Prefab);
        //         if(null==loadPrefab){
        //             bundle.load(heroName,cc.Prefab,(error:Error,prefab:cc.Prefab)=>{
        //                 if(error!=null){
        //                     cc.error(error);
        //                     return;
        //                 }
        //                 let mainBundle = cc.assetManager.getBundle("main");
        //                 mainBundle.preloadDir(`spine/${heroName}`,(error:Error)=>{
        //                     if(error!=null){
        //                         cc.error(error);
        //                         return;
        //                     }
        //                     let heroNode = cc.instantiate(prefab);
        //                     funCallback(heroNode)
        //                 })
        //             });
        //         }
        //     });
        // }
    }

    // update (dt) {}
}
