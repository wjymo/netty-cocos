import Common from "./Common";

export default  class UserManager {
    private static readonly _oMyHeroCompMap:{[nUserId:number]:Common}={};

    private constructor() {
    }

    static putMyHeroComp(nUserId:number,oMyHeroComp:Common):void{
        UserManager._oMyHeroCompMap[nUserId]=oMyHeroComp;
    }

    static getMyHeroComp(nUserId:number):Common{
        return UserManager._oMyHeroCompMap[nUserId];
    }
}
