import mod_GameMsgProtocol = require('../msg/GameMsgProtocol');
import UserManager from "../script/xiaojingling/UserManager";

export default class UserMoveToResultHandler  {
    handle(oResult:mod_GameMsgProtocol.msg.UserMoveToResult):void{
        if (oResult == null) {
            return;
        }
        let userId = oResult.moveUserId;

        let oHreoComp = UserManager.getMyHeroComp(userId);
        // let oHreoComp =find();


        oHreoComp.moveTo(oResult.moveToPosX,oResult.moveToPosY)
    }

}
