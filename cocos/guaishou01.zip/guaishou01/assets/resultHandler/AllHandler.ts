import mod_GameMsgProtocol = require('../msg/GameMsgProtocol');
import UserEntryResultHandler from './UserEntryResultHandler';
import WhoElseIsHereHandler from "./WhoElseIsHereHandler";
import UserQuitResultHandler from "./UserQuitResultHandler";
import UserMoveToResultHandler from "./UserMoveToResultHandler";

export default class AllHandler  {
    private readonly _oHandlerMap:{[nMsgCode:number]:any}={};
    constructor() {
        let oMsgCode=mod_GameMsgProtocol.msg.MsgCode;
        this._oHandlerMap[oMsgCode.USER_ENTRY_RESULT]=new UserEntryResultHandler();
        this._oHandlerMap[oMsgCode.WHO_ELSE_IS_HERE_RESULT]=new WhoElseIsHereHandler();
        this._oHandlerMap[oMsgCode.USER_MOVE_TO_RESULT]=new UserMoveToResultHandler();
        this._oHandlerMap[oMsgCode.USER_QUIT_RESULT]=new UserQuitResultHandler();

    }
    handle(nMsgCode:number,oMsgBody:any):void{
        if(nMsgCode<0||oMsgBody==null){
            return;
        }
        let oHandler = this._oHandlerMap[nMsgCode];
        if (oHandler == null) {
            cc.error(`nMsgCode:${nMsgCode}找不到对应handler`);
            return;
        }

        oHandler.handle(oMsgBody);
    }

}
