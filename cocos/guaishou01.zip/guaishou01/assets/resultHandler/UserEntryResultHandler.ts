import mod_GameMsgProtocol = require('../msg/GameMsgProtocol');
import HeroFactory from "../script/xiaojingling/HeroFactory";
import WebUtil from "../script/xiaojingling/WebUtil";
import Common from "../script/xiaojingling/Common";
import FightScene from "../script/xiaojingling/FightScene";
import UserManager from "../script/xiaojingling/UserManager";

export default class UserEntryResultHandler  {
    handle(oResult:mod_GameMsgProtocol.msg.UserEntryResult):void{
        cc.log(`用户：${oResult.heroAvatar},id=${oResult.userId}入场`);
        HeroFactory.createAsync(oResult.heroAvatar, (heroNode) => {
            if(heroNode==null){
                return;
            }

            let nMyUserId=Number.parseInt(WebUtil.getQueryParam("userId"));
            //oResult是后台传的英雄对象，nMyUserId是url地址里写的用户id，oMyHeroComp是通过后台传入的oResult的名称加载出来的预制体
            let oMyHeroComp = heroNode.getComponent(Common);
            if(oResult.userId==nMyUserId){
                cc.Canvas.instance.node.getComponent(FightScene)._oMyHreo=oMyHeroComp;
            }


            cc.Canvas.instance.node.addChild(heroNode);
            // heroNode.x = 300 * Math.random();
            // heroNode.y = 300 * Math.random();
            // heroNode.x = -200;
            // heroNode.y = 0;
            // heroNode.active = true;
            let skeleton = heroNode.getComponent(sp.Skeleton);
            skeleton.setAnimation(1, 'stand', true);
            UserManager.putMyHeroComp(oResult.userId,oMyHeroComp);
        });
    }

}
