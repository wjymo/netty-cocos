import mod_GameMsgProtocol = require('../msg/GameMsgProtocol');
import HeroFactory from "../script/xiaojingling/HeroFactory";
import WebUtil from "../script/xiaojingling/WebUtil";
import Common from "../script/xiaojingling/Common";
import FightScene from "../script/xiaojingling/FightScene";
import UserManager from "../script/xiaojingling/UserManager";

export default class WhoElseIsHereHandler  {
    handle(oResult:mod_GameMsgProtocol.msg.WhoElseIsHereResult):void{
        let oUserInfoArray = oResult.userInfo;
        for (let oUserInfo of oUserInfoArray) {
            if (oUserInfo == null) {
                continue;
            }
            let heroAvatar = oUserInfo.heroAvatar;
            HeroFactory.createAsync(heroAvatar, (heroNode) => {
                if(heroNode==null){
                    return;
                }

                cc.Canvas.instance.node.addChild(heroNode);
                // heroNode.x = 300 * Math.random();
                // heroNode.y = 300 * Math.random();
                // heroNode.x = -200;
                // heroNode.y = 0;
                // heroNode.active = true;
                let skeleton = heroNode.getComponent(sp.Skeleton);
                skeleton.setAnimation(1, 'stand', true);
                UserManager.putMyHeroComp(oUserInfo.userId,heroNode.getComponent(Common));
            });
        }
    }

}
