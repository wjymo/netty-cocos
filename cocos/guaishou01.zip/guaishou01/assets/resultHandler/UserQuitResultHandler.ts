import mod_GameMsgProtocol = require('../msg/GameMsgProtocol');
import UserManager from "../script/xiaojingling/UserManager";


export default class UserQuitResultHandler  {
    handle(oResult:mod_GameMsgProtocol.msg.UserQuitResult):void{
        cc.log(`用户：${oResult.quitUserId}离场`);
        let myHeroComp = UserManager.getMyHeroComp(oResult.quitUserId);

    }

}
