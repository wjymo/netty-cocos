
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/msg/GameMsgProtocol');
require('./assets/msg/MsgDecoder');
require('./assets/msg/MsgEncoder');
require('./assets/msg/MsgSender');
require('./assets/msg/protobuf');
require('./assets/resultHandler/AllHandler');
require('./assets/resultHandler/UserEntryResultHandler');
require('./assets/resultHandler/UserMoveToResultHandler');
require('./assets/resultHandler/UserQuitResultHandler');
require('./assets/resultHandler/WhoElseIsHereHandler');
require('./assets/script/x');
require('./assets/script/xiaojingling/Async');
require('./assets/script/xiaojingling/Common');
require('./assets/script/xiaojingling/Eyu');
require('./assets/script/xiaojingling/FightScene');
require('./assets/script/xiaojingling/HeroFactory');
require('./assets/script/xiaojingling/Huolong');
require('./assets/script/xiaojingling/MyHuolong');
require('./assets/script/xiaojingling/UserManager');
require('./assets/script/xiaojingling/WebUtil');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();