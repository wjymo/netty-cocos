
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/msg/GameMsgProtocol');
require('./assets/msg/MsgDecoder');
require('./assets/msg/MsgEncoder');
require('./assets/msg/MsgSender');
require('./assets/msg/protobuf');
require('./assets/resultHandler/AllHandler');
require('./assets/resultHandler/UserEntryResultHandler');
require('./assets/resultHandler/UserMoveToResultHandler');
require('./assets/resultHandler/UserQuitResultHandler');
require('./assets/resultHandler/WhoElseIsHereHandler');
require('./assets/script/x');
require('./assets/script/xiaojingling/Async');
require('./assets/script/xiaojingling/Common');
require('./assets/script/xiaojingling/Eyu');
require('./assets/script/xiaojingling/FightScene');
require('./assets/script/xiaojingling/HeroFactory');
require('./assets/script/xiaojingling/Huolong');
require('./assets/script/xiaojingling/MyHuolong');
require('./assets/script/xiaojingling/UserManager');
require('./assets/script/xiaojingling/WebUtil');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/FightScene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b959c5jWaxClrV2I6mL83rC', 'FightScene');
// script/xiaojingling/FightScene.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MsgSender_1 = require("../../msg/MsgSender");
var AllHandler_1 = require("../../resultHandler/AllHandler");
var WebUtil_1 = require("./WebUtil");
var mod_GameMsgProcotol = require("../../msg/GameMsgProtocol");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var heroName = "Huolong";
var FightScene = /** @class */ (function (_super) {
    __extends(FightScene, _super);
    function FightScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._oMyHreo = null;
        return _this;
    }
    // onLoad () {}
    FightScene.prototype.start = function () {
        var _this = this;
        var collisionManager = cc.director.getCollisionManager();
        collisionManager.enabled = true;
        collisionManager.enabledDebugDraw = true;
        collisionManager.enabledDrawBoundingBox = true;
        console.log('collisionManager', collisionManager);
        var colliders = collisionManager['_colliders'];
        console.log('colliders', colliders);
        MsgSender_1.default.getInstance().connect(function () {
            var oAllHandler = new AllHandler_1.default();
            MsgSender_1.default.getInstance().onMsgReceived = function (nMsgCode, oMsgBody) {
                oAllHandler.handle(nMsgCode, oMsgBody);
            };
            var userId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            var heroAvatar = WebUtil_1.default.getQueryParam("heroAvatar");
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_ENTRY_CMD, mod_GameMsgProcotol.msg.UserEntryCmd.create({
                userId: userId,
                heroAvatar: heroAvatar
            }));
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.WHO_ELSE_IS_HERE_CMD, mod_GameMsgProcotol.msg.WhoElseIsHereCmd.create({}));
        });
        // HeroFactory.createAsync(heroName, (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     // heroNode.x = 300 * Math.random();
        //     // heroNode.y = 300 * Math.random();
        //     heroNode.x = -200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Xiyi", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 0;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Gui", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        cc.Canvas.instance.node.on(cc.Node.EventType.MOUSE_UP, function (event) {
            switch (event['getButton']()) {
                case 0: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    // cc.find('Canvas/Huolong').getComponent(MyHuolong).attk(oMoveToV2.x,oMoveToV2.y);
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).attk(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.attk(oMoveToV2.x, oMoveToV2.y);
                    break;
                }
                case 2: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).moveTo(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.moveTo(oMoveToV2.x, oMoveToV2.y);
                    MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_MOVE_TO_CMD, mod_GameMsgProcotol.msg.UserMoveToCmd.create({
                        // moveFromPosX:this._oMyHreo.node.x,
                        // moveFromPosY:this._oMyHreo.node.y,
                        moveToPosX: oMoveToV2.x,
                        moveToPosY: oMoveToV2.y,
                    }));
                    break;
                }
            }
            // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
            // let traceEntry = skeleton.setAnimation(1,'skill01',false);
            // skeleton.setTrackCompleteListener(traceEntry,function () {
            //     skeleton.clearTrack(1);
            // })
        });
    };
    FightScene.prototype.update = function (dt) {
        //
    };
    FightScene = __decorate([
        ccclass
    ], FightScene);
    return FightScene;
}(cc.Component));
exports.default = FightScene;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEZpZ2h0U2NlbmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVUEsaURBQTRDO0FBQzVDLDZEQUF3RDtBQUN4RCxxQ0FBZ0M7QUFDaEMsK0RBQWdFO0FBRzFELElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBQzFDLElBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUUzQjtJQUF3Qyw4QkFBWTtJQUFwRDtRQUFBLHFFQXNIQztRQXBIRyxjQUFRLEdBQVEsSUFBSSxDQUFDOztJQW9IekIsQ0FBQztJQWpIRyxlQUFlO0lBRWYsMEJBQUssR0FBTDtRQUFBLGlCQXlHQztRQXhHRyxJQUFJLGdCQUFnQixHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUN6RCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDO1FBQzlCLGdCQUFnQixDQUFDLGdCQUFnQixHQUFDLElBQUksQ0FBQztRQUN2QyxnQkFBZ0IsQ0FBQyxzQkFBc0IsR0FBRSxJQUFJLENBQUM7UUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2pELElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRW5DLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQzVCLElBQUksV0FBVyxHQUFHLElBQUksb0JBQVUsRUFBRSxDQUFDO1lBQ25DLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsYUFBYSxHQUFDLFVBQUMsUUFBUSxFQUFDLFFBQVE7Z0JBQ3BELFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQTtZQUVELElBQUksTUFBTSxHQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQU8sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUM1RCxJQUFJLFVBQVUsR0FBQyxpQkFBTyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVuRCxtQkFBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FDM0IsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQzlDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO2dCQUN4QyxNQUFNLEVBQUMsTUFBTTtnQkFDYixVQUFVLEVBQUMsVUFBVTthQUN4QixDQUFDLENBQ0wsQ0FBQztZQUNGLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUMzQixtQkFBbUIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUNwRCxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUN0RCxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7UUFHSCxvREFBb0Q7UUFDcEQsa0RBQWtEO1FBQ2xELDJDQUEyQztRQUMzQywyQ0FBMkM7UUFDM0MseUJBQXlCO1FBQ3pCLHNCQUFzQjtRQUN0Qiw4QkFBOEI7UUFDOUIseURBQXlEO1FBQ3pELCtDQUErQztRQUMvQyxNQUFNO1FBQ04sa0RBQWtEO1FBQ2xELGtEQUFrRDtRQUNsRCxzQkFBc0I7UUFDdEIsc0JBQXNCO1FBQ3RCLDhCQUE4QjtRQUM5Qix5REFBeUQ7UUFDekQsK0NBQStDO1FBQy9DLE1BQU07UUFDTixpREFBaUQ7UUFDakQsa0RBQWtEO1FBQ2xELHdCQUF3QjtRQUN4QixzQkFBc0I7UUFDdEIsOEJBQThCO1FBQzlCLHlEQUF5RDtRQUN6RCwrQ0FBK0M7UUFDL0MsTUFBTTtRQUVOLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFVBQUMsS0FBZTtZQUNuRSxRQUFRLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFO2dCQUMxQixLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNKLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO29CQUN2QyxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBRXhGLG1GQUFtRjtvQkFDbkYsSUFBRyxLQUFJLENBQUMsUUFBUSxJQUFFLElBQUksRUFBQzt3QkFDbkIsT0FBTztxQkFDVjtvQkFDRCxxRkFBcUY7b0JBQ3JGLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM3QyxNQUFNO2lCQUNUO2dCQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ0osSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7b0JBQ3ZDLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO29CQUN2QyxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFDeEYsSUFBRyxLQUFJLENBQUMsUUFBUSxJQUFFLElBQUksRUFBQzt3QkFDbkIsT0FBTztxQkFDVjtvQkFDRCx1RkFBdUY7b0JBQ3ZGLEtBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvQyxtQkFBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FDM0IsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFDaEQsbUJBQW1CLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7d0JBQ3pDLHFDQUFxQzt3QkFDckMscUNBQXFDO3dCQUNyQyxVQUFVLEVBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ3RCLFVBQVUsRUFBQyxTQUFTLENBQUMsQ0FBQztxQkFFekIsQ0FBQyxDQUNMLENBQUM7b0JBRUYsTUFBTTtpQkFDVDthQUNKO1lBR0Qsb0VBQW9FO1lBQ3BFLDZEQUE2RDtZQUM3RCw2REFBNkQ7WUFDN0QsOEJBQThCO1lBQzlCLEtBQUs7UUFDVCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sRUFBRTtRQUVMLEVBQUU7SUFDTixDQUFDO0lBckhnQixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBc0g5QjtJQUFELGlCQUFDO0NBdEhELEFBc0hDLENBdEh1QyxFQUFFLENBQUMsU0FBUyxHQXNIbkQ7a0JBdEhvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5pbXBvcnQgTXlIdW9sb25nIGZyb20gXCIuL015SHVvbG9uZ1wiO1xyXG5pbXBvcnQgRXl1IGZyb20gXCIuL0V5dVwiO1xyXG5pbXBvcnQgQ29tbW9uIGZyb20gXCIuL0NvbW1vblwiO1xyXG5pbXBvcnQgSGVyb0ZhY3RvcnkgZnJvbSBcIi4vSGVyb0ZhY3RvcnlcIjtcclxuaW1wb3J0IE1zZ1NlbmRlciBmcm9tIFwiLi4vLi4vbXNnL01zZ1NlbmRlclwiO1xyXG5pbXBvcnQgQWxsSGFuZGxlciBmcm9tIFwiLi4vLi4vcmVzdWx0SGFuZGxlci9BbGxIYW5kbGVyXCI7XHJcbmltcG9ydCBXZWJVdGlsIGZyb20gXCIuL1dlYlV0aWxcIjtcclxuaW1wb3J0IG1vZF9HYW1lTXNnUHJvY290b2w9cmVxdWlyZShcIi4uLy4uL21zZy9HYW1lTXNnUHJvdG9jb2xcIik7XHJcblxyXG5cclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IGhlcm9OYW1lID0gXCJIdW9sb25nXCI7XHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEZpZ2h0U2NlbmUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIF9vTXlIcmVvOkNvbW1vbj1udWxsO1xyXG5cclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge31cclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICBsZXQgY29sbGlzaW9uTWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWQ9dHJ1ZTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXc9dHJ1ZTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWREcmF3Qm91bmRpbmdCb3ggPXRydWU7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbGxpc2lvbk1hbmFnZXInLGNvbGxpc2lvbk1hbmFnZXIpO1xyXG4gICAgICAgIGxldCBjb2xsaWRlcnMgPSBjb2xsaXNpb25NYW5hZ2VyWydfY29sbGlkZXJzJ107XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbGxpZGVycycsY29sbGlkZXJzKTtcclxuXHJcbiAgICAgICAgTXNnU2VuZGVyLmdldEluc3RhbmNlKCkuY29ubmVjdCgoKT0+e1xyXG4gICAgICAgICAgICBsZXQgb0FsbEhhbmRsZXIgPSBuZXcgQWxsSGFuZGxlcigpO1xyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5vbk1zZ1JlY2VpdmVkPShuTXNnQ29kZSxvTXNnQm9keSk9PntcclxuICAgICAgICAgICAgICAgIG9BbGxIYW5kbGVyLmhhbmRsZShuTXNnQ29kZSxvTXNnQm9keSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCB1c2VySWQ9TnVtYmVyLnBhcnNlSW50KFdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcInVzZXJJZFwiKSk7XHJcbiAgICAgICAgICAgIGxldCBoZXJvQXZhdGFyPVdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcImhlcm9BdmF0YXJcIik7XHJcblxyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgbW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZS5VU0VSX0VOVFJZX0NNRCxcclxuICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLlVzZXJFbnRyeUNtZC5jcmVhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJJZDp1c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVyb0F2YXRhcjpoZXJvQXZhdGFyXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgbW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZS5XSE9fRUxTRV9JU19IRVJFX0NNRCxcclxuICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLldob0Vsc2VJc0hlcmVDbWQuY3JlYXRlKHt9KVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgLy8gSGVyb0ZhY3RvcnkuY3JlYXRlQXN5bmMoaGVyb05hbWUsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIC8vIGhlcm9Ob2RlLnggPSAzMDAgKiBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIC8vICAgICAvLyBoZXJvTm9kZS55ID0gMzAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAvLyAgICAgaGVyb05vZGUueCA9IC0yMDA7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnkgPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICBsZXQgc2tlbGV0b24gPSBoZXJvTm9kZS5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vICAgICBza2VsZXRvbi5zZXRBbmltYXRpb24oMSwgJ3N0YW5kJywgdHJ1ZSk7XHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgLy8gSGVyb0ZhY3RvcnkuY3JlYXRlQXN5bmMoXCJYaXlpXCIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnggPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS55ID0gMDtcclxuICAgICAgICAvLyAgICAgaGVyb05vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgbGV0IHNrZWxldG9uID0gaGVyb05vZGUuZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAvLyAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsICdzdGFuZCcsIHRydWUpO1xyXG4gICAgICAgIC8vIH0pO1xyXG4gICAgICAgIC8vIEhlcm9GYWN0b3J5LmNyZWF0ZUFzeW5jKFwiR3VpXCIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnggPSAyMDA7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnkgPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICBsZXQgc2tlbGV0b24gPSBoZXJvTm9kZS5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vICAgICBza2VsZXRvbi5zZXRBbmltYXRpb24oMSwgJ3N0YW5kJywgdHJ1ZSk7XHJcbiAgICAgICAgLy8gfSk7XHJcblxyXG4gICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQLCAoZXZlbnQ6IGNjLkV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoZXZlbnRbJ2dldEJ1dHRvbiddKCkpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDoge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuTW92ZVRvWCA9IGV2ZW50WydnZXRMb2NhdGlvblgnXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuTW92ZVRvWSA9IGV2ZW50WydnZXRMb2NhdGlvblknXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBvTW92ZVRvVjIgPSBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihjYy52MihuTW92ZVRvWCwgbk1vdmVUb1kpKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2MuZmluZCgnQ2FudmFzL0h1b2xvbmcnKS5nZXRDb21wb25lbnQoTXlIdW9sb25nKS5hdHRrKG9Nb3ZlVG9WMi54LG9Nb3ZlVG9WMi55KTtcclxuICAgICAgICAgICAgICAgICAgICBpZih0aGlzLl9vTXlIcmVvPT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBjYy5maW5kKGBDYW52YXMvJHtoZXJvTmFtZX1gKS5nZXRDb21wb25lbnQoQ29tbW9uKS5hdHRrKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb015SHJlby5hdHRrKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbk1vdmVUb1ggPSBldmVudFsnZ2V0TG9jYXRpb25YJ10oKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbk1vdmVUb1kgPSBldmVudFsnZ2V0TG9jYXRpb25ZJ10oKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgb01vdmVUb1YyID0gY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIoY2MudjIobk1vdmVUb1gsIG5Nb3ZlVG9ZKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYodGhpcy5fb015SHJlbz09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2MuZmluZChgQ2FudmFzLyR7aGVyb05hbWV9YCkuZ2V0Q29tcG9uZW50KENvbW1vbikubW92ZVRvKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb015SHJlby5tb3ZlVG8ob01vdmVUb1YyLngsIG9Nb3ZlVG9WMi55KTtcclxuICAgICAgICAgICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RfR2FtZU1zZ1Byb2NvdG9sLm1zZy5Nc2dDb2RlLlVTRVJfTU9WRV9UT19DTUQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLlVzZXJNb3ZlVG9DbWQuY3JlYXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1vdmVGcm9tUG9zWDp0aGlzLl9vTXlIcmVvLm5vZGUueCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1vdmVGcm9tUG9zWTp0aGlzLl9vTXlIcmVvLm5vZGUueSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vdmVUb1Bvc1g6b01vdmVUb1YyLngsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb3ZlVG9Qb3NZOm9Nb3ZlVG9WMi55LFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGxldCBza2VsZXRvbj1jYy5maW5kKCdDYW52YXMvSHVvbG9uZycpLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIC8vIGxldCB0cmFjZUVudHJ5ID0gc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3NraWxsMDEnLGZhbHNlKTtcclxuICAgICAgICAgICAgLy8gc2tlbGV0b24uc2V0VHJhY2tDb21wbGV0ZUxpc3RlbmVyKHRyYWNlRW50cnksZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvLyAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgLy8gfSlcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUoZHQpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgLy9cclxuICAgIH1cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Eyu.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '74180Tk7FlDB4Y11ms3KYN6', 'Eyu');
// script/xiaojingling/Eyu.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
var speed = 120;
var customScaleX = 0.8;
var MyHuuolong = /** @class */ (function (_super) {
    __extends(MyHuuolong, _super);
    function MyHuuolong() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._bIsMoving = false;
        _this._oMoveDirection = null;
        _this._oMoveTo = null;
        return _this;
    }
    // onLoad () {}
    MyHuuolong.prototype.start = function () {
    };
    MyHuuolong.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
    };
    MyHuuolong.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    MyHuuolong.prototype.attk = function (nPosX, nPosY) {
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
        });
    };
    MyHuuolong.prototype.die = function () {
    };
    MyHuuolong = __decorate([
        ccclass
    ], MyHuuolong);
    return MyHuuolong;
}(cc.Component));
exports.default = MyHuuolong;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEV5dS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUUzRSxJQUFBLE9BQU8sR0FBSyxFQUFFLENBQUMsVUFBVSxRQUFsQixDQUFtQjtBQUNqQyxJQUFNLEtBQUssR0FBQyxHQUFHLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUMsR0FBRyxDQUFDO0FBRXZCO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBc0ZDO1FBcEZHLGdCQUFVLEdBQVMsS0FBSyxDQUFDO1FBRXpCLHFCQUFlLEdBQXlCLElBQUksQ0FBQztRQUU3QyxjQUFRLEdBQXlCLElBQUksQ0FBQzs7SUFnRjFDLENBQUM7SUE5RUcsZUFBZTtJQUVmLDBCQUFLLEdBQUw7SUFFQSxDQUFDO0lBRUQsMkJBQU0sR0FBTixVQUFRLEVBQUU7UUFDTixJQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztZQUNoQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHNDQUFzQztRQUN0QywyREFBMkQ7UUFDM0QsSUFBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQztZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzdELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQTtTQUM3QjtRQUNELElBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFFLENBQUMsRUFBQztZQUN4RCxJQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN0QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLEtBQUssR0FBQyxFQUFFLENBQUM7UUFDL0MsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDO1FBRS9DLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sS0FBWSxFQUFDLEtBQVk7UUFDNUIsbUNBQW1DO1FBQ25DLHNDQUFzQztRQUN0QywwQ0FBMEM7UUFFMUMsSUFBSSxDQUFDLGVBQWUsR0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQ25DLEVBQUU7UUFDRixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRTFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekQsRUFBRTtRQUVGLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUM7WUFDVixHQUFHLEVBQUMsS0FBSztZQUNULEdBQUcsRUFBQyxLQUFLO1NBQ1osQ0FBQztRQUNGLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCx5QkFBSSxHQUFKLFVBQUssS0FBWSxFQUFDLEtBQVk7UUFDMUIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQix5QkFBeUI7UUFDekIsNENBQTRDO1FBQzVDLElBQUk7UUFFSixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxTQUFTLEVBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFVBQVUsRUFBQztZQUN6QyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELHdCQUFHLEdBQUg7SUFFQSxDQUFDO0lBckZnQixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBc0Y5QjtJQUFELGlCQUFDO0NBdEZELEFBc0ZDLENBdEZ1QyxFQUFFLENBQUMsU0FBUyxHQXNGbkQ7a0JBdEZvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY29uc3Qge2NjY2xhc3MsfSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IHNwZWVkPTEyMDtcclxuY29uc3QgY3VzdG9tU2NhbGVYPTAuODtcclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlIdXVvbG9uZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgX2JJc01vdmluZzpib29sZWFuPWZhbHNlO1xyXG5cclxuICAgIF9vTW92ZURpcmVjdGlvbjp7X25YOm51bWJlcixfblk6bnVtYmVyfT1udWxsO1xyXG5cclxuICAgIF9vTW92ZVRvOntfblg6bnVtYmVyLF9uWTpudW1iZXJ9PW51bGw7XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgaWYoIXRoaXMuX2JJc01vdmluZyl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVybycsb0N1cnJIZXJvKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fb01vdmVEaXJlY3Rpb24nLHRoaXMuX29Nb3ZlRGlyZWN0aW9uKVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueDw9dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWDwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueD49dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueTw9dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWTwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueT49dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD09MCYmdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPWZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgc2tlbGV0b24gPSBvQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3N0YW5kJyx0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLngrPXRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWCpzcGVlZCpkdDtcclxuICAgICAgICBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKnNwZWVkKmR0O1xyXG5cclxuICAgICAgICBvQ3Vyckhlcm8uekluZGV4PS1vQ3Vyckhlcm8ueTtcclxuICAgIH1cclxuXHJcbiAgICBtb3ZlVG8oblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5Nb3ZlVG9YXCIsbk1vdmVUb1gpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb01vdmVUb1YyLngnLG9Nb3ZlVG9WMi54KTtcclxuXHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb249e19uWDowLF9uWTowfTtcclxuICAgICAgICAvL1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25YPShvQ3Vyckhlcm8ueDw9blBvc1gpPzE6LTE7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPShvQ3Vyckhlcm8ueTw9blBvc1kpPzE6LTE7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbik7XHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLnNjYWxlWD10aGlzLl9vTW92ZURpcmVjdGlvbi5fblgqY3VzdG9tU2NhbGVYO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlVG89e1xyXG4gICAgICAgICAgICBfblg6blBvc1gsXHJcbiAgICAgICAgICAgIF9uWTpuUG9zWSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmKCF0aGlzLl9iSXNNb3Zpbmcpe1xyXG4gICAgICAgICAgICBsZXQgb1NrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgICAgICBvU2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3dhbGsnLHRydWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9iSXNNb3Zpbmc9dHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXR0ayhuUG9zWDpudW1iZXIsblBvc1k6bnVtYmVyKTp2b2lke1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gaWYoblBvc1g8b0N1cnJIZXJvLngpe1xyXG4gICAgICAgIC8vICAgICBvQ3Vyckhlcm8uc2NhbGVYPW9DdXJySGVyby5zY2FsZVgqLTE7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICBsZXQgc2tlbGV0b249b0N1cnJIZXJvLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgbGV0IHRyYWNlRW50cnkgPSBza2VsZXRvbi5zZXRBbmltYXRpb24oMiwnc2tpbGwwMScsZmFsc2UpO1xyXG4gICAgICAgIHNrZWxldG9uLnNldFRyYWNrQ29tcGxldGVMaXN0ZW5lcih0cmFjZUVudHJ5LGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygyKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIGRpZSgpOnZvaWR7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Huolong.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a833cHQ1KFAL5FaYlGkgFoC', 'Huolong');
// script/xiaojingling/Huolong.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var speed = 120;
cc.Class({
  "extends": cc.Component,
  properties: {
    _bIsMoving: false,
    _oMoveDirection: null,
    _oMoveTo: null
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    cc.Canvas.instance.node.on(cc.Node.EventType.TOUCH_END, function (event) {
      var nMoveToX = event['getLocationX']();
      var nMoveToY = event['getLocationY']();
      var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY)); // console.log("nMoveToX",nMoveToX)
      // console.log('oMoveToV2',oMoveToV2);
      // console.log('oMoveToV2.x',oMoveToV2.x);

      this._oMoveDirection = {
        _nX: 0,
        _nY: 0
      }; //

      var oCurrHero = cc.find('Canvas/Huolong');
      console.log('oCurrHero', oCurrHero);
      this._oMoveDirection._nX = oCurrHero.x <= oMoveToV2.x ? 1 : -1;
      this._oMoveDirection._nY = oCurrHero.y <= oMoveToV2.y ? 1 : -1;
      console.log('this._oMoveDirection', this._oMoveDirection); //

      this._oMoveTo = {
        _nX: oMoveToV2.x,
        _nY: oMoveToV2.y
      };
      var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
      oSkeleton.setAnimation(1, 'walk', true); // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
      // let traceEntry = skeleton.setAnimation(1,'skill01',false);
      // skeleton.setTrackCompleteListener(traceEntry,function () {
      //     skeleton.clearTrack(1);
      // })
    });
  },
  update: function update(dt) {
    var oCurrHero = cc.find('Canvas/Huolong'); // console.log('oCurrHero',oCurrHero);
    // console.log('this._oMoveDirection',this._oMoveDirection)
    // if((oCurrHero.x<=this._oMoveTo._nX&&this._oMoveDirection._nX<0)||
    //     (oCurrHero.x>=this._oMoveTo._nX&&this._oMoveDirection._nX>0)){
    //     this._oMoveDirection._nX=0
    // }
    // if((oCurrHero.y<=this._oMoveTo._nY&&this._oMoveDirection._nY<0)||
    //     (oCurrHero.y>=this._oMoveTo._nY&&this._oMoveDirection._nY>0)){
    //     this._oMoveDirection._nY=0
    // }
    // if(this._oMoveDirection._nX==0&&this._oMoveDirection._nY==0){
    //     return;
    // }
    //
    // oCurrHero.x+=this._oMoveDirection._nX*120*dt;
    // oCurrHero.y+=this._oMoveDirection._nY*120*dt;
    //
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEh1b2xvbmcuanMiXSwibmFtZXMiOlsic3BlZWQiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIl9iSXNNb3ZpbmciLCJfb01vdmVEaXJlY3Rpb24iLCJfb01vdmVUbyIsInN0YXJ0IiwiQ2FudmFzIiwiaW5zdGFuY2UiLCJub2RlIiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfRU5EIiwiZXZlbnQiLCJuTW92ZVRvWCIsIm5Nb3ZlVG9ZIiwib01vdmVUb1YyIiwiY29udmVydFRvTm9kZVNwYWNlQVIiLCJ2MiIsIl9uWCIsIl9uWSIsIm9DdXJySGVybyIsImZpbmQiLCJjb25zb2xlIiwibG9nIiwieCIsInkiLCJvU2tlbGV0b24iLCJnZXRDb21wb25lbnQiLCJzcCIsIlNrZWxldG9uIiwic2V0QW5pbWF0aW9uIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUEsS0FBSyxHQUFDLEdBQVo7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBQyxLQURIO0FBRVJDLElBQUFBLGVBQWUsRUFBQyxJQUZSO0FBR1JDLElBQUFBLFFBQVEsRUFBQztBQUhELEdBSFA7QUFTTDtBQUVBO0FBRUFDLEVBQUFBLEtBYkssbUJBYUk7QUFDTFAsSUFBQUEsRUFBRSxDQUFDUSxNQUFILENBQVVDLFFBQVYsQ0FBbUJDLElBQW5CLENBQXdCQyxFQUF4QixDQUEyQlgsRUFBRSxDQUFDWSxJQUFILENBQVFDLFNBQVIsQ0FBa0JDLFNBQTdDLEVBQXVELFVBQVVDLEtBQVYsRUFBaUI7QUFDcEUsVUFBSUMsUUFBUSxHQUFHRCxLQUFLLENBQUMsY0FBRCxDQUFMLEVBQWY7QUFDQSxVQUFJRSxRQUFRLEdBQUdGLEtBQUssQ0FBQyxjQUFELENBQUwsRUFBZjtBQUNBLFVBQUlHLFNBQVMsR0FBQ2xCLEVBQUUsQ0FBQ1EsTUFBSCxDQUFVQyxRQUFWLENBQW1CQyxJQUFuQixDQUF3QlMsb0JBQXhCLENBQTZDbkIsRUFBRSxDQUFDb0IsRUFBSCxDQUFNSixRQUFOLEVBQWVDLFFBQWYsQ0FBN0MsQ0FBZCxDQUhvRSxDQUtwRTtBQUNBO0FBQ0E7O0FBRUEsV0FBS1osZUFBTCxHQUFxQjtBQUFDZ0IsUUFBQUEsR0FBRyxFQUFDLENBQUw7QUFBT0MsUUFBQUEsR0FBRyxFQUFDO0FBQVgsT0FBckIsQ0FUb0UsQ0FVcEU7O0FBQ0EsVUFBSUMsU0FBUyxHQUFHdkIsRUFBRSxDQUFDd0IsSUFBSCxDQUFRLGdCQUFSLENBQWhCO0FBRUFDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBd0JILFNBQXhCO0FBQ0EsV0FBS2xCLGVBQUwsQ0FBcUJnQixHQUFyQixHQUEwQkUsU0FBUyxDQUFDSSxDQUFWLElBQWFULFNBQVMsQ0FBQ1MsQ0FBeEIsR0FBMkIsQ0FBM0IsR0FBNkIsQ0FBQyxDQUF2RDtBQUNBLFdBQUt0QixlQUFMLENBQXFCaUIsR0FBckIsR0FBMEJDLFNBQVMsQ0FBQ0ssQ0FBVixJQUFhVixTQUFTLENBQUNVLENBQXhCLEdBQTJCLENBQTNCLEdBQTZCLENBQUMsQ0FBdkQ7QUFDQUgsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBbUMsS0FBS3JCLGVBQXhDLEVBaEJvRSxDQWlCcEU7O0FBQ0EsV0FBS0MsUUFBTCxHQUFjO0FBQ1ZlLFFBQUFBLEdBQUcsRUFBQ0gsU0FBUyxDQUFDUyxDQURKO0FBRVZMLFFBQUFBLEdBQUcsRUFBQ0osU0FBUyxDQUFDVTtBQUZKLE9BQWQ7QUFLQSxVQUFJQyxTQUFTLEdBQUNOLFNBQVMsQ0FBQ08sWUFBVixDQUF1QkMsRUFBRSxDQUFDQyxRQUExQixDQUFkO0FBQ0FILE1BQUFBLFNBQVMsQ0FBQ0ksWUFBVixDQUF1QixDQUF2QixFQUF5QixNQUF6QixFQUFnQyxJQUFoQyxFQXhCb0UsQ0E2QnBFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSCxLQWxDRDtBQW1DSCxHQWpESTtBQW1ETEMsRUFBQUEsTUFuREssa0JBbURHQyxFQW5ESCxFQW1ETztBQUNSLFFBQUlaLFNBQVMsR0FBR3ZCLEVBQUUsQ0FBQ3dCLElBQUgsQ0FBUSxnQkFBUixDQUFoQixDQURRLENBRVI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSjtBQUNDO0FBdEVJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5jb25zdCBzcGVlZD0xMjA7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgX2JJc01vdmluZzpmYWxzZSxcclxuICAgICAgICBfb01vdmVEaXJlY3Rpb246bnVsbCxcclxuICAgICAgICBfb01vdmVUbzpudWxsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBsZXQgbk1vdmVUb1ggPSBldmVudFsnZ2V0TG9jYXRpb25YJ10oKTtcclxuICAgICAgICAgICAgbGV0IG5Nb3ZlVG9ZID0gZXZlbnRbJ2dldExvY2F0aW9uWSddKCk7XHJcbiAgICAgICAgICAgIGxldCBvTW92ZVRvVjI9Y2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIoY2MudjIobk1vdmVUb1gsbk1vdmVUb1kpKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwibk1vdmVUb1hcIixuTW92ZVRvWClcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMi54JyxvTW92ZVRvVjIueCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbj17X25YOjAsX25ZOjB9O1xyXG4gICAgICAgICAgICAvL1xyXG4gICAgICAgICAgICBsZXQgb0N1cnJIZXJvID0gY2MuZmluZCgnQ2FudmFzL0h1b2xvbmcnKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0ob0N1cnJIZXJvLng8PW9Nb3ZlVG9WMi54KT8xOi0xO1xyXG4gICAgICAgICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk9KG9DdXJySGVyby55PD1vTW92ZVRvVjIueSk/MTotMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbik7XHJcbiAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlVG89e1xyXG4gICAgICAgICAgICAgICAgX25YOm9Nb3ZlVG9WMi54LFxyXG4gICAgICAgICAgICAgICAgX25ZOm9Nb3ZlVG9WMi55LFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgbGV0IG9Ta2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgb1NrZWxldG9uLnNldEFuaW1hdGlvbigxLCd3YWxrJyx0cnVlKTtcclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGxldCBza2VsZXRvbj1jYy5maW5kKCdDYW52YXMvSHVvbG9uZycpLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIC8vIGxldCB0cmFjZUVudHJ5ID0gc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3NraWxsMDEnLGZhbHNlKTtcclxuICAgICAgICAgICAgLy8gc2tlbGV0b24uc2V0VHJhY2tDb21wbGV0ZUxpc3RlbmVyKHRyYWNlRW50cnksZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvLyAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgLy8gfSlcclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSBjYy5maW5kKCdDYW52YXMvSHVvbG9uZycpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbilcclxuICAgICAgICAvLyBpZigob0N1cnJIZXJvLng8PXRoaXMuX29Nb3ZlVG8uX25YJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg8MCl8fFxyXG4gICAgICAgIC8vICAgICAob0N1cnJIZXJvLng+PXRoaXMuX29Nb3ZlVG8uX25YJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg+MCkpe1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg9MFxyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyBpZigob0N1cnJIZXJvLnk8PXRoaXMuX29Nb3ZlVG8uX25ZJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk8MCl8fFxyXG4gICAgICAgIC8vICAgICAob0N1cnJIZXJvLnk+PXRoaXMuX29Nb3ZlVG8uX25ZJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk+MCkpe1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk9MFxyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyBpZih0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg9PTAmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT09MCl7XHJcbiAgICAgICAgLy8gICAgIHJldHVybjtcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBvQ3Vyckhlcm8ueCs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25YKjEyMCpkdDtcclxuICAgICAgICAvLyBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKjEyMCpkdDtcclxuICAgIC8vXHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/MyHuolong.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ac5eeu2IzNBAr/RIh2OKbLI', 'MyHuolong');
// script/xiaojingling/MyHuolong.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
var speed = 120;
var customScaleX = 0.7;
var MyHuuolong = /** @class */ (function (_super) {
    __extends(MyHuuolong, _super);
    function MyHuuolong() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._bIsMoving = false;
        _this._oMoveDirection = null;
        _this._oMoveTo = null;
        return _this;
    }
    // onLoad () {}
    MyHuuolong.prototype.start = function () {
    };
    MyHuuolong.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
    };
    MyHuuolong.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    MyHuuolong.prototype.attk = function (nPosX, nPosY) {
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
        });
    };
    MyHuuolong.prototype.die = function () {
    };
    MyHuuolong = __decorate([
        ccclass
    ], MyHuuolong);
    return MyHuuolong;
}(cc.Component));
exports.default = MyHuuolong;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXE15SHVvbG9uZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUUzRSxJQUFBLE9BQU8sR0FBSyxFQUFFLENBQUMsVUFBVSxRQUFsQixDQUFtQjtBQUNqQyxJQUFNLEtBQUssR0FBQyxHQUFHLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUMsR0FBRyxDQUFDO0FBRXZCO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBc0ZDO1FBcEZHLGdCQUFVLEdBQVMsS0FBSyxDQUFDO1FBRXpCLHFCQUFlLEdBQXlCLElBQUksQ0FBQztRQUU3QyxjQUFRLEdBQXlCLElBQUksQ0FBQzs7SUFnRjFDLENBQUM7SUE5RUcsZUFBZTtJQUVmLDBCQUFLLEdBQUw7SUFFQSxDQUFDO0lBRUQsMkJBQU0sR0FBTixVQUFRLEVBQUU7UUFDTixJQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztZQUNoQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHNDQUFzQztRQUN0QywyREFBMkQ7UUFDM0QsSUFBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQztZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzdELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQTtTQUM3QjtRQUNELElBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFFLENBQUMsRUFBQztZQUN4RCxJQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN0QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLEtBQUssR0FBQyxFQUFFLENBQUM7UUFDL0MsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDO1FBRS9DLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sS0FBWSxFQUFDLEtBQVk7UUFDNUIsbUNBQW1DO1FBQ25DLHNDQUFzQztRQUN0QywwQ0FBMEM7UUFFMUMsSUFBSSxDQUFDLGVBQWUsR0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQ25DLEVBQUU7UUFDRixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRTFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekQsRUFBRTtRQUVGLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUM7WUFDVixHQUFHLEVBQUMsS0FBSztZQUNULEdBQUcsRUFBQyxLQUFLO1NBQ1osQ0FBQztRQUNGLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCx5QkFBSSxHQUFKLFVBQUssS0FBWSxFQUFDLEtBQVk7UUFDMUIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQix5QkFBeUI7UUFDekIsNENBQTRDO1FBQzVDLElBQUk7UUFFSixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxTQUFTLEVBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFVBQVUsRUFBQztZQUN6QyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELHdCQUFHLEdBQUg7SUFFQSxDQUFDO0lBckZnQixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBc0Y5QjtJQUFELGlCQUFDO0NBdEZELEFBc0ZDLENBdEZ1QyxFQUFFLENBQUMsU0FBUyxHQXNGbkQ7a0JBdEZvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY29uc3Qge2NjY2xhc3MsfSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IHNwZWVkPTEyMDtcclxuY29uc3QgY3VzdG9tU2NhbGVYPTAuNztcclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlIdXVvbG9uZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgX2JJc01vdmluZzpib29sZWFuPWZhbHNlO1xyXG5cclxuICAgIF9vTW92ZURpcmVjdGlvbjp7X25YOm51bWJlcixfblk6bnVtYmVyfT1udWxsO1xyXG5cclxuICAgIF9vTW92ZVRvOntfblg6bnVtYmVyLF9uWTpudW1iZXJ9PW51bGw7XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgaWYoIXRoaXMuX2JJc01vdmluZyl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVybycsb0N1cnJIZXJvKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fb01vdmVEaXJlY3Rpb24nLHRoaXMuX29Nb3ZlRGlyZWN0aW9uKVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueDw9dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWDwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueD49dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueTw9dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWTwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueT49dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD09MCYmdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPWZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgc2tlbGV0b24gPSBvQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3N0YW5kJyx0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLngrPXRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWCpzcGVlZCpkdDtcclxuICAgICAgICBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKnNwZWVkKmR0O1xyXG5cclxuICAgICAgICBvQ3Vyckhlcm8uekluZGV4PS1vQ3Vyckhlcm8ueTtcclxuICAgIH1cclxuXHJcbiAgICBtb3ZlVG8oblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5Nb3ZlVG9YXCIsbk1vdmVUb1gpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb01vdmVUb1YyLngnLG9Nb3ZlVG9WMi54KTtcclxuXHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb249e19uWDowLF9uWTowfTtcclxuICAgICAgICAvL1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25YPShvQ3Vyckhlcm8ueDw9blBvc1gpPzE6LTE7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPShvQ3Vyckhlcm8ueTw9blBvc1kpPzE6LTE7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbik7XHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLnNjYWxlWD10aGlzLl9vTW92ZURpcmVjdGlvbi5fblgqY3VzdG9tU2NhbGVYO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlVG89e1xyXG4gICAgICAgICAgICBfblg6blBvc1gsXHJcbiAgICAgICAgICAgIF9uWTpuUG9zWSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmKCF0aGlzLl9iSXNNb3Zpbmcpe1xyXG4gICAgICAgICAgICBsZXQgb1NrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgICAgICBvU2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3dhbGsnLHRydWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9iSXNNb3Zpbmc9dHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXR0ayhuUG9zWDpudW1iZXIsblBvc1k6bnVtYmVyKTp2b2lke1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gaWYoblBvc1g8b0N1cnJIZXJvLngpe1xyXG4gICAgICAgIC8vICAgICBvQ3Vyckhlcm8uc2NhbGVYPW9DdXJySGVyby5zY2FsZVgqLTE7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICBsZXQgc2tlbGV0b249b0N1cnJIZXJvLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgbGV0IHRyYWNlRW50cnkgPSBza2VsZXRvbi5zZXRBbmltYXRpb24oMiwnc2tpbGwwMScsZmFsc2UpO1xyXG4gICAgICAgIHNrZWxldG9uLnNldFRyYWNrQ29tcGxldGVMaXN0ZW5lcih0cmFjZUVudHJ5LGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygyKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIGRpZSgpOnZvaWR7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/HeroFactory.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f45fepUk19OLqYbfIDphft/', 'HeroFactory');
// script/xiaojingling/HeroFactory.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Async_1 = require("./Async");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BUNDLE_NAME = "prefab";
var HeroFacyor = /** @class */ (function (_super) {
    __extends(HeroFacyor, _super);
    function HeroFacyor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // onLoad () {}
    HeroFacyor.prototype.start = function () {
    };
    HeroFacyor.createAsync = function (heroName, funCallback) {
        if (heroName == null) {
            return;
        }
        var loadBundle = cc.assetManager.getBundle(BUNDLE_NAME);
        var loadPrefab = null;
        Async_1.default.seriez(function (funYesContinue) {
            if (loadBundle != null) {
                funYesContinue();
                return;
            }
            cc.assetManager.loadBundle(BUNDLE_NAME, function (error, bundle) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                loadBundle = bundle;
                funYesContinue();
            });
        }, function (funYesContinue) {
            loadPrefab = loadBundle.get(heroName, cc.Prefab);
            if (null != loadPrefab) {
                funYesContinue();
                return;
            }
            loadBundle.load(heroName, cc.Prefab, function (error, prefab) {
                if (error != null) {
                    cc.error("heroName:" + heroName + "\u627E\u4E0D\u5230\u5BF9\u5E94\u9884\u5236\u4F53", error);
                    return;
                }
                loadPrefab = prefab;
                funYesContinue();
            });
        }, function (funYesContinue) {
            var mainBundle = cc.assetManager.getBundle("main");
            mainBundle.preloadDir("spine/xiaojingling/" + heroName, function (error) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                funYesContinue();
            });
        }, function (funYesContinue) {
            if (loadPrefab == null) {
                cc.error("loadPrefab\u4E3A\u7A7A\uFF0C\u540D\u5B57\uFF1A" + heroName);
                return;
            }
            var heroNode = cc.instantiate(loadPrefab);
            funCallback(heroNode);
        });
        // if(loadBundle==null){
        //     cc.assetManager.loadBundle(BUNDLE_NAME,(error:Error,bundle:cc.AssetManager.Bundle)=>{
        //         if(error!=null){
        //             cc.error(error);
        //             return;
        //         }
        //         let loadPrefab = bundle.get(heroName,cc.Prefab);
        //         if(null==loadPrefab){
        //             bundle.load(heroName,cc.Prefab,(error:Error,prefab:cc.Prefab)=>{
        //                 if(error!=null){
        //                     cc.error(error);
        //                     return;
        //                 }
        //                 let mainBundle = cc.assetManager.getBundle("main");
        //                 mainBundle.preloadDir(`spine/${heroName}`,(error:Error)=>{
        //                     if(error!=null){
        //                         cc.error(error);
        //                         return;
        //                     }
        //                     let heroNode = cc.instantiate(prefab);
        //                     funCallback(heroNode)
        //                 })
        //             });
        //         }
        //     });
        // }
    };
    HeroFacyor = __decorate([
        ccclass
    ], HeroFacyor);
    return HeroFacyor;
}(cc.Component));
exports.default = HeroFacyor;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEhlcm9GYWN0b3J5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWxGLGlDQUEyQjtBQUVyQixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUMxQyxJQUFNLFdBQVcsR0FBQyxRQUFRLENBQUM7QUFFM0I7SUFBd0MsOEJBQVk7SUFBcEQ7O0lBcUdBLENBQUM7SUFsR0csZUFBZTtJQUVmLDBCQUFLLEdBQUw7SUFFQSxDQUFDO0lBRU0sc0JBQVcsR0FBbEIsVUFBbUIsUUFBZSxFQUFDLFdBQW9DO1FBQ25FLElBQUksUUFBUSxJQUFJLElBQUksRUFBRTtZQUNsQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN4RCxJQUFJLFVBQVUsR0FBQyxJQUFJLENBQUM7UUFDcEIsZUFBSyxDQUFDLE1BQU0sQ0FDUixVQUFDLGNBQWM7WUFDWCxJQUFHLFVBQVUsSUFBRSxJQUFJLEVBQUM7Z0JBQ2hCLGNBQWMsRUFBRSxDQUFDO2dCQUNqQixPQUFPO2FBQ1Y7WUFDRCxFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUMsVUFBQyxLQUFXLEVBQUMsTUFBNkI7Z0JBQzdFLElBQUcsS0FBSyxJQUFFLElBQUksRUFBQztvQkFDWCxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNoQixPQUFPO2lCQUNWO2dCQUNELFVBQVUsR0FBQyxNQUFNLENBQUM7Z0JBQ2xCLGNBQWMsRUFBRSxDQUFDO1lBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxFQUNELFVBQUMsY0FBYztZQUNYLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDaEQsSUFBRyxJQUFJLElBQUUsVUFBVSxFQUFDO2dCQUNoQixjQUFjLEVBQUUsQ0FBQztnQkFDakIsT0FBTzthQUNWO1lBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBQyxVQUFDLEtBQVcsRUFBQyxNQUFnQjtnQkFDNUQsSUFBRyxLQUFLLElBQUUsSUFBSSxFQUFDO29CQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBWSxRQUFRLHFEQUFVLEVBQUMsS0FBSyxDQUFDLENBQUM7b0JBQy9DLE9BQU87aUJBQ1Y7Z0JBQ0QsVUFBVSxHQUFDLE1BQU0sQ0FBQztnQkFDbEIsY0FBYyxFQUFFLENBQUM7WUFDckIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0QsVUFBQyxjQUFjO1lBQ1gsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkQsVUFBVSxDQUFDLFVBQVUsQ0FBQyx3QkFBc0IsUUFBVSxFQUFDLFVBQUMsS0FBVztnQkFDL0QsSUFBRyxLQUFLLElBQUUsSUFBSSxFQUFDO29CQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2hCLE9BQU87aUJBQ1Y7Z0JBQ0QsY0FBYyxFQUFFLENBQUM7WUFDckIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0QsVUFBQyxjQUFjO1lBQ1gsSUFBRyxVQUFVLElBQUUsSUFBSSxFQUFDO2dCQUNoQixFQUFFLENBQUMsS0FBSyxDQUFDLG1EQUFtQixRQUFVLENBQUMsQ0FBQTtnQkFDdkMsT0FBTzthQUNWO1lBQ0QsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUNKLENBQUE7UUFRRCx3QkFBd0I7UUFDeEIsNEZBQTRGO1FBQzVGLDJCQUEyQjtRQUMzQiwrQkFBK0I7UUFDL0Isc0JBQXNCO1FBQ3RCLFlBQVk7UUFDWiwyREFBMkQ7UUFDM0QsZ0NBQWdDO1FBQ2hDLCtFQUErRTtRQUMvRSxtQ0FBbUM7UUFDbkMsdUNBQXVDO1FBQ3ZDLDhCQUE4QjtRQUM5QixvQkFBb0I7UUFDcEIsc0VBQXNFO1FBQ3RFLDZFQUE2RTtRQUM3RSx1Q0FBdUM7UUFDdkMsMkNBQTJDO1FBQzNDLGtDQUFrQztRQUNsQyx3QkFBd0I7UUFDeEIsNkRBQTZEO1FBQzdELDRDQUE0QztRQUM1QyxxQkFBcUI7UUFDckIsa0JBQWtCO1FBQ2xCLFlBQVk7UUFDWixVQUFVO1FBQ1YsSUFBSTtJQUNSLENBQUM7SUFsR2dCLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FxRzlCO0lBQUQsaUJBQUM7Q0FyR0QsQUFxR0MsQ0FyR3VDLEVBQUUsQ0FBQyxTQUFTLEdBcUduRDtrQkFyR29CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5pbXBvcnQgQXN5bmMgZnJvbSBcIi4vQXN5bmNcIlxyXG5cclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IEJVTkRMRV9OQU1FPVwicHJlZmFiXCI7XHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEhlcm9GYWN5b3IgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge31cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBjcmVhdGVBc3luYyhoZXJvTmFtZTpzdHJpbmcsZnVuQ2FsbGJhY2s6KGhlcm9Ob2RlOmNjLk5vZGUpPT52b2lkKTp2b2lke1xyXG4gICAgICAgIGlmIChoZXJvTmFtZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBsb2FkQnVuZGxlID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShCVU5ETEVfTkFNRSk7XHJcbiAgICAgICAgbGV0IGxvYWRQcmVmYWI9bnVsbDtcclxuICAgICAgICBBc3luYy5zZXJpZXooXHJcbiAgICAgICAgICAgIChmdW5ZZXNDb250aW51ZSk9PntcclxuICAgICAgICAgICAgICAgIGlmKGxvYWRCdW5kbGUhPW51bGwpe1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2MuYXNzZXRNYW5hZ2VyLmxvYWRCdW5kbGUoQlVORExFX05BTUUsKGVycm9yOkVycm9yLGJ1bmRsZTpjYy5Bc3NldE1hbmFnZXIuQnVuZGxlKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVycm9yIT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRCdW5kbGU9YnVuZGxlO1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGZ1blllc0NvbnRpbnVlKT0+e1xyXG4gICAgICAgICAgICAgICAgbG9hZFByZWZhYiA9IGxvYWRCdW5kbGUuZ2V0KGhlcm9OYW1lLGNjLlByZWZhYik7XHJcbiAgICAgICAgICAgICAgICBpZihudWxsIT1sb2FkUHJlZmFiKXtcclxuICAgICAgICAgICAgICAgICAgICBmdW5ZZXNDb250aW51ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxvYWRCdW5kbGUubG9hZChoZXJvTmFtZSxjYy5QcmVmYWIsKGVycm9yOkVycm9yLHByZWZhYjpjYy5QcmVmYWIpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoZXJyb3IhPW51bGwpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihgaGVyb05hbWU6JHtoZXJvTmFtZX3mib7kuI3liLDlr7nlupTpooTliLbkvZNgLGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsb2FkUHJlZmFiPXByZWZhYjtcclxuICAgICAgICAgICAgICAgICAgICBmdW5ZZXNDb250aW51ZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChmdW5ZZXNDb250aW51ZSk9PntcclxuICAgICAgICAgICAgICAgIGxldCBtYWluQnVuZGxlID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShcIm1haW5cIik7XHJcbiAgICAgICAgICAgICAgICBtYWluQnVuZGxlLnByZWxvYWREaXIoYHNwaW5lL3hpYW9qaW5nbGluZy8ke2hlcm9OYW1lfWAsKGVycm9yOkVycm9yKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVycm9yIT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGZ1blllc0NvbnRpbnVlKT0+e1xyXG4gICAgICAgICAgICAgICAgaWYobG9hZFByZWZhYj09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoYGxvYWRQcmVmYWLkuLrnqbrvvIzlkI3lrZfvvJoke2hlcm9OYW1lfWApXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGhlcm9Ob2RlID0gY2MuaW5zdGFudGlhdGUobG9hZFByZWZhYik7XHJcbiAgICAgICAgICAgICAgICBmdW5DYWxsYmFjayhoZXJvTm9kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgICAgIC8vIGlmKGxvYWRCdW5kbGU9PW51bGwpe1xyXG4gICAgICAgIC8vICAgICBjYy5hc3NldE1hbmFnZXIubG9hZEJ1bmRsZShCVU5ETEVfTkFNRSwoZXJyb3I6RXJyb3IsYnVuZGxlOmNjLkFzc2V0TWFuYWdlci5CdW5kbGUpPT57XHJcbiAgICAgICAgLy8gICAgICAgICBpZihlcnJvciE9bnVsbCl7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgIGxldCBsb2FkUHJlZmFiID0gYnVuZGxlLmdldChoZXJvTmFtZSxjYy5QcmVmYWIpO1xyXG4gICAgICAgIC8vICAgICAgICAgaWYobnVsbD09bG9hZFByZWZhYil7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgYnVuZGxlLmxvYWQoaGVyb05hbWUsY2MuUHJlZmFiLChlcnJvcjpFcnJvcixwcmVmYWI6Y2MuUHJlZmFiKT0+e1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBpZihlcnJvciE9bnVsbCl7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IG1haW5CdW5kbGUgPSBjYy5hc3NldE1hbmFnZXIuZ2V0QnVuZGxlKFwibWFpblwiKTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbWFpbkJ1bmRsZS5wcmVsb2FkRGlyKGBzcGluZS8ke2hlcm9OYW1lfWAsKGVycm9yOkVycm9yKT0+e1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgaWYoZXJyb3IhPW51bGwpe1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmVycm9yKGVycm9yKTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBsZXQgaGVyb05vZGUgPSBjYy5pbnN0YW50aWF0ZShwcmVmYWIpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgZnVuQ2FsbGJhY2soaGVyb05vZGUpXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgIH0pO1xyXG4gICAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Async.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '07852WwxSlDuJkdDsDPNxD+', 'Async');
// script/xiaojingling/Async.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Async = /** @class */ (function () {
    function Async() {
    }
    Async.seriez = function () {
        var funArry = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            funArry[_i] = arguments[_i];
        }
        if (null == funArry || funArry.length <= 0) {
            return;
        }
        var funYesContinue = function () {
            if (funArry.length < 0) {
                return;
            }
            var funCurr = funArry.shift();
            if ("function" == typeof (funCurr)) {
                funCurr(funYesContinue);
            }
            else {
                funYesContinue();
            }
        };
        funYesContinue();
    };
    Async = __decorate([
        ccclass
    ], Async);
    return Async;
}());
exports.default = Async;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEFzeW5jLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7QUFFNUUsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFPMUM7SUFFRztJQUNBLENBQUM7SUFFTyxZQUFNLEdBQWI7UUFBYyxpQkFBMkI7YUFBM0IsVUFBMkIsRUFBM0IscUJBQTJCLEVBQTNCLElBQTJCO1lBQTNCLDRCQUEyQjs7UUFDdEMsSUFBRyxJQUFJLElBQUUsT0FBTyxJQUFFLE9BQU8sQ0FBQyxNQUFNLElBQUUsQ0FBQyxFQUFDO1lBQ2hDLE9BQU87U0FDVjtRQUVELElBQUssY0FBYyxHQUFDO1lBQ2hCLElBQUcsT0FBTyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUM7Z0JBQ2hCLE9BQU87YUFDVjtZQUNELElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUM3QixJQUFHLFVBQVUsSUFBRSxPQUFNLENBQUMsT0FBTyxDQUFDLEVBQUM7Z0JBQzNCLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUMzQjtpQkFBSztnQkFDRixjQUFjLEVBQUUsQ0FBQzthQUNwQjtRQUNOLENBQUMsQ0FBQTtRQUNELGNBQWMsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUF0QmdCLEtBQUs7UUFEekIsT0FBTztPQUNhLEtBQUssQ0F1QnpCO0lBQUQsWUFBQztDQXZCRCxBQXVCQyxJQUFBO2tCQXZCb0IsS0FBSyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxudHlwZSBZZXNDb250aW51ZSA9KCk9PnZvaWQ7XHJcbnR5cGUgQ3VzdG9tRnVuPShmdW5ZZXNDb250aW51ZTpZZXNDb250aW51ZSk9PnZvaWQ7XHJcblxyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQXN5bmN7XHJcblxyXG4gICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICB9XHJcblxyXG4gICAgc3RhdGljIHNlcmlleiguLi5mdW5BcnJ5OkFycmF5PEN1c3RvbUZ1bj4pOnZvaWR7XHJcbiAgICAgICBpZihudWxsPT1mdW5BcnJ5fHxmdW5BcnJ5Lmxlbmd0aDw9MCl7XHJcbiAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgfVxyXG5cclxuICAgICAgIGxldCAgZnVuWWVzQ29udGludWU9KCk6dm9pZD0+e1xyXG4gICAgICAgICAgIGlmKGZ1bkFycnkubGVuZ3RoPDApe1xyXG4gICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGxldCBmdW5DdXJyID0gZnVuQXJyeS5zaGlmdCgpO1xyXG4gICAgICAgICAgICBpZihcImZ1bmN0aW9uXCI9PXR5cGVvZihmdW5DdXJyKSl7XHJcbiAgICAgICAgICAgICAgICBmdW5DdXJyKGZ1blllc0NvbnRpbnVlKTtcclxuICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZnVuWWVzQ29udGludWUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgfVxyXG4gICAgICAgZnVuWWVzQ29udGludWUoKTtcclxuICAgIH1cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Common.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8cc52LoIFNAy65yLLiKdbrw', 'Common');
// script/xiaojingling/Common.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var speed = 120;
var customScaleX = 0.7;
var Common = /** @class */ (function (_super) {
    __extends(Common, _super);
    function Common() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.rangeAttack = null;
        /**
         * 是否在移动
         */
        _this._bIsMoving = false;
        /**
         * 移动方向
         */
        _this._oMoveDirection = null;
        /**
         * 目标位置
         */
        _this._oMoveTo = null;
        /**
         *可以攻击的目标集合
         */
        _this._oAttkableObjSet = null;
        /**
         * 当前血量
         */
        _this._nCurrHp = 0;
        /**
         * 是否正在攻击
         */
        _this._bIsAttacking = false;
        return _this;
    }
    Common_1 = Common;
    // onLoad () {}
    Common.prototype.start = function () {
        this._nCurrHp = 100;
        // let oCurrHero = this.node;
        // let skeleton=oCurrHero.getComponent(sp.Skeleton);
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
        // oCurrHero.anchorY=100;
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
    };
    Common.prototype.onCollisionEnter = function (oAnotherBox, self) {
        cc.log("\u81EA\u5DF1\u7684\u540D\u5B57\uFF1A" + self.node["_name"] + ",\u5F53\u524Dnode\u540D\u5B57\uFF1A" + this.node.name + ",\u78B0\u5230\u5176\u5B83\u7269\u4F53,name=" + oAnotherBox.node.name);
        if (null != oAnotherBox) {
            var oAnotherBoxName = oAnotherBox.node.name;
            if (oAnotherBoxName.indexOf("_") != -1) {
                console.log("被碰撞的是攻击盒子");
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子
                var strings = oAnotherBoxName.split("_");
                // console.log(`oAnotherBoxName的前缀：${strings[0]}`);
                var heroName = strings[0];
                if (heroName === self.node["_name"]) {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）等于当前节点的名称，说明这个攻击盒子属于当前节点，不做操作
                    return;
                }
                else {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）不等于当前节点的名称，说明这个攻击盒子不属于当前节点
                    //那么要找到这个攻击盒子的父节点a，将当前节点加入a的碰撞set中
                    var parent = oAnotherBox.node.parent;
                    console.log("\u653B\u51FB\u76D2\u5B50\u7684\u7236\u8282\u70B9\u7684\u7EC4\u4EF6:", parent.getComponent(Common_1));
                    var fuCommon = parent.getComponent(Common_1);
                    fuCommon._oAttkableObjSet = fuCommon._oAttkableObjSet || new Set();
                    fuCommon._oAttkableObjSet.add(self.node);
                    console.log('component._oAttkableObjSet', fuCommon._oAttkableObjSet);
                    return;
                }
            }
            else {
                console.log("被碰撞的是人物");
                this._oAttkableObjSet = this._oAttkableObjSet || new Set();
                this._oAttkableObjSet.add(oAnotherBox.node);
            }
        }
        // 碰撞系统会计算出碰撞组件在世界坐标系下的相关的值，并放到 world 这个属性里面
        // var world = self.world;
        // let points = self.points;
        // console.log(`${this.node.name},points`,points);
        // for (let i = 0; i < points.length; i++) {
        //     let point = points[i];
        //     console.log(`${this.node.name},point`,point);
        // }
        // // 碰撞组件的 aabb 碰撞框
        // var aabb = world.aabb;
        // console.log('aabb',aabb);
        //
        // // 上一次计算的碰撞组件的 aabb 碰撞框
        // var preAabb = world.preAabb;
        //
        // // 碰撞框的世界矩阵
        // var t = world.transform;
        //
        // // 以下属性为圆形碰撞组件特有属性
        // var r = world.radius;
        // var p = world.position;
        //
        // // 以下属性为 矩形 和 多边形 碰撞组件特有属性
        // var ps = world.points;
    };
    Common.prototype.onCollisionExit = function (oAnotherBox, self) {
        var oAnotherBoxName = oAnotherBox.node.name;
        cc.log("\u79BB\u5F00\u5176\u5B83\u7269\u4F53,name=" + oAnotherBoxName);
        if (null != oAnotherBox) {
            if (oAnotherBoxName.indexOf("_") != -1) {
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子，那么要找到他的父节点，从父节点中移除self的节点
                console.log("被离开碰撞的是攻击盒子");
                var parent = oAnotherBox.node.parent;
                var fuCommon = parent.getComponent(Common_1);
                console.log('【离开】攻击盒子的父节点的Common', fuCommon);
                if (fuCommon._oAttkableObjSet != null) {
                    fuCommon._oAttkableObjSet.delete(self.node);
                }
            }
            else {
                console.log("被离开碰撞的是英雄的盒子");
                if (null != this._oAttkableObjSet) {
                    this._oAttkableObjSet.delete(oAnotherBox.node);
                }
            }
        }
    };
    /**
     * 节点销毁时，清空集合，避免内存谢落
     */
    Common.prototype.onDestroy = function () {
        if (null != this._oAttkableObjSet) {
            this._oAttkableObjSet.clear();
        }
    };
    Common.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
        // console.log(this.node,"oCurrHero",oCurrHero.zIndex);
    };
    Common.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        //正在攻击的话，不让他移动，避免R闪
        if (this._bIsAttacking) {
            return;
        }
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    Common.prototype.attk = function (nPosX, nPosY) {
        var _this = this;
        if (this._bIsAttacking) {
            return;
        }
        this._bIsAttacking = true;
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        var self = this;
        var components = self.node['_components'];
        console.log('components', components);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
            self._bIsAttacking = false;
        });
        if (this._oAttkableObjSet == null || this._oAttkableObjSet.size <= 0) {
            return;
        }
        this._oAttkableObjSet.forEach(function (oAttkableObj) {
            if (oAttkableObj == null) {
                return;
            }
            var name = oAttkableObj.name;
            var suffix = name.split("_")[1];
            //如果要攻击的物体为被攻击方的碰撞盒子，直接return
            if (suffix === 'RangeAttack') {
                return;
            }
            //上下位置差太多，打不到对方
            if (Math.abs(_this.node.zIndex - oAttkableObj.zIndex) > 64) {
                return;
            }
            //双方左右位置相反，并有一段距离，打不到对方
            if (((oAttkableObj.x - _this.node.x) <= -64 && _this.node.scale > 0) ||
                ((oAttkableObj.x - _this.node.x) >= 64 && _this.node.scale < 0)) {
                return;
            }
            oAttkableObj.getComponent(Common_1).subtractHp(40);
        });
    };
    /**
     * 被打减血时
     * @param nVal
     */
    Common.prototype.subtractHp = function (nVal) {
        if (nVal < 0) {
            return;
        }
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        //减血效果要延时一下，因为每个小精灵的攻击都需要1秒以上
        var self = this;
        this.schedule(function () {
            //减血时开启被打的动画
            skeleton.setAnimation(1, 'hurt', false);
            self._nCurrHp = Math.max(self._nCurrHp - nVal, 0);
            var oSubBlood = cc.find("SubBlood", self.node);
            oSubBlood = cc.instantiate(oSubBlood);
            oSubBlood.getComponent(cc.Label).string = nVal.toString();
            oSubBlood.active = true;
            // console.log("当前node的名字",self.node.name)
            self.node.addChild(oSubBlood);
            cc.tween(oSubBlood)
                .to(0.0, { scale: 3.2 })
                .to(0.2, { scale: 1.0 })
                .by(0.4, { y: 64, opacity: -128 })
                .start();
            self.schedule(function () {
                oSubBlood.destroy();
            }, 0.6);
            if (self._nCurrHp <= 0) {
                self.die();
            }
        }, 1.2, 0, 0);
    };
    Common.prototype.die = function () {
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        skeleton.schedule(function () {
            // 这里的 this 指向 component
            skeleton.setAnimation(1, 'dead', false);
        }, 1, 0, 0);
    };
    var Common_1;
    __decorate([
        property(cc.Prefab)
    ], Common.prototype, "rangeAttack", void 0);
    Common = Common_1 = __decorate([
        ccclass
    ], Common);
    return Common;
}(cc.Component));
exports.default = Common;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXENvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUU1RSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUMxQyxJQUFNLEtBQUssR0FBQyxHQUFHLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUMsR0FBRyxDQUFDO0FBRXZCO0lBQW9DLDBCQUFZO0lBQWhEO1FBQUEscUVBdVNDO1FBcFNHLGlCQUFXLEdBQWMsSUFBSSxDQUFDO1FBQzlCOztXQUVHO1FBQ0gsZ0JBQVUsR0FBUyxLQUFLLENBQUM7UUFFekI7O1dBRUc7UUFDSCxxQkFBZSxHQUF5QixJQUFJLENBQUM7UUFFN0M7O1dBRUc7UUFDSCxjQUFRLEdBQXlCLElBQUksQ0FBQztRQUV0Qzs7V0FFRztRQUNILHNCQUFnQixHQUFjLElBQUksQ0FBQztRQUVuQzs7V0FFRztRQUNILGNBQVEsR0FBUSxDQUFDLENBQUM7UUFFbEI7O1dBRUc7UUFDSCxtQkFBYSxHQUFTLEtBQUssQ0FBQzs7SUF1UWhDLENBQUM7ZUF2U29CLE1BQU07SUFrQ3ZCLGVBQWU7SUFFZixzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBQyxHQUFHLENBQUM7UUFDbEIsNkJBQTZCO1FBQzdCLG9EQUFvRDtRQUNwRCx1REFBdUQ7UUFDdkQseUJBQXlCO1FBQ3pCLHVEQUF1RDtJQUMzRCxDQUFDO0lBRUQsaUNBQWdCLEdBQWhCLFVBQWlCLFdBQTBCLEVBQUMsSUFBSTtRQUM1QyxFQUFFLENBQUMsR0FBRyxDQUFDLHlDQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJDQUFhLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxtREFBZ0IsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFNLENBQUMsQ0FBQTtRQUNyRyxJQUFHLElBQUksSUFBRSxXQUFXLEVBQUM7WUFDakIsSUFBSSxlQUFlLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDNUMsSUFBRyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDO2dCQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN6Qix5QkFBeUI7Z0JBQ3pCLElBQUksT0FBTyxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pDLG1EQUFtRDtnQkFDbkQsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixJQUFHLFFBQVEsS0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDO29CQUM3Qix3REFBd0Q7b0JBQ3hELE9BQU87aUJBQ1Y7cUJBQUs7b0JBQ0YscURBQXFEO29CQUNyRCxrQ0FBa0M7b0JBQ2xDLElBQUksTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFFQUFjLEVBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFNLENBQUMsQ0FBQyxDQUFBO29CQUN2RCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLFFBQU0sQ0FBQyxDQUFDO29CQUMzQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUMsUUFBUSxDQUFDLGdCQUFnQixJQUFJLElBQUksR0FBRyxFQUFXLENBQUM7b0JBQzFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO29CQUNuRSxPQUFPO2lCQUNWO2FBQ0o7aUJBQUs7Z0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLGdCQUFnQixHQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxJQUFJLEdBQUcsRUFBVyxDQUFDO2dCQUNoRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMvQztTQUNKO1FBRUQsNENBQTRDO1FBQzVDLDBCQUEwQjtRQUMxQiw0QkFBNEI7UUFDNUIsa0RBQWtEO1FBQ2xELDRDQUE0QztRQUM1Qyw2QkFBNkI7UUFDN0Isb0RBQW9EO1FBQ3BELElBQUk7UUFDSixvQkFBb0I7UUFDcEIseUJBQXlCO1FBQ3pCLDRCQUE0QjtRQUM1QixFQUFFO1FBQ0YsMEJBQTBCO1FBQzFCLCtCQUErQjtRQUMvQixFQUFFO1FBQ0YsY0FBYztRQUNkLDJCQUEyQjtRQUMzQixFQUFFO1FBQ0YscUJBQXFCO1FBQ3JCLHdCQUF3QjtRQUN4QiwwQkFBMEI7UUFDMUIsRUFBRTtRQUNGLDZCQUE2QjtRQUM3Qix5QkFBeUI7SUFDN0IsQ0FBQztJQUNELGdDQUFlLEdBQWYsVUFBZ0IsV0FBMEIsRUFBQyxJQUFJO1FBQzNDLElBQUksZUFBZSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzVDLEVBQUUsQ0FBQyxHQUFHLENBQUMsK0NBQWUsZUFBaUIsQ0FBQyxDQUFBO1FBQ3hDLElBQUcsSUFBSSxJQUFFLFdBQVcsRUFBQztZQUNqQixJQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUM7Z0JBQ2hDLG1EQUFtRDtnQkFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDM0IsSUFBSSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQ3JDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBTSxDQUFDLENBQUM7Z0JBQzNDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUMsUUFBUSxDQUFDLENBQUE7Z0JBQzNDLElBQUcsUUFBUSxDQUFDLGdCQUFnQixJQUFFLElBQUksRUFBQztvQkFDL0IsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQy9DO2FBQ0o7aUJBQUs7Z0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDNUIsSUFBRyxJQUFJLElBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFDO29CQUMzQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDbEQ7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsMEJBQVMsR0FBVDtRQUNJLElBQUcsSUFBSSxJQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBQztZQUMzQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRUQsdUJBQU0sR0FBTixVQUFRLEVBQUU7UUFDTixJQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztZQUNoQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHNDQUFzQztRQUN0QywyREFBMkQ7UUFDM0QsSUFBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQztZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzdELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQTtTQUM3QjtRQUNELElBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFFLENBQUMsRUFBQztZQUN4RCxJQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN0QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLEtBQUssR0FBQyxFQUFFLENBQUM7UUFDL0MsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDO1FBRS9DLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzlCLHVEQUF1RDtJQUMzRCxDQUFDO0lBRUQsdUJBQU0sR0FBTixVQUFPLEtBQVksRUFBQyxLQUFZO1FBQzVCLG1DQUFtQztRQUNuQyxzQ0FBc0M7UUFDdEMsMENBQTBDO1FBQzFDLG1CQUFtQjtRQUNuQixJQUFHLElBQUksQ0FBQyxhQUFhLEVBQUM7WUFDbEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQ25DLEVBQUU7UUFDRixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRTFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekQsRUFBRTtRQUVGLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUM7WUFDVixHQUFHLEVBQUMsS0FBSztZQUNULEdBQUcsRUFBQyxLQUFLO1NBQ1osQ0FBQztRQUNGLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCxxQkFBSSxHQUFKLFVBQUssS0FBWSxFQUFDLEtBQVk7UUFBOUIsaUJBb0RDO1FBbkRHLElBQUcsSUFBSSxDQUFDLGFBQWEsRUFBQztZQUNsQixPQUFPO1NBQ1Y7UUFHRCxJQUFJLENBQUMsYUFBYSxHQUFDLElBQUksQ0FBQztRQUN4QixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHlCQUF5QjtRQUN6Qiw0Q0FBNEM7UUFDNUMsSUFBSTtRQUVKLElBQUksUUFBUSxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pELElBQUksVUFBVSxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBQyxLQUFLLENBQUMsQ0FBQztRQUMxRCxJQUFJLElBQUksR0FBQyxJQUFJLENBQUM7UUFFZCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFDLFVBQVUsQ0FBQyxDQUFDO1FBSXJDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVLEVBQUM7WUFDekMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QixJQUFJLENBQUMsYUFBYSxHQUFDLEtBQUssQ0FBQztRQUU3QixDQUFDLENBQUMsQ0FBQztRQUNILElBQUcsSUFBSSxDQUFDLGdCQUFnQixJQUFFLElBQUksSUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFFLENBQUMsRUFBQztZQUMxRCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFVBQUMsWUFBWTtZQUN4QyxJQUFHLFlBQVksSUFBRSxJQUFJLEVBQUM7Z0JBQ2xCLE9BQU87YUFDVjtZQUNELElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7WUFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyw2QkFBNkI7WUFDN0IsSUFBRyxNQUFNLEtBQUcsYUFBYSxFQUFDO2dCQUNyQixPQUFPO2FBQ1g7WUFDRCxlQUFlO1lBQ2YsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBQyxFQUFFLEVBQUM7Z0JBQ2pELE9BQU87YUFDVjtZQUNELHVCQUF1QjtZQUN2QixJQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxFQUFFLElBQUUsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsSUFBRSxLQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsRUFBQztnQkFDdEQsT0FBTzthQUNWO1lBQ0QsWUFBWSxDQUFDLFlBQVksQ0FBQyxRQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUM7SUFHUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsMkJBQVUsR0FBVixVQUFXLElBQVc7UUFDbEIsSUFBRyxJQUFJLEdBQUMsQ0FBQyxFQUFDO1lBQ04sT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVqRCw2QkFBNkI7UUFDN0IsSUFBSSxJQUFJLEdBQUMsSUFBSSxDQUFDO1FBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNWLFlBQVk7WUFDWixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxNQUFNLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdDLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM5QyxTQUFTLEdBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hELFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDO1lBQ3RCLDBDQUEwQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUM5QixFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztpQkFDZCxFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxDQUFDO2lCQUNuQixFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxDQUFDO2lCQUNuQixFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsQ0FBQyxFQUFDLEVBQUUsRUFBQyxPQUFPLEVBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQztpQkFDM0IsS0FBSyxFQUFFLENBQUM7WUFFYixJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNWLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN4QixDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUM7WUFHUCxJQUFHLElBQUksQ0FBQyxRQUFRLElBQUUsQ0FBQyxFQUFDO2dCQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDZDtRQUNMLENBQUMsRUFBRSxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hCLENBQUM7SUFDRCxvQkFBRyxHQUFIO1FBQ0ksSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQ2Qsd0JBQXdCO1lBQ3hCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxLQUFLLENBQUMsQ0FBQztRQUMxQyxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNkLENBQUM7O0lBblNEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7K0NBQ1U7SUFIYixNQUFNO1FBRDFCLE9BQU87T0FDYSxNQUFNLENBdVMxQjtJQUFELGFBQUM7Q0F2U0QsQUF1U0MsQ0F2U21DLEVBQUUsQ0FBQyxTQUFTLEdBdVMvQztrQkF2U29CLE1BQU0iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuY29uc3Qgc3BlZWQ9MTIwO1xyXG5jb25zdCBjdXN0b21TY2FsZVg9MC43O1xyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb21tb24gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICByYW5nZUF0dGFjazogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIC8qKlxyXG4gICAgICog5piv5ZCm5Zyo56e75YqoXHJcbiAgICAgKi9cclxuICAgIF9iSXNNb3Zpbmc6Ym9vbGVhbj1mYWxzZTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOenu+WKqOaWueWQkVxyXG4gICAgICovXHJcbiAgICBfb01vdmVEaXJlY3Rpb246e19uWDpudW1iZXIsX25ZOm51bWJlcn09bnVsbDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOebruagh+S9jee9rlxyXG4gICAgICovXHJcbiAgICBfb01vdmVUbzp7X25YOm51bWJlcixfblk6bnVtYmVyfT1udWxsO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICrlj6/ku6XmlLvlh7vnmoTnm67moIfpm4blkIhcclxuICAgICAqL1xyXG4gICAgX29BdHRrYWJsZU9ialNldDpTZXQ8Y2MuTm9kZT49bnVsbDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOW9k+WJjeihgOmHj1xyXG4gICAgICovXHJcbiAgICBfbkN1cnJIcDpudW1iZXI9MDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOaYr+WQpuato+WcqOaUu+WHu1xyXG4gICAgICovXHJcbiAgICBfYklzQXR0YWNraW5nOmJvb2xlYW49ZmFsc2U7XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuX25DdXJySHA9MTAwO1xyXG4gICAgICAgIC8vIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gbGV0IHNrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8uYW5jaG9yWScsIG9DdXJySGVyby5hbmNob3JZKTtcclxuICAgICAgICAvLyBvQ3Vyckhlcm8uYW5jaG9yWT0xMDA7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVyby5hbmNob3JZJywgb0N1cnJIZXJvLmFuY2hvclkpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXIob0Fub3RoZXJCb3g6Y2MuQm94Q29sbGlkZXIsc2VsZik6dm9pZHtcclxuICAgICAgICBjYy5sb2coYOiHquW3seeahOWQjeWtl++8miR7c2VsZi5ub2RlW1wiX25hbWVcIl19LOW9k+WJjW5vZGXlkI3lrZfvvJoke3RoaXMubm9kZS5uYW1lfSznorDliLDlhbblroPniankvZMsbmFtZT0ke29Bbm90aGVyQm94Lm5vZGUubmFtZX1gKVxyXG4gICAgICAgIGlmKG51bGwhPW9Bbm90aGVyQm94KXtcclxuICAgICAgICAgICAgbGV0IG9Bbm90aGVyQm94TmFtZSA9IG9Bbm90aGVyQm94Lm5vZGUubmFtZTtcclxuICAgICAgICAgICAgaWYob0Fub3RoZXJCb3hOYW1lLmluZGV4T2YoXCJfXCIpIT0tMSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuiiq+eisOaSnueahOaYr+aUu+WHu+ebkuWtkFwiKTtcclxuICAgICAgICAgICAgICAgIC8v5b2T6KKr56Kw5pKe55qE55uS5a2Q55qE5ZCN56ew5YyF5ZCr5LiL5YiS57q/77yM6K+05piO5piv5pS75Ye755uS5a2QXHJcbiAgICAgICAgICAgICAgICBsZXQgc3RyaW5ncyA9IG9Bbm90aGVyQm94TmFtZS5zcGxpdChcIl9cIik7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhgb0Fub3RoZXJCb3hOYW1l55qE5YmN57yA77yaJHtzdHJpbmdzWzBdfWApO1xyXG4gICAgICAgICAgICAgICAgbGV0IGhlcm9OYW1lID0gc3RyaW5nc1swXTtcclxuICAgICAgICAgICAgICAgIGlmKGhlcm9OYW1lPT09c2VsZi5ub2RlW1wiX25hbWVcIl0pe1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aaC5p6c6KKr56Kw5pKe55qE55uS5a2Q5omA5bGe6IqC54K555qE5ZCN56ew5YmN57yA77yI5LiA5Liq5pS75Ye755uS5a2Q77yJ562J5LqO5b2T5YmN6IqC54K555qE5ZCN56ew77yM6K+05piO6L+Z5Liq5pS75Ye755uS5a2Q5bGe5LqO5b2T5YmN6IqC54K577yM5LiN5YGa5pON5L2cXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aaC5p6c6KKr56Kw5pKe55qE55uS5a2Q5omA5bGe6IqC54K555qE5ZCN56ew5YmN57yA77yI5LiA5Liq5pS75Ye755uS5a2Q77yJ5LiN562J5LqO5b2T5YmN6IqC54K555qE5ZCN56ew77yM6K+05piO6L+Z5Liq5pS75Ye755uS5a2Q5LiN5bGe5LqO5b2T5YmN6IqC54K5XHJcbiAgICAgICAgICAgICAgICAgICAgLy/pgqPkuYjopoHmib7liLDov5nkuKrmlLvlh7vnm5LlrZDnmoTniLboioLngrlh77yM5bCG5b2T5YmN6IqC54K55Yqg5YWlYeeahOeisOaSnnNldOS4rVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBwYXJlbnQgPSBvQW5vdGhlckJveC5ub2RlLnBhcmVudDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhg5pS75Ye755uS5a2Q55qE54i26IqC54K555qE57uE5Lu2OmAscGFyZW50LmdldENvbXBvbmVudChDb21tb24pKVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBmdUNvbW1vbiA9IHBhcmVudC5nZXRDb21wb25lbnQoQ29tbW9uKTtcclxuICAgICAgICAgICAgICAgICAgICBmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0PWZ1Q29tbW9uLl9vQXR0a2FibGVPYmpTZXQgfHwgbmV3IFNldDxjYy5Ob2RlPigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1Q29tbW9uLl9vQXR0a2FibGVPYmpTZXQuYWRkKHNlbGYubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NvbXBvbmVudC5fb0F0dGthYmxlT2JqU2V0JyxmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0KVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLooqvnorDmkp7nmoTmmK/kurrnialcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQ9dGhpcy5fb0F0dGthYmxlT2JqU2V0fHxuZXcgU2V0PGNjLk5vZGU+KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQuYWRkKG9Bbm90aGVyQm94Lm5vZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDnorDmkp7ns7vnu5/kvJrorqHnrpflh7rnorDmkp7nu4Tku7blnKjkuJbnlYzlnZDmoIfns7vkuIvnmoTnm7jlhbPnmoTlgLzvvIzlubbmlL7liLAgd29ybGQg6L+Z5Liq5bGe5oCn6YeM6Z2iXHJcbiAgICAgICAgLy8gdmFyIHdvcmxkID0gc2VsZi53b3JsZDtcclxuICAgICAgICAvLyBsZXQgcG9pbnRzID0gc2VsZi5wb2ludHM7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coYCR7dGhpcy5ub2RlLm5hbWV9LHBvaW50c2AscG9pbnRzKTtcclxuICAgICAgICAvLyBmb3IgKGxldCBpID0gMDsgaSA8IHBvaW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgIC8vICAgICBsZXQgcG9pbnQgPSBwb2ludHNbaV07XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGAke3RoaXMubm9kZS5uYW1lfSxwb2ludGAscG9pbnQpO1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyAvLyDnorDmkp7nu4Tku7bnmoQgYWFiYiDnorDmkp7moYZcclxuICAgICAgICAvLyB2YXIgYWFiYiA9IHdvcmxkLmFhYmI7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2FhYmInLGFhYmIpO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g5LiK5LiA5qyh6K6h566X55qE56Kw5pKe57uE5Lu255qEIGFhYmIg56Kw5pKe5qGGXHJcbiAgICAgICAgLy8gdmFyIHByZUFhYmIgPSB3b3JsZC5wcmVBYWJiO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g56Kw5pKe5qGG55qE5LiW55WM55+p6Zi1XHJcbiAgICAgICAgLy8gdmFyIHQgPSB3b3JsZC50cmFuc2Zvcm07XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyAvLyDku6XkuIvlsZ7mgKfkuLrlnIblvaLnorDmkp7nu4Tku7bnibnmnInlsZ7mgKdcclxuICAgICAgICAvLyB2YXIgciA9IHdvcmxkLnJhZGl1cztcclxuICAgICAgICAvLyB2YXIgcCA9IHdvcmxkLnBvc2l0aW9uO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g5Lul5LiL5bGe5oCn5Li6IOefqeW9oiDlkowg5aSa6L655b2iIOeisOaSnue7hOS7tueJueacieWxnuaAp1xyXG4gICAgICAgIC8vIHZhciBwcyA9IHdvcmxkLnBvaW50cztcclxuICAgIH1cclxuICAgIG9uQ29sbGlzaW9uRXhpdChvQW5vdGhlckJveDpjYy5Cb3hDb2xsaWRlcixzZWxmKTp2b2lke1xyXG4gICAgICAgIGxldCBvQW5vdGhlckJveE5hbWUgPSBvQW5vdGhlckJveC5ub2RlLm5hbWU7XHJcbiAgICAgICAgY2MubG9nKGDnprvlvIDlhbblroPniankvZMsbmFtZT0ke29Bbm90aGVyQm94TmFtZX1gKVxyXG4gICAgICAgIGlmKG51bGwhPW9Bbm90aGVyQm94KXtcclxuICAgICAgICAgICAgaWYob0Fub3RoZXJCb3hOYW1lLmluZGV4T2YoXCJfXCIpIT0tMSl7XHJcbiAgICAgICAgICAgICAgICAvL+W9k+iiq+eisOaSnueahOebkuWtkOeahOWQjeensOWMheWQq+S4i+WIkue6v++8jOivtOaYjuaYr+aUu+WHu+ebkuWtkO+8jOmCo+S5iOimgeaJvuWIsOS7lueahOeItuiKgueCue+8jOS7jueItuiKgueCueS4reenu+mZpHNlbGbnmoToioLngrlcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6KKr56a75byA56Kw5pKe55qE5piv5pS75Ye755uS5a2QXCIpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHBhcmVudCA9IG9Bbm90aGVyQm94Lm5vZGUucGFyZW50O1xyXG4gICAgICAgICAgICAgICAgbGV0IGZ1Q29tbW9uID0gcGFyZW50LmdldENvbXBvbmVudChDb21tb24pO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+OAkOemu+W8gOOAkeaUu+WHu+ebkuWtkOeahOeItuiKgueCueeahENvbW1vbicsZnVDb21tb24pXHJcbiAgICAgICAgICAgICAgICBpZihmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0IT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICBmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0LmRlbGV0ZShzZWxmLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuiiq+emu+W8gOeisOaSnueahOaYr+iLsembhOeahOebkuWtkFwiKTtcclxuICAgICAgICAgICAgICAgIGlmKG51bGwhPXRoaXMuX29BdHRrYWJsZU9ialNldCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb0F0dGthYmxlT2JqU2V0LmRlbGV0ZShvQW5vdGhlckJveC5ub2RlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiKgueCuemUgOavgeaXtu+8jOa4heepuumbhuWQiO+8jOmBv+WFjeWGheWtmOiwouiQvVxyXG4gICAgICovXHJcbiAgICBvbkRlc3Ryb3koKTp2b2lke1xyXG4gICAgICAgIGlmKG51bGwhPXRoaXMuX29BdHRrYWJsZU9ialNldCl7XHJcbiAgICAgICAgICAgIHRoaXMuX29BdHRrYWJsZU9ialNldC5jbGVhcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgaWYoIXRoaXMuX2JJc01vdmluZyl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVybycsb0N1cnJIZXJvKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fb01vdmVEaXJlY3Rpb24nLHRoaXMuX29Nb3ZlRGlyZWN0aW9uKVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueDw9dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWDwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueD49dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueTw9dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWTwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueT49dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD09MCYmdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPWZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgc2tlbGV0b24gPSBvQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3N0YW5kJyx0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLngrPXRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWCpzcGVlZCpkdDtcclxuICAgICAgICBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKnNwZWVkKmR0O1xyXG5cclxuICAgICAgICBvQ3Vyckhlcm8uekluZGV4PS1vQ3Vyckhlcm8ueTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLm5vZGUsXCJvQ3Vyckhlcm9cIixvQ3Vyckhlcm8uekluZGV4KTtcclxuICAgIH1cclxuXHJcbiAgICBtb3ZlVG8oblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5Nb3ZlVG9YXCIsbk1vdmVUb1gpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb01vdmVUb1YyLngnLG9Nb3ZlVG9WMi54KTtcclxuICAgICAgICAvL+ato+WcqOaUu+WHu+eahOivne+8jOS4jeiuqeS7luenu+WKqO+8jOmBv+WFjVLpl6pcclxuICAgICAgICBpZih0aGlzLl9iSXNBdHRhY2tpbmcpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uPXtfblg6MCxfblk6MH07XHJcbiAgICAgICAgLy9cclxuICAgICAgICBsZXQgb0N1cnJIZXJvID0gdGhpcy5ub2RlO1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZygnb0N1cnJIZXJvJyxvQ3Vyckhlcm8pO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0ob0N1cnJIZXJvLng8PW5Qb3NYKT8xOi0xO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0ob0N1cnJIZXJvLnk8PW5Qb3NZKT8xOi0xO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0aGlzLl9vTW92ZURpcmVjdGlvbicsdGhpcy5fb01vdmVEaXJlY3Rpb24pO1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIG9DdXJySGVyby5zY2FsZVg9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25YKmN1c3RvbVNjYWxlWDtcclxuICAgICAgICB0aGlzLl9vTW92ZVRvPXtcclxuICAgICAgICAgICAgX25YOm5Qb3NYLFxyXG4gICAgICAgICAgICBfblk6blBvc1ksXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZighdGhpcy5fYklzTW92aW5nKXtcclxuICAgICAgICAgICAgbGV0IG9Ta2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgb1NrZWxldG9uLnNldEFuaW1hdGlvbigxLCd3YWxrJyx0cnVlKTtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPXRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGF0dGsoblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICBpZih0aGlzLl9iSXNBdHRhY2tpbmcpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fYklzQXR0YWNraW5nPXRydWU7XHJcbiAgICAgICAgbGV0IG9DdXJySGVybyA9IHRoaXMubm9kZTtcclxuICAgICAgICAvLyBpZihuUG9zWDxvQ3Vyckhlcm8ueCl7XHJcbiAgICAgICAgLy8gICAgIG9DdXJySGVyby5zY2FsZVg9b0N1cnJIZXJvLnNjYWxlWCotMTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIGxldCBza2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICBsZXQgdHJhY2VFbnRyeSA9IHNrZWxldG9uLnNldEFuaW1hdGlvbigyLCdza2lsbDAxJyxmYWxzZSk7XHJcbiAgICAgICAgbGV0IHNlbGY9dGhpcztcclxuXHJcbiAgICAgICAgbGV0IGNvbXBvbmVudHMgPSBzZWxmLm5vZGVbJ19jb21wb25lbnRzJ107XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbXBvbmVudHMnLGNvbXBvbmVudHMpO1xyXG5cclxuXHJcblxyXG4gICAgICAgIHNrZWxldG9uLnNldFRyYWNrQ29tcGxldGVMaXN0ZW5lcih0cmFjZUVudHJ5LGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygyKTtcclxuICAgICAgICAgICAgc2VsZi5fYklzQXR0YWNraW5nPWZhbHNlO1xyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZih0aGlzLl9vQXR0a2FibGVPYmpTZXQ9PW51bGx8fHRoaXMuX29BdHRrYWJsZU9ialNldC5zaXplPD0wKXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQuZm9yRWFjaCgob0F0dGthYmxlT2JqKT0+e1xyXG4gICAgICAgICAgIGlmKG9BdHRrYWJsZU9iaj09bnVsbCl7XHJcbiAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgbGV0IG5hbWUgPSBvQXR0a2FibGVPYmoubmFtZTtcclxuICAgICAgICAgICBsZXQgc3VmZml4ID0gbmFtZS5zcGxpdChcIl9cIilbMV07XHJcbiAgICAgICAgICAgLy/lpoLmnpzopoHmlLvlh7vnmoTniankvZPkuLrooqvmlLvlh7vmlrnnmoTnorDmkp7nm5LlrZDvvIznm7TmjqVyZXR1cm5cclxuICAgICAgICAgICBpZihzdWZmaXg9PT0nUmFuZ2VBdHRhY2snKXtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgLy/kuIrkuIvkvY3nva7lt67lpKrlpJrvvIzmiZPkuI3liLDlr7nmlrlcclxuICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLm5vZGUuekluZGV4LW9BdHRrYWJsZU9iai56SW5kZXgpPjY0KXtcclxuICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICAvL+WPjOaWueW3puWPs+S9jee9ruebuOWPje+8jOW5tuacieS4gOautei3neemu++8jOaJk+S4jeWIsOWvueaWuVxyXG4gICAgICAgICAgIGlmKCgob0F0dGthYmxlT2JqLngtdGhpcy5ub2RlLngpPD0tNjQmJnRoaXMubm9kZS5zY2FsZT4wKXx8XHJcbiAgICAgICAgICAgICAgICgob0F0dGthYmxlT2JqLngtdGhpcy5ub2RlLngpPj02NCYmdGhpcy5ub2RlLnNjYWxlPDApKXtcclxuICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBvQXR0a2FibGVPYmouZ2V0Q29tcG9uZW50KENvbW1vbikuc3VidHJhY3RIcCg0MCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiiq+aJk+WHj+ihgOaXtlxyXG4gICAgICogQHBhcmFtIG5WYWxcclxuICAgICAqL1xyXG4gICAgc3VidHJhY3RIcChuVmFsOm51bWJlcik6dm9pZHtcclxuICAgICAgICBpZihuVmFsPDApe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgbGV0IHNrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG5cclxuICAgICAgICAvL+WHj+ihgOaViOaenOimgeW7tuaXtuS4gOS4i++8jOWboOS4uuavj+S4quWwj+eyvueBteeahOaUu+WHu+mDvemcgOimgTHnp5Lku6XkuIpcclxuICAgICAgICBsZXQgc2VsZj10aGlzO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIC8v5YeP6KGA5pe25byA5ZCv6KKr5omT55qE5Yqo55S7XHJcbiAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCdodXJ0JyxmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICBzZWxmLl9uQ3VyckhwPU1hdGgubWF4KHNlbGYuX25DdXJySHAtblZhbCwwKTtcclxuICAgICAgICAgICAgbGV0IG9TdWJCbG9vZCA9IGNjLmZpbmQoXCJTdWJCbG9vZFwiLHNlbGYubm9kZSk7XHJcbiAgICAgICAgICAgIG9TdWJCbG9vZD1jYy5pbnN0YW50aWF0ZShvU3ViQmxvb2QpO1xyXG4gICAgICAgICAgICBvU3ViQmxvb2QuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9blZhbC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICBvU3ViQmxvb2QuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwi5b2T5YmNbm9kZeeahOWQjeWtl1wiLHNlbGYubm9kZS5uYW1lKVxyXG4gICAgICAgICAgICBzZWxmLm5vZGUuYWRkQ2hpbGQob1N1YkJsb29kKTtcclxuICAgICAgICAgICAgY2MudHdlZW4ob1N1YkJsb29kKVxyXG4gICAgICAgICAgICAgICAgLnRvKDAuMCx7c2NhbGU6My4yfSlcclxuICAgICAgICAgICAgICAgIC50bygwLjIse3NjYWxlOjEuMH0pXHJcbiAgICAgICAgICAgICAgICAuYnkoMC40LHt5OjY0LG9wYWNpdHk6LTEyOH0pXHJcbiAgICAgICAgICAgICAgICAuc3RhcnQoKTtcclxuXHJcbiAgICAgICAgICAgIHNlbGYuc2NoZWR1bGUoKCk9PntcclxuICAgICAgICAgICAgICAgIG9TdWJCbG9vZC5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH0sMC42KTtcclxuXHJcblxyXG4gICAgICAgICAgICBpZihzZWxmLl9uQ3VyckhwPD0wKXtcclxuICAgICAgICAgICAgICAgIHNlbGYuZGllKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCAxLjIsMCwwKTtcclxuICAgIH1cclxuICAgIGRpZSgpOnZvaWR7XHJcbiAgICAgICAgbGV0IG9DdXJySGVybyA9IHRoaXMubm9kZTtcclxuICAgICAgICBsZXQgc2tlbGV0b249b0N1cnJIZXJvLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgc2tlbGV0b24uc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIC8vIOi/memHjOeahCB0aGlzIOaMh+WQkSBjb21wb25lbnRcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ2RlYWQnLGZhbHNlKTtcclxuICAgICAgICB9LCAxLDAsMCk7XHJcbiAgICB9XHJcbn1cclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/x.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e1f1429PapFmYvo/wEALQco', 'x');
// script/x.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = 'hello';
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    NewClass.prototype.start = function () {
    };
    __decorate([
        property(cc.Label)
    ], NewClass.prototype, "label", void 0);
    __decorate([
        property
    ], NewClass.prototype, "text", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTVFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBaUJDO1FBZEcsV0FBSyxHQUFhLElBQUksQ0FBQztRQUd2QixVQUFJLEdBQVcsT0FBTyxDQUFDOztRQVV2QixpQkFBaUI7SUFDckIsQ0FBQztJQVRHLHdCQUF3QjtJQUV4QixlQUFlO0lBRWYsd0JBQUssR0FBTDtJQUVBLENBQUM7SUFYRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOzJDQUNJO0lBR3ZCO1FBREMsUUFBUTswQ0FDYztJQU5OLFFBQVE7UUFENUIsT0FBTztPQUNhLFFBQVEsQ0FpQjVCO0lBQUQsZUFBQztDQWpCRCxBQWlCQyxDQWpCcUMsRUFBRSxDQUFDLFNBQVMsR0FpQmpEO2tCQWpCb0IsUUFBUSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTmV3Q2xhc3MgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcclxuICAgIGxhYmVsOiBjYy5MYWJlbCA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5XHJcbiAgICB0ZXh0OiBzdHJpbmcgPSAnaGVsbG8nO1xyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fVxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge31cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/protobuf.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}(function (global){
"use strict";
cc._RF.push(module, '535ecX0K+xF9I7ep13vV1i0', 'protobuf');
// msg/protobuf.js

"use strict";

/*!
 * protobuf.js v6.11.0 (c) 2016, daniel wirtz
 * compiled thu, 29 apr 2021 02:20:44 utc
 * licensed under the bsd-3-clause license
 * see: https://github.com/dcodeio/protobuf.js for details
 */
(function (undefined) {
  "use strict";

  (function prelude(modules, cache, entries) {
    // This is the prelude used to bundle protobuf.js for the browser. Wraps up the CommonJS
    // sources through a conflict-free require shim and is again wrapped within an iife that
    // provides a minification-friendly `undefined` var plus a global "use strict" directive
    // so that minification can remove the directives of each module.
    function $require(name) {
      var $module = cache[name];
      if (!$module) modules[name][0].call($module = cache[name] = {
        exports: {}
      }, $require, $module, $module.exports);
      return $module.exports;
    }

    var protobuf = $require(entries[0]); // Expose globally

    protobuf.util.global.protobuf = protobuf; // Be nice to AMD

    if (typeof define === "function" && define.amd) define(["long"], function (Long) {
      if (Long && Long.isLong) {
        protobuf.util.Long = Long;
        protobuf.configure();
      }

      return protobuf;
    }); // Be nice to CommonJS

    if (typeof module === "object" && module && module.exports) module.exports = protobuf;
  })(
  /* end of prelude */
  {
    1: [function (require, module, exports) {
      "use strict";

      module.exports = asPromise;
      /**
       * Callback as used by {@link util.asPromise}.
       * @typedef asPromiseCallback
       * @type {function}
       * @param {Error|null} error Error, if any
       * @param {...*} params Additional arguments
       * @returns {undefined}
       */

      /**
       * Returns a promise from a node-style callback function.
       * @memberof util
       * @param {asPromiseCallback} fn Function to call
       * @param {*} ctx Function context
       * @param {...*} params Function arguments
       * @returns {Promise<*>} Promisified function
       */

      function asPromise(fn, ctx
      /*, varargs */
      ) {
        var params = new Array(arguments.length - 1),
            offset = 0,
            index = 2,
            pending = true;

        while (index < arguments.length) {
          params[offset++] = arguments[index++];
        }

        return new Promise(function executor(resolve, reject) {
          params[offset] = function callback(err
          /*, varargs */
          ) {
            if (pending) {
              pending = false;
              if (err) reject(err);else {
                var params = new Array(arguments.length - 1),
                    offset = 0;

                while (offset < params.length) {
                  params[offset++] = arguments[offset];
                }

                resolve.apply(null, params);
              }
            }
          };

          try {
            fn.apply(ctx || null, params);
          } catch (err) {
            if (pending) {
              pending = false;
              reject(err);
            }
          }
        });
      }
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * A minimal base64 implementation for number arrays.
       * @memberof util
       * @namespace
       */

      var base64 = exports;
      /**
       * Calculates the byte length of a base64 encoded string.
       * @param {string} string Base64 encoded string
       * @returns {number} Byte length
       */

      base64.length = function length(string) {
        var p = string.length;
        if (!p) return 0;
        var n = 0;

        while (--p % 4 > 1 && string.charAt(p) === "=") {
          ++n;
        }

        return Math.ceil(string.length * 3) / 4 - n;
      }; // Base64 encoding table


      var b64 = new Array(64); // Base64 decoding table

      var s64 = new Array(123); // 65..90, 97..122, 48..57, 43, 47

      for (var i = 0; i < 64;) {
        s64[b64[i] = i < 26 ? i + 65 : i < 52 ? i + 71 : i < 62 ? i - 4 : i - 59 | 43] = i++;
      }
      /**
       * Encodes a buffer to a base64 encoded string.
       * @param {Uint8Array} buffer Source buffer
       * @param {number} start Source start
       * @param {number} end Source end
       * @returns {string} Base64 encoded string
       */


      base64.encode = function encode(buffer, start, end) {
        var parts = null,
            chunk = [];
        var i = 0,
            // output index
        j = 0,
            // goto index
        t; // temporary

        while (start < end) {
          var b = buffer[start++];

          switch (j) {
            case 0:
              chunk[i++] = b64[b >> 2];
              t = (b & 3) << 4;
              j = 1;
              break;

            case 1:
              chunk[i++] = b64[t | b >> 4];
              t = (b & 15) << 2;
              j = 2;
              break;

            case 2:
              chunk[i++] = b64[t | b >> 6];
              chunk[i++] = b64[b & 63];
              j = 0;
              break;
          }

          if (i > 8191) {
            (parts || (parts = [])).push(String.fromCharCode.apply(String, chunk));
            i = 0;
          }
        }

        if (j) {
          chunk[i++] = b64[t];
          chunk[i++] = 61;
          if (j === 1) chunk[i++] = 61;
        }

        if (parts) {
          if (i) parts.push(String.fromCharCode.apply(String, chunk.slice(0, i)));
          return parts.join("");
        }

        return String.fromCharCode.apply(String, chunk.slice(0, i));
      };

      var invalidEncoding = "invalid encoding";
      /**
       * Decodes a base64 encoded string to a buffer.
       * @param {string} string Source string
       * @param {Uint8Array} buffer Destination buffer
       * @param {number} offset Destination offset
       * @returns {number} Number of bytes written
       * @throws {Error} If encoding is invalid
       */

      base64.decode = function decode(string, buffer, offset) {
        var start = offset;
        var j = 0,
            // goto index
        t; // temporary

        for (var i = 0; i < string.length;) {
          var c = string.charCodeAt(i++);
          if (c === 61 && j > 1) break;
          if ((c = s64[c]) === undefined) throw Error(invalidEncoding);

          switch (j) {
            case 0:
              t = c;
              j = 1;
              break;

            case 1:
              buffer[offset++] = t << 2 | (c & 48) >> 4;
              t = c;
              j = 2;
              break;

            case 2:
              buffer[offset++] = (t & 15) << 4 | (c & 60) >> 2;
              t = c;
              j = 3;
              break;

            case 3:
              buffer[offset++] = (t & 3) << 6 | c;
              j = 0;
              break;
          }
        }

        if (j === 1) throw Error(invalidEncoding);
        return offset - start;
      };
      /**
       * Tests if the specified string appears to be base64 encoded.
       * @param {string} string String to test
       * @returns {boolean} `true` if probably base64 encoded, otherwise false
       */


      base64.test = function test(string) {
        return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(string);
      };
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      module.exports = EventEmitter;
      /**
       * Constructs a new event emitter instance.
       * @classdesc A minimal event emitter.
       * @memberof util
       * @constructor
       */

      function EventEmitter() {
        /**
         * Registered listeners.
         * @type {Object.<string,*>}
         * @private
         */
        this._listeners = {};
      }
      /**
       * Registers an event listener.
       * @param {string} evt Event name
       * @param {function} fn Listener
       * @param {*} [ctx] Listener context
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.on = function on(evt, fn, ctx) {
        (this._listeners[evt] || (this._listeners[evt] = [])).push({
          fn: fn,
          ctx: ctx || this
        });
        return this;
      };
      /**
       * Removes an event listener or any matching listeners if arguments are omitted.
       * @param {string} [evt] Event name. Removes all listeners if omitted.
       * @param {function} [fn] Listener to remove. Removes all listeners of `evt` if omitted.
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.off = function off(evt, fn) {
        if (evt === undefined) this._listeners = {};else {
          if (fn === undefined) this._listeners[evt] = [];else {
            var listeners = this._listeners[evt];

            for (var i = 0; i < listeners.length;) {
              if (listeners[i].fn === fn) listeners.splice(i, 1);else ++i;
            }
          }
        }
        return this;
      };
      /**
       * Emits an event by calling its listeners with the specified arguments.
       * @param {string} evt Event name
       * @param {...*} args Arguments
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.emit = function emit(evt) {
        var listeners = this._listeners[evt];

        if (listeners) {
          var args = [],
              i = 1;

          for (; i < arguments.length;) {
            args.push(arguments[i++]);
          }

          for (i = 0; i < listeners.length;) {
            listeners[i].fn.apply(listeners[i++].ctx, args);
          }
        }

        return this;
      };
    }, {}],
    4: [function (require, module, exports) {
      "use strict";

      module.exports = factory(factory);
      /**
       * Reads / writes floats / doubles from / to buffers.
       * @name util.float
       * @namespace
       */

      /**
       * Writes a 32 bit float to a buffer using little endian byte order.
       * @name util.float.writeFloatLE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Writes a 32 bit float to a buffer using big endian byte order.
       * @name util.float.writeFloatBE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Reads a 32 bit float from a buffer using little endian byte order.
       * @name util.float.readFloatLE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Reads a 32 bit float from a buffer using big endian byte order.
       * @name util.float.readFloatBE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Writes a 64 bit double to a buffer using little endian byte order.
       * @name util.float.writeDoubleLE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Writes a 64 bit double to a buffer using big endian byte order.
       * @name util.float.writeDoubleBE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Reads a 64 bit double from a buffer using little endian byte order.
       * @name util.float.readDoubleLE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Reads a 64 bit double from a buffer using big endian byte order.
       * @name util.float.readDoubleBE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */
      // Factory function for the purpose of node-based testing in modified global environments

      function factory(exports) {
        // float: typed array
        if (typeof Float32Array !== "undefined") (function () {
          var f32 = new Float32Array([-0]),
              f8b = new Uint8Array(f32.buffer),
              le = f8b[3] === 128;

          function writeFloat_f32_cpy(val, buf, pos) {
            f32[0] = val;
            buf[pos] = f8b[0];
            buf[pos + 1] = f8b[1];
            buf[pos + 2] = f8b[2];
            buf[pos + 3] = f8b[3];
          }

          function writeFloat_f32_rev(val, buf, pos) {
            f32[0] = val;
            buf[pos] = f8b[3];
            buf[pos + 1] = f8b[2];
            buf[pos + 2] = f8b[1];
            buf[pos + 3] = f8b[0];
          }
          /* istanbul ignore next */


          exports.writeFloatLE = le ? writeFloat_f32_cpy : writeFloat_f32_rev;
          /* istanbul ignore next */

          exports.writeFloatBE = le ? writeFloat_f32_rev : writeFloat_f32_cpy;

          function readFloat_f32_cpy(buf, pos) {
            f8b[0] = buf[pos];
            f8b[1] = buf[pos + 1];
            f8b[2] = buf[pos + 2];
            f8b[3] = buf[pos + 3];
            return f32[0];
          }

          function readFloat_f32_rev(buf, pos) {
            f8b[3] = buf[pos];
            f8b[2] = buf[pos + 1];
            f8b[1] = buf[pos + 2];
            f8b[0] = buf[pos + 3];
            return f32[0];
          }
          /* istanbul ignore next */


          exports.readFloatLE = le ? readFloat_f32_cpy : readFloat_f32_rev;
          /* istanbul ignore next */

          exports.readFloatBE = le ? readFloat_f32_rev : readFloat_f32_cpy; // float: ieee754
        })();else (function () {
          function writeFloat_ieee754(writeUint, val, buf, pos) {
            var sign = val < 0 ? 1 : 0;
            if (sign) val = -val;
            if (val === 0) writeUint(1 / val > 0 ?
            /* positive */
            0 :
            /* negative 0 */
            2147483648, buf, pos);else if (isNaN(val)) writeUint(2143289344, buf, pos);else if (val > 3.4028234663852886e+38) // +-Infinity
              writeUint((sign << 31 | 2139095040) >>> 0, buf, pos);else if (val < 1.1754943508222875e-38) // denormal
              writeUint((sign << 31 | Math.round(val / 1.401298464324817e-45)) >>> 0, buf, pos);else {
              var exponent = Math.floor(Math.log(val) / Math.LN2),
                  mantissa = Math.round(val * Math.pow(2, -exponent) * 8388608) & 8388607;
              writeUint((sign << 31 | exponent + 127 << 23 | mantissa) >>> 0, buf, pos);
            }
          }

          exports.writeFloatLE = writeFloat_ieee754.bind(null, writeUintLE);
          exports.writeFloatBE = writeFloat_ieee754.bind(null, writeUintBE);

          function readFloat_ieee754(readUint, buf, pos) {
            var uint = readUint(buf, pos),
                sign = (uint >> 31) * 2 + 1,
                exponent = uint >>> 23 & 255,
                mantissa = uint & 8388607;
            return exponent === 255 ? mantissa ? NaN : sign * Infinity : exponent === 0 // denormal
            ? sign * 1.401298464324817e-45 * mantissa : sign * Math.pow(2, exponent - 150) * (mantissa + 8388608);
          }

          exports.readFloatLE = readFloat_ieee754.bind(null, readUintLE);
          exports.readFloatBE = readFloat_ieee754.bind(null, readUintBE);
        })(); // double: typed array

        if (typeof Float64Array !== "undefined") (function () {
          var f64 = new Float64Array([-0]),
              f8b = new Uint8Array(f64.buffer),
              le = f8b[7] === 128;

          function writeDouble_f64_cpy(val, buf, pos) {
            f64[0] = val;
            buf[pos] = f8b[0];
            buf[pos + 1] = f8b[1];
            buf[pos + 2] = f8b[2];
            buf[pos + 3] = f8b[3];
            buf[pos + 4] = f8b[4];
            buf[pos + 5] = f8b[5];
            buf[pos + 6] = f8b[6];
            buf[pos + 7] = f8b[7];
          }

          function writeDouble_f64_rev(val, buf, pos) {
            f64[0] = val;
            buf[pos] = f8b[7];
            buf[pos + 1] = f8b[6];
            buf[pos + 2] = f8b[5];
            buf[pos + 3] = f8b[4];
            buf[pos + 4] = f8b[3];
            buf[pos + 5] = f8b[2];
            buf[pos + 6] = f8b[1];
            buf[pos + 7] = f8b[0];
          }
          /* istanbul ignore next */


          exports.writeDoubleLE = le ? writeDouble_f64_cpy : writeDouble_f64_rev;
          /* istanbul ignore next */

          exports.writeDoubleBE = le ? writeDouble_f64_rev : writeDouble_f64_cpy;

          function readDouble_f64_cpy(buf, pos) {
            f8b[0] = buf[pos];
            f8b[1] = buf[pos + 1];
            f8b[2] = buf[pos + 2];
            f8b[3] = buf[pos + 3];
            f8b[4] = buf[pos + 4];
            f8b[5] = buf[pos + 5];
            f8b[6] = buf[pos + 6];
            f8b[7] = buf[pos + 7];
            return f64[0];
          }

          function readDouble_f64_rev(buf, pos) {
            f8b[7] = buf[pos];
            f8b[6] = buf[pos + 1];
            f8b[5] = buf[pos + 2];
            f8b[4] = buf[pos + 3];
            f8b[3] = buf[pos + 4];
            f8b[2] = buf[pos + 5];
            f8b[1] = buf[pos + 6];
            f8b[0] = buf[pos + 7];
            return f64[0];
          }
          /* istanbul ignore next */


          exports.readDoubleLE = le ? readDouble_f64_cpy : readDouble_f64_rev;
          /* istanbul ignore next */

          exports.readDoubleBE = le ? readDouble_f64_rev : readDouble_f64_cpy; // double: ieee754
        })();else (function () {
          function writeDouble_ieee754(writeUint, off0, off1, val, buf, pos) {
            var sign = val < 0 ? 1 : 0;
            if (sign) val = -val;

            if (val === 0) {
              writeUint(0, buf, pos + off0);
              writeUint(1 / val > 0 ?
              /* positive */
              0 :
              /* negative 0 */
              2147483648, buf, pos + off1);
            } else if (isNaN(val)) {
              writeUint(0, buf, pos + off0);
              writeUint(2146959360, buf, pos + off1);
            } else if (val > 1.7976931348623157e+308) {
              // +-Infinity
              writeUint(0, buf, pos + off0);
              writeUint((sign << 31 | 2146435072) >>> 0, buf, pos + off1);
            } else {
              var mantissa;

              if (val < 2.2250738585072014e-308) {
                // denormal
                mantissa = val / 5e-324;
                writeUint(mantissa >>> 0, buf, pos + off0);
                writeUint((sign << 31 | mantissa / 4294967296) >>> 0, buf, pos + off1);
              } else {
                var exponent = Math.floor(Math.log(val) / Math.LN2);
                if (exponent === 1024) exponent = 1023;
                mantissa = val * Math.pow(2, -exponent);
                writeUint(mantissa * 4503599627370496 >>> 0, buf, pos + off0);
                writeUint((sign << 31 | exponent + 1023 << 20 | mantissa * 1048576 & 1048575) >>> 0, buf, pos + off1);
              }
            }
          }

          exports.writeDoubleLE = writeDouble_ieee754.bind(null, writeUintLE, 0, 4);
          exports.writeDoubleBE = writeDouble_ieee754.bind(null, writeUintBE, 4, 0);

          function readDouble_ieee754(readUint, off0, off1, buf, pos) {
            var lo = readUint(buf, pos + off0),
                hi = readUint(buf, pos + off1);
            var sign = (hi >> 31) * 2 + 1,
                exponent = hi >>> 20 & 2047,
                mantissa = 4294967296 * (hi & 1048575) + lo;
            return exponent === 2047 ? mantissa ? NaN : sign * Infinity : exponent === 0 // denormal
            ? sign * 5e-324 * mantissa : sign * Math.pow(2, exponent - 1075) * (mantissa + 4503599627370496);
          }

          exports.readDoubleLE = readDouble_ieee754.bind(null, readUintLE, 0, 4);
          exports.readDoubleBE = readDouble_ieee754.bind(null, readUintBE, 4, 0);
        })();
        return exports;
      } // uint helpers


      function writeUintLE(val, buf, pos) {
        buf[pos] = val & 255;
        buf[pos + 1] = val >>> 8 & 255;
        buf[pos + 2] = val >>> 16 & 255;
        buf[pos + 3] = val >>> 24;
      }

      function writeUintBE(val, buf, pos) {
        buf[pos] = val >>> 24;
        buf[pos + 1] = val >>> 16 & 255;
        buf[pos + 2] = val >>> 8 & 255;
        buf[pos + 3] = val & 255;
      }

      function readUintLE(buf, pos) {
        return (buf[pos] | buf[pos + 1] << 8 | buf[pos + 2] << 16 | buf[pos + 3] << 24) >>> 0;
      }

      function readUintBE(buf, pos) {
        return (buf[pos] << 24 | buf[pos + 1] << 16 | buf[pos + 2] << 8 | buf[pos + 3]) >>> 0;
      }
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      module.exports = inquire;
      /**
       * Requires a module only if available.
       * @memberof util
       * @param {string} moduleName Module to require
       * @returns {?Object} Required module if available and not empty, otherwise `null`
       */

      function inquire(moduleName) {
        try {
          var mod = eval("quire".replace(/^/, "re"))(moduleName); // eslint-disable-line no-eval

          if (mod && (mod.length || Object.keys(mod).length)) return mod;
        } catch (e) {} // eslint-disable-line no-empty


        return null;
      }
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      module.exports = pool;
      /**
       * An allocator as used by {@link util.pool}.
       * @typedef PoolAllocator
       * @type {function}
       * @param {number} size Buffer size
       * @returns {Uint8Array} Buffer
       */

      /**
       * A slicer as used by {@link util.pool}.
       * @typedef PoolSlicer
       * @type {function}
       * @param {number} start Start offset
       * @param {number} end End offset
       * @returns {Uint8Array} Buffer slice
       * @this {Uint8Array}
       */

      /**
       * A general purpose buffer pool.
       * @memberof util
       * @function
       * @param {PoolAllocator} alloc Allocator
       * @param {PoolSlicer} slice Slicer
       * @param {number} [size=8192] Slab size
       * @returns {PoolAllocator} Pooled allocator
       */

      function pool(alloc, slice, size) {
        var SIZE = size || 8192;
        var MAX = SIZE >>> 1;
        var slab = null;
        var offset = SIZE;
        return function pool_alloc(size) {
          if (size < 1 || size > MAX) return alloc(size);

          if (offset + size > SIZE) {
            slab = alloc(SIZE);
            offset = 0;
          }

          var buf = slice.call(slab, offset, offset += size);
          if (offset & 7) // align to 32 bit
            offset = (offset | 7) + 1;
          return buf;
        };
      }
    }, {}],
    7: [function (require, module, exports) {
      "use strict";
      /**
       * A minimal UTF8 implementation for number arrays.
       * @memberof util
       * @namespace
       */

      var utf8 = exports;
      /**
       * Calculates the UTF8 byte length of a string.
       * @param {string} string String
       * @returns {number} Byte length
       */

      utf8.length = function utf8_length(string) {
        var len = 0,
            c = 0;

        for (var i = 0; i < string.length; ++i) {
          c = string.charCodeAt(i);
          if (c < 128) len += 1;else if (c < 2048) len += 2;else if ((c & 0xFC00) === 0xD800 && (string.charCodeAt(i + 1) & 0xFC00) === 0xDC00) {
            ++i;
            len += 4;
          } else len += 3;
        }

        return len;
      };
      /**
       * Reads UTF8 bytes as a string.
       * @param {Uint8Array} buffer Source buffer
       * @param {number} start Source start
       * @param {number} end Source end
       * @returns {string} String read
       */


      utf8.read = function utf8_read(buffer, start, end) {
        var len = end - start;
        if (len < 1) return "";
        var parts = null,
            chunk = [],
            i = 0,
            // char offset
        t; // temporary

        while (start < end) {
          t = buffer[start++];
          if (t < 128) chunk[i++] = t;else if (t > 191 && t < 224) chunk[i++] = (t & 31) << 6 | buffer[start++] & 63;else if (t > 239 && t < 365) {
            t = ((t & 7) << 18 | (buffer[start++] & 63) << 12 | (buffer[start++] & 63) << 6 | buffer[start++] & 63) - 0x10000;
            chunk[i++] = 0xD800 + (t >> 10);
            chunk[i++] = 0xDC00 + (t & 1023);
          } else chunk[i++] = (t & 15) << 12 | (buffer[start++] & 63) << 6 | buffer[start++] & 63;

          if (i > 8191) {
            (parts || (parts = [])).push(String.fromCharCode.apply(String, chunk));
            i = 0;
          }
        }

        if (parts) {
          if (i) parts.push(String.fromCharCode.apply(String, chunk.slice(0, i)));
          return parts.join("");
        }

        return String.fromCharCode.apply(String, chunk.slice(0, i));
      };
      /**
       * Writes a string as UTF8 bytes.
       * @param {string} string Source string
       * @param {Uint8Array} buffer Destination buffer
       * @param {number} offset Destination offset
       * @returns {number} Bytes written
       */


      utf8.write = function utf8_write(string, buffer, offset) {
        var start = offset,
            c1,
            // character 1
        c2; // character 2

        for (var i = 0; i < string.length; ++i) {
          c1 = string.charCodeAt(i);

          if (c1 < 128) {
            buffer[offset++] = c1;
          } else if (c1 < 2048) {
            buffer[offset++] = c1 >> 6 | 192;
            buffer[offset++] = c1 & 63 | 128;
          } else if ((c1 & 0xFC00) === 0xD800 && ((c2 = string.charCodeAt(i + 1)) & 0xFC00) === 0xDC00) {
            c1 = 0x10000 + ((c1 & 0x03FF) << 10) + (c2 & 0x03FF);
            ++i;
            buffer[offset++] = c1 >> 18 | 240;
            buffer[offset++] = c1 >> 12 & 63 | 128;
            buffer[offset++] = c1 >> 6 & 63 | 128;
            buffer[offset++] = c1 & 63 | 128;
          } else {
            buffer[offset++] = c1 >> 12 | 224;
            buffer[offset++] = c1 >> 6 & 63 | 128;
            buffer[offset++] = c1 & 63 | 128;
          }
        }

        return offset - start;
      };
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      var protobuf = exports;
      /**
       * Build type, one of `"full"`, `"light"` or `"minimal"`.
       * @name build
       * @type {string}
       * @const
       */

      protobuf.build = "minimal"; // Serialization

      protobuf.Writer = require(16);
      protobuf.BufferWriter = require(17);
      protobuf.Reader = require(9);
      protobuf.BufferReader = require(10); // Utility

      protobuf.util = require(15);
      protobuf.rpc = require(12);
      protobuf.roots = require(11);
      protobuf.configure = configure;
      /* istanbul ignore next */

      /**
       * Reconfigures the library according to the environment.
       * @returns {undefined}
       */

      function configure() {
        protobuf.util._configure();

        protobuf.Writer._configure(protobuf.BufferWriter);

        protobuf.Reader._configure(protobuf.BufferReader);
      } // Set up buffer utility according to the environment


      configure();
    }, {
      "10": 10,
      "11": 11,
      "12": 12,
      "15": 15,
      "16": 16,
      "17": 17,
      "9": 9
    }],
    9: [function (require, module, exports) {
      "use strict";

      module.exports = Reader;

      var util = require(15);

      var BufferReader; // cyclic

      var LongBits = util.LongBits,
          utf8 = util.utf8;
      /* istanbul ignore next */

      function indexOutOfRange(reader, writeLength) {
        return RangeError("index out of range: " + reader.pos + " + " + (writeLength || 1) + " > " + reader.len);
      }
      /**
       * Constructs a new reader instance using the specified buffer.
       * @classdesc Wire format reader using `Uint8Array` if available, otherwise `Array`.
       * @constructor
       * @param {Uint8Array} buffer Buffer to read from
       */


      function Reader(buffer) {
        /**
         * Read buffer.
         * @type {Uint8Array}
         */
        this.buf = buffer;
        /**
         * Read buffer position.
         * @type {number}
         */

        this.pos = 0;
        /**
         * Read buffer length.
         * @type {number}
         */

        this.len = buffer.length;
      }

      var create_array = typeof Uint8Array !== "undefined" ? function create_typed_array(buffer) {
        if (buffer instanceof Uint8Array || Array.isArray(buffer)) return new Reader(buffer);
        throw Error("illegal buffer");
      }
      /* istanbul ignore next */
      : function create_array(buffer) {
        if (Array.isArray(buffer)) return new Reader(buffer);
        throw Error("illegal buffer");
      };

      var create = function create() {
        return util.Buffer ? function create_buffer_setup(buffer) {
          return (Reader.create = function create_buffer(buffer) {
            return util.Buffer.isBuffer(buffer) ? new BufferReader(buffer)
            /* istanbul ignore next */
            : create_array(buffer);
          })(buffer);
        }
        /* istanbul ignore next */
        : create_array;
      };
      /**
       * Creates a new reader using the specified buffer.
       * @function
       * @param {Uint8Array|Buffer} buffer Buffer to read from
       * @returns {Reader|BufferReader} A {@link BufferReader} if `buffer` is a Buffer, otherwise a {@link Reader}
       * @throws {Error} If `buffer` is not a valid buffer
       */


      Reader.create = create();
      Reader.prototype._slice = util.Array.prototype.subarray ||
      /* istanbul ignore next */
      util.Array.prototype.slice;
      /**
       * Reads a varint as an unsigned 32 bit value.
       * @function
       * @returns {number} Value read
       */

      Reader.prototype.uint32 = function read_uint32_setup() {
        var value = 4294967295; // optimizer type-hint, tends to deopt otherwise (?!)

        return function read_uint32() {
          value = (this.buf[this.pos] & 127) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 7) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 14) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 21) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 15) << 28) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          /* istanbul ignore if */

          if ((this.pos += 5) > this.len) {
            this.pos = this.len;
            throw indexOutOfRange(this, 10);
          }

          return value;
        };
      }();
      /**
       * Reads a varint as a signed 32 bit value.
       * @returns {number} Value read
       */


      Reader.prototype.int32 = function read_int32() {
        return this.uint32() | 0;
      };
      /**
       * Reads a zig-zag encoded varint as a signed 32 bit value.
       * @returns {number} Value read
       */


      Reader.prototype.sint32 = function read_sint32() {
        var value = this.uint32();
        return value >>> 1 ^ -(value & 1) | 0;
      };
      /* eslint-disable no-invalid-this */


      function readLongVarint() {
        // tends to deopt with local vars for octet etc.
        var bits = new LongBits(0, 0);
        var i = 0;

        if (this.len - this.pos > 4) {
          // fast route (lo)
          for (; i < 4; ++i) {
            // 1st..4th
            bits.lo = (bits.lo | (this.buf[this.pos] & 127) << i * 7) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          } // 5th


          bits.lo = (bits.lo | (this.buf[this.pos] & 127) << 28) >>> 0;
          bits.hi = (bits.hi | (this.buf[this.pos] & 127) >> 4) >>> 0;
          if (this.buf[this.pos++] < 128) return bits;
          i = 0;
        } else {
          for (; i < 3; ++i) {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this); // 1st..3th

            bits.lo = (bits.lo | (this.buf[this.pos] & 127) << i * 7) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          } // 4th


          bits.lo = (bits.lo | (this.buf[this.pos++] & 127) << i * 7) >>> 0;
          return bits;
        }

        if (this.len - this.pos > 4) {
          // fast route (hi)
          for (; i < 5; ++i) {
            // 6th..10th
            bits.hi = (bits.hi | (this.buf[this.pos] & 127) << i * 7 + 3) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          }
        } else {
          for (; i < 5; ++i) {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this); // 6th..10th

            bits.hi = (bits.hi | (this.buf[this.pos] & 127) << i * 7 + 3) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          }
        }
        /* istanbul ignore next */


        throw Error("invalid varint encoding");
      }
      /* eslint-enable no-invalid-this */

      /**
       * Reads a varint as a signed 64 bit value.
       * @name Reader#int64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a varint as an unsigned 64 bit value.
       * @name Reader#uint64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a zig-zag encoded varint as a signed 64 bit value.
       * @name Reader#sint64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a varint as a boolean.
       * @returns {boolean} Value read
       */


      Reader.prototype.bool = function read_bool() {
        return this.uint32() !== 0;
      };

      function readFixed32_end(buf, end) {
        // note that this uses `end`, not `pos`
        return (buf[end - 4] | buf[end - 3] << 8 | buf[end - 2] << 16 | buf[end - 1] << 24) >>> 0;
      }
      /**
       * Reads fixed 32 bits as an unsigned 32 bit integer.
       * @returns {number} Value read
       */


      Reader.prototype.fixed32 = function read_fixed32() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        return readFixed32_end(this.buf, this.pos += 4);
      };
      /**
       * Reads fixed 32 bits as a signed 32 bit integer.
       * @returns {number} Value read
       */


      Reader.prototype.sfixed32 = function read_sfixed32() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        return readFixed32_end(this.buf, this.pos += 4) | 0;
      };
      /* eslint-disable no-invalid-this */


      function readFixed64()
      /* this: Reader */
      {
        /* istanbul ignore if */
        if (this.pos + 8 > this.len) throw indexOutOfRange(this, 8);
        return new LongBits(readFixed32_end(this.buf, this.pos += 4), readFixed32_end(this.buf, this.pos += 4));
      }
      /* eslint-enable no-invalid-this */

      /**
       * Reads fixed 64 bits.
       * @name Reader#fixed64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads zig-zag encoded fixed 64 bits.
       * @name Reader#sfixed64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a float (32 bit) as a number.
       * @function
       * @returns {number} Value read
       */


      Reader.prototype["float"] = function read_float() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        var value = util["float"].readFloatLE(this.buf, this.pos);
        this.pos += 4;
        return value;
      };
      /**
       * Reads a double (64 bit float) as a number.
       * @function
       * @returns {number} Value read
       */


      Reader.prototype["double"] = function read_double() {
        /* istanbul ignore if */
        if (this.pos + 8 > this.len) throw indexOutOfRange(this, 4);
        var value = util["float"].readDoubleLE(this.buf, this.pos);
        this.pos += 8;
        return value;
      };
      /**
       * Reads a sequence of bytes preceeded by its length as a varint.
       * @returns {Uint8Array} Value read
       */


      Reader.prototype.bytes = function read_bytes() {
        var length = this.uint32(),
            start = this.pos,
            end = this.pos + length;
        /* istanbul ignore if */

        if (end > this.len) throw indexOutOfRange(this, length);
        this.pos += length;
        if (Array.isArray(this.buf)) // plain array
          return this.buf.slice(start, end);
        return start === end // fix for IE 10/Win8 and others' subarray returning array of size 1
        ? new this.buf.constructor(0) : this._slice.call(this.buf, start, end);
      };
      /**
       * Reads a string preceeded by its byte length as a varint.
       * @returns {string} Value read
       */


      Reader.prototype.string = function read_string() {
        var bytes = this.bytes();
        return utf8.read(bytes, 0, bytes.length);
      };
      /**
       * Skips the specified number of bytes if specified, otherwise skips a varint.
       * @param {number} [length] Length if known, otherwise a varint is assumed
       * @returns {Reader} `this`
       */


      Reader.prototype.skip = function skip(length) {
        if (typeof length === "number") {
          /* istanbul ignore if */
          if (this.pos + length > this.len) throw indexOutOfRange(this, length);
          this.pos += length;
        } else {
          do {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this);
          } while (this.buf[this.pos++] & 128);
        }

        return this;
      };
      /**
       * Skips the next element of the specified wire type.
       * @param {number} wireType Wire type received
       * @returns {Reader} `this`
       */


      Reader.prototype.skipType = function (wireType) {
        switch (wireType) {
          case 0:
            this.skip();
            break;

          case 1:
            this.skip(8);
            break;

          case 2:
            this.skip(this.uint32());
            break;

          case 3:
            while ((wireType = this.uint32() & 7) !== 4) {
              this.skipType(wireType);
            }

            break;

          case 5:
            this.skip(4);
            break;

          /* istanbul ignore next */

          default:
            throw Error("invalid wire type " + wireType + " at offset " + this.pos);
        }

        return this;
      };

      Reader._configure = function (BufferReader_) {
        BufferReader = BufferReader_;
        Reader.create = create();

        BufferReader._configure();

        var fn = util.Long ? "toLong" :
        /* istanbul ignore next */
        "toNumber";
        util.merge(Reader.prototype, {
          int64: function read_int64() {
            return readLongVarint.call(this)[fn](false);
          },
          uint64: function read_uint64() {
            return readLongVarint.call(this)[fn](true);
          },
          sint64: function read_sint64() {
            return readLongVarint.call(this).zzDecode()[fn](false);
          },
          fixed64: function read_fixed64() {
            return readFixed64.call(this)[fn](true);
          },
          sfixed64: function read_sfixed64() {
            return readFixed64.call(this)[fn](false);
          }
        });
      };
    }, {
      "15": 15
    }],
    10: [function (require, module, exports) {
      "use strict";

      module.exports = BufferReader; // extends Reader

      var Reader = require(9);

      (BufferReader.prototype = Object.create(Reader.prototype)).constructor = BufferReader;

      var util = require(15);
      /**
       * Constructs a new buffer reader instance.
       * @classdesc Wire format reader using node buffers.
       * @extends Reader
       * @constructor
       * @param {Buffer} buffer Buffer to read from
       */


      function BufferReader(buffer) {
        Reader.call(this, buffer);
        /**
         * Read buffer.
         * @name BufferReader#buf
         * @type {Buffer}
         */
      }

      BufferReader._configure = function () {
        /* istanbul ignore else */
        if (util.Buffer) BufferReader.prototype._slice = util.Buffer.prototype.slice;
      };
      /**
       * @override
       */


      BufferReader.prototype.string = function read_string_buffer() {
        var len = this.uint32(); // modifies pos

        return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + len, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + len, this.len));
      };
      /**
       * Reads a sequence of bytes preceeded by its length as a varint.
       * @name BufferReader#bytes
       * @function
       * @returns {Buffer} Value read
       */


      BufferReader._configure();
    }, {
      "15": 15,
      "9": 9
    }],
    11: [function (require, module, exports) {
      "use strict";

      module.exports = {};
      /**
       * Named roots.
       * This is where pbjs stores generated structures (the option `-r, --root` specifies a name).
       * Can also be used manually to make roots available accross modules.
       * @name roots
       * @type {Object.<string,Root>}
       * @example
       * // pbjs -r myroot -o compiled.js ...
       *
       * // in another module:
       * require("./compiled.js");
       *
       * // in any subsequent module:
       * var root = protobuf.roots["myroot"];
       */
    }, {}],
    12: [function (require, module, exports) {
      "use strict";
      /**
       * Streaming RPC helpers.
       * @namespace
       */

      var rpc = exports;
      /**
       * RPC implementation passed to {@link Service#create} performing a service request on network level, i.e. by utilizing http requests or websockets.
       * @typedef RPCImpl
       * @type {function}
       * @param {Method|rpc.ServiceMethod<Message<{}>,Message<{}>>} method Reflected or static method being called
       * @param {Uint8Array} requestData Request data
       * @param {RPCImplCallback} callback Callback function
       * @returns {undefined}
       * @example
       * function rpcImpl(method, requestData, callback) {
       *     if (protobuf.util.lcFirst(method.name) !== "myMethod") // compatible with static code
       *         throw Error("no such method");
       *     asynchronouslyObtainAResponse(requestData, function(err, responseData) {
       *         callback(err, responseData);
       *     });
       * }
       */

      /**
       * Node-style callback as used by {@link RPCImpl}.
       * @typedef RPCImplCallback
       * @type {function}
       * @param {Error|null} error Error, if any, otherwise `null`
       * @param {Uint8Array|null} [response] Response data or `null` to signal end of stream, if there hasn't been an error
       * @returns {undefined}
       */

      rpc.Service = require(13);
    }, {
      "13": 13
    }],
    13: [function (require, module, exports) {
      "use strict";

      module.exports = Service;

      var util = require(15); // Extends EventEmitter


      (Service.prototype = Object.create(util.EventEmitter.prototype)).constructor = Service;
      /**
       * A service method callback as used by {@link rpc.ServiceMethod|ServiceMethod}.
       *
       * Differs from {@link RPCImplCallback} in that it is an actual callback of a service method which may not return `response = null`.
       * @typedef rpc.ServiceMethodCallback
       * @template TRes extends Message<TRes>
       * @type {function}
       * @param {Error|null} error Error, if any
       * @param {TRes} [response] Response message
       * @returns {undefined}
       */

      /**
       * A service method part of a {@link rpc.Service} as created by {@link Service.create}.
       * @typedef rpc.ServiceMethod
       * @template TReq extends Message<TReq>
       * @template TRes extends Message<TRes>
       * @type {function}
       * @param {TReq|Properties<TReq>} request Request message or plain object
       * @param {rpc.ServiceMethodCallback<TRes>} [callback] Node-style callback called with the error, if any, and the response message
       * @returns {Promise<Message<TRes>>} Promise if `callback` has been omitted, otherwise `undefined`
       */

      /**
       * Constructs a new RPC service instance.
       * @classdesc An RPC service as returned by {@link Service#create}.
       * @exports rpc.Service
       * @extends util.EventEmitter
       * @constructor
       * @param {RPCImpl} rpcImpl RPC implementation
       * @param {boolean} [requestDelimited=false] Whether requests are length-delimited
       * @param {boolean} [responseDelimited=false] Whether responses are length-delimited
       */

      function Service(rpcImpl, requestDelimited, responseDelimited) {
        if (typeof rpcImpl !== "function") throw TypeError("rpcImpl must be a function");
        util.EventEmitter.call(this);
        /**
         * RPC implementation. Becomes `null` once the service is ended.
         * @type {RPCImpl|null}
         */

        this.rpcImpl = rpcImpl;
        /**
         * Whether requests are length-delimited.
         * @type {boolean}
         */

        this.requestDelimited = Boolean(requestDelimited);
        /**
         * Whether responses are length-delimited.
         * @type {boolean}
         */

        this.responseDelimited = Boolean(responseDelimited);
      }
      /**
       * Calls a service method through {@link rpc.Service#rpcImpl|rpcImpl}.
       * @param {Method|rpc.ServiceMethod<TReq,TRes>} method Reflected or static method
       * @param {Constructor<TReq>} requestCtor Request constructor
       * @param {Constructor<TRes>} responseCtor Response constructor
       * @param {TReq|Properties<TReq>} request Request message or plain object
       * @param {rpc.ServiceMethodCallback<TRes>} callback Service callback
       * @returns {undefined}
       * @template TReq extends Message<TReq>
       * @template TRes extends Message<TRes>
       */


      Service.prototype.rpcCall = function rpcCall(method, requestCtor, responseCtor, request, callback) {
        if (!request) throw TypeError("request must be specified");
        var self = this;
        if (!callback) return util.asPromise(rpcCall, self, method, requestCtor, responseCtor, request);

        if (!self.rpcImpl) {
          setTimeout(function () {
            callback(Error("already ended"));
          }, 0);
          return undefined;
        }

        try {
          return self.rpcImpl(method, requestCtor[self.requestDelimited ? "encodeDelimited" : "encode"](request).finish(), function rpcCallback(err, response) {
            if (err) {
              self.emit("error", err, method);
              return callback(err);
            }

            if (response === null) {
              self.end(
              /* endedByRPC */
              true);
              return undefined;
            }

            if (!(response instanceof responseCtor)) {
              try {
                response = responseCtor[self.responseDelimited ? "decodeDelimited" : "decode"](response);
              } catch (err) {
                self.emit("error", err, method);
                return callback(err);
              }
            }

            self.emit("data", response, method);
            return callback(null, response);
          });
        } catch (err) {
          self.emit("error", err, method);
          setTimeout(function () {
            callback(err);
          }, 0);
          return undefined;
        }
      };
      /**
       * Ends this service and emits the `end` event.
       * @param {boolean} [endedByRPC=false] Whether the service has been ended by the RPC implementation.
       * @returns {rpc.Service} `this`
       */


      Service.prototype.end = function end(endedByRPC) {
        if (this.rpcImpl) {
          if (!endedByRPC) // signal end to rpcImpl
            this.rpcImpl(null, null, null);
          this.rpcImpl = null;
          this.emit("end").off();
        }

        return this;
      };
    }, {
      "15": 15
    }],
    14: [function (require, module, exports) {
      "use strict";

      module.exports = LongBits;

      var util = require(15);
      /**
       * Constructs new long bits.
       * @classdesc Helper class for working with the low and high bits of a 64 bit value.
       * @memberof util
       * @constructor
       * @param {number} lo Low 32 bits, unsigned
       * @param {number} hi High 32 bits, unsigned
       */


      function LongBits(lo, hi) {
        // note that the casts below are theoretically unnecessary as of today, but older statically
        // generated converter code might still call the ctor with signed 32bits. kept for compat.

        /**
         * Low bits.
         * @type {number}
         */
        this.lo = lo >>> 0;
        /**
         * High bits.
         * @type {number}
         */

        this.hi = hi >>> 0;
      }
      /**
       * Zero bits.
       * @memberof util.LongBits
       * @type {util.LongBits}
       */


      var zero = LongBits.zero = new LongBits(0, 0);

      zero.toNumber = function () {
        return 0;
      };

      zero.zzEncode = zero.zzDecode = function () {
        return this;
      };

      zero.length = function () {
        return 1;
      };
      /**
       * Zero hash.
       * @memberof util.LongBits
       * @type {string}
       */


      var zeroHash = LongBits.zeroHash = "\0\0\0\0\0\0\0\0";
      /**
       * Constructs new long bits from the specified number.
       * @param {number} value Value
       * @returns {util.LongBits} Instance
       */

      LongBits.fromNumber = function fromNumber(value) {
        if (value === 0) return zero;
        var sign = value < 0;
        if (sign) value = -value;
        var lo = value >>> 0,
            hi = (value - lo) / 4294967296 >>> 0;

        if (sign) {
          hi = ~hi >>> 0;
          lo = ~lo >>> 0;

          if (++lo > 4294967295) {
            lo = 0;
            if (++hi > 4294967295) hi = 0;
          }
        }

        return new LongBits(lo, hi);
      };
      /**
       * Constructs new long bits from a number, long or string.
       * @param {Long|number|string} value Value
       * @returns {util.LongBits} Instance
       */


      LongBits.from = function from(value) {
        if (typeof value === "number") return LongBits.fromNumber(value);

        if (util.isString(value)) {
          /* istanbul ignore else */
          if (util.Long) value = util.Long.fromString(value);else return LongBits.fromNumber(parseInt(value, 10));
        }

        return value.low || value.high ? new LongBits(value.low >>> 0, value.high >>> 0) : zero;
      };
      /**
       * Converts this long bits to a possibly unsafe JavaScript number.
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {number} Possibly unsafe number
       */


      LongBits.prototype.toNumber = function toNumber(unsigned) {
        if (!unsigned && this.hi >>> 31) {
          var lo = ~this.lo + 1 >>> 0,
              hi = ~this.hi >>> 0;
          if (!lo) hi = hi + 1 >>> 0;
          return -(lo + hi * 4294967296);
        }

        return this.lo + this.hi * 4294967296;
      };
      /**
       * Converts this long bits to a long.
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {Long} Long
       */


      LongBits.prototype.toLong = function toLong(unsigned) {
        return util.Long ? new util.Long(this.lo | 0, this.hi | 0, Boolean(unsigned))
        /* istanbul ignore next */
        : {
          low: this.lo | 0,
          high: this.hi | 0,
          unsigned: Boolean(unsigned)
        };
      };

      var charCodeAt = String.prototype.charCodeAt;
      /**
       * Constructs new long bits from the specified 8 characters long hash.
       * @param {string} hash Hash
       * @returns {util.LongBits} Bits
       */

      LongBits.fromHash = function fromHash(hash) {
        if (hash === zeroHash) return zero;
        return new LongBits((charCodeAt.call(hash, 0) | charCodeAt.call(hash, 1) << 8 | charCodeAt.call(hash, 2) << 16 | charCodeAt.call(hash, 3) << 24) >>> 0, (charCodeAt.call(hash, 4) | charCodeAt.call(hash, 5) << 8 | charCodeAt.call(hash, 6) << 16 | charCodeAt.call(hash, 7) << 24) >>> 0);
      };
      /**
       * Converts this long bits to a 8 characters long hash.
       * @returns {string} Hash
       */


      LongBits.prototype.toHash = function toHash() {
        return String.fromCharCode(this.lo & 255, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, this.hi & 255, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
      };
      /**
       * Zig-zag encodes this long bits.
       * @returns {util.LongBits} `this`
       */


      LongBits.prototype.zzEncode = function zzEncode() {
        var mask = this.hi >> 31;
        this.hi = ((this.hi << 1 | this.lo >>> 31) ^ mask) >>> 0;
        this.lo = (this.lo << 1 ^ mask) >>> 0;
        return this;
      };
      /**
       * Zig-zag decodes this long bits.
       * @returns {util.LongBits} `this`
       */


      LongBits.prototype.zzDecode = function zzDecode() {
        var mask = -(this.lo & 1);
        this.lo = ((this.lo >>> 1 | this.hi << 31) ^ mask) >>> 0;
        this.hi = (this.hi >>> 1 ^ mask) >>> 0;
        return this;
      };
      /**
       * Calculates the length of this longbits when encoded as a varint.
       * @returns {number} Length
       */


      LongBits.prototype.length = function length() {
        var part0 = this.lo,
            part1 = (this.lo >>> 28 | this.hi << 4) >>> 0,
            part2 = this.hi >>> 24;
        return part2 === 0 ? part1 === 0 ? part0 < 16384 ? part0 < 128 ? 1 : 2 : part0 < 2097152 ? 3 : 4 : part1 < 16384 ? part1 < 128 ? 5 : 6 : part1 < 2097152 ? 7 : 8 : part2 < 128 ? 9 : 10;
      };
    }, {
      "15": 15
    }],
    15: [function (require, module, exports) {
      "use strict";

      var util = exports; // used to return a Promise where callback is omitted

      util.asPromise = require(1); // converts to / from base64 encoded strings

      util.base64 = require(2); // base class of rpc.Service

      util.EventEmitter = require(3); // float handling accross browsers

      util["float"] = require(4); // requires modules optionally and hides the call from bundlers

      util.inquire = require(5); // converts to / from utf8 encoded strings

      util.utf8 = require(7); // provides a node-like buffer pool in the browser

      util.pool = require(6); // utility to work with the low and high bits of a 64 bit value

      util.LongBits = require(14);
      /**
       * Whether running within node or not.
       * @memberof util
       * @type {boolean}
       */

      util.isNode = Boolean(typeof global !== "undefined" && global && global.process && global.process.versions && global.process.versions.node);
      /**
       * Global object reference.
       * @memberof util
       * @type {Object}
       */

      util.global = util.isNode && global || typeof window !== "undefined" && window || typeof self !== "undefined" && self || this; // eslint-disable-line no-invalid-this

      /**
       * An immuable empty array.
       * @memberof util
       * @type {Array.<*>}
       * @const
       */

      util.emptyArray = Object.freeze ? Object.freeze([]) :
      /* istanbul ignore next */
      []; // used on prototypes

      /**
       * An immutable empty object.
       * @type {Object}
       * @const
       */

      util.emptyObject = Object.freeze ? Object.freeze({}) :
      /* istanbul ignore next */
      {}; // used on prototypes

      /**
       * Tests if the specified value is an integer.
       * @function
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is an integer
       */

      util.isInteger = Number.isInteger ||
      /* istanbul ignore next */
      function isInteger(value) {
        return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
      };
      /**
       * Tests if the specified value is a string.
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is a string
       */


      util.isString = function isString(value) {
        return typeof value === "string" || value instanceof String;
      };
      /**
       * Tests if the specified value is a non-null object.
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is a non-null object
       */


      util.isObject = function isObject(value) {
        return value && typeof value === "object";
      };
      /**
       * Checks if a property on a message is considered to be present.
       * This is an alias of {@link util.isSet}.
       * @function
       * @param {Object} obj Plain object or message instance
       * @param {string} prop Property name
       * @returns {boolean} `true` if considered to be present, otherwise `false`
       */


      util.isset =
      /**
       * Checks if a property on a message is considered to be present.
       * @param {Object} obj Plain object or message instance
       * @param {string} prop Property name
       * @returns {boolean} `true` if considered to be present, otherwise `false`
       */
      util.isSet = function isSet(obj, prop) {
        var value = obj[prop];
        if (value != null && obj.hasOwnProperty(prop)) // eslint-disable-line eqeqeq, no-prototype-builtins
          return typeof value !== "object" || (Array.isArray(value) ? value.length : Object.keys(value).length) > 0;
        return false;
      };
      /**
       * Any compatible Buffer instance.
       * This is a minimal stand-alone definition of a Buffer instance. The actual type is that exported by node's typings.
       * @interface Buffer
       * @extends Uint8Array
       */

      /**
       * Node's Buffer class if available.
       * @type {Constructor<Buffer>}
       */


      util.Buffer = function () {
        try {
          var Buffer = util.inquire("buffer").Buffer; // refuse to use non-node buffers if not explicitly assigned (perf reasons):

          return Buffer.prototype.utf8Write ? Buffer :
          /* istanbul ignore next */
          null;
        } catch (e) {
          /* istanbul ignore next */
          return null;
        }
      }(); // Internal alias of or polyfull for Buffer.from.


      util._Buffer_from = null; // Internal alias of or polyfill for Buffer.allocUnsafe.

      util._Buffer_allocUnsafe = null;
      /**
       * Creates a new buffer of whatever type supported by the environment.
       * @param {number|number[]} [sizeOrArray=0] Buffer size or number array
       * @returns {Uint8Array|Buffer} Buffer
       */

      util.newBuffer = function newBuffer(sizeOrArray) {
        /* istanbul ignore next */
        return typeof sizeOrArray === "number" ? util.Buffer ? util._Buffer_allocUnsafe(sizeOrArray) : new util.Array(sizeOrArray) : util.Buffer ? util._Buffer_from(sizeOrArray) : typeof Uint8Array === "undefined" ? sizeOrArray : new Uint8Array(sizeOrArray);
      };
      /**
       * Array implementation used in the browser. `Uint8Array` if supported, otherwise `Array`.
       * @type {Constructor<Uint8Array>}
       */


      util.Array = typeof Uint8Array !== "undefined" ? Uint8Array
      /* istanbul ignore next */
      : Array;
      /**
       * Any compatible Long instance.
       * This is a minimal stand-alone definition of a Long instance. The actual type is that exported by long.js.
       * @interface Long
       * @property {number} low Low bits
       * @property {number} high High bits
       * @property {boolean} unsigned Whether unsigned or not
       */

      /**
       * Long.js's Long class if available.
       * @type {Constructor<Long>}
       */

      util.Long =
      /* istanbul ignore next */
      util.global.dcodeIO &&
      /* istanbul ignore next */
      util.global.dcodeIO.Long ||
      /* istanbul ignore next */
      util.global.Long || util.inquire("long");
      /**
       * Regular expression used to verify 2 bit (`bool`) map keys.
       * @type {RegExp}
       * @const
       */

      util.key2Re = /^true|false|0|1$/;
      /**
       * Regular expression used to verify 32 bit (`int32` etc.) map keys.
       * @type {RegExp}
       * @const
       */

      util.key32Re = /^-?(?:0|[1-9][0-9]*)$/;
      /**
       * Regular expression used to verify 64 bit (`int64` etc.) map keys.
       * @type {RegExp}
       * @const
       */

      util.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/;
      /**
       * Converts a number or long to an 8 characters long hash string.
       * @param {Long|number} value Value to convert
       * @returns {string} Hash
       */

      util.longToHash = function longToHash(value) {
        return value ? util.LongBits.from(value).toHash() : util.LongBits.zeroHash;
      };
      /**
       * Converts an 8 characters long hash string to a long or number.
       * @param {string} hash Hash
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {Long|number} Original value
       */


      util.longFromHash = function longFromHash(hash, unsigned) {
        var bits = util.LongBits.fromHash(hash);
        if (util.Long) return util.Long.fromBits(bits.lo, bits.hi, unsigned);
        return bits.toNumber(Boolean(unsigned));
      };
      /**
       * Merges the properties of the source object into the destination object.
       * @memberof util
       * @param {Object.<string,*>} dst Destination object
       * @param {Object.<string,*>} src Source object
       * @param {boolean} [ifNotSet=false] Merges only if the key is not already set
       * @returns {Object.<string,*>} Destination object
       */


      function merge(dst, src, ifNotSet) {
        // used by converters
        for (var keys = Object.keys(src), i = 0; i < keys.length; ++i) {
          if (dst[keys[i]] === undefined || !ifNotSet) dst[keys[i]] = src[keys[i]];
        }

        return dst;
      }

      util.merge = merge;
      /**
       * Converts the first character of a string to lower case.
       * @param {string} str String to convert
       * @returns {string} Converted string
       */

      util.lcFirst = function lcFirst(str) {
        return str.charAt(0).toLowerCase() + str.substring(1);
      };
      /**
       * Creates a custom error constructor.
       * @memberof util
       * @param {string} name Error name
       * @returns {Constructor<Error>} Custom error constructor
       */


      function newError(name) {
        function CustomError(message, properties) {
          if (!(this instanceof CustomError)) return new CustomError(message, properties); // Error.call(this, message);
          // ^ just returns a new error instance because the ctor can be called as a function

          Object.defineProperty(this, "message", {
            get: function get() {
              return message;
            }
          });
          /* istanbul ignore next */

          if (Error.captureStackTrace) // node
            Error.captureStackTrace(this, CustomError);else Object.defineProperty(this, "stack", {
            value: new Error().stack || ""
          });
          if (properties) merge(this, properties);
        }

        (CustomError.prototype = Object.create(Error.prototype)).constructor = CustomError;
        Object.defineProperty(CustomError.prototype, "name", {
          get: function get() {
            return name;
          }
        });

        CustomError.prototype.toString = function toString() {
          return this.name + ": " + this.message;
        };

        return CustomError;
      }

      util.newError = newError;
      /**
       * Constructs a new protocol error.
       * @classdesc Error subclass indicating a protocol specifc error.
       * @memberof util
       * @extends Error
       * @template T extends Message<T>
       * @constructor
       * @param {string} message Error message
       * @param {Object.<string,*>} [properties] Additional properties
       * @example
       * try {
       *     MyMessage.decode(someBuffer); // throws if required fields are missing
       * } catch (e) {
       *     if (e instanceof ProtocolError && e.instance)
       *         console.log("decoded so far: " + JSON.stringify(e.instance));
       * }
       */

      util.ProtocolError = newError("ProtocolError");
      /**
       * So far decoded message instance.
       * @name util.ProtocolError#instance
       * @type {Message<T>}
       */

      /**
       * A OneOf getter as returned by {@link util.oneOfGetter}.
       * @typedef OneOfGetter
       * @type {function}
       * @returns {string|undefined} Set field name, if any
       */

      /**
       * Builds a getter for a oneof's present field name.
       * @param {string[]} fieldNames Field names
       * @returns {OneOfGetter} Unbound getter
       */

      util.oneOfGetter = function getOneOf(fieldNames) {
        var fieldMap = {};

        for (var i = 0; i < fieldNames.length; ++i) {
          fieldMap[fieldNames[i]] = 1;
        }
        /**
         * @returns {string|undefined} Set field name, if any
         * @this Object
         * @ignore
         */


        return function () {
          // eslint-disable-line consistent-return
          for (var keys = Object.keys(this), i = keys.length - 1; i > -1; --i) {
            if (fieldMap[keys[i]] === 1 && this[keys[i]] !== undefined && this[keys[i]] !== null) return keys[i];
          }
        };
      };
      /**
       * A OneOf setter as returned by {@link util.oneOfSetter}.
       * @typedef OneOfSetter
       * @type {function}
       * @param {string|undefined} value Field name
       * @returns {undefined}
       */

      /**
       * Builds a setter for a oneof's present field name.
       * @param {string[]} fieldNames Field names
       * @returns {OneOfSetter} Unbound setter
       */


      util.oneOfSetter = function setOneOf(fieldNames) {
        /**
         * @param {string} name Field name
         * @returns {undefined}
         * @this Object
         * @ignore
         */
        return function (name) {
          for (var i = 0; i < fieldNames.length; ++i) {
            if (fieldNames[i] !== name) delete this[fieldNames[i]];
          }
        };
      };
      /**
       * Default conversion options used for {@link Message#toJSON} implementations.
       *
       * These options are close to proto3's JSON mapping with the exception that internal types like Any are handled just like messages. More precisely:
       *
       * - Longs become strings
       * - Enums become string keys
       * - Bytes become base64 encoded strings
       * - (Sub-)Messages become plain objects
       * - Maps become plain objects with all string keys
       * - Repeated fields become arrays
       * - NaN and Infinity for float and double fields become strings
       *
       * @type {IConversionOptions}
       * @see https://developers.google.com/protocol-buffers/docs/proto3?hl=en#json
       */


      util.toJSONOptions = {
        longs: String,
        enums: String,
        bytes: String,
        json: true
      }; // Sets up buffer utility according to the environment (called in index-minimal)

      util._configure = function () {
        var Buffer = util.Buffer;
        /* istanbul ignore if */

        if (!Buffer) {
          util._Buffer_from = util._Buffer_allocUnsafe = null;
          return;
        } // because node 4.x buffers are incompatible & immutable
        // see: https://github.com/dcodeIO/protobuf.js/pull/665


        util._Buffer_from = Buffer.from !== Uint8Array.from && Buffer.from ||
        /* istanbul ignore next */
        function Buffer_from(value, encoding) {
          return new Buffer(value, encoding);
        };

        util._Buffer_allocUnsafe = Buffer.allocUnsafe ||
        /* istanbul ignore next */
        function Buffer_allocUnsafe(size) {
          return new Buffer(size);
        };
      };
    }, {
      "1": 1,
      "14": 14,
      "2": 2,
      "3": 3,
      "4": 4,
      "5": 5,
      "6": 6,
      "7": 7
    }],
    16: [function (require, module, exports) {
      "use strict";

      module.exports = Writer;

      var util = require(15);

      var BufferWriter; // cyclic

      var LongBits = util.LongBits,
          base64 = util.base64,
          utf8 = util.utf8;
      /**
       * Constructs a new writer operation instance.
       * @classdesc Scheduled writer operation.
       * @constructor
       * @param {function(*, Uint8Array, number)} fn Function to call
       * @param {number} len Value byte length
       * @param {*} val Value to write
       * @ignore
       */

      function Op(fn, len, val) {
        /**
         * Function to call.
         * @type {function(Uint8Array, number, *)}
         */
        this.fn = fn;
        /**
         * Value byte length.
         * @type {number}
         */

        this.len = len;
        /**
         * Next operation.
         * @type {Writer.Op|undefined}
         */

        this.next = undefined;
        /**
         * Value to write.
         * @type {*}
         */

        this.val = val; // type varies
      }
      /* istanbul ignore next */


      function noop() {} // eslint-disable-line no-empty-function

      /**
       * Constructs a new writer state instance.
       * @classdesc Copied writer state.
       * @memberof Writer
       * @constructor
       * @param {Writer} writer Writer to copy state from
       * @ignore
       */


      function State(writer) {
        /**
         * Current head.
         * @type {Writer.Op}
         */
        this.head = writer.head;
        /**
         * Current tail.
         * @type {Writer.Op}
         */

        this.tail = writer.tail;
        /**
         * Current buffer length.
         * @type {number}
         */

        this.len = writer.len;
        /**
         * Next state.
         * @type {State|null}
         */

        this.next = writer.states;
      }
      /**
       * Constructs a new writer instance.
       * @classdesc Wire format writer using `Uint8Array` if available, otherwise `Array`.
       * @constructor
       */


      function Writer() {
        /**
         * Current length.
         * @type {number}
         */
        this.len = 0;
        /**
         * Operations head.
         * @type {Object}
         */

        this.head = new Op(noop, 0, 0);
        /**
         * Operations tail
         * @type {Object}
         */

        this.tail = this.head;
        /**
         * Linked forked states.
         * @type {Object|null}
         */

        this.states = null; // When a value is written, the writer calculates its byte length and puts it into a linked
        // list of operations to perform when finish() is called. This both allows us to allocate
        // buffers of the exact required size and reduces the amount of work we have to do compared
        // to first calculating over objects and then encoding over objects. In our case, the encoding
        // part is just a linked list walk calling operations with already prepared values.
      }

      var create = function create() {
        return util.Buffer ? function create_buffer_setup() {
          return (Writer.create = function create_buffer() {
            return new BufferWriter();
          })();
        }
        /* istanbul ignore next */
        : function create_array() {
          return new Writer();
        };
      };
      /**
       * Creates a new writer.
       * @function
       * @returns {BufferWriter|Writer} A {@link BufferWriter} when Buffers are supported, otherwise a {@link Writer}
       */


      Writer.create = create();
      /**
       * Allocates a buffer of the specified size.
       * @param {number} size Buffer size
       * @returns {Uint8Array} Buffer
       */

      Writer.alloc = function alloc(size) {
        return new util.Array(size);
      }; // Use Uint8Array buffer pool in the browser, just like node does with buffers

      /* istanbul ignore else */


      if (util.Array !== Array) Writer.alloc = util.pool(Writer.alloc, util.Array.prototype.subarray);
      /**
       * Pushes a new operation to the queue.
       * @param {function(Uint8Array, number, *)} fn Function to call
       * @param {number} len Value byte length
       * @param {number} val Value to write
       * @returns {Writer} `this`
       * @private
       */

      Writer.prototype._push = function push(fn, len, val) {
        this.tail = this.tail.next = new Op(fn, len, val);
        this.len += len;
        return this;
      };

      function writeByte(val, buf, pos) {
        buf[pos] = val & 255;
      }

      function writeVarint32(val, buf, pos) {
        while (val > 127) {
          buf[pos++] = val & 127 | 128;
          val >>>= 7;
        }

        buf[pos] = val;
      }
      /**
       * Constructs a new varint writer operation instance.
       * @classdesc Scheduled varint writer operation.
       * @extends Op
       * @constructor
       * @param {number} len Value byte length
       * @param {number} val Value to write
       * @ignore
       */


      function VarintOp(len, val) {
        this.len = len;
        this.next = undefined;
        this.val = val;
      }

      VarintOp.prototype = Object.create(Op.prototype);
      VarintOp.prototype.fn = writeVarint32;
      /**
       * Writes an unsigned 32 bit value as a varint.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */

      Writer.prototype.uint32 = function write_uint32(value) {
        // here, the call to this.push has been inlined and a varint specific Op subclass is used.
        // uint32 is by far the most frequently used operation and benefits significantly from this.
        this.len += (this.tail = this.tail.next = new VarintOp((value = value >>> 0) < 128 ? 1 : value < 16384 ? 2 : value < 2097152 ? 3 : value < 268435456 ? 4 : 5, value)).len;
        return this;
      };
      /**
       * Writes a signed 32 bit value as a varint.
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.int32 = function write_int32(value) {
        return value < 0 ? this._push(writeVarint64, 10, LongBits.fromNumber(value)) // 10 bytes per spec
        : this.uint32(value);
      };
      /**
       * Writes a 32 bit value as a varint, zig-zag encoded.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.sint32 = function write_sint32(value) {
        return this.uint32((value << 1 ^ value >> 31) >>> 0);
      };

      function writeVarint64(val, buf, pos) {
        while (val.hi) {
          buf[pos++] = val.lo & 127 | 128;
          val.lo = (val.lo >>> 7 | val.hi << 25) >>> 0;
          val.hi >>>= 7;
        }

        while (val.lo > 127) {
          buf[pos++] = val.lo & 127 | 128;
          val.lo = val.lo >>> 7;
        }

        buf[pos++] = val.lo;
      }
      /**
       * Writes an unsigned 64 bit value as a varint.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.uint64 = function write_uint64(value) {
        var bits = LongBits.from(value);
        return this._push(writeVarint64, bits.length(), bits);
      };
      /**
       * Writes a signed 64 bit value as a varint.
       * @function
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.int64 = Writer.prototype.uint64;
      /**
       * Writes a signed 64 bit value as a varint, zig-zag encoded.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */

      Writer.prototype.sint64 = function write_sint64(value) {
        var bits = LongBits.from(value).zzEncode();
        return this._push(writeVarint64, bits.length(), bits);
      };
      /**
       * Writes a boolish value as a varint.
       * @param {boolean} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.bool = function write_bool(value) {
        return this._push(writeByte, 1, value ? 1 : 0);
      };

      function writeFixed32(val, buf, pos) {
        buf[pos] = val & 255;
        buf[pos + 1] = val >>> 8 & 255;
        buf[pos + 2] = val >>> 16 & 255;
        buf[pos + 3] = val >>> 24;
      }
      /**
       * Writes an unsigned 32 bit value as fixed 32 bits.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.fixed32 = function write_fixed32(value) {
        return this._push(writeFixed32, 4, value >>> 0);
      };
      /**
       * Writes a signed 32 bit value as fixed 32 bits.
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.sfixed32 = Writer.prototype.fixed32;
      /**
       * Writes an unsigned 64 bit value as fixed 64 bits.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */

      Writer.prototype.fixed64 = function write_fixed64(value) {
        var bits = LongBits.from(value);
        return this._push(writeFixed32, 4, bits.lo)._push(writeFixed32, 4, bits.hi);
      };
      /**
       * Writes a signed 64 bit value as fixed 64 bits.
       * @function
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.sfixed64 = Writer.prototype.fixed64;
      /**
       * Writes a float (32 bit).
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */

      Writer.prototype["float"] = function write_float(value) {
        return this._push(util["float"].writeFloatLE, 4, value);
      };
      /**
       * Writes a double (64 bit float).
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype["double"] = function write_double(value) {
        return this._push(util["float"].writeDoubleLE, 8, value);
      };

      var writeBytes = util.Array.prototype.set ? function writeBytes_set(val, buf, pos) {
        buf.set(val, pos); // also works for plain array values
      }
      /* istanbul ignore next */
      : function writeBytes_for(val, buf, pos) {
        for (var i = 0; i < val.length; ++i) {
          buf[pos + i] = val[i];
        }
      };
      /**
       * Writes a sequence of bytes.
       * @param {Uint8Array|string} value Buffer or base64 encoded string to write
       * @returns {Writer} `this`
       */

      Writer.prototype.bytes = function write_bytes(value) {
        var len = value.length >>> 0;
        if (!len) return this._push(writeByte, 1, 0);

        if (util.isString(value)) {
          var buf = Writer.alloc(len = base64.length(value));
          base64.decode(value, buf, 0);
          value = buf;
        }

        return this.uint32(len)._push(writeBytes, len, value);
      };
      /**
       * Writes a string.
       * @param {string} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.string = function write_string(value) {
        var len = utf8.length(value);
        return len ? this.uint32(len)._push(utf8.write, len, value) : this._push(writeByte, 1, 0);
      };
      /**
       * Forks this writer's state by pushing it to a stack.
       * Calling {@link Writer#reset|reset} or {@link Writer#ldelim|ldelim} resets the writer to the previous state.
       * @returns {Writer} `this`
       */


      Writer.prototype.fork = function fork() {
        this.states = new State(this);
        this.head = this.tail = new Op(noop, 0, 0);
        this.len = 0;
        return this;
      };
      /**
       * Resets this instance to the last state.
       * @returns {Writer} `this`
       */


      Writer.prototype.reset = function reset() {
        if (this.states) {
          this.head = this.states.head;
          this.tail = this.states.tail;
          this.len = this.states.len;
          this.states = this.states.next;
        } else {
          this.head = this.tail = new Op(noop, 0, 0);
          this.len = 0;
        }

        return this;
      };
      /**
       * Resets to the last state and appends the fork state's current write length as a varint followed by its operations.
       * @returns {Writer} `this`
       */


      Writer.prototype.ldelim = function ldelim() {
        var head = this.head,
            tail = this.tail,
            len = this.len;
        this.reset().uint32(len);

        if (len) {
          this.tail.next = head.next; // skip noop

          this.tail = tail;
          this.len += len;
        }

        return this;
      };
      /**
       * Finishes the write operation.
       * @returns {Uint8Array} Finished buffer
       */


      Writer.prototype.finish = function finish() {
        var head = this.head.next,
            // skip noop
        buf = this.constructor.alloc(this.len),
            pos = 0;

        while (head) {
          head.fn(head.val, buf, pos);
          pos += head.len;
          head = head.next;
        } // this.head = this.tail = null;


        return buf;
      };

      Writer._configure = function (BufferWriter_) {
        BufferWriter = BufferWriter_;
        Writer.create = create();

        BufferWriter._configure();
      };
    }, {
      "15": 15
    }],
    17: [function (require, module, exports) {
      "use strict";

      module.exports = BufferWriter; // extends Writer

      var Writer = require(16);

      (BufferWriter.prototype = Object.create(Writer.prototype)).constructor = BufferWriter;

      var util = require(15);
      /**
       * Constructs a new buffer writer instance.
       * @classdesc Wire format writer using node buffers.
       * @extends Writer
       * @constructor
       */


      function BufferWriter() {
        Writer.call(this);
      }

      BufferWriter._configure = function () {
        /**
         * Allocates a buffer of the specified size.
         * @function
         * @param {number} size Buffer size
         * @returns {Buffer} Buffer
         */
        BufferWriter.alloc = util._Buffer_allocUnsafe;
        BufferWriter.writeBytesBuffer = util.Buffer && util.Buffer.prototype instanceof Uint8Array && util.Buffer.prototype.set.name === "set" ? function writeBytesBuffer_set(val, buf, pos) {
          buf.set(val, pos); // faster than copy (requires node >= 4 where Buffers extend Uint8Array and set is properly inherited)
          // also works for plain array values
        }
        /* istanbul ignore next */
        : function writeBytesBuffer_copy(val, buf, pos) {
          if (val.copy) // Buffer values
            val.copy(buf, pos, 0, val.length);else for (var i = 0; i < val.length;) {
            // plain array values
            buf[pos++] = val[i++];
          }
        };
      };
      /**
       * @override
       */


      BufferWriter.prototype.bytes = function write_bytes_buffer(value) {
        if (util.isString(value)) value = util._Buffer_from(value, "base64");
        var len = value.length >>> 0;
        this.uint32(len);
        if (len) this._push(BufferWriter.writeBytesBuffer, len, value);
        return this;
      };

      function writeStringBuffer(val, buf, pos) {
        if (val.length < 40) // plain js is faster for short strings (probably due to redundant assertions)
          util.utf8.write(val, buf, pos);else if (buf.utf8Write) buf.utf8Write(val, pos);else buf.write(val, pos);
      }
      /**
       * @override
       */


      BufferWriter.prototype.string = function write_string_buffer(value) {
        var len = util.Buffer.byteLength(value);
        this.uint32(len);
        if (len) this._push(writeStringBuffer, len, value);
        return this;
      };
      /**
       * Finishes the write operation.
       * @name BufferWriter#finish
       * @function
       * @returns {Buffer} Finished buffer
       */


      BufferWriter._configure();
    }, {
      "15": 15,
      "16": 16
    }]
  }, {}, [8]);
})(); 

cc._RF.pop();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9hc3NldHNcXG1zZ1xccHJvdG9idWYuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs7OztBQU1BLENBQUMsVUFBUyxTQUFULEVBQW1CO0FBQUM7O0FBQWEsR0FBQyxTQUFTLE9BQVQsQ0FBaUIsT0FBakIsRUFBMEIsS0FBMUIsRUFBaUMsT0FBakMsRUFBMEM7QUFFekU7QUFDQTtBQUNBO0FBQ0E7QUFFQSxhQUFTLFFBQVQsQ0FBa0IsSUFBbEIsRUFBd0I7QUFDcEIsVUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUQsQ0FBbkI7QUFDQSxVQUFJLENBQUMsT0FBTCxFQUNJLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FBYyxDQUFkLEVBQWlCLElBQWpCLENBQXNCLE9BQU8sR0FBRyxLQUFLLENBQUMsSUFBRCxDQUFMLEdBQWM7QUFBRSxRQUFBLE9BQU8sRUFBRTtBQUFYLE9BQTlDLEVBQStELFFBQS9ELEVBQXlFLE9BQXpFLEVBQWtGLE9BQU8sQ0FBQyxPQUExRjtBQUNKLGFBQU8sT0FBTyxDQUFDLE9BQWY7QUFDSDs7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUQsQ0FBUixDQUF2QixDQWR5RSxDQWdCekU7O0FBQ0EsSUFBQSxRQUFRLENBQUMsSUFBVCxDQUFjLE1BQWQsQ0FBcUIsUUFBckIsR0FBZ0MsUUFBaEMsQ0FqQnlFLENBbUJ6RTs7QUFDQSxRQUFJLE9BQU8sTUFBUCxLQUFrQixVQUFsQixJQUFnQyxNQUFNLENBQUMsR0FBM0MsRUFDSSxNQUFNLENBQUMsQ0FBQyxNQUFELENBQUQsRUFBVyxVQUFTLElBQVQsRUFBZTtBQUM1QixVQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBakIsRUFBeUI7QUFDckIsUUFBQSxRQUFRLENBQUMsSUFBVCxDQUFjLElBQWQsR0FBcUIsSUFBckI7QUFDQSxRQUFBLFFBQVEsQ0FBQyxTQUFUO0FBQ0g7O0FBQ0QsYUFBTyxRQUFQO0FBQ0gsS0FOSyxDQUFOLENBckJxRSxDQTZCekU7O0FBQ0EsUUFBSSxPQUFPLE1BQVAsS0FBa0IsUUFBbEIsSUFBOEIsTUFBOUIsSUFBd0MsTUFBTSxDQUFDLE9BQW5ELEVBQ0ksTUFBTSxDQUFDLE9BQVAsR0FBaUIsUUFBakI7QUFFUCxHQWpDaUM7QUFpQ2hDO0FBQXFCO0FBQUMsT0FBRSxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUMzRDs7QUFDQSxNQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFNBQWpCO0FBRUE7Ozs7Ozs7OztBQVNBOzs7Ozs7Ozs7QUFRQSxlQUFTLFNBQVQsQ0FBbUIsRUFBbkIsRUFBdUI7QUFBRztBQUExQixRQUEwQztBQUN0QyxZQUFJLE1BQU0sR0FBSSxJQUFJLEtBQUosQ0FBVSxTQUFTLENBQUMsTUFBVixHQUFtQixDQUE3QixDQUFkO0FBQUEsWUFDSSxNQUFNLEdBQUksQ0FEZDtBQUFBLFlBRUksS0FBSyxHQUFLLENBRmQ7QUFBQSxZQUdJLE9BQU8sR0FBRyxJQUhkOztBQUlBLGVBQU8sS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUF6QjtBQUNJLFVBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLFNBQVMsQ0FBQyxLQUFLLEVBQU4sQ0FBNUI7QUFESjs7QUFFQSxlQUFPLElBQUksT0FBSixDQUFZLFNBQVMsUUFBVCxDQUFrQixPQUFsQixFQUEyQixNQUEzQixFQUFtQztBQUNsRCxVQUFBLE1BQU0sQ0FBQyxNQUFELENBQU4sR0FBaUIsU0FBUyxRQUFULENBQWtCO0FBQUc7QUFBckIsWUFBcUM7QUFDbEQsZ0JBQUksT0FBSixFQUFhO0FBQ1QsY0FBQSxPQUFPLEdBQUcsS0FBVjtBQUNBLGtCQUFJLEdBQUosRUFDSSxNQUFNLENBQUMsR0FBRCxDQUFOLENBREosS0FFSztBQUNELG9CQUFJLE1BQU0sR0FBRyxJQUFJLEtBQUosQ0FBVSxTQUFTLENBQUMsTUFBVixHQUFtQixDQUE3QixDQUFiO0FBQUEsb0JBQ0ksTUFBTSxHQUFHLENBRGI7O0FBRUEsdUJBQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUF2QjtBQUNJLGtCQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixTQUFTLENBQUMsTUFBRCxDQUE1QjtBQURKOztBQUVBLGdCQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsSUFBZCxFQUFvQixNQUFwQjtBQUNIO0FBQ0o7QUFDSixXQWJEOztBQWNBLGNBQUk7QUFDQSxZQUFBLEVBQUUsQ0FBQyxLQUFILENBQVMsR0FBRyxJQUFJLElBQWhCLEVBQXNCLE1BQXRCO0FBQ0gsV0FGRCxDQUVFLE9BQU8sR0FBUCxFQUFZO0FBQ1YsZ0JBQUksT0FBSixFQUFhO0FBQ1QsY0FBQSxPQUFPLEdBQUcsS0FBVjtBQUNBLGNBQUEsTUFBTSxDQUFDLEdBQUQsQ0FBTjtBQUNIO0FBQ0o7QUFDSixTQXZCTSxDQUFQO0FBd0JIO0FBRUEsS0F0RHlCLEVBc0R4QixFQXREd0IsQ0FBSDtBQXNEakIsT0FBRSxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUN6QztBQUVBOzs7Ozs7QUFLQSxVQUFJLE1BQU0sR0FBRyxPQUFiO0FBRUE7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCO0FBQ3BDLFlBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFmO0FBQ0EsWUFBSSxDQUFDLENBQUwsRUFDSSxPQUFPLENBQVA7QUFDSixZQUFJLENBQUMsR0FBRyxDQUFSOztBQUNBLGVBQU8sRUFBRSxDQUFGLEdBQU0sQ0FBTixHQUFVLENBQVYsSUFBZSxNQUFNLENBQUMsTUFBUCxDQUFjLENBQWQsTUFBcUIsR0FBM0M7QUFDSSxZQUFFLENBQUY7QUFESjs7QUFFQSxlQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsQ0FBMUIsSUFBK0IsQ0FBL0IsR0FBbUMsQ0FBMUM7QUFDSCxPQVJELENBZnlDLENBeUJ6Qzs7O0FBQ0EsVUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFKLENBQVUsRUFBVixDQUFWLENBMUJ5QyxDQTRCekM7O0FBQ0EsVUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFKLENBQVUsR0FBVixDQUFWLENBN0J5QyxDQStCekM7O0FBQ0EsV0FBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxFQUFwQjtBQUNJLFFBQUEsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxDQUFDLEdBQUcsRUFBSixHQUFTLENBQUMsR0FBRyxFQUFiLEdBQWtCLENBQUMsR0FBRyxFQUFKLEdBQVMsQ0FBQyxHQUFHLEVBQWIsR0FBa0IsQ0FBQyxHQUFHLEVBQUosR0FBUyxDQUFDLEdBQUcsQ0FBYixHQUFpQixDQUFDLEdBQUcsRUFBSixHQUFTLEVBQXhFLENBQUgsR0FBaUYsQ0FBQyxFQUFsRjtBQURKO0FBR0E7Ozs7Ozs7OztBQU9BLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCLEtBQXhCLEVBQStCLEdBQS9CLEVBQW9DO0FBQ2hELFlBQUksS0FBSyxHQUFHLElBQVo7QUFBQSxZQUNJLEtBQUssR0FBRyxFQURaO0FBRUEsWUFBSSxDQUFDLEdBQUcsQ0FBUjtBQUFBLFlBQVc7QUFDUCxRQUFBLENBQUMsR0FBRyxDQURSO0FBQUEsWUFDVztBQUNQLFFBQUEsQ0FGSixDQUhnRCxDQUtyQzs7QUFDWCxlQUFPLEtBQUssR0FBRyxHQUFmLEVBQW9CO0FBQ2hCLGNBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBZDs7QUFDQSxrQkFBUSxDQUFSO0FBQ0ksaUJBQUssQ0FBTDtBQUNJLGNBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFOLENBQWhCO0FBQ0EsY0FBQSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBTCxLQUFXLENBQWY7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBVixDQUFoQjtBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUFoQjtBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQTs7QUFDSixpQkFBSyxDQUFMO0FBQ0ksY0FBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFWLENBQWhCO0FBQ0EsY0FBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUwsQ0FBaEI7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7QUFmUjs7QUFpQkEsY0FBSSxDQUFDLEdBQUcsSUFBUixFQUFjO0FBQ1YsYUFBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQWIsQ0FBTixFQUF3QixJQUF4QixDQUE2QixNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFsQyxDQUE3QjtBQUNBLFlBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSDtBQUNKOztBQUNELFlBQUksQ0FBSixFQUFPO0FBQ0gsVUFBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBRCxDQUFoQjtBQUNBLFVBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsRUFBYjtBQUNBLGNBQUksQ0FBQyxLQUFLLENBQVYsRUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxFQUFiO0FBQ1A7O0FBQ0QsWUFBSSxLQUFKLEVBQVc7QUFDUCxjQUFJLENBQUosRUFDSSxLQUFLLENBQUMsSUFBTixDQUFXLE1BQU0sQ0FBQyxZQUFQLENBQW9CLEtBQXBCLENBQTBCLE1BQTFCLEVBQWtDLEtBQUssQ0FBQyxLQUFOLENBQVksQ0FBWixFQUFlLENBQWYsQ0FBbEMsQ0FBWDtBQUNKLGlCQUFPLEtBQUssQ0FBQyxJQUFOLENBQVcsRUFBWCxDQUFQO0FBQ0g7O0FBQ0QsZUFBTyxNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFLLENBQUMsS0FBTixDQUFZLENBQVosRUFBZSxDQUFmLENBQWxDLENBQVA7QUFDSCxPQTFDRDs7QUE0Q0EsVUFBSSxlQUFlLEdBQUcsa0JBQXRCO0FBRUE7Ozs7Ozs7OztBQVFBLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCLE1BQXhCLEVBQWdDLE1BQWhDLEVBQXdDO0FBQ3BELFlBQUksS0FBSyxHQUFHLE1BQVo7QUFDQSxZQUFJLENBQUMsR0FBRyxDQUFSO0FBQUEsWUFBVztBQUNQLFFBQUEsQ0FESixDQUZvRCxDQUd6Qzs7QUFDWCxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUEzQixHQUFvQztBQUNoQyxjQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsVUFBUCxDQUFrQixDQUFDLEVBQW5CLENBQVI7QUFDQSxjQUFJLENBQUMsS0FBSyxFQUFOLElBQVksQ0FBQyxHQUFHLENBQXBCLEVBQ0k7QUFDSixjQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFELENBQVIsTUFBaUIsU0FBckIsRUFDSSxNQUFNLEtBQUssQ0FBQyxlQUFELENBQVg7O0FBQ0osa0JBQVEsQ0FBUjtBQUNJLGlCQUFLLENBQUw7QUFDSSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0EsY0FBQSxDQUFDLEdBQUcsQ0FBSjtBQUNBOztBQUNKLGlCQUFLLENBQUw7QUFDSSxjQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixDQUFDLElBQUksQ0FBTCxHQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUF4QztBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUFaLEdBQWdCLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUEvQztBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLENBQUMsQ0FBQyxHQUFHLENBQUwsS0FBVyxDQUFYLEdBQWUsQ0FBbEM7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7QUFsQlI7QUFvQkg7O0FBQ0QsWUFBSSxDQUFDLEtBQUssQ0FBVixFQUNJLE1BQU0sS0FBSyxDQUFDLGVBQUQsQ0FBWDtBQUNKLGVBQU8sTUFBTSxHQUFHLEtBQWhCO0FBQ0gsT0FsQ0Q7QUFvQ0E7Ozs7Ozs7QUFLQSxNQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsU0FBUyxJQUFULENBQWMsTUFBZCxFQUFzQjtBQUNoQyxlQUFPLG1FQUFtRSxJQUFuRSxDQUF3RSxNQUF4RSxDQUFQO0FBQ0gsT0FGRDtBQUlDLEtBN0lPLEVBNklOLEVBN0lNLENBdERlO0FBbU1qQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsWUFBakI7QUFFQTs7Ozs7OztBQU1BLGVBQVMsWUFBVCxHQUF3QjtBQUVwQjs7Ozs7QUFLQSxhQUFLLFVBQUwsR0FBa0IsRUFBbEI7QUFDSDtBQUVEOzs7Ozs7Ozs7QUFPQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLEVBQXZCLEdBQTRCLFNBQVMsRUFBVCxDQUFZLEdBQVosRUFBaUIsRUFBakIsRUFBcUIsR0FBckIsRUFBMEI7QUFDbEQsU0FBQyxLQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsTUFBeUIsS0FBSyxVQUFMLENBQWdCLEdBQWhCLElBQXVCLEVBQWhELENBQUQsRUFBc0QsSUFBdEQsQ0FBMkQ7QUFDdkQsVUFBQSxFQUFFLEVBQUksRUFEaUQ7QUFFdkQsVUFBQSxHQUFHLEVBQUcsR0FBRyxJQUFJO0FBRjBDLFNBQTNEO0FBSUEsZUFBTyxJQUFQO0FBQ0gsT0FORDtBQVFBOzs7Ozs7OztBQU1BLE1BQUEsWUFBWSxDQUFDLFNBQWIsQ0FBdUIsR0FBdkIsR0FBNkIsU0FBUyxHQUFULENBQWEsR0FBYixFQUFrQixFQUFsQixFQUFzQjtBQUMvQyxZQUFJLEdBQUcsS0FBSyxTQUFaLEVBQ0ksS0FBSyxVQUFMLEdBQWtCLEVBQWxCLENBREosS0FFSztBQUNELGNBQUksRUFBRSxLQUFLLFNBQVgsRUFDSSxLQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsSUFBdUIsRUFBdkIsQ0FESixLQUVLO0FBQ0QsZ0JBQUksU0FBUyxHQUFHLEtBQUssVUFBTCxDQUFnQixHQUFoQixDQUFoQjs7QUFDQSxpQkFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBOUI7QUFDSSxrQkFBSSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsRUFBYixLQUFvQixFQUF4QixFQUNJLFNBQVMsQ0FBQyxNQUFWLENBQWlCLENBQWpCLEVBQW9CLENBQXBCLEVBREosS0FHSSxFQUFFLENBQUY7QUFKUjtBQUtIO0FBQ0o7QUFDRCxlQUFPLElBQVA7QUFDSCxPQWhCRDtBQWtCQTs7Ozs7Ozs7QUFNQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLElBQXZCLEdBQThCLFNBQVMsSUFBVCxDQUFjLEdBQWQsRUFBbUI7QUFDN0MsWUFBSSxTQUFTLEdBQUcsS0FBSyxVQUFMLENBQWdCLEdBQWhCLENBQWhCOztBQUNBLFlBQUksU0FBSixFQUFlO0FBQ1gsY0FBSSxJQUFJLEdBQUcsRUFBWDtBQUFBLGNBQ0ksQ0FBQyxHQUFHLENBRFI7O0FBRUEsaUJBQU8sQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFyQjtBQUNJLFlBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFTLENBQUMsQ0FBQyxFQUFGLENBQW5CO0FBREo7O0FBRUEsZUFBSyxDQUFDLEdBQUcsQ0FBVCxFQUFZLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBMUI7QUFDSSxZQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxFQUFiLENBQWdCLEtBQWhCLENBQXNCLFNBQVMsQ0FBQyxDQUFDLEVBQUYsQ0FBVCxDQUFlLEdBQXJDLEVBQTBDLElBQTFDO0FBREo7QUFFSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQVhEO0FBYUMsS0E5RU8sRUE4RU4sRUE5RU0sQ0FuTWU7QUFpUmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBRUEsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixPQUFPLENBQUMsT0FBRCxDQUF4QjtBQUVBOzs7Ozs7QUFNQTs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7OztBQVNBOzs7Ozs7Ozs7QUFTQTs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7OztBQVNBOzs7Ozs7OztBQVNBOztBQUNBLGVBQVMsT0FBVCxDQUFpQixPQUFqQixFQUEwQjtBQUV0QjtBQUNBLFlBQUksT0FBTyxZQUFQLEtBQXdCLFdBQTVCLEVBQXlDLENBQUMsWUFBVztBQUVqRCxjQUFJLEdBQUcsR0FBRyxJQUFJLFlBQUosQ0FBaUIsQ0FBRSxDQUFDLENBQUgsQ0FBakIsQ0FBVjtBQUFBLGNBQ0ksR0FBRyxHQUFHLElBQUksVUFBSixDQUFlLEdBQUcsQ0FBQyxNQUFuQixDQURWO0FBQUEsY0FFSSxFQUFFLEdBQUksR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBRnJCOztBQUlBLG1CQUFTLGtCQUFULENBQTRCLEdBQTVCLEVBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLEVBQTJDO0FBQ3ZDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIOztBQUVELG1CQUFTLGtCQUFULENBQTRCLEdBQTVCLEVBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLEVBQTJDO0FBQ3ZDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDs7QUFFQSxtQkFBUyxpQkFBVCxDQUEyQixHQUEzQixFQUFnQyxHQUFoQyxFQUFxQztBQUNqQyxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsbUJBQU8sR0FBRyxDQUFDLENBQUQsQ0FBVjtBQUNIOztBQUVELG1CQUFTLGlCQUFULENBQTJCLEdBQTNCLEVBQWdDLEdBQWhDLEVBQXFDO0FBQ2pDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFELENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxtQkFBTyxHQUFHLENBQUMsQ0FBRCxDQUFWO0FBQ0g7QUFFRDs7O0FBQ0EsVUFBQSxPQUFPLENBQUMsV0FBUixHQUFzQixFQUFFLEdBQUcsaUJBQUgsR0FBdUIsaUJBQS9DO0FBQ0E7O0FBQ0EsVUFBQSxPQUFPLENBQUMsV0FBUixHQUFzQixFQUFFLEdBQUcsaUJBQUgsR0FBdUIsaUJBQS9DLENBOUNpRCxDQWdEckQ7QUFDQyxTQWpEd0MsSUFBekMsS0FpRFcsQ0FBQyxZQUFXO0FBRW5CLG1CQUFTLGtCQUFULENBQTRCLFNBQTVCLEVBQXVDLEdBQXZDLEVBQTRDLEdBQTVDLEVBQWlELEdBQWpELEVBQXNEO0FBQ2xELGdCQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBTixHQUFVLENBQVYsR0FBYyxDQUF6QjtBQUNBLGdCQUFJLElBQUosRUFDSSxHQUFHLEdBQUcsQ0FBQyxHQUFQO0FBQ0osZ0JBQUksR0FBRyxLQUFLLENBQVosRUFDSSxTQUFTLENBQUMsSUFBSSxHQUFKLEdBQVUsQ0FBVjtBQUFjO0FBQWUsYUFBN0I7QUFBaUM7QUFBaUIsc0JBQW5ELEVBQStELEdBQS9ELEVBQW9FLEdBQXBFLENBQVQsQ0FESixLQUVLLElBQUksS0FBSyxDQUFDLEdBQUQsQ0FBVCxFQUNELFNBQVMsQ0FBQyxVQUFELEVBQWEsR0FBYixFQUFrQixHQUFsQixDQUFULENBREMsS0FFQSxJQUFJLEdBQUcsR0FBRyxzQkFBVixFQUFrQztBQUNuQyxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsVUFBZCxNQUE4QixDQUEvQixFQUFrQyxHQUFsQyxFQUF1QyxHQUF2QyxDQUFULENBREMsS0FFQSxJQUFJLEdBQUcsR0FBRyxzQkFBVixFQUFrQztBQUNuQyxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsSUFBSSxDQUFDLEtBQUwsQ0FBVyxHQUFHLEdBQUcscUJBQWpCLENBQWQsTUFBMkQsQ0FBNUQsRUFBK0QsR0FBL0QsRUFBb0UsR0FBcEUsQ0FBVCxDQURDLEtBRUE7QUFDRCxrQkFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEdBQVQsSUFBZ0IsSUFBSSxDQUFDLEdBQWhDLENBQWY7QUFBQSxrQkFDSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksQ0FBQyxRQUFiLENBQU4sR0FBK0IsT0FBMUMsSUFBcUQsT0FEcEU7QUFFQSxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsUUFBUSxHQUFHLEdBQVgsSUFBa0IsRUFBL0IsR0FBb0MsUUFBckMsTUFBbUQsQ0FBcEQsRUFBdUQsR0FBdkQsRUFBNEQsR0FBNUQsQ0FBVDtBQUNIO0FBQ0o7O0FBRUQsVUFBQSxPQUFPLENBQUMsWUFBUixHQUF1QixrQkFBa0IsQ0FBQyxJQUFuQixDQUF3QixJQUF4QixFQUE4QixXQUE5QixDQUF2QjtBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEIsV0FBOUIsQ0FBdkI7O0FBRUEsbUJBQVMsaUJBQVQsQ0FBMkIsUUFBM0IsRUFBcUMsR0FBckMsRUFBMEMsR0FBMUMsRUFBK0M7QUFDM0MsZ0JBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFuQjtBQUFBLGdCQUNJLElBQUksR0FBRyxDQUFDLElBQUksSUFBSSxFQUFULElBQWUsQ0FBZixHQUFtQixDQUQ5QjtBQUFBLGdCQUVJLFFBQVEsR0FBRyxJQUFJLEtBQUssRUFBVCxHQUFjLEdBRjdCO0FBQUEsZ0JBR0ksUUFBUSxHQUFHLElBQUksR0FBRyxPQUh0QjtBQUlBLG1CQUFPLFFBQVEsS0FBSyxHQUFiLEdBQ0QsUUFBUSxHQUNSLEdBRFEsR0FFUixJQUFJLEdBQUcsUUFITixHQUlELFFBQVEsS0FBSyxDQUFiLENBQWU7QUFBZixjQUNBLElBQUksR0FBRyxxQkFBUCxHQUErQixRQUQvQixHQUVBLElBQUksR0FBRyxJQUFJLENBQUMsR0FBTCxDQUFTLENBQVQsRUFBWSxRQUFRLEdBQUcsR0FBdkIsQ0FBUCxJQUFzQyxRQUFRLEdBQUcsT0FBakQsQ0FOTjtBQU9IOztBQUVELFVBQUEsT0FBTyxDQUFDLFdBQVIsR0FBc0IsaUJBQWlCLENBQUMsSUFBbEIsQ0FBdUIsSUFBdkIsRUFBNkIsVUFBN0IsQ0FBdEI7QUFDQSxVQUFBLE9BQU8sQ0FBQyxXQUFSLEdBQXNCLGlCQUFpQixDQUFDLElBQWxCLENBQXVCLElBQXZCLEVBQTZCLFVBQTdCLENBQXRCO0FBRUgsU0F6Q1UsSUFwRFcsQ0ErRnRCOztBQUNBLFlBQUksT0FBTyxZQUFQLEtBQXdCLFdBQTVCLEVBQXlDLENBQUMsWUFBVztBQUVqRCxjQUFJLEdBQUcsR0FBRyxJQUFJLFlBQUosQ0FBaUIsQ0FBQyxDQUFDLENBQUYsQ0FBakIsQ0FBVjtBQUFBLGNBQ0ksR0FBRyxHQUFHLElBQUksVUFBSixDQUFlLEdBQUcsQ0FBQyxNQUFuQixDQURWO0FBQUEsY0FFSSxFQUFFLEdBQUksR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBRnJCOztBQUlBLG1CQUFTLG1CQUFULENBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDLEdBQXZDLEVBQTRDO0FBQ3hDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIOztBQUVELG1CQUFTLG1CQUFULENBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDLEdBQXZDLEVBQTRDO0FBQ3hDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsRUFBRSxHQUFHLG1CQUFILEdBQXlCLG1CQUFuRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsRUFBRSxHQUFHLG1CQUFILEdBQXlCLG1CQUFuRDs7QUFFQSxtQkFBUyxrQkFBVCxDQUE0QixHQUE1QixFQUFpQyxHQUFqQyxFQUFzQztBQUNsQyxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxtQkFBTyxHQUFHLENBQUMsQ0FBRCxDQUFWO0FBQ0g7O0FBRUQsbUJBQVMsa0JBQVQsQ0FBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUQsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsbUJBQU8sR0FBRyxDQUFDLENBQUQsQ0FBVjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRCxDQTlEaUQsQ0FnRXJEO0FBQ0MsU0FqRXdDLElBQXpDLEtBaUVXLENBQUMsWUFBVztBQUVuQixtQkFBUyxtQkFBVCxDQUE2QixTQUE3QixFQUF3QyxJQUF4QyxFQUE4QyxJQUE5QyxFQUFvRCxHQUFwRCxFQUF5RCxHQUF6RCxFQUE4RCxHQUE5RCxFQUFtRTtBQUMvRCxnQkFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQU4sR0FBVSxDQUFWLEdBQWMsQ0FBekI7QUFDQSxnQkFBSSxJQUFKLEVBQ0ksR0FBRyxHQUFHLENBQUMsR0FBUDs7QUFDSixnQkFBSSxHQUFHLEtBQUssQ0FBWixFQUFlO0FBQ1gsY0FBQSxTQUFTLENBQUMsQ0FBRCxFQUFJLEdBQUosRUFBUyxHQUFHLEdBQUcsSUFBZixDQUFUO0FBQ0EsY0FBQSxTQUFTLENBQUMsSUFBSSxHQUFKLEdBQVUsQ0FBVjtBQUFjO0FBQWUsZUFBN0I7QUFBaUM7QUFBaUIsd0JBQW5ELEVBQStELEdBQS9ELEVBQW9FLEdBQUcsR0FBRyxJQUExRSxDQUFUO0FBQ0gsYUFIRCxNQUdPLElBQUksS0FBSyxDQUFDLEdBQUQsQ0FBVCxFQUFnQjtBQUNuQixjQUFBLFNBQVMsQ0FBQyxDQUFELEVBQUksR0FBSixFQUFTLEdBQUcsR0FBRyxJQUFmLENBQVQ7QUFDQSxjQUFBLFNBQVMsQ0FBQyxVQUFELEVBQWEsR0FBYixFQUFrQixHQUFHLEdBQUcsSUFBeEIsQ0FBVDtBQUNILGFBSE0sTUFHQSxJQUFJLEdBQUcsR0FBRyx1QkFBVixFQUFtQztBQUFFO0FBQ3hDLGNBQUEsU0FBUyxDQUFDLENBQUQsRUFBSSxHQUFKLEVBQVMsR0FBRyxHQUFHLElBQWYsQ0FBVDtBQUNBLGNBQUEsU0FBUyxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQVIsR0FBYSxVQUFkLE1BQThCLENBQS9CLEVBQWtDLEdBQWxDLEVBQXVDLEdBQUcsR0FBRyxJQUE3QyxDQUFUO0FBQ0gsYUFITSxNQUdBO0FBQ0gsa0JBQUksUUFBSjs7QUFDQSxrQkFBSSxHQUFHLEdBQUcsdUJBQVYsRUFBbUM7QUFBRTtBQUNqQyxnQkFBQSxRQUFRLEdBQUcsR0FBRyxHQUFHLE1BQWpCO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLFFBQVEsS0FBSyxDQUFkLEVBQWlCLEdBQWpCLEVBQXNCLEdBQUcsR0FBRyxJQUE1QixDQUFUO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQVIsR0FBYSxRQUFRLEdBQUcsVUFBekIsTUFBeUMsQ0FBMUMsRUFBNkMsR0FBN0MsRUFBa0QsR0FBRyxHQUFHLElBQXhELENBQVQ7QUFDSCxlQUpELE1BSU87QUFDSCxvQkFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEdBQVQsSUFBZ0IsSUFBSSxDQUFDLEdBQWhDLENBQWY7QUFDQSxvQkFBSSxRQUFRLEtBQUssSUFBakIsRUFDSSxRQUFRLEdBQUcsSUFBWDtBQUNKLGdCQUFBLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksQ0FBQyxRQUFiLENBQWpCO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLFFBQVEsR0FBRyxnQkFBWCxLQUFnQyxDQUFqQyxFQUFvQyxHQUFwQyxFQUF5QyxHQUFHLEdBQUcsSUFBL0MsQ0FBVDtBQUNBLGdCQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsUUFBUSxHQUFHLElBQVgsSUFBbUIsRUFBaEMsR0FBcUMsUUFBUSxHQUFHLE9BQVgsR0FBcUIsT0FBM0QsTUFBd0UsQ0FBekUsRUFBNEUsR0FBNUUsRUFBaUYsR0FBRyxHQUFHLElBQXZGLENBQVQ7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsVUFBQSxPQUFPLENBQUMsYUFBUixHQUF3QixtQkFBbUIsQ0FBQyxJQUFwQixDQUF5QixJQUF6QixFQUErQixXQUEvQixFQUE0QyxDQUE1QyxFQUErQyxDQUEvQyxDQUF4QjtBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsbUJBQW1CLENBQUMsSUFBcEIsQ0FBeUIsSUFBekIsRUFBK0IsV0FBL0IsRUFBNEMsQ0FBNUMsRUFBK0MsQ0FBL0MsQ0FBeEI7O0FBRUEsbUJBQVMsa0JBQVQsQ0FBNEIsUUFBNUIsRUFBc0MsSUFBdEMsRUFBNEMsSUFBNUMsRUFBa0QsR0FBbEQsRUFBdUQsR0FBdkQsRUFBNEQ7QUFDeEQsZ0JBQUksRUFBRSxHQUFHLFFBQVEsQ0FBQyxHQUFELEVBQU0sR0FBRyxHQUFHLElBQVosQ0FBakI7QUFBQSxnQkFDSSxFQUFFLEdBQUcsUUFBUSxDQUFDLEdBQUQsRUFBTSxHQUFHLEdBQUcsSUFBWixDQURqQjtBQUVBLGdCQUFJLElBQUksR0FBRyxDQUFDLEVBQUUsSUFBSSxFQUFQLElBQWEsQ0FBYixHQUFpQixDQUE1QjtBQUFBLGdCQUNJLFFBQVEsR0FBRyxFQUFFLEtBQUssRUFBUCxHQUFZLElBRDNCO0FBQUEsZ0JBRUksUUFBUSxHQUFHLGNBQWMsRUFBRSxHQUFHLE9BQW5CLElBQThCLEVBRjdDO0FBR0EsbUJBQU8sUUFBUSxLQUFLLElBQWIsR0FDRCxRQUFRLEdBQ1IsR0FEUSxHQUVSLElBQUksR0FBRyxRQUhOLEdBSUQsUUFBUSxLQUFLLENBQWIsQ0FBZTtBQUFmLGNBQ0EsSUFBSSxHQUFHLE1BQVAsR0FBZ0IsUUFEaEIsR0FFQSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksUUFBUSxHQUFHLElBQXZCLENBQVAsSUFBdUMsUUFBUSxHQUFHLGdCQUFsRCxDQU5OO0FBT0g7O0FBRUQsVUFBQSxPQUFPLENBQUMsWUFBUixHQUF1QixrQkFBa0IsQ0FBQyxJQUFuQixDQUF3QixJQUF4QixFQUE4QixVQUE5QixFQUEwQyxDQUExQyxFQUE2QyxDQUE3QyxDQUF2QjtBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEIsVUFBOUIsRUFBMEMsQ0FBMUMsRUFBNkMsQ0FBN0MsQ0FBdkI7QUFFSCxTQXJEVTtBQXVEWCxlQUFPLE9BQVA7QUFDSCxPQWpUd0MsQ0FtVHpDOzs7QUFFQSxlQUFTLFdBQVQsQ0FBcUIsR0FBckIsRUFBMEIsR0FBMUIsRUFBK0IsR0FBL0IsRUFBb0M7QUFDaEMsUUFBQSxHQUFHLENBQUMsR0FBRCxDQUFILEdBQWdCLEdBQUcsR0FBVSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLENBQVIsR0FBYSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLEVBQVIsR0FBYSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLEVBQXhCO0FBQ0g7O0FBRUQsZUFBUyxXQUFULENBQXFCLEdBQXJCLEVBQTBCLEdBQTFCLEVBQStCLEdBQS9CLEVBQW9DO0FBQ2hDLFFBQUEsR0FBRyxDQUFDLEdBQUQsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBeEI7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsS0FBSyxFQUFSLEdBQWEsR0FBN0I7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsS0FBSyxDQUFSLEdBQWEsR0FBN0I7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsR0FBVSxHQUE3QjtBQUNIOztBQUVELGVBQVMsVUFBVCxDQUFvQixHQUFwQixFQUF5QixHQUF6QixFQUE4QjtBQUMxQixlQUFPLENBQUMsR0FBRyxDQUFDLEdBQUQsQ0FBSCxHQUNBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLENBRGhCLEdBRUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsRUFGaEIsR0FHQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxJQUFnQixFQUhqQixNQUd5QixDQUhoQztBQUlIOztBQUVELGVBQVMsVUFBVCxDQUFvQixHQUFwQixFQUF5QixHQUF6QixFQUE4QjtBQUMxQixlQUFPLENBQUMsR0FBRyxDQUFDLEdBQUQsQ0FBSCxJQUFnQixFQUFoQixHQUNBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLEVBRGhCLEdBRUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsQ0FGaEIsR0FHQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FISixNQUdtQixDQUgxQjtBQUlIO0FBRUEsS0FqVk8sRUFpVk4sRUFqVk0sQ0FqUmU7QUFrbUJqQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsT0FBakI7QUFFQTs7Ozs7OztBQU1BLGVBQVMsT0FBVCxDQUFpQixVQUFqQixFQUE2QjtBQUN6QixZQUFJO0FBQ0EsY0FBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsT0FBUixDQUFnQixHQUFoQixFQUFvQixJQUFwQixDQUFELENBQUosQ0FBZ0MsVUFBaEMsQ0FBVixDQURBLENBQ3VEOztBQUN2RCxjQUFJLEdBQUcsS0FBSyxHQUFHLENBQUMsTUFBSixJQUFjLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixFQUFpQixNQUFwQyxDQUFQLEVBQ0ksT0FBTyxHQUFQO0FBQ1AsU0FKRCxDQUlFLE9BQU8sQ0FBUCxFQUFVLENBQUUsQ0FMVyxDQUtWOzs7QUFDZixlQUFPLElBQVA7QUFDSDtBQUVBLEtBbkJPLEVBbUJOLEVBbkJNLENBbG1CZTtBQXFuQmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixJQUFqQjtBQUVBOzs7Ozs7OztBQVFBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7Ozs7QUFTQSxlQUFTLElBQVQsQ0FBYyxLQUFkLEVBQXFCLEtBQXJCLEVBQTRCLElBQTVCLEVBQWtDO0FBQzlCLFlBQUksSUFBSSxHQUFLLElBQUksSUFBSSxJQUFyQjtBQUNBLFlBQUksR0FBRyxHQUFNLElBQUksS0FBSyxDQUF0QjtBQUNBLFlBQUksSUFBSSxHQUFLLElBQWI7QUFDQSxZQUFJLE1BQU0sR0FBRyxJQUFiO0FBQ0EsZUFBTyxTQUFTLFVBQVQsQ0FBb0IsSUFBcEIsRUFBMEI7QUFDN0IsY0FBSSxJQUFJLEdBQUcsQ0FBUCxJQUFZLElBQUksR0FBRyxHQUF2QixFQUNJLE9BQU8sS0FBSyxDQUFDLElBQUQsQ0FBWjs7QUFDSixjQUFJLE1BQU0sR0FBRyxJQUFULEdBQWdCLElBQXBCLEVBQTBCO0FBQ3RCLFlBQUEsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFELENBQVo7QUFDQSxZQUFBLE1BQU0sR0FBRyxDQUFUO0FBQ0g7O0FBQ0QsY0FBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLElBQU4sQ0FBVyxJQUFYLEVBQWlCLE1BQWpCLEVBQXlCLE1BQU0sSUFBSSxJQUFuQyxDQUFWO0FBQ0EsY0FBSSxNQUFNLEdBQUcsQ0FBYixFQUFnQjtBQUNaLFlBQUEsTUFBTSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQVYsSUFBZSxDQUF4QjtBQUNKLGlCQUFPLEdBQVA7QUFDSCxTQVhEO0FBWUg7QUFFQSxLQWxETyxFQWtETixFQWxETSxDQXJuQmU7QUF1cUJqQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDO0FBRUE7Ozs7OztBQUtBLFVBQUksSUFBSSxHQUFHLE9BQVg7QUFFQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLFNBQVMsV0FBVCxDQUFxQixNQUFyQixFQUE2QjtBQUN2QyxZQUFJLEdBQUcsR0FBRyxDQUFWO0FBQUEsWUFDSSxDQUFDLEdBQUcsQ0FEUjs7QUFFQSxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUEzQixFQUFtQyxFQUFFLENBQXJDLEVBQXdDO0FBQ3BDLFVBQUEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxVQUFQLENBQWtCLENBQWxCLENBQUo7QUFDQSxjQUFJLENBQUMsR0FBRyxHQUFSLEVBQ0ksR0FBRyxJQUFJLENBQVAsQ0FESixLQUVLLElBQUksQ0FBQyxHQUFHLElBQVIsRUFDRCxHQUFHLElBQUksQ0FBUCxDQURDLEtBRUEsSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFMLE1BQWlCLE1BQWpCLElBQTJCLENBQUMsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsQ0FBQyxHQUFHLENBQXRCLElBQTJCLE1BQTVCLE1BQXdDLE1BQXZFLEVBQStFO0FBQ2hGLGNBQUUsQ0FBRjtBQUNBLFlBQUEsR0FBRyxJQUFJLENBQVA7QUFDSCxXQUhJLE1BSUQsR0FBRyxJQUFJLENBQVA7QUFDUDs7QUFDRCxlQUFPLEdBQVA7QUFDSCxPQWhCRDtBQWtCQTs7Ozs7Ozs7O0FBT0EsTUFBQSxJQUFJLENBQUMsSUFBTCxHQUFZLFNBQVMsU0FBVCxDQUFtQixNQUFuQixFQUEyQixLQUEzQixFQUFrQyxHQUFsQyxFQUF1QztBQUMvQyxZQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBaEI7QUFDQSxZQUFJLEdBQUcsR0FBRyxDQUFWLEVBQ0ksT0FBTyxFQUFQO0FBQ0osWUFBSSxLQUFLLEdBQUcsSUFBWjtBQUFBLFlBQ0ksS0FBSyxHQUFHLEVBRFo7QUFBQSxZQUVJLENBQUMsR0FBRyxDQUZSO0FBQUEsWUFFVztBQUNQLFFBQUEsQ0FISixDQUorQyxDQU9wQzs7QUFDWCxlQUFPLEtBQUssR0FBRyxHQUFmLEVBQW9CO0FBQ2hCLFVBQUEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBVjtBQUNBLGNBQUksQ0FBQyxHQUFHLEdBQVIsRUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxDQUFiLENBREosS0FFSyxJQUFJLENBQUMsR0FBRyxHQUFKLElBQVcsQ0FBQyxHQUFHLEdBQW5CLEVBQ0QsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBTCxLQUFZLENBQVosR0FBZ0IsTUFBTSxDQUFDLEtBQUssRUFBTixDQUFOLEdBQWtCLEVBQS9DLENBREMsS0FFQSxJQUFJLENBQUMsR0FBRyxHQUFKLElBQVcsQ0FBQyxHQUFHLEdBQW5CLEVBQXdCO0FBQ3pCLFlBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBTCxLQUFXLEVBQVgsR0FBZ0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBbkIsS0FBMEIsRUFBMUMsR0FBK0MsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBbkIsS0FBMEIsQ0FBekUsR0FBNkUsTUFBTSxDQUFDLEtBQUssRUFBTixDQUFOLEdBQWtCLEVBQWhHLElBQXNHLE9BQTFHO0FBQ0EsWUFBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxVQUFVLENBQUMsSUFBSSxFQUFmLENBQWI7QUFDQSxZQUFBLEtBQUssQ0FBQyxDQUFDLEVBQUYsQ0FBTCxHQUFhLFVBQVUsQ0FBQyxHQUFHLElBQWQsQ0FBYjtBQUNILFdBSkksTUFLRCxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxDQUFDLENBQUMsR0FBRyxFQUFMLEtBQVksRUFBWixHQUFpQixDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBTixHQUFrQixFQUFuQixLQUEwQixDQUEzQyxHQUErQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBOUU7O0FBQ0osY0FBSSxDQUFDLEdBQUcsSUFBUixFQUFjO0FBQ1YsYUFBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQWIsQ0FBTixFQUF3QixJQUF4QixDQUE2QixNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFsQyxDQUE3QjtBQUNBLFlBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSDtBQUNKOztBQUNELFlBQUksS0FBSixFQUFXO0FBQ1AsY0FBSSxDQUFKLEVBQ0ksS0FBSyxDQUFDLElBQU4sQ0FBVyxNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFLLENBQUMsS0FBTixDQUFZLENBQVosRUFBZSxDQUFmLENBQWxDLENBQVg7QUFDSixpQkFBTyxLQUFLLENBQUMsSUFBTixDQUFXLEVBQVgsQ0FBUDtBQUNIOztBQUNELGVBQU8sTUFBTSxDQUFDLFlBQVAsQ0FBb0IsS0FBcEIsQ0FBMEIsTUFBMUIsRUFBa0MsS0FBSyxDQUFDLEtBQU4sQ0FBWSxDQUFaLEVBQWUsQ0FBZixDQUFsQyxDQUFQO0FBQ0gsT0EvQkQ7QUFpQ0E7Ozs7Ozs7OztBQU9BLE1BQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxTQUFTLFVBQVQsQ0FBb0IsTUFBcEIsRUFBNEIsTUFBNUIsRUFBb0MsTUFBcEMsRUFBNEM7QUFDckQsWUFBSSxLQUFLLEdBQUcsTUFBWjtBQUFBLFlBQ0ksRUFESjtBQUFBLFlBQ1E7QUFDSixRQUFBLEVBRkosQ0FEcUQsQ0FHN0M7O0FBQ1IsYUFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBM0IsRUFBbUMsRUFBRSxDQUFyQyxFQUF3QztBQUNwQyxVQUFBLEVBQUUsR0FBRyxNQUFNLENBQUMsVUFBUCxDQUFrQixDQUFsQixDQUFMOztBQUNBLGNBQUksRUFBRSxHQUFHLEdBQVQsRUFBYztBQUNWLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQW5CO0FBQ0gsV0FGRCxNQUVPLElBQUksRUFBRSxHQUFHLElBQVQsRUFBZTtBQUNsQixZQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixFQUFFLElBQUksQ0FBTixHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsR0FBUyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0gsV0FITSxNQUdBLElBQUksQ0FBQyxFQUFFLEdBQUcsTUFBTixNQUFrQixNQUFsQixJQUE0QixDQUFDLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxVQUFQLENBQWtCLENBQUMsR0FBRyxDQUF0QixDQUFOLElBQWtDLE1BQW5DLE1BQStDLE1BQS9FLEVBQXVGO0FBQzFGLFlBQUEsRUFBRSxHQUFHLFdBQVcsQ0FBQyxFQUFFLEdBQUcsTUFBTixLQUFpQixFQUE1QixLQUFtQyxFQUFFLEdBQUcsTUFBeEMsQ0FBTDtBQUNBLGNBQUUsQ0FBRjtBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsSUFBSSxFQUFOLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxJQUFJLEVBQU4sR0FBVyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxJQUFJLENBQU4sR0FBVyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxHQUFTLEVBQVgsR0FBZ0IsR0FBbkM7QUFDSCxXQVBNLE1BT0E7QUFDSCxZQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixFQUFFLElBQUksRUFBTixHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsSUFBSSxDQUFOLEdBQVcsRUFBWCxHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsR0FBUyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0g7QUFDSjs7QUFDRCxlQUFPLE1BQU0sR0FBRyxLQUFoQjtBQUNILE9BekJEO0FBMkJDLEtBM0dPLEVBMkdOLEVBM0dNLENBdnFCZTtBQWt4QmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBQ0EsVUFBSSxRQUFRLEdBQUcsT0FBZjtBQUVBOzs7Ozs7O0FBTUEsTUFBQSxRQUFRLENBQUMsS0FBVCxHQUFpQixTQUFqQixDQVZ5QyxDQVl6Qzs7QUFDQSxNQUFBLFFBQVEsQ0FBQyxNQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CO0FBQ0EsTUFBQSxRQUFRLENBQUMsWUFBVCxHQUF3QixPQUFPLENBQUMsRUFBRCxDQUEvQjtBQUNBLE1BQUEsUUFBUSxDQUFDLE1BQVQsR0FBd0IsT0FBTyxDQUFDLENBQUQsQ0FBL0I7QUFDQSxNQUFBLFFBQVEsQ0FBQyxZQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CLENBaEJ5QyxDQWtCekM7O0FBQ0EsTUFBQSxRQUFRLENBQUMsSUFBVCxHQUF3QixPQUFPLENBQUMsRUFBRCxDQUEvQjtBQUNBLE1BQUEsUUFBUSxDQUFDLEdBQVQsR0FBd0IsT0FBTyxDQUFDLEVBQUQsQ0FBL0I7QUFDQSxNQUFBLFFBQVEsQ0FBQyxLQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CO0FBQ0EsTUFBQSxRQUFRLENBQUMsU0FBVCxHQUF3QixTQUF4QjtBQUVBOztBQUNBOzs7OztBQUlBLGVBQVMsU0FBVCxHQUFxQjtBQUNqQixRQUFBLFFBQVEsQ0FBQyxJQUFULENBQWMsVUFBZDs7QUFDQSxRQUFBLFFBQVEsQ0FBQyxNQUFULENBQWdCLFVBQWhCLENBQTJCLFFBQVEsQ0FBQyxZQUFwQzs7QUFDQSxRQUFBLFFBQVEsQ0FBQyxNQUFULENBQWdCLFVBQWhCLENBQTJCLFFBQVEsQ0FBQyxZQUFwQztBQUNILE9BakN3QyxDQW1DekM7OztBQUNBLE1BQUEsU0FBUztBQUVSLEtBdENPLEVBc0NOO0FBQUMsWUFBSyxFQUFOO0FBQVMsWUFBSyxFQUFkO0FBQWlCLFlBQUssRUFBdEI7QUFBeUIsWUFBSyxFQUE5QjtBQUFpQyxZQUFLLEVBQXRDO0FBQXlDLFlBQUssRUFBOUM7QUFBaUQsV0FBSTtBQUFyRCxLQXRDTSxDQWx4QmU7QUF3ekJvQyxPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQzlGOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsTUFBakI7O0FBRUEsVUFBSSxJQUFJLEdBQVEsT0FBTyxDQUFDLEVBQUQsQ0FBdkI7O0FBRUEsVUFBSSxZQUFKLENBTjhGLENBTTVFOztBQUVsQixVQUFJLFFBQVEsR0FBSSxJQUFJLENBQUMsUUFBckI7QUFBQSxVQUNJLElBQUksR0FBUSxJQUFJLENBQUMsSUFEckI7QUFHQTs7QUFDQSxlQUFTLGVBQVQsQ0FBeUIsTUFBekIsRUFBaUMsV0FBakMsRUFBOEM7QUFDMUMsZUFBTyxVQUFVLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxHQUFoQyxHQUFzQyxLQUF0QyxJQUErQyxXQUFXLElBQUksQ0FBOUQsSUFBbUUsS0FBbkUsR0FBMkUsTUFBTSxDQUFDLEdBQW5GLENBQWpCO0FBQ0g7QUFFRDs7Ozs7Ozs7QUFNQSxlQUFTLE1BQVQsQ0FBZ0IsTUFBaEIsRUFBd0I7QUFFcEI7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxNQUFYO0FBRUE7Ozs7O0FBSUEsYUFBSyxHQUFMLEdBQVcsQ0FBWDtBQUVBOzs7OztBQUlBLGFBQUssR0FBTCxHQUFXLE1BQU0sQ0FBQyxNQUFsQjtBQUNIOztBQUVELFVBQUksWUFBWSxHQUFHLE9BQU8sVUFBUCxLQUFzQixXQUF0QixHQUNiLFNBQVMsa0JBQVQsQ0FBNEIsTUFBNUIsRUFBb0M7QUFDbEMsWUFBSSxNQUFNLFlBQVksVUFBbEIsSUFBZ0MsS0FBSyxDQUFDLE9BQU4sQ0FBYyxNQUFkLENBQXBDLEVBQ0ksT0FBTyxJQUFJLE1BQUosQ0FBVyxNQUFYLENBQVA7QUFDSixjQUFNLEtBQUssQ0FBQyxnQkFBRCxDQUFYO0FBQ0g7QUFDRDtBQU5lLFFBT2IsU0FBUyxZQUFULENBQXNCLE1BQXRCLEVBQThCO0FBQzVCLFlBQUksS0FBSyxDQUFDLE9BQU4sQ0FBYyxNQUFkLENBQUosRUFDSSxPQUFPLElBQUksTUFBSixDQUFXLE1BQVgsQ0FBUDtBQUNKLGNBQU0sS0FBSyxDQUFDLGdCQUFELENBQVg7QUFDSCxPQVhMOztBQWFBLFVBQUksTUFBTSxHQUFHLFNBQVMsTUFBVCxHQUFrQjtBQUMzQixlQUFPLElBQUksQ0FBQyxNQUFMLEdBQ0QsU0FBUyxtQkFBVCxDQUE2QixNQUE3QixFQUFxQztBQUNuQyxpQkFBTyxDQUFDLE1BQU0sQ0FBQyxNQUFQLEdBQWdCLFNBQVMsYUFBVCxDQUF1QixNQUF2QixFQUErQjtBQUNuRCxtQkFBTyxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosQ0FBcUIsTUFBckIsSUFDRCxJQUFJLFlBQUosQ0FBaUIsTUFBakI7QUFDRjtBQUZHLGNBR0QsWUFBWSxDQUFDLE1BQUQsQ0FIbEI7QUFJSCxXQUxNLEVBS0osTUFMSSxDQUFQO0FBTUg7QUFDRDtBQVRHLFVBVUQsWUFWTjtBQVdILE9BWkQ7QUFjQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLEVBQXRCO0FBRUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsUUFBckI7QUFBaUM7QUFBMkIsTUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsS0FBM0c7QUFFQTs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEyQixTQUFTLGlCQUFULEdBQTZCO0FBQ3BELFlBQUksS0FBSyxHQUFHLFVBQVosQ0FEb0QsQ0FDNUI7O0FBQ3hCLGVBQU8sU0FBUyxXQUFULEdBQXVCO0FBQzFCLFVBQUEsS0FBSyxHQUFHLENBQVUsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQS9CLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQStCLENBQXhDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXNCLEVBQXZCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBRTFGOztBQUNBLGNBQUksQ0FBQyxLQUFLLEdBQUwsSUFBWSxDQUFiLElBQWtCLEtBQUssR0FBM0IsRUFBZ0M7QUFDNUIsaUJBQUssR0FBTCxHQUFXLEtBQUssR0FBaEI7QUFDQSxrQkFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLEVBQVAsQ0FBckI7QUFDSDs7QUFDRCxpQkFBTyxLQUFQO0FBQ0gsU0FiRDtBQWNILE9BaEJ5QixFQUExQjtBQWtCQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixTQUFTLFVBQVQsR0FBc0I7QUFDM0MsZUFBTyxLQUFLLE1BQUwsS0FBZ0IsQ0FBdkI7QUFDSCxPQUZEO0FBSUE7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxXQUFULEdBQXVCO0FBQzdDLFlBQUksS0FBSyxHQUFHLEtBQUssTUFBTCxFQUFaO0FBQ0EsZUFBTyxLQUFLLEtBQUssQ0FBVixHQUFjLEVBQUUsS0FBSyxHQUFHLENBQVYsQ0FBZCxHQUE2QixDQUFwQztBQUNILE9BSEQ7QUFLQTs7O0FBRUEsZUFBUyxjQUFULEdBQTBCO0FBQ3RCO0FBQ0EsWUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFKLENBQWEsQ0FBYixFQUFnQixDQUFoQixDQUFYO0FBQ0EsWUFBSSxDQUFDLEdBQUcsQ0FBUjs7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLEtBQUssR0FBaEIsR0FBc0IsQ0FBMUIsRUFBNkI7QUFBRTtBQUMzQixpQkFBTyxDQUFDLEdBQUcsQ0FBWCxFQUFjLEVBQUUsQ0FBaEIsRUFBbUI7QUFDZjtBQUNBLFlBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBOEIsQ0FBQyxHQUFHLENBQTdDLE1BQW9ELENBQTlEO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUCxXQU53QixDQU96Qjs7O0FBQ0EsVUFBQSxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBZCxJQUFxQixHQUF0QixLQUE4QixFQUF6QyxNQUFpRCxDQUEzRDtBQUNBLFVBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBK0IsQ0FBMUMsTUFBaUQsQ0FBM0Q7QUFDQSxjQUFJLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBTCxFQUFULElBQXVCLEdBQTNCLEVBQ0ksT0FBTyxJQUFQO0FBQ0osVUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILFNBYkQsTUFhTztBQUNILGlCQUFPLENBQUMsR0FBRyxDQUFYLEVBQWMsRUFBRSxDQUFoQixFQUFtQjtBQUNmO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLElBQVksS0FBSyxHQUFyQixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsQ0FBckIsQ0FIVyxDQUlmOztBQUNBLFlBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBOEIsQ0FBQyxHQUFHLENBQTdDLE1BQW9ELENBQTlEO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUCxXQVRFLENBVUg7OztBQUNBLFVBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQUwsRUFBVCxJQUF1QixHQUF4QixLQUFnQyxDQUFDLEdBQUcsQ0FBL0MsTUFBc0QsQ0FBaEU7QUFDQSxpQkFBTyxJQUFQO0FBQ0g7O0FBQ0QsWUFBSSxLQUFLLEdBQUwsR0FBVyxLQUFLLEdBQWhCLEdBQXNCLENBQTFCLEVBQTZCO0FBQUU7QUFDM0IsaUJBQU8sQ0FBQyxHQUFHLENBQVgsRUFBYyxFQUFFLENBQWhCLEVBQW1CO0FBQ2Y7QUFDQSxZQUFBLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLENBQUMsR0FBRyxDQUFKLEdBQVEsQ0FBakQsTUFBd0QsQ0FBbEU7QUFDQSxnQkFBSSxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQUwsRUFBVCxJQUF1QixHQUEzQixFQUNJLE9BQU8sSUFBUDtBQUNQO0FBQ0osU0FQRCxNQU9PO0FBQ0gsaUJBQU8sQ0FBQyxHQUFHLENBQVgsRUFBYyxFQUFFLENBQWhCLEVBQW1CO0FBQ2Y7QUFDQSxnQkFBSSxLQUFLLEdBQUwsSUFBWSxLQUFLLEdBQXJCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxDQUFyQixDQUhXLENBSWY7O0FBQ0EsWUFBQSxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBZCxJQUFxQixHQUF0QixLQUE4QixDQUFDLEdBQUcsQ0FBSixHQUFRLENBQWpELE1BQXdELENBQWxFO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUDtBQUNKO0FBQ0Q7OztBQUNBLGNBQU0sS0FBSyxDQUFDLHlCQUFELENBQVg7QUFDSDtBQUVEOztBQUVBOzs7Ozs7O0FBT0E7Ozs7Ozs7QUFPQTs7Ozs7OztBQU9BOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLElBQWpCLEdBQXdCLFNBQVMsU0FBVCxHQUFxQjtBQUN6QyxlQUFPLEtBQUssTUFBTCxPQUFrQixDQUF6QjtBQUNILE9BRkQ7O0FBSUEsZUFBUyxlQUFULENBQXlCLEdBQXpCLEVBQThCLEdBQTlCLEVBQW1DO0FBQUU7QUFDakMsZUFBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQ0EsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsQ0FEaEIsR0FFQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxJQUFnQixFQUZoQixHQUdBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLEVBSGpCLE1BR3lCLENBSGhDO0FBSUg7QUFFRDs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixPQUFqQixHQUEyQixTQUFTLFlBQVQsR0FBd0I7QUFFL0M7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUF0QjtBQUNILE9BUEQ7QUFTQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixTQUFTLGFBQVQsR0FBeUI7QUFFakQ7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUFmLEdBQTJDLENBQWxEO0FBQ0gsT0FQRDtBQVNBOzs7QUFFQSxlQUFTLFdBQVQ7QUFBcUI7QUFBb0I7QUFFckM7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLElBQUksUUFBSixDQUFhLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUE1QixFQUF1RCxlQUFlLENBQUMsS0FBSyxHQUFOLEVBQVcsS0FBSyxHQUFMLElBQVksQ0FBdkIsQ0FBdEUsQ0FBUDtBQUNIO0FBRUQ7O0FBRUE7Ozs7Ozs7QUFPQTs7Ozs7OztBQU9BOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxZQUF5QixTQUFTLFVBQVQsR0FBc0I7QUFFM0M7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixZQUFJLEtBQUssR0FBRyxJQUFJLFNBQUosQ0FBVyxXQUFYLENBQXVCLEtBQUssR0FBNUIsRUFBaUMsS0FBSyxHQUF0QyxDQUFaO0FBQ0EsYUFBSyxHQUFMLElBQVksQ0FBWjtBQUNBLGVBQU8sS0FBUDtBQUNILE9BVEQ7QUFXQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsYUFBMEIsU0FBUyxXQUFULEdBQXVCO0FBRTdDO0FBQ0EsWUFBSSxLQUFLLEdBQUwsR0FBVyxDQUFYLEdBQWUsS0FBSyxHQUF4QixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsRUFBTyxDQUFQLENBQXJCO0FBRUosWUFBSSxLQUFLLEdBQUcsSUFBSSxTQUFKLENBQVcsWUFBWCxDQUF3QixLQUFLLEdBQTdCLEVBQWtDLEtBQUssR0FBdkMsQ0FBWjtBQUNBLGFBQUssR0FBTCxJQUFZLENBQVo7QUFDQSxlQUFPLEtBQVA7QUFDSCxPQVREO0FBV0E7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsS0FBakIsR0FBeUIsU0FBUyxVQUFULEdBQXNCO0FBQzNDLFlBQUksTUFBTSxHQUFHLEtBQUssTUFBTCxFQUFiO0FBQUEsWUFDSSxLQUFLLEdBQUksS0FBSyxHQURsQjtBQUFBLFlBRUksR0FBRyxHQUFNLEtBQUssR0FBTCxHQUFXLE1BRnhCO0FBSUE7O0FBQ0EsWUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFmLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBckI7QUFFSixhQUFLLEdBQUwsSUFBWSxNQUFaO0FBQ0EsWUFBSSxLQUFLLENBQUMsT0FBTixDQUFjLEtBQUssR0FBbkIsQ0FBSixFQUE2QjtBQUN6QixpQkFBTyxLQUFLLEdBQUwsQ0FBUyxLQUFULENBQWUsS0FBZixFQUFzQixHQUF0QixDQUFQO0FBQ0osZUFBTyxLQUFLLEtBQUssR0FBVixDQUFjO0FBQWQsVUFDRCxJQUFJLEtBQUssR0FBTCxDQUFTLFdBQWIsQ0FBeUIsQ0FBekIsQ0FEQyxHQUVELEtBQUssTUFBTCxDQUFZLElBQVosQ0FBaUIsS0FBSyxHQUF0QixFQUEyQixLQUEzQixFQUFrQyxHQUFsQyxDQUZOO0FBR0gsT0FmRDtBQWlCQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFdBQVQsR0FBdUI7QUFDN0MsWUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFMLEVBQVo7QUFDQSxlQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsS0FBVixFQUFpQixDQUFqQixFQUFvQixLQUFLLENBQUMsTUFBMUIsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBakIsR0FBd0IsU0FBUyxJQUFULENBQWMsTUFBZCxFQUFzQjtBQUMxQyxZQUFJLE9BQU8sTUFBUCxLQUFrQixRQUF0QixFQUFnQztBQUM1QjtBQUNBLGNBQUksS0FBSyxHQUFMLEdBQVcsTUFBWCxHQUFvQixLQUFLLEdBQTdCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBckI7QUFDSixlQUFLLEdBQUwsSUFBWSxNQUFaO0FBQ0gsU0FMRCxNQUtPO0FBQ0gsYUFBRztBQUNDO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLElBQVksS0FBSyxHQUFyQixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsQ0FBckI7QUFDUCxXQUpELFFBSVMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FKaEM7QUFLSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQWREO0FBZ0JBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixVQUFTLFFBQVQsRUFBbUI7QUFDM0MsZ0JBQVEsUUFBUjtBQUNJLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUw7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSSxpQkFBSyxJQUFMLENBQVUsQ0FBVjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUwsQ0FBVSxLQUFLLE1BQUwsRUFBVjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJLG1CQUFPLENBQUMsUUFBUSxHQUFHLEtBQUssTUFBTCxLQUFnQixDQUE1QixNQUFtQyxDQUExQyxFQUE2QztBQUN6QyxtQkFBSyxRQUFMLENBQWMsUUFBZDtBQUNIOztBQUNEOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUwsQ0FBVSxDQUFWO0FBQ0E7O0FBRUo7O0FBQ0E7QUFDSSxrQkFBTSxLQUFLLENBQUMsdUJBQXVCLFFBQXZCLEdBQWtDLGFBQWxDLEdBQWtELEtBQUssR0FBeEQsQ0FBWDtBQXJCUjs7QUF1QkEsZUFBTyxJQUFQO0FBQ0gsT0F6QkQ7O0FBMkJBLE1BQUEsTUFBTSxDQUFDLFVBQVAsR0FBb0IsVUFBUyxhQUFULEVBQXdCO0FBQ3hDLFFBQUEsWUFBWSxHQUFHLGFBQWY7QUFDQSxRQUFBLE1BQU0sQ0FBQyxNQUFQLEdBQWdCLE1BQU0sRUFBdEI7O0FBQ0EsUUFBQSxZQUFZLENBQUMsVUFBYjs7QUFFQSxZQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBTCxHQUFZLFFBQVo7QUFBdUI7QUFBMkIsa0JBQTNEO0FBQ0EsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE1BQU0sQ0FBQyxTQUFsQixFQUE2QjtBQUV6QixVQUFBLEtBQUssRUFBRSxTQUFTLFVBQVQsR0FBc0I7QUFDekIsbUJBQU8sY0FBYyxDQUFDLElBQWYsQ0FBb0IsSUFBcEIsRUFBMEIsRUFBMUIsRUFBOEIsS0FBOUIsQ0FBUDtBQUNILFdBSndCO0FBTXpCLFVBQUEsTUFBTSxFQUFFLFNBQVMsV0FBVCxHQUF1QjtBQUMzQixtQkFBTyxjQUFjLENBQUMsSUFBZixDQUFvQixJQUFwQixFQUEwQixFQUExQixFQUE4QixJQUE5QixDQUFQO0FBQ0gsV0FSd0I7QUFVekIsVUFBQSxNQUFNLEVBQUUsU0FBUyxXQUFULEdBQXVCO0FBQzNCLG1CQUFPLGNBQWMsQ0FBQyxJQUFmLENBQW9CLElBQXBCLEVBQTBCLFFBQTFCLEdBQXFDLEVBQXJDLEVBQXlDLEtBQXpDLENBQVA7QUFDSCxXQVp3QjtBQWN6QixVQUFBLE9BQU8sRUFBRSxTQUFTLFlBQVQsR0FBd0I7QUFDN0IsbUJBQU8sV0FBVyxDQUFDLElBQVosQ0FBaUIsSUFBakIsRUFBdUIsRUFBdkIsRUFBMkIsSUFBM0IsQ0FBUDtBQUNILFdBaEJ3QjtBQWtCekIsVUFBQSxRQUFRLEVBQUUsU0FBUyxhQUFULEdBQXlCO0FBQy9CLG1CQUFPLFdBQVcsQ0FBQyxJQUFaLENBQWlCLElBQWpCLEVBQXVCLEVBQXZCLEVBQTJCLEtBQTNCLENBQVA7QUFDSDtBQXBCd0IsU0FBN0I7QUF1QkgsT0E3QkQ7QUErQkMsS0E3WjRELEVBNlozRDtBQUFDLFlBQUs7QUFBTixLQTdaMkQsQ0F4ekJ0QztBQXF0Q1YsUUFBRyxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUNqRDs7QUFDQSxNQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFlBQWpCLENBRmlELENBSWpEOztBQUNBLFVBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFELENBQXBCOztBQUNBLE9BQUMsWUFBWSxDQUFDLFNBQWIsR0FBeUIsTUFBTSxDQUFDLE1BQVAsQ0FBYyxNQUFNLENBQUMsU0FBckIsQ0FBMUIsRUFBMkQsV0FBM0QsR0FBeUUsWUFBekU7O0FBRUEsVUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEVBQUQsQ0FBbEI7QUFFQTs7Ozs7Ozs7O0FBT0EsZUFBUyxZQUFULENBQXNCLE1BQXRCLEVBQThCO0FBQzFCLFFBQUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaLEVBQWtCLE1BQWxCO0FBRUE7Ozs7O0FBS0g7O0FBRUQsTUFBQSxZQUFZLENBQUMsVUFBYixHQUEwQixZQUFZO0FBQ2xDO0FBQ0EsWUFBSSxJQUFJLENBQUMsTUFBVCxFQUNJLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLElBQUksQ0FBQyxNQUFMLENBQVksU0FBWixDQUFzQixLQUF0RDtBQUNQLE9BSkQ7QUFPQTs7Ozs7QUFHQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLFNBQVMsa0JBQVQsR0FBOEI7QUFDMUQsWUFBSSxHQUFHLEdBQUcsS0FBSyxNQUFMLEVBQVYsQ0FEMEQsQ0FDakM7O0FBQ3pCLGVBQU8sS0FBSyxHQUFMLENBQVMsU0FBVCxHQUNELEtBQUssR0FBTCxDQUFTLFNBQVQsQ0FBbUIsS0FBSyxHQUF4QixFQUE2QixLQUFLLEdBQUwsR0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEtBQUssR0FBTCxHQUFXLEdBQXBCLEVBQXlCLEtBQUssR0FBOUIsQ0FBeEMsQ0FEQyxHQUVELEtBQUssR0FBTCxDQUFTLFFBQVQsQ0FBa0IsT0FBbEIsRUFBMkIsS0FBSyxHQUFoQyxFQUFxQyxLQUFLLEdBQUwsR0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEtBQUssR0FBTCxHQUFXLEdBQXBCLEVBQXlCLEtBQUssR0FBOUIsQ0FBaEQsQ0FGTjtBQUdILE9BTEQ7QUFPQTs7Ozs7Ozs7QUFPQSxNQUFBLFlBQVksQ0FBQyxVQUFiO0FBRUMsS0FyRGUsRUFxRGQ7QUFBQyxZQUFLLEVBQU47QUFBUyxXQUFJO0FBQWIsS0FyRGMsQ0FydENPO0FBMHdDSixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3ZEOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsRUFBakI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JDLEtBcEJxQixFQW9CcEIsRUFwQm9CLENBMXdDQztBQTh4Q2pCLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDMUM7QUFFQTs7Ozs7QUFJQSxVQUFJLEdBQUcsR0FBRyxPQUFWO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQTs7Ozs7Ozs7O0FBU0EsTUFBQSxHQUFHLENBQUMsT0FBSixHQUFjLE9BQU8sQ0FBQyxFQUFELENBQXJCO0FBRUMsS0F0Q1EsRUFzQ1A7QUFBQyxZQUFLO0FBQU4sS0F0Q08sQ0E5eENjO0FBbzBDVixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ2pEOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsT0FBakI7O0FBRUEsVUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEVBQUQsQ0FBbEIsQ0FKaUQsQ0FNakQ7OztBQUNBLE9BQUMsT0FBTyxDQUFDLFNBQVIsR0FBb0IsTUFBTSxDQUFDLE1BQVAsQ0FBYyxJQUFJLENBQUMsWUFBTCxDQUFrQixTQUFoQyxDQUFyQixFQUFpRSxXQUFqRSxHQUErRSxPQUEvRTtBQUVBOzs7Ozs7Ozs7Ozs7QUFZQTs7Ozs7Ozs7Ozs7QUFXQTs7Ozs7Ozs7Ozs7QUFVQSxlQUFTLE9BQVQsQ0FBaUIsT0FBakIsRUFBMEIsZ0JBQTFCLEVBQTRDLGlCQUE1QyxFQUErRDtBQUUzRCxZQUFJLE9BQU8sT0FBUCxLQUFtQixVQUF2QixFQUNJLE1BQU0sU0FBUyxDQUFDLDRCQUFELENBQWY7QUFFSixRQUFBLElBQUksQ0FBQyxZQUFMLENBQWtCLElBQWxCLENBQXVCLElBQXZCO0FBRUE7Ozs7O0FBSUEsYUFBSyxPQUFMLEdBQWUsT0FBZjtBQUVBOzs7OztBQUlBLGFBQUssZ0JBQUwsR0FBd0IsT0FBTyxDQUFDLGdCQUFELENBQS9CO0FBRUE7Ozs7O0FBSUEsYUFBSyxpQkFBTCxHQUF5QixPQUFPLENBQUMsaUJBQUQsQ0FBaEM7QUFDSDtBQUVEOzs7Ozs7Ozs7Ozs7O0FBV0EsTUFBQSxPQUFPLENBQUMsU0FBUixDQUFrQixPQUFsQixHQUE0QixTQUFTLE9BQVQsQ0FBaUIsTUFBakIsRUFBeUIsV0FBekIsRUFBc0MsWUFBdEMsRUFBb0QsT0FBcEQsRUFBNkQsUUFBN0QsRUFBdUU7QUFFL0YsWUFBSSxDQUFDLE9BQUwsRUFDSSxNQUFNLFNBQVMsQ0FBQywyQkFBRCxDQUFmO0FBRUosWUFBSSxJQUFJLEdBQUcsSUFBWDtBQUNBLFlBQUksQ0FBQyxRQUFMLEVBQ0ksT0FBTyxJQUFJLENBQUMsU0FBTCxDQUFlLE9BQWYsRUFBd0IsSUFBeEIsRUFBOEIsTUFBOUIsRUFBc0MsV0FBdEMsRUFBbUQsWUFBbkQsRUFBaUUsT0FBakUsQ0FBUDs7QUFFSixZQUFJLENBQUMsSUFBSSxDQUFDLE9BQVYsRUFBbUI7QUFDZixVQUFBLFVBQVUsQ0FBQyxZQUFXO0FBQUUsWUFBQSxRQUFRLENBQUMsS0FBSyxDQUFDLGVBQUQsQ0FBTixDQUFSO0FBQW1DLFdBQWpELEVBQW1ELENBQW5ELENBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7O0FBRUQsWUFBSTtBQUNBLGlCQUFPLElBQUksQ0FBQyxPQUFMLENBQ0gsTUFERyxFQUVILFdBQVcsQ0FBQyxJQUFJLENBQUMsZ0JBQUwsR0FBd0IsaUJBQXhCLEdBQTRDLFFBQTdDLENBQVgsQ0FBa0UsT0FBbEUsRUFBMkUsTUFBM0UsRUFGRyxFQUdILFNBQVMsV0FBVCxDQUFxQixHQUFyQixFQUEwQixRQUExQixFQUFvQztBQUVoQyxnQkFBSSxHQUFKLEVBQVM7QUFDTCxjQUFBLElBQUksQ0FBQyxJQUFMLENBQVUsT0FBVixFQUFtQixHQUFuQixFQUF3QixNQUF4QjtBQUNBLHFCQUFPLFFBQVEsQ0FBQyxHQUFELENBQWY7QUFDSDs7QUFFRCxnQkFBSSxRQUFRLEtBQUssSUFBakIsRUFBdUI7QUFDbkIsY0FBQSxJQUFJLENBQUMsR0FBTDtBQUFTO0FBQWlCLGtCQUExQjtBQUNBLHFCQUFPLFNBQVA7QUFDSDs7QUFFRCxnQkFBSSxFQUFFLFFBQVEsWUFBWSxZQUF0QixDQUFKLEVBQXlDO0FBQ3JDLGtCQUFJO0FBQ0EsZ0JBQUEsUUFBUSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsaUJBQUwsR0FBeUIsaUJBQXpCLEdBQTZDLFFBQTlDLENBQVosQ0FBb0UsUUFBcEUsQ0FBWDtBQUNILGVBRkQsQ0FFRSxPQUFPLEdBQVAsRUFBWTtBQUNWLGdCQUFBLElBQUksQ0FBQyxJQUFMLENBQVUsT0FBVixFQUFtQixHQUFuQixFQUF3QixNQUF4QjtBQUNBLHVCQUFPLFFBQVEsQ0FBQyxHQUFELENBQWY7QUFDSDtBQUNKOztBQUVELFlBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxNQUFWLEVBQWtCLFFBQWxCLEVBQTRCLE1BQTVCO0FBQ0EsbUJBQU8sUUFBUSxDQUFDLElBQUQsRUFBTyxRQUFQLENBQWY7QUFDSCxXQTFCRSxDQUFQO0FBNEJILFNBN0JELENBNkJFLE9BQU8sR0FBUCxFQUFZO0FBQ1YsVUFBQSxJQUFJLENBQUMsSUFBTCxDQUFVLE9BQVYsRUFBbUIsR0FBbkIsRUFBd0IsTUFBeEI7QUFDQSxVQUFBLFVBQVUsQ0FBQyxZQUFXO0FBQUUsWUFBQSxRQUFRLENBQUMsR0FBRCxDQUFSO0FBQWdCLFdBQTlCLEVBQWdDLENBQWhDLENBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7QUFDSixPQWhERDtBQWtEQTs7Ozs7OztBQUtBLE1BQUEsT0FBTyxDQUFDLFNBQVIsQ0FBa0IsR0FBbEIsR0FBd0IsU0FBUyxHQUFULENBQWEsVUFBYixFQUF5QjtBQUM3QyxZQUFJLEtBQUssT0FBVCxFQUFrQjtBQUNkLGNBQUksQ0FBQyxVQUFMLEVBQWlCO0FBQ2IsaUJBQUssT0FBTCxDQUFhLElBQWIsRUFBbUIsSUFBbkIsRUFBeUIsSUFBekI7QUFDSixlQUFLLE9BQUwsR0FBZSxJQUFmO0FBQ0EsZUFBSyxJQUFMLENBQVUsS0FBVixFQUFpQixHQUFqQjtBQUNIOztBQUNELGVBQU8sSUFBUDtBQUNILE9BUkQ7QUFVQyxLQWhKZSxFQWdKZDtBQUFDLFlBQUs7QUFBTixLQWhKYyxDQXAwQ087QUFvOUNWLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDakQ7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFqQjs7QUFFQSxVQUFJLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRCxDQUFsQjtBQUVBOzs7Ozs7Ozs7O0FBUUEsZUFBUyxRQUFULENBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCO0FBRXRCO0FBQ0E7O0FBRUE7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFFLEtBQUssQ0FBakI7QUFFQTs7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFFLEtBQUssQ0FBakI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsVUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsR0FBZ0IsSUFBSSxRQUFKLENBQWEsQ0FBYixFQUFnQixDQUFoQixDQUEzQjs7QUFFQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLFlBQVc7QUFBRSxlQUFPLENBQVA7QUFBVyxPQUF4Qzs7QUFDQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLElBQUksQ0FBQyxRQUFMLEdBQWdCLFlBQVc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUEzRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsWUFBVztBQUFFLGVBQU8sQ0FBUDtBQUFXLE9BQXRDO0FBRUE7Ozs7Ozs7QUFLQSxVQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBVCxHQUFvQixrQkFBbkM7QUFFQTs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsVUFBVCxHQUFzQixTQUFTLFVBQVQsQ0FBb0IsS0FBcEIsRUFBMkI7QUFDN0MsWUFBSSxLQUFLLEtBQUssQ0FBZCxFQUNJLE9BQU8sSUFBUDtBQUNKLFlBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxDQUFuQjtBQUNBLFlBQUksSUFBSixFQUNJLEtBQUssR0FBRyxDQUFDLEtBQVQ7QUFDSixZQUFJLEVBQUUsR0FBRyxLQUFLLEtBQUssQ0FBbkI7QUFBQSxZQUNJLEVBQUUsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFULElBQWUsVUFBZixLQUE4QixDQUR2Qzs7QUFFQSxZQUFJLElBQUosRUFBVTtBQUNOLFVBQUEsRUFBRSxHQUFHLENBQUMsRUFBRCxLQUFRLENBQWI7QUFDQSxVQUFBLEVBQUUsR0FBRyxDQUFDLEVBQUQsS0FBUSxDQUFiOztBQUNBLGNBQUksRUFBRSxFQUFGLEdBQU8sVUFBWCxFQUF1QjtBQUNuQixZQUFBLEVBQUUsR0FBRyxDQUFMO0FBQ0EsZ0JBQUksRUFBRSxFQUFGLEdBQU8sVUFBWCxFQUNJLEVBQUUsR0FBRyxDQUFMO0FBQ1A7QUFDSjs7QUFDRCxlQUFPLElBQUksUUFBSixDQUFhLEVBQWIsRUFBaUIsRUFBakIsQ0FBUDtBQUNILE9BbEJEO0FBb0JBOzs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsSUFBVCxHQUFnQixTQUFTLElBQVQsQ0FBYyxLQUFkLEVBQXFCO0FBQ2pDLFlBQUksT0FBTyxLQUFQLEtBQWlCLFFBQXJCLEVBQ0ksT0FBTyxRQUFRLENBQUMsVUFBVCxDQUFvQixLQUFwQixDQUFQOztBQUNKLFlBQUksSUFBSSxDQUFDLFFBQUwsQ0FBYyxLQUFkLENBQUosRUFBMEI7QUFDdEI7QUFDQSxjQUFJLElBQUksQ0FBQyxJQUFULEVBQ0ksS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFMLENBQVUsVUFBVixDQUFxQixLQUFyQixDQUFSLENBREosS0FHSSxPQUFPLFFBQVEsQ0FBQyxVQUFULENBQW9CLFFBQVEsQ0FBQyxLQUFELEVBQVEsRUFBUixDQUE1QixDQUFQO0FBQ1A7O0FBQ0QsZUFBTyxLQUFLLENBQUMsR0FBTixJQUFhLEtBQUssQ0FBQyxJQUFuQixHQUEwQixJQUFJLFFBQUosQ0FBYSxLQUFLLENBQUMsR0FBTixLQUFjLENBQTNCLEVBQThCLEtBQUssQ0FBQyxJQUFOLEtBQWUsQ0FBN0MsQ0FBMUIsR0FBNEUsSUFBbkY7QUFDSCxPQVhEO0FBYUE7Ozs7Ozs7QUFLQSxNQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLFFBQW5CLEdBQThCLFNBQVMsUUFBVCxDQUFrQixRQUFsQixFQUE0QjtBQUN0RCxZQUFJLENBQUMsUUFBRCxJQUFhLEtBQUssRUFBTCxLQUFZLEVBQTdCLEVBQWlDO0FBQzdCLGNBQUksRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFOLEdBQVcsQ0FBWCxLQUFpQixDQUExQjtBQUFBLGNBQ0ksRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFOLEtBQWlCLENBRDFCO0FBRUEsY0FBSSxDQUFDLEVBQUwsRUFDSSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUwsS0FBVyxDQUFoQjtBQUNKLGlCQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxVQUFaLENBQVA7QUFDSDs7QUFDRCxlQUFPLEtBQUssRUFBTCxHQUFVLEtBQUssRUFBTCxHQUFVLFVBQTNCO0FBQ0gsT0FURDtBQVdBOzs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixNQUFuQixHQUE0QixTQUFTLE1BQVQsQ0FBZ0IsUUFBaEIsRUFBMEI7QUFDbEQsZUFBTyxJQUFJLENBQUMsSUFBTCxHQUNELElBQUksSUFBSSxDQUFDLElBQVQsQ0FBYyxLQUFLLEVBQUwsR0FBVSxDQUF4QixFQUEyQixLQUFLLEVBQUwsR0FBVSxDQUFyQyxFQUF3QyxPQUFPLENBQUMsUUFBRCxDQUEvQztBQUNGO0FBRkcsVUFHRDtBQUFFLFVBQUEsR0FBRyxFQUFFLEtBQUssRUFBTCxHQUFVLENBQWpCO0FBQW9CLFVBQUEsSUFBSSxFQUFFLEtBQUssRUFBTCxHQUFVLENBQXBDO0FBQXVDLFVBQUEsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFEO0FBQXhELFNBSE47QUFJSCxPQUxEOztBQU9BLFVBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFQLENBQWlCLFVBQWxDO0FBRUE7Ozs7OztBQUtBLE1BQUEsUUFBUSxDQUFDLFFBQVQsR0FBb0IsU0FBUyxRQUFULENBQWtCLElBQWxCLEVBQXdCO0FBQ3hDLFlBQUksSUFBSSxLQUFLLFFBQWIsRUFDSSxPQUFPLElBQVA7QUFDSixlQUFPLElBQUksUUFBSixDQUNILENBQUUsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsSUFDQSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixLQUE0QixDQUQ1QixHQUVBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEtBQTRCLEVBRjVCLEdBR0EsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsS0FBNEIsRUFIOUIsTUFHc0MsQ0FKbkMsRUFNSCxDQUFFLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLElBQ0EsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsS0FBNEIsQ0FENUIsR0FFQSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixLQUE0QixFQUY1QixHQUdBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEtBQTRCLEVBSDlCLE1BR3NDLENBVG5DLENBQVA7QUFXSCxPQWREO0FBZ0JBOzs7Ozs7QUFJQSxNQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLE1BQW5CLEdBQTRCLFNBQVMsTUFBVCxHQUFrQjtBQUMxQyxlQUFPLE1BQU0sQ0FBQyxZQUFQLENBQ0gsS0FBSyxFQUFMLEdBQWlCLEdBRGQsRUFFSCxLQUFLLEVBQUwsS0FBWSxDQUFaLEdBQWlCLEdBRmQsRUFHSCxLQUFLLEVBQUwsS0FBWSxFQUFaLEdBQWlCLEdBSGQsRUFJSCxLQUFLLEVBQUwsS0FBWSxFQUpULEVBS0gsS0FBSyxFQUFMLEdBQWlCLEdBTGQsRUFNSCxLQUFLLEVBQUwsS0FBWSxDQUFaLEdBQWlCLEdBTmQsRUFPSCxLQUFLLEVBQUwsS0FBWSxFQUFaLEdBQWlCLEdBUGQsRUFRSCxLQUFLLEVBQUwsS0FBWSxFQVJULENBQVA7QUFVSCxPQVhEO0FBYUE7Ozs7OztBQUlBLE1BQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsUUFBbkIsR0FBOEIsU0FBUyxRQUFULEdBQW9CO0FBQzlDLFlBQUksSUFBSSxHQUFLLEtBQUssRUFBTCxJQUFXLEVBQXhCO0FBQ0EsYUFBSyxFQUFMLEdBQVcsQ0FBQyxDQUFDLEtBQUssRUFBTCxJQUFXLENBQVgsR0FBZSxLQUFLLEVBQUwsS0FBWSxFQUE1QixJQUFrQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGFBQUssRUFBTCxHQUFXLENBQUUsS0FBSyxFQUFMLElBQVcsQ0FBWCxHQUFpQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGVBQU8sSUFBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7O0FBSUEsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixRQUFuQixHQUE4QixTQUFTLFFBQVQsR0FBb0I7QUFDOUMsWUFBSSxJQUFJLEdBQUcsRUFBRSxLQUFLLEVBQUwsR0FBVSxDQUFaLENBQVg7QUFDQSxhQUFLLEVBQUwsR0FBVyxDQUFDLENBQUMsS0FBSyxFQUFMLEtBQVksQ0FBWixHQUFnQixLQUFLLEVBQUwsSUFBVyxFQUE1QixJQUFrQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGFBQUssRUFBTCxHQUFXLENBQUUsS0FBSyxFQUFMLEtBQVksQ0FBWixHQUFpQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGVBQU8sSUFBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7O0FBSUEsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixNQUFuQixHQUE0QixTQUFTLE1BQVQsR0FBa0I7QUFDMUMsWUFBSSxLQUFLLEdBQUksS0FBSyxFQUFsQjtBQUFBLFlBQ0ksS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFMLEtBQVksRUFBWixHQUFpQixLQUFLLEVBQUwsSUFBVyxDQUE3QixNQUFvQyxDQURoRDtBQUFBLFlBRUksS0FBSyxHQUFJLEtBQUssRUFBTCxLQUFZLEVBRnpCO0FBR0EsZUFBTyxLQUFLLEtBQUssQ0FBVixHQUNBLEtBQUssS0FBSyxDQUFWLEdBQ0UsS0FBSyxHQUFHLEtBQVIsR0FDRSxLQUFLLEdBQUcsR0FBUixHQUFjLENBQWQsR0FBa0IsQ0FEcEIsR0FFRSxLQUFLLEdBQUcsT0FBUixHQUFrQixDQUFsQixHQUFzQixDQUgxQixHQUlFLEtBQUssR0FBRyxLQUFSLEdBQ0UsS0FBSyxHQUFHLEdBQVIsR0FBYyxDQUFkLEdBQWtCLENBRHBCLEdBRUUsS0FBSyxHQUFHLE9BQVIsR0FBa0IsQ0FBbEIsR0FBc0IsQ0FQMUIsR0FRQSxLQUFLLEdBQUcsR0FBUixHQUFjLENBQWQsR0FBa0IsRUFSekI7QUFTSCxPQWJEO0FBZUMsS0ExTWUsRUEwTWQ7QUFBQyxZQUFLO0FBQU4sS0ExTWMsQ0FwOUNPO0FBOHBEVixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ2pEOztBQUNBLFVBQUksSUFBSSxHQUFHLE9BQVgsQ0FGaUQsQ0FJakQ7O0FBQ0EsTUFBQSxJQUFJLENBQUMsU0FBTCxHQUFpQixPQUFPLENBQUMsQ0FBRCxDQUF4QixDQUxpRCxDQU9qRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsT0FBTyxDQUFDLENBQUQsQ0FBckIsQ0FSaUQsQ0FVakQ7O0FBQ0EsTUFBQSxJQUFJLENBQUMsWUFBTCxHQUFvQixPQUFPLENBQUMsQ0FBRCxDQUEzQixDQVhpRCxDQWFqRDs7QUFDQSxNQUFBLElBQUksU0FBSixHQUFhLE9BQU8sQ0FBQyxDQUFELENBQXBCLENBZGlELENBZ0JqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxPQUFMLEdBQWUsT0FBTyxDQUFDLENBQUQsQ0FBdEIsQ0FqQmlELENBbUJqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxJQUFMLEdBQVksT0FBTyxDQUFDLENBQUQsQ0FBbkIsQ0FwQmlELENBc0JqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxJQUFMLEdBQVksT0FBTyxDQUFDLENBQUQsQ0FBbkIsQ0F2QmlELENBeUJqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLE9BQU8sQ0FBQyxFQUFELENBQXZCO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxPQUFPLENBQUMsT0FBTyxNQUFQLEtBQWtCLFdBQWxCLElBQ0EsTUFEQSxJQUVBLE1BQU0sQ0FBQyxPQUZQLElBR0EsTUFBTSxDQUFDLE9BQVAsQ0FBZSxRQUhmLElBSUEsTUFBTSxDQUFDLE9BQVAsQ0FBZSxRQUFmLENBQXdCLElBSnpCLENBQXJCO0FBTUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFJLENBQUMsTUFBTCxJQUFlLE1BQWYsSUFDQSxPQUFPLE1BQVAsS0FBa0IsV0FBbEIsSUFBaUMsTUFEakMsSUFFQSxPQUFPLElBQVAsS0FBa0IsV0FBbEIsSUFBaUMsSUFGakMsSUFHQSxJQUhkLENBNUNpRCxDQStDN0I7O0FBRXBCOzs7Ozs7O0FBTUEsTUFBQSxJQUFJLENBQUMsVUFBTCxHQUFrQixNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLENBQUMsTUFBUCxDQUFjLEVBQWQsQ0FBaEI7QUFBb0M7QUFBMkIsUUFBakYsQ0F2RGlELENBdURvQzs7QUFFckY7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLFdBQUwsR0FBbUIsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsTUFBTSxDQUFDLE1BQVAsQ0FBYyxFQUFkLENBQWhCO0FBQW9DO0FBQTJCLFFBQWxGLENBOURpRCxDQThEcUM7O0FBRXRGOzs7Ozs7O0FBTUEsTUFBQSxJQUFJLENBQUMsU0FBTCxHQUFpQixNQUFNLENBQUMsU0FBUDtBQUFvQjtBQUEyQixlQUFTLFNBQVQsQ0FBbUIsS0FBbkIsRUFBMEI7QUFDdEYsZUFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsUUFBUSxDQUFDLEtBQUQsQ0FBckMsSUFBZ0QsSUFBSSxDQUFDLEtBQUwsQ0FBVyxLQUFYLE1BQXNCLEtBQTdFO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsUUFBTCxHQUFnQixTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsRUFBeUI7QUFDckMsZUFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsS0FBSyxZQUFZLE1BQXJEO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsUUFBTCxHQUFnQixTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsRUFBeUI7QUFDckMsZUFBTyxLQUFLLElBQUksT0FBTyxLQUFQLEtBQWlCLFFBQWpDO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7Ozs7O0FBUUEsTUFBQSxJQUFJLENBQUMsS0FBTDtBQUVBOzs7Ozs7QUFNQSxNQUFBLElBQUksQ0FBQyxLQUFMLEdBQWEsU0FBUyxLQUFULENBQWUsR0FBZixFQUFvQixJQUFwQixFQUEwQjtBQUNuQyxZQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsSUFBRCxDQUFmO0FBQ0EsWUFBSSxLQUFLLElBQUksSUFBVCxJQUFpQixHQUFHLENBQUMsY0FBSixDQUFtQixJQUFuQixDQUFyQixFQUErQztBQUMzQyxpQkFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsQ0FBQyxLQUFLLENBQUMsT0FBTixDQUFjLEtBQWQsSUFBdUIsS0FBSyxDQUFDLE1BQTdCLEdBQXNDLE1BQU0sQ0FBQyxJQUFQLENBQVksS0FBWixFQUFtQixNQUExRCxJQUFvRSxDQUF4RztBQUNKLGVBQU8sS0FBUDtBQUNILE9BYkQ7QUFlQTs7Ozs7OztBQU9BOzs7Ozs7QUFJQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWUsWUFBVztBQUN0QixZQUFJO0FBQ0EsY0FBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxRQUFiLEVBQXVCLE1BQXBDLENBREEsQ0FFQTs7QUFDQSxpQkFBTyxNQUFNLENBQUMsU0FBUCxDQUFpQixTQUFqQixHQUE2QixNQUE3QjtBQUFzQztBQUEyQixjQUF4RTtBQUNILFNBSkQsQ0FJRSxPQUFPLENBQVAsRUFBVTtBQUNSO0FBQ0EsaUJBQU8sSUFBUDtBQUNIO0FBQ0osT0FUYSxFQUFkLENBOUhpRCxDQXlJakQ7OztBQUNBLE1BQUEsSUFBSSxDQUFDLFlBQUwsR0FBb0IsSUFBcEIsQ0ExSWlELENBNElqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxtQkFBTCxHQUEyQixJQUEzQjtBQUVBOzs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxTQUFMLEdBQWlCLFNBQVMsU0FBVCxDQUFtQixXQUFuQixFQUFnQztBQUM3QztBQUNBLGVBQU8sT0FBTyxXQUFQLEtBQXVCLFFBQXZCLEdBQ0QsSUFBSSxDQUFDLE1BQUwsR0FDSSxJQUFJLENBQUMsbUJBQUwsQ0FBeUIsV0FBekIsQ0FESixHQUVJLElBQUksSUFBSSxDQUFDLEtBQVQsQ0FBZSxXQUFmLENBSEgsR0FJRCxJQUFJLENBQUMsTUFBTCxHQUNJLElBQUksQ0FBQyxZQUFMLENBQWtCLFdBQWxCLENBREosR0FFSSxPQUFPLFVBQVAsS0FBc0IsV0FBdEIsR0FDSSxXQURKLEdBRUksSUFBSSxVQUFKLENBQWUsV0FBZixDQVJkO0FBU0gsT0FYRDtBQWFBOzs7Ozs7QUFJQSxNQUFBLElBQUksQ0FBQyxLQUFMLEdBQWEsT0FBTyxVQUFQLEtBQXNCLFdBQXRCLEdBQW9DO0FBQVc7QUFBL0MsUUFBNEUsS0FBekY7QUFFQTs7Ozs7Ozs7O0FBU0E7Ozs7O0FBSUEsTUFBQSxJQUFJLENBQUMsSUFBTDtBQUFZO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxPQUFaO0FBQXVCO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxPQUFaLENBQW9CLElBQXRFO0FBQzNCO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxJQURaLElBRTNCLElBQUksQ0FBQyxPQUFMLENBQWEsTUFBYixDQUZaO0FBSUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxrQkFBZDtBQUVBOzs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxPQUFMLEdBQWUsdUJBQWY7QUFFQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsT0FBTCxHQUFlLDRDQUFmO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLFVBQUwsR0FBa0IsU0FBUyxVQUFULENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pDLGVBQU8sS0FBSyxHQUNOLElBQUksQ0FBQyxRQUFMLENBQWMsSUFBZCxDQUFtQixLQUFuQixFQUEwQixNQUExQixFQURNLEdBRU4sSUFBSSxDQUFDLFFBQUwsQ0FBYyxRQUZwQjtBQUdILE9BSkQ7QUFNQTs7Ozs7Ozs7QUFNQSxNQUFBLElBQUksQ0FBQyxZQUFMLEdBQW9CLFNBQVMsWUFBVCxDQUFzQixJQUF0QixFQUE0QixRQUE1QixFQUFzQztBQUN0RCxZQUFJLElBQUksR0FBRyxJQUFJLENBQUMsUUFBTCxDQUFjLFFBQWQsQ0FBdUIsSUFBdkIsQ0FBWDtBQUNBLFlBQUksSUFBSSxDQUFDLElBQVQsRUFDSSxPQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsUUFBVixDQUFtQixJQUFJLENBQUMsRUFBeEIsRUFBNEIsSUFBSSxDQUFDLEVBQWpDLEVBQXFDLFFBQXJDLENBQVA7QUFDSixlQUFPLElBQUksQ0FBQyxRQUFMLENBQWMsT0FBTyxDQUFDLFFBQUQsQ0FBckIsQ0FBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7Ozs7OztBQVFBLGVBQVMsS0FBVCxDQUFlLEdBQWYsRUFBb0IsR0FBcEIsRUFBeUIsUUFBekIsRUFBbUM7QUFBRTtBQUNqQyxhQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixDQUFYLEVBQTZCLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQWxELEVBQTBELEVBQUUsQ0FBNUQ7QUFDSSxjQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQUgsS0FBaUIsU0FBakIsSUFBOEIsQ0FBQyxRQUFuQyxFQUNJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQUgsR0FBZSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUQsQ0FBTCxDQUFsQjtBQUZSOztBQUdBLGVBQU8sR0FBUDtBQUNIOztBQUVELE1BQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxLQUFiO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE9BQUwsR0FBZSxTQUFTLE9BQVQsQ0FBaUIsR0FBakIsRUFBc0I7QUFDakMsZUFBTyxHQUFHLENBQUMsTUFBSixDQUFXLENBQVgsRUFBYyxXQUFkLEtBQThCLEdBQUcsQ0FBQyxTQUFKLENBQWMsQ0FBZCxDQUFyQztBQUNILE9BRkQ7QUFJQTs7Ozs7Ozs7QUFNQSxlQUFTLFFBQVQsQ0FBa0IsSUFBbEIsRUFBd0I7QUFFcEIsaUJBQVMsV0FBVCxDQUFxQixPQUFyQixFQUE4QixVQUE5QixFQUEwQztBQUV0QyxjQUFJLEVBQUUsZ0JBQWdCLFdBQWxCLENBQUosRUFDSSxPQUFPLElBQUksV0FBSixDQUFnQixPQUFoQixFQUF5QixVQUF6QixDQUFQLENBSGtDLENBS3RDO0FBQ0E7O0FBRUEsVUFBQSxNQUFNLENBQUMsY0FBUCxDQUFzQixJQUF0QixFQUE0QixTQUE1QixFQUF1QztBQUFFLFlBQUEsR0FBRyxFQUFFLGVBQVc7QUFBRSxxQkFBTyxPQUFQO0FBQWlCO0FBQXJDLFdBQXZDO0FBRUE7O0FBQ0EsY0FBSSxLQUFLLENBQUMsaUJBQVYsRUFBNkI7QUFDekIsWUFBQSxLQUFLLENBQUMsaUJBQU4sQ0FBd0IsSUFBeEIsRUFBOEIsV0FBOUIsRUFESixLQUdJLE1BQU0sQ0FBQyxjQUFQLENBQXNCLElBQXRCLEVBQTRCLE9BQTVCLEVBQXFDO0FBQUUsWUFBQSxLQUFLLEVBQUUsSUFBSSxLQUFKLEdBQVksS0FBWixJQUFxQjtBQUE5QixXQUFyQztBQUVKLGNBQUksVUFBSixFQUNJLEtBQUssQ0FBQyxJQUFELEVBQU8sVUFBUCxDQUFMO0FBQ1A7O0FBRUQsU0FBQyxXQUFXLENBQUMsU0FBWixHQUF3QixNQUFNLENBQUMsTUFBUCxDQUFjLEtBQUssQ0FBQyxTQUFwQixDQUF6QixFQUF5RCxXQUF6RCxHQUF1RSxXQUF2RTtBQUVBLFFBQUEsTUFBTSxDQUFDLGNBQVAsQ0FBc0IsV0FBVyxDQUFDLFNBQWxDLEVBQTZDLE1BQTdDLEVBQXFEO0FBQUUsVUFBQSxHQUFHLEVBQUUsZUFBVztBQUFFLG1CQUFPLElBQVA7QUFBYztBQUFsQyxTQUFyRDs7QUFFQSxRQUFBLFdBQVcsQ0FBQyxTQUFaLENBQXNCLFFBQXRCLEdBQWlDLFNBQVMsUUFBVCxHQUFvQjtBQUNqRCxpQkFBTyxLQUFLLElBQUwsR0FBWSxJQUFaLEdBQW1CLEtBQUssT0FBL0I7QUFDSCxTQUZEOztBQUlBLGVBQU8sV0FBUDtBQUNIOztBQUVELE1BQUEsSUFBSSxDQUFDLFFBQUwsR0FBZ0IsUUFBaEI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLE1BQUEsSUFBSSxDQUFDLGFBQUwsR0FBcUIsUUFBUSxDQUFDLGVBQUQsQ0FBN0I7QUFFQTs7Ozs7O0FBTUE7Ozs7Ozs7QUFPQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsV0FBTCxHQUFtQixTQUFTLFFBQVQsQ0FBa0IsVUFBbEIsRUFBOEI7QUFDN0MsWUFBSSxRQUFRLEdBQUcsRUFBZjs7QUFDQSxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUEvQixFQUF1QyxFQUFFLENBQXpDO0FBQ0ksVUFBQSxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUQsQ0FBWCxDQUFSLEdBQTBCLENBQTFCO0FBREo7QUFHQTs7Ozs7OztBQUtBLGVBQU8sWUFBVztBQUFFO0FBQ2hCLGVBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaLENBQVgsRUFBOEIsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFMLEdBQWMsQ0FBckQsRUFBd0QsQ0FBQyxHQUFHLENBQUMsQ0FBN0QsRUFBZ0UsRUFBRSxDQUFsRTtBQUNJLGdCQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQVIsS0FBc0IsQ0FBdEIsSUFBMkIsS0FBSyxJQUFJLENBQUMsQ0FBRCxDQUFULE1BQWtCLFNBQTdDLElBQTBELEtBQUssSUFBSSxDQUFDLENBQUQsQ0FBVCxNQUFrQixJQUFoRixFQUNJLE9BQU8sSUFBSSxDQUFDLENBQUQsQ0FBWDtBQUZSO0FBR0gsU0FKRDtBQUtILE9BZkQ7QUFpQkE7Ozs7Ozs7O0FBUUE7Ozs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxXQUFMLEdBQW1CLFNBQVMsUUFBVCxDQUFrQixVQUFsQixFQUE4QjtBQUU3Qzs7Ozs7O0FBTUEsZUFBTyxVQUFTLElBQVQsRUFBZTtBQUNsQixlQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUEvQixFQUF1QyxFQUFFLENBQXpDO0FBQ0ksZ0JBQUksVUFBVSxDQUFDLENBQUQsQ0FBVixLQUFrQixJQUF0QixFQUNJLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBRCxDQUFmLENBQVA7QUFGUjtBQUdILFNBSkQ7QUFLSCxPQWJEO0FBZUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxNQUFBLElBQUksQ0FBQyxhQUFMLEdBQXFCO0FBQ2pCLFFBQUEsS0FBSyxFQUFFLE1BRFU7QUFFakIsUUFBQSxLQUFLLEVBQUUsTUFGVTtBQUdqQixRQUFBLEtBQUssRUFBRSxNQUhVO0FBSWpCLFFBQUEsSUFBSSxFQUFFO0FBSlcsT0FBckIsQ0ExWWlELENBaVpqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxVQUFMLEdBQWtCLFlBQVc7QUFDekIsWUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQWxCO0FBQ0E7O0FBQ0EsWUFBSSxDQUFDLE1BQUwsRUFBYTtBQUNULFVBQUEsSUFBSSxDQUFDLFlBQUwsR0FBb0IsSUFBSSxDQUFDLG1CQUFMLEdBQTJCLElBQS9DO0FBQ0E7QUFDSCxTQU53QixDQU96QjtBQUNBOzs7QUFDQSxRQUFBLElBQUksQ0FBQyxZQUFMLEdBQW9CLE1BQU0sQ0FBQyxJQUFQLEtBQWdCLFVBQVUsQ0FBQyxJQUEzQixJQUFtQyxNQUFNLENBQUMsSUFBMUM7QUFDaEI7QUFDQSxpQkFBUyxXQUFULENBQXFCLEtBQXJCLEVBQTRCLFFBQTVCLEVBQXNDO0FBQ2xDLGlCQUFPLElBQUksTUFBSixDQUFXLEtBQVgsRUFBa0IsUUFBbEIsQ0FBUDtBQUNILFNBSkw7O0FBS0EsUUFBQSxJQUFJLENBQUMsbUJBQUwsR0FBMkIsTUFBTSxDQUFDLFdBQVA7QUFDdkI7QUFDQSxpQkFBUyxrQkFBVCxDQUE0QixJQUE1QixFQUFrQztBQUM5QixpQkFBTyxJQUFJLE1BQUosQ0FBVyxJQUFYLENBQVA7QUFDSCxTQUpMO0FBS0gsT0FuQkQ7QUFxQkMsS0F2YWUsRUF1YWQ7QUFBQyxXQUFJLENBQUw7QUFBTyxZQUFLLEVBQVo7QUFBZSxXQUFJLENBQW5CO0FBQXFCLFdBQUksQ0FBekI7QUFBMkIsV0FBSSxDQUEvQjtBQUFpQyxXQUFJLENBQXJDO0FBQXVDLFdBQUksQ0FBM0M7QUFBNkMsV0FBSTtBQUFqRCxLQXZhYyxDQTlwRE87QUFxa0VnQyxRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQzNGOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsTUFBakI7O0FBRUEsVUFBSSxJQUFJLEdBQVEsT0FBTyxDQUFDLEVBQUQsQ0FBdkI7O0FBRUEsVUFBSSxZQUFKLENBTjJGLENBTXpFOztBQUVsQixVQUFJLFFBQVEsR0FBSSxJQUFJLENBQUMsUUFBckI7QUFBQSxVQUNJLE1BQU0sR0FBTSxJQUFJLENBQUMsTUFEckI7QUFBQSxVQUVJLElBQUksR0FBUSxJQUFJLENBQUMsSUFGckI7QUFJQTs7Ozs7Ozs7OztBQVNBLGVBQVMsRUFBVCxDQUFZLEVBQVosRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckIsRUFBMEI7QUFFdEI7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFWO0FBRUE7Ozs7O0FBSUEsYUFBSyxHQUFMLEdBQVcsR0FBWDtBQUVBOzs7OztBQUlBLGFBQUssSUFBTCxHQUFZLFNBQVo7QUFFQTs7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxHQUFYLENBeEJzQixDQXdCTjtBQUNuQjtBQUVEOzs7QUFDQSxlQUFTLElBQVQsR0FBZ0IsQ0FBRSxDQWpEeUUsQ0FpRHhFOztBQUVuQjs7Ozs7Ozs7OztBQVFBLGVBQVMsS0FBVCxDQUFlLE1BQWYsRUFBdUI7QUFFbkI7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsSUFBbkI7QUFFQTs7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsSUFBbkI7QUFFQTs7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxNQUFNLENBQUMsR0FBbEI7QUFFQTs7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsTUFBbkI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsZUFBUyxNQUFULEdBQWtCO0FBRWQ7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxDQUFYO0FBRUE7Ozs7O0FBSUEsYUFBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBWjtBQUVBOzs7OztBQUlBLGFBQUssSUFBTCxHQUFZLEtBQUssSUFBakI7QUFFQTs7Ozs7QUFJQSxhQUFLLE1BQUwsR0FBYyxJQUFkLENBeEJjLENBMEJkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRCxVQUFJLE1BQU0sR0FBRyxTQUFTLE1BQVQsR0FBa0I7QUFDM0IsZUFBTyxJQUFJLENBQUMsTUFBTCxHQUNELFNBQVMsbUJBQVQsR0FBK0I7QUFDN0IsaUJBQU8sQ0FBQyxNQUFNLENBQUMsTUFBUCxHQUFnQixTQUFTLGFBQVQsR0FBeUI7QUFDN0MsbUJBQU8sSUFBSSxZQUFKLEVBQVA7QUFDSCxXQUZNLEdBQVA7QUFHSDtBQUNEO0FBTkcsVUFPRCxTQUFTLFlBQVQsR0FBd0I7QUFDdEIsaUJBQU8sSUFBSSxNQUFKLEVBQVA7QUFDSCxTQVRMO0FBVUgsT0FYRDtBQWFBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLEVBQXRCO0FBRUE7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLEtBQVAsR0FBZSxTQUFTLEtBQVQsQ0FBZSxJQUFmLEVBQXFCO0FBQ2hDLGVBQU8sSUFBSSxJQUFJLENBQUMsS0FBVCxDQUFlLElBQWYsQ0FBUDtBQUNILE9BRkQsQ0FySjJGLENBeUozRjs7QUFDQTs7O0FBQ0EsVUFBSSxJQUFJLENBQUMsS0FBTCxLQUFlLEtBQW5CLEVBQ0ksTUFBTSxDQUFDLEtBQVAsR0FBZSxJQUFJLENBQUMsSUFBTCxDQUFVLE1BQU0sQ0FBQyxLQUFqQixFQUF3QixJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsUUFBN0MsQ0FBZjtBQUVKOzs7Ozs7Ozs7QUFRQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsSUFBVCxDQUFjLEVBQWQsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsRUFBNEI7QUFDakQsYUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLEVBQUosQ0FBTyxFQUFQLEVBQVcsR0FBWCxFQUFnQixHQUFoQixDQUE3QjtBQUNBLGFBQUssR0FBTCxJQUFZLEdBQVo7QUFDQSxlQUFPLElBQVA7QUFDSCxPQUpEOztBQU1BLGVBQVMsU0FBVCxDQUFtQixHQUFuQixFQUF3QixHQUF4QixFQUE2QixHQUE3QixFQUFrQztBQUM5QixRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBVyxHQUFHLEdBQUcsR0FBakI7QUFDSDs7QUFFRCxlQUFTLGFBQVQsQ0FBdUIsR0FBdkIsRUFBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsZUFBTyxHQUFHLEdBQUcsR0FBYixFQUFrQjtBQUNkLFVBQUEsR0FBRyxDQUFDLEdBQUcsRUFBSixDQUFILEdBQWEsR0FBRyxHQUFHLEdBQU4sR0FBWSxHQUF6QjtBQUNBLFVBQUEsR0FBRyxNQUFNLENBQVQ7QUFDSDs7QUFDRCxRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBVyxHQUFYO0FBQ0g7QUFFRDs7Ozs7Ozs7Ozs7QUFTQSxlQUFTLFFBQVQsQ0FBa0IsR0FBbEIsRUFBdUIsR0FBdkIsRUFBNEI7QUFDeEIsYUFBSyxHQUFMLEdBQVcsR0FBWDtBQUNBLGFBQUssSUFBTCxHQUFZLFNBQVo7QUFDQSxhQUFLLEdBQUwsR0FBVyxHQUFYO0FBQ0g7O0FBRUQsTUFBQSxRQUFRLENBQUMsU0FBVCxHQUFxQixNQUFNLENBQUMsTUFBUCxDQUFjLEVBQUUsQ0FBQyxTQUFqQixDQUFyQjtBQUNBLE1BQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsRUFBbkIsR0FBd0IsYUFBeEI7QUFFQTs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQ7QUFDQTtBQUNBLGFBQUssR0FBTCxJQUFZLENBQUMsS0FBSyxJQUFMLEdBQVksS0FBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLFFBQUosQ0FDdEMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQW5CLElBQ1UsR0FEVixHQUNzQixDQUR0QixHQUVFLEtBQUssR0FBRyxLQUFSLEdBQW9CLENBQXBCLEdBQ0EsS0FBSyxHQUFHLE9BQVIsR0FBb0IsQ0FBcEIsR0FDQSxLQUFLLEdBQUcsU0FBUixHQUFvQixDQUFwQixHQUNvQixDQU5nQixFQU8xQyxLQVAwQyxDQUE5QixFQU9KLEdBUFI7QUFRQSxlQUFPLElBQVA7QUFDSCxPQVpEO0FBY0E7Ozs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixTQUFTLFdBQVQsQ0FBcUIsS0FBckIsRUFBNEI7QUFDakQsZUFBTyxLQUFLLEdBQUcsQ0FBUixHQUNELEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsRUFBMUIsRUFBOEIsUUFBUSxDQUFDLFVBQVQsQ0FBb0IsS0FBcEIsQ0FBOUIsQ0FEQyxDQUN5RDtBQUR6RCxVQUVELEtBQUssTUFBTCxDQUFZLEtBQVosQ0FGTjtBQUdILE9BSkQ7QUFNQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCO0FBQ25ELGVBQU8sS0FBSyxNQUFMLENBQVksQ0FBQyxLQUFLLElBQUksQ0FBVCxHQUFhLEtBQUssSUFBSSxFQUF2QixNQUErQixDQUEzQyxDQUFQO0FBQ0gsT0FGRDs7QUFJQSxlQUFTLGFBQVQsQ0FBdUIsR0FBdkIsRUFBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsZUFBTyxHQUFHLENBQUMsRUFBWCxFQUFlO0FBQ1gsVUFBQSxHQUFHLENBQUMsR0FBRyxFQUFKLENBQUgsR0FBYSxHQUFHLENBQUMsRUFBSixHQUFTLEdBQVQsR0FBZSxHQUE1QjtBQUNBLFVBQUEsR0FBRyxDQUFDLEVBQUosR0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFKLEtBQVcsQ0FBWCxHQUFlLEdBQUcsQ0FBQyxFQUFKLElBQVUsRUFBMUIsTUFBa0MsQ0FBM0M7QUFDQSxVQUFBLEdBQUcsQ0FBQyxFQUFKLE1BQVksQ0FBWjtBQUNIOztBQUNELGVBQU8sR0FBRyxDQUFDLEVBQUosR0FBUyxHQUFoQixFQUFxQjtBQUNqQixVQUFBLEdBQUcsQ0FBQyxHQUFHLEVBQUosQ0FBSCxHQUFhLEdBQUcsQ0FBQyxFQUFKLEdBQVMsR0FBVCxHQUFlLEdBQTVCO0FBQ0EsVUFBQSxHQUFHLENBQUMsRUFBSixHQUFTLEdBQUcsQ0FBQyxFQUFKLEtBQVcsQ0FBcEI7QUFDSDs7QUFDRCxRQUFBLEdBQUcsQ0FBQyxHQUFHLEVBQUosQ0FBSCxHQUFhLEdBQUcsQ0FBQyxFQUFqQjtBQUNIO0FBRUQ7Ozs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsQ0FBYyxLQUFkLENBQVg7QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsSUFBSSxDQUFDLE1BQUwsRUFBMUIsRUFBeUMsSUFBekMsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixNQUFNLENBQUMsU0FBUCxDQUFpQixNQUExQztBQUVBOzs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsQ0FBYyxLQUFkLEVBQXFCLFFBQXJCLEVBQVg7QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsSUFBSSxDQUFDLE1BQUwsRUFBMUIsRUFBeUMsSUFBekMsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBakIsR0FBd0IsU0FBUyxVQUFULENBQW9CLEtBQXBCLEVBQTJCO0FBQy9DLGVBQU8sS0FBSyxLQUFMLENBQVcsU0FBWCxFQUFzQixDQUF0QixFQUF5QixLQUFLLEdBQUcsQ0FBSCxHQUFPLENBQXJDLENBQVA7QUFDSCxPQUZEOztBQUlBLGVBQVMsWUFBVCxDQUFzQixHQUF0QixFQUEyQixHQUEzQixFQUFnQyxHQUFoQyxFQUFxQztBQUNqQyxRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZ0IsR0FBRyxHQUFXLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssQ0FBUixHQUFjLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBUixHQUFjLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBeEI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixPQUFqQixHQUEyQixTQUFTLGFBQVQsQ0FBdUIsS0FBdkIsRUFBOEI7QUFDckQsZUFBTyxLQUFLLEtBQUwsQ0FBVyxZQUFYLEVBQXlCLENBQXpCLEVBQTRCLEtBQUssS0FBSyxDQUF0QyxDQUFQO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsUUFBakIsR0FBNEIsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsT0FBN0M7QUFFQTs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsT0FBakIsR0FBMkIsU0FBUyxhQUFULENBQXVCLEtBQXZCLEVBQThCO0FBQ3JELFlBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFULENBQWMsS0FBZCxDQUFYO0FBQ0EsZUFBTyxLQUFLLEtBQUwsQ0FBVyxZQUFYLEVBQXlCLENBQXpCLEVBQTRCLElBQUksQ0FBQyxFQUFqQyxFQUFxQyxLQUFyQyxDQUEyQyxZQUEzQyxFQUF5RCxDQUF6RCxFQUE0RCxJQUFJLENBQUMsRUFBakUsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixNQUFNLENBQUMsU0FBUCxDQUFpQixPQUE3QztBQUVBOzs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxZQUF5QixTQUFTLFdBQVQsQ0FBcUIsS0FBckIsRUFBNEI7QUFDakQsZUFBTyxLQUFLLEtBQUwsQ0FBVyxJQUFJLFNBQUosQ0FBVyxZQUF0QixFQUFvQyxDQUFwQyxFQUF1QyxLQUF2QyxDQUFQO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsYUFBMEIsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCO0FBQ25ELGVBQU8sS0FBSyxLQUFMLENBQVcsSUFBSSxTQUFKLENBQVcsYUFBdEIsRUFBcUMsQ0FBckMsRUFBd0MsS0FBeEMsQ0FBUDtBQUNILE9BRkQ7O0FBSUEsVUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxTQUFYLENBQXFCLEdBQXJCLEdBQ1gsU0FBUyxjQUFULENBQXdCLEdBQXhCLEVBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDO0FBQ3JDLFFBQUEsR0FBRyxDQUFDLEdBQUosQ0FBUSxHQUFSLEVBQWEsR0FBYixFQURxQyxDQUNsQjtBQUN0QjtBQUNEO0FBSmEsUUFLWCxTQUFTLGNBQVQsQ0FBd0IsR0FBeEIsRUFBNkIsR0FBN0IsRUFBa0MsR0FBbEMsRUFBdUM7QUFDckMsYUFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBeEIsRUFBZ0MsRUFBRSxDQUFsQztBQUNJLFVBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQURKO0FBRUgsT0FSTDtBQVVBOzs7Ozs7QUFLQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsV0FBVCxDQUFxQixLQUFyQixFQUE0QjtBQUNqRCxZQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsTUFBTixLQUFpQixDQUEzQjtBQUNBLFlBQUksQ0FBQyxHQUFMLEVBQ0ksT0FBTyxLQUFLLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLENBQVA7O0FBQ0osWUFBSSxJQUFJLENBQUMsUUFBTCxDQUFjLEtBQWQsQ0FBSixFQUEwQjtBQUN0QixjQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBUCxDQUFhLEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBUCxDQUFjLEtBQWQsQ0FBbkIsQ0FBVjtBQUNBLFVBQUEsTUFBTSxDQUFDLE1BQVAsQ0FBYyxLQUFkLEVBQXFCLEdBQXJCLEVBQTBCLENBQTFCO0FBQ0EsVUFBQSxLQUFLLEdBQUcsR0FBUjtBQUNIOztBQUNELGVBQU8sS0FBSyxNQUFMLENBQVksR0FBWixFQUFpQixLQUFqQixDQUF1QixVQUF2QixFQUFtQyxHQUFuQyxFQUF3QyxLQUF4QyxDQUFQO0FBQ0gsT0FWRDtBQVlBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQUwsQ0FBWSxLQUFaLENBQVY7QUFDQSxlQUFPLEdBQUcsR0FDSixLQUFLLE1BQUwsQ0FBWSxHQUFaLEVBQWlCLEtBQWpCLENBQXVCLElBQUksQ0FBQyxLQUE1QixFQUFtQyxHQUFuQyxFQUF3QyxLQUF4QyxDQURJLEdBRUosS0FBSyxLQUFMLENBQVcsU0FBWCxFQUFzQixDQUF0QixFQUF5QixDQUF6QixDQUZOO0FBR0gsT0FMRDtBQU9BOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixJQUFqQixHQUF3QixTQUFTLElBQVQsR0FBZ0I7QUFDcEMsYUFBSyxNQUFMLEdBQWMsSUFBSSxLQUFKLENBQVUsSUFBVixDQUFkO0FBQ0EsYUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBeEI7QUFDQSxhQUFLLEdBQUwsR0FBVyxDQUFYO0FBQ0EsZUFBTyxJQUFQO0FBQ0gsT0FMRDtBQU9BOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsS0FBVCxHQUFpQjtBQUN0QyxZQUFJLEtBQUssTUFBVCxFQUFpQjtBQUNiLGVBQUssSUFBTCxHQUFjLEtBQUssTUFBTCxDQUFZLElBQTFCO0FBQ0EsZUFBSyxJQUFMLEdBQWMsS0FBSyxNQUFMLENBQVksSUFBMUI7QUFDQSxlQUFLLEdBQUwsR0FBYyxLQUFLLE1BQUwsQ0FBWSxHQUExQjtBQUNBLGVBQUssTUFBTCxHQUFjLEtBQUssTUFBTCxDQUFZLElBQTFCO0FBQ0gsU0FMRCxNQUtPO0FBQ0gsZUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBeEI7QUFDQSxlQUFLLEdBQUwsR0FBWSxDQUFaO0FBQ0g7O0FBQ0QsZUFBTyxJQUFQO0FBQ0gsT0FYRDtBQWFBOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLE1BQWpCLEdBQTBCLFNBQVMsTUFBVCxHQUFrQjtBQUN4QyxZQUFJLElBQUksR0FBRyxLQUFLLElBQWhCO0FBQUEsWUFDSSxJQUFJLEdBQUcsS0FBSyxJQURoQjtBQUFBLFlBRUksR0FBRyxHQUFJLEtBQUssR0FGaEI7QUFHQSxhQUFLLEtBQUwsR0FBYSxNQUFiLENBQW9CLEdBQXBCOztBQUNBLFlBQUksR0FBSixFQUFTO0FBQ0wsZUFBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLENBQUMsSUFBdEIsQ0FESyxDQUN1Qjs7QUFDNUIsZUFBSyxJQUFMLEdBQVksSUFBWjtBQUNBLGVBQUssR0FBTCxJQUFZLEdBQVo7QUFDSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQVhEO0FBYUE7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxNQUFULEdBQWtCO0FBQ3hDLFlBQUksSUFBSSxHQUFHLEtBQUssSUFBTCxDQUFVLElBQXJCO0FBQUEsWUFBMkI7QUFDdkIsUUFBQSxHQUFHLEdBQUksS0FBSyxXQUFMLENBQWlCLEtBQWpCLENBQXVCLEtBQUssR0FBNUIsQ0FEWDtBQUFBLFlBRUksR0FBRyxHQUFJLENBRlg7O0FBR0EsZUFBTyxJQUFQLEVBQWE7QUFDVCxVQUFBLElBQUksQ0FBQyxFQUFMLENBQVEsSUFBSSxDQUFDLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkI7QUFDQSxVQUFBLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBWjtBQUNBLFVBQUEsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFaO0FBQ0gsU0FSdUMsQ0FTeEM7OztBQUNBLGVBQU8sR0FBUDtBQUNILE9BWEQ7O0FBYUEsTUFBQSxNQUFNLENBQUMsVUFBUCxHQUFvQixVQUFTLGFBQVQsRUFBd0I7QUFDeEMsUUFBQSxZQUFZLEdBQUcsYUFBZjtBQUNBLFFBQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsTUFBTSxFQUF0Qjs7QUFDQSxRQUFBLFlBQVksQ0FBQyxVQUFiO0FBQ0gsT0FKRDtBQU1DLEtBbmR5RCxFQW1keEQ7QUFBQyxZQUFLO0FBQU4sS0FuZHdELENBcmtFbkM7QUF3aEZWLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDakQ7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixZQUFqQixDQUZpRCxDQUlqRDs7QUFDQSxVQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsRUFBRCxDQUFwQjs7QUFDQSxPQUFDLFlBQVksQ0FBQyxTQUFiLEdBQXlCLE1BQU0sQ0FBQyxNQUFQLENBQWMsTUFBTSxDQUFDLFNBQXJCLENBQTFCLEVBQTJELFdBQTNELEdBQXlFLFlBQXpFOztBQUVBLFVBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxFQUFELENBQWxCO0FBRUE7Ozs7Ozs7O0FBTUEsZUFBUyxZQUFULEdBQXdCO0FBQ3BCLFFBQUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaO0FBQ0g7O0FBRUQsTUFBQSxZQUFZLENBQUMsVUFBYixHQUEwQixZQUFZO0FBQ2xDOzs7Ozs7QUFNQSxRQUFBLFlBQVksQ0FBQyxLQUFiLEdBQXFCLElBQUksQ0FBQyxtQkFBMUI7QUFFQSxRQUFBLFlBQVksQ0FBQyxnQkFBYixHQUFnQyxJQUFJLENBQUMsTUFBTCxJQUFlLElBQUksQ0FBQyxNQUFMLENBQVksU0FBWixZQUFpQyxVQUFoRCxJQUE4RCxJQUFJLENBQUMsTUFBTCxDQUFZLFNBQVosQ0FBc0IsR0FBdEIsQ0FBMEIsSUFBMUIsS0FBbUMsS0FBakcsR0FDMUIsU0FBUyxvQkFBVCxDQUE4QixHQUE5QixFQUFtQyxHQUFuQyxFQUF3QyxHQUF4QyxFQUE2QztBQUM3QyxVQUFBLEdBQUcsQ0FBQyxHQUFKLENBQVEsR0FBUixFQUFhLEdBQWIsRUFENkMsQ0FDMUI7QUFDbkI7QUFDRDtBQUNEO0FBTDRCLFVBTTFCLFNBQVMscUJBQVQsQ0FBK0IsR0FBL0IsRUFBb0MsR0FBcEMsRUFBeUMsR0FBekMsRUFBOEM7QUFDOUMsY0FBSSxHQUFHLENBQUMsSUFBUixFQUFjO0FBQ1osWUFBQSxHQUFHLENBQUMsSUFBSixDQUFTLEdBQVQsRUFBYyxHQUFkLEVBQW1CLENBQW5CLEVBQXNCLEdBQUcsQ0FBQyxNQUExQixFQURGLEtBRUssS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBeEI7QUFBaUM7QUFDcEMsWUFBQSxHQUFHLENBQUMsR0FBRyxFQUFKLENBQUgsR0FBYSxHQUFHLENBQUMsQ0FBQyxFQUFGLENBQWhCO0FBREc7QUFFTixTQVhMO0FBWUgsT0FyQkQ7QUF3QkE7Ozs7O0FBR0EsTUFBQSxZQUFZLENBQUMsU0FBYixDQUF1QixLQUF2QixHQUErQixTQUFTLGtCQUFULENBQTRCLEtBQTVCLEVBQW1DO0FBQzlELFlBQUksSUFBSSxDQUFDLFFBQUwsQ0FBYyxLQUFkLENBQUosRUFDSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsS0FBbEIsRUFBeUIsUUFBekIsQ0FBUjtBQUNKLFlBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFOLEtBQWlCLENBQTNCO0FBQ0EsYUFBSyxNQUFMLENBQVksR0FBWjtBQUNBLFlBQUksR0FBSixFQUNJLEtBQUssS0FBTCxDQUFXLFlBQVksQ0FBQyxnQkFBeEIsRUFBMEMsR0FBMUMsRUFBK0MsS0FBL0M7QUFDSixlQUFPLElBQVA7QUFDSCxPQVJEOztBQVVBLGVBQVMsaUJBQVQsQ0FBMkIsR0FBM0IsRUFBZ0MsR0FBaEMsRUFBcUMsR0FBckMsRUFBMEM7QUFDdEMsWUFBSSxHQUFHLENBQUMsTUFBSixHQUFhLEVBQWpCLEVBQXFCO0FBQ2pCLFVBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxLQUFWLENBQWdCLEdBQWhCLEVBQXFCLEdBQXJCLEVBQTBCLEdBQTFCLEVBREosS0FFSyxJQUFJLEdBQUcsQ0FBQyxTQUFSLEVBQ0QsR0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEdBQW5CLEVBREMsS0FHRCxHQUFHLENBQUMsS0FBSixDQUFVLEdBQVYsRUFBZSxHQUFmO0FBQ1A7QUFFRDs7Ozs7QUFHQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLFNBQVMsbUJBQVQsQ0FBNkIsS0FBN0IsRUFBb0M7QUFDaEUsWUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQUwsQ0FBWSxVQUFaLENBQXVCLEtBQXZCLENBQVY7QUFDQSxhQUFLLE1BQUwsQ0FBWSxHQUFaO0FBQ0EsWUFBSSxHQUFKLEVBQ0ksS0FBSyxLQUFMLENBQVcsaUJBQVgsRUFBOEIsR0FBOUIsRUFBbUMsS0FBbkM7QUFDSixlQUFPLElBQVA7QUFDSCxPQU5EO0FBU0E7Ozs7Ozs7O0FBT0EsTUFBQSxZQUFZLENBQUMsVUFBYjtBQUVDLEtBdkZlLEVBdUZkO0FBQUMsWUFBSyxFQUFOO0FBQVMsWUFBSztBQUFkLEtBdkZjO0FBeGhGTyxHQWpDVyxFQWdwRlosRUFocEZZLEVBZ3BGVCxDQUFDLENBQUQsQ0FocEZTO0FBa3BGakMsQ0FscEZELEtBbXBGQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOltudWxsXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgSender.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db8e8qijfhLu5qRq3LZHeRc', 'MsgSender');
// msg/MsgSender.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MsgEncoder_1 = require("./MsgEncoder");
var MsgDecoder_1 = require("./MsgDecoder");
var MsgSender = /** @class */ (function () {
    function MsgSender() {
        this._oWebsocket = null;
        this._oMsgEncoder = new MsgEncoder_1.default();
        this._oMsgDecoder = new MsgDecoder_1.default();
    }
    /**
     * 获取单例对象
     */
    MsgSender.getInstance = function () {
        return MsgSender._oInstance;
    };
    MsgSender.prototype.connect = function (funCallback) {
        var _this = this;
        if (funCallback === void 0) { funCallback = null; }
        var url = 'ws://192.168.1.63:6666/websocket';
        var oWebsocket = new WebSocket(url);
        oWebsocket.binaryType = "arraybuffer";
        oWebsocket.onopen = function () {
            cc.log("\u5DF2\u8FDE\u63A5\u670D\u52A1\u5668\uFF0Curl=" + url);
            _this._oWebsocket = oWebsocket;
            if (null != funCallback) {
                funCallback();
            }
        };
        oWebsocket.onclose = function () {
            cc.log("\u670D\u52A1\u5668\u5173\u95ED\u8FDE\u63A5");
            _this._oWebsocket = null;
        };
        oWebsocket.onmessage = function (oEvent) {
            console.log("onmessage进入");
            if (oEvent == null || null == oEvent.data) {
                return;
            }
            var uint8Array = new Uint8Array(oEvent.data);
            var nMsgCode = _this._oMsgDecoder.getMsgCode(uint8Array);
            var decode = _this._oMsgDecoder.decode(nMsgCode, uint8Array.slice(4));
            console.log("decode", decode);
            if (_this.onMsgReceived != null) {
                _this.onMsgReceived(nMsgCode, decode);
            }
        };
    };
    MsgSender.prototype.sendMsg = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        if (null == this._oWebsocket) {
            return;
        }
        var uint8Array = this._oMsgEncoder.encode(nMsgCode, oMsgBody);
        if (uint8Array == null) {
            return;
        }
        console.log('发送消息，消息编号：', nMsgCode);
        this._oWebsocket.send(uint8Array);
    };
    MsgSender.prototype.onMsgReceived = function (nMsgCode, oMsgBody) {
    };
    MsgSender._oInstance = new MsgSender();
    return MsgSender;
}());
exports.default = MsgSender;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dTZW5kZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwyQ0FBc0M7QUFDdEMsMkNBQXNDO0FBRXRDO0lBUUk7UUFKUSxnQkFBVyxHQUFXLElBQUksQ0FBQztRQUVsQixpQkFBWSxHQUFZLElBQUksb0JBQVUsRUFBRSxDQUFDO1FBQ3pDLGlCQUFZLEdBQVksSUFBSSxvQkFBVSxFQUFFLENBQUM7SUFFMUQsQ0FBQztJQUVEOztPQUVHO0lBQ1cscUJBQVcsR0FBekI7UUFDSSxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQUM7SUFDaEMsQ0FBQztJQUNELDJCQUFPLEdBQVAsVUFBUSxXQUF5QjtRQUFqQyxpQkFpQ0M7UUFqQ08sNEJBQUEsRUFBQSxrQkFBeUI7UUFDN0IsSUFBSSxHQUFHLEdBQUMsa0NBQWtDLENBQUM7UUFDM0MsSUFBSSxVQUFVLEdBQUMsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEMsVUFBVSxDQUFDLFVBQVUsR0FBQyxhQUFhLENBQUM7UUFFcEMsVUFBVSxDQUFDLE1BQU0sR0FBQztZQUNkLEVBQUUsQ0FBQyxHQUFHLENBQUMsbURBQWMsR0FBSyxDQUFDLENBQUE7WUFDM0IsS0FBSSxDQUFDLFdBQVcsR0FBQyxVQUFVLENBQUM7WUFDNUIsSUFBRyxJQUFJLElBQUUsV0FBVyxFQUFDO2dCQUNqQixXQUFXLEVBQUUsQ0FBQzthQUNqQjtRQUNMLENBQUMsQ0FBQTtRQUVELFVBQVUsQ0FBQyxPQUFPLEdBQUM7WUFDZixFQUFFLENBQUMsR0FBRyxDQUFDLDRDQUFTLENBQUMsQ0FBQTtZQUNqQixLQUFJLENBQUMsV0FBVyxHQUFDLElBQUksQ0FBQztRQUMxQixDQUFDLENBQUE7UUFFRCxVQUFVLENBQUMsU0FBUyxHQUFDLFVBQUMsTUFBbUI7WUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMzQixJQUFHLE1BQU0sSUFBRSxJQUFJLElBQUUsSUFBSSxJQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUM7Z0JBQy9CLE9BQU87YUFDVjtZQUNELElBQUksVUFBVSxHQUFHLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM3QyxJQUFJLFFBQVEsR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUV4RCxJQUFJLE1BQU0sR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTdCLElBQUksS0FBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLEVBQUU7Z0JBQzVCLEtBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0wsQ0FBQyxDQUFBO0lBQ0wsQ0FBQztJQUVELDJCQUFPLEdBQVAsVUFBUSxRQUFlLEVBQUMsUUFBWTtRQUNoQyxJQUFHLFFBQVEsR0FBQyxDQUFDLElBQUUsSUFBSSxJQUFFLFFBQVEsRUFBQztZQUMxQixPQUFPO1NBQ1Y7UUFDRCxJQUFHLElBQUksSUFBRSxJQUFJLENBQUMsV0FBVyxFQUFDO1lBQ3RCLE9BQU87U0FDVjtRQUNELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBQyxRQUFRLENBQUMsQ0FBQztRQUM3RCxJQUFHLFVBQVUsSUFBRSxJQUFJLEVBQUM7WUFDaEIsT0FBTztTQUNWO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUMsUUFBUSxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELGlDQUFhLEdBQWIsVUFBYyxRQUFlLEVBQUMsUUFBWTtJQUUxQyxDQUFDO0lBbkV1QixvQkFBVSxHQUFZLElBQUksU0FBUyxFQUFFLENBQUM7SUFvRWxFLGdCQUFDO0NBdEVELEFBc0VDLElBQUE7a0JBdEVvQixTQUFTIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE1zZ0VuY29kZXIgZnJvbSAnLi9Nc2dFbmNvZGVyJztcclxuaW1wb3J0IE1zZ0RlY29kZXIgZnJvbSAnLi9Nc2dEZWNvZGVyJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1zZ1NlbmRlciAvKmV4dGVuZHMgY2MuQ29tcG9uZW50Ki8ge1xyXG5cclxuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IF9vSW5zdGFuY2U6TXNnU2VuZGVyID1uZXcgTXNnU2VuZGVyKCk7XHJcblxyXG4gICAgcHJpdmF0ZSBfb1dlYnNvY2tldDpXZWJTb2NrZXQ9bnVsbDtcclxuXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IF9vTXNnRW5jb2RlcjpNc2dFbmNvZGVyPW5ldyBNc2dFbmNvZGVyKCk7XHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IF9vTXNnRGVjb2RlcjpNc2dEZWNvZGVyPW5ldyBNc2dEZWNvZGVyKCk7XHJcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6I635Y+W5Y2V5L6L5a+56LGhXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0SW5zdGFuY2UoKTpNc2dTZW5kZXJ7XHJcbiAgICAgICAgcmV0dXJuIE1zZ1NlbmRlci5fb0luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgY29ubmVjdChmdW5DYWxsYmFjazooKT0+dm9pZD1udWxsKTp2b2lke1xyXG4gICAgICAgIGxldCB1cmw9J3dzOi8vMTkyLjE2OC4xLjYzOjY2NjYvd2Vic29ja2V0JztcclxuICAgICAgICBsZXQgb1dlYnNvY2tldD1uZXcgV2ViU29ja2V0KHVybCk7XHJcbiAgICAgICAgb1dlYnNvY2tldC5iaW5hcnlUeXBlPVwiYXJyYXlidWZmZXJcIjtcclxuXHJcbiAgICAgICAgb1dlYnNvY2tldC5vbm9wZW49KCk6dm9pZD0+e1xyXG4gICAgICAgICAgICBjYy5sb2coYOW3sui/nuaOpeacjeWKoeWZqO+8jHVybD0ke3VybH1gKVxyXG4gICAgICAgICAgICB0aGlzLl9vV2Vic29ja2V0PW9XZWJzb2NrZXQ7XHJcbiAgICAgICAgICAgIGlmKG51bGwhPWZ1bkNhbGxiYWNrKXtcclxuICAgICAgICAgICAgICAgIGZ1bkNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9XZWJzb2NrZXQub25jbG9zZT0oKTp2b2lkPT57XHJcbiAgICAgICAgICAgIGNjLmxvZyhg5pyN5Yqh5Zmo5YWz6Zet6L+e5o6lYClcclxuICAgICAgICAgICAgdGhpcy5fb1dlYnNvY2tldD1udWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb1dlYnNvY2tldC5vbm1lc3NhZ2U9KG9FdmVudDpNZXNzYWdlRXZlbnQpOnZvaWQgPT57XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwib25tZXNzYWdl6L+b5YWlXCIpO1xyXG4gICAgICAgICAgICBpZihvRXZlbnQ9PW51bGx8fG51bGw9PW9FdmVudC5kYXRhKXtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgdWludDhBcnJheSA9IG5ldyBVaW50OEFycmF5KG9FdmVudC5kYXRhKTtcclxuICAgICAgICAgICAgbGV0IG5Nc2dDb2RlID0gdGhpcy5fb01zZ0RlY29kZXIuZ2V0TXNnQ29kZSh1aW50OEFycmF5KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkZWNvZGUgPSB0aGlzLl9vTXNnRGVjb2Rlci5kZWNvZGUobk1zZ0NvZGUsdWludDhBcnJheS5zbGljZSg0KSk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGVjb2RlXCIsZGVjb2RlKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm9uTXNnUmVjZWl2ZWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vbk1zZ1JlY2VpdmVkKG5Nc2dDb2RlLGRlY29kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZE1zZyhuTXNnQ29kZTpudW1iZXIsb01zZ0JvZHk6YW55KTp2b2lke1xyXG4gICAgICAgIGlmKG5Nc2dDb2RlPDB8fG51bGw9PW9Nc2dCb2R5KXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihudWxsPT10aGlzLl9vV2Vic29ja2V0KXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdWludDhBcnJheSA9IHRoaXMuX29Nc2dFbmNvZGVyLmVuY29kZShuTXNnQ29kZSxvTXNnQm9keSk7XHJcbiAgICAgICAgaWYodWludDhBcnJheT09bnVsbCl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+WPkemAgea2iOaBr++8jOa2iOaBr+e8luWPt++8micsbk1zZ0NvZGUpO1xyXG4gICAgICAgIHRoaXMuX29XZWJzb2NrZXQuc2VuZCh1aW50OEFycmF5KTtcclxuICAgIH1cclxuXHJcbiAgICBvbk1zZ1JlY2VpdmVkKG5Nc2dDb2RlOm51bWJlcixvTXNnQm9keTphbnkpOnZvaWR7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgEncoder.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '173416YXH9KiY/sjR5VNENm', 'MsgEncoder');
// msg/MsgEncoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_protobuf = require("./protobuf");
var MsgEncoder = /** @class */ (function () {
    function MsgEncoder() {
    }
    MsgEncoder.prototype.encode = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        var oWriter = mod_protobuf.Writer.create();
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        var oByteAttay = oMsgBody.constructor.encode(oMsgBody, oWriter).finish();
        var nMsgLen = oByteAttay.byteLength = 2;
        oByteAttay[0] = nMsgLen >> 8 & 0xff;
        oByteAttay[1] = nMsgLen & 0xff;
        oByteAttay[2] = nMsgCode >> 8 & 0xff;
        oByteAttay[3] = nMsgCode & 0xff;
        return oByteAttay;
    };
    return MsgEncoder;
}());
exports.default = MsgEncoder;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dFbmNvZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUNBQTJDO0FBRzNDO0lBQUE7SUFzQkEsQ0FBQztJQXJCRywyQkFBTSxHQUFOLFVBQU8sUUFBZSxFQUFDLFFBQVk7UUFDL0IsSUFBRyxRQUFRLEdBQUMsQ0FBQyxJQUFFLElBQUksSUFBRSxRQUFRLEVBQUM7WUFDMUIsT0FBTztTQUNWO1FBRUQsSUFBSSxPQUFPLEdBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN6QyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakIsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqQixPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWpCLElBQUksVUFBVSxHQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUV0RSxJQUFJLE9BQU8sR0FBQyxVQUFVLENBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQztRQUNwQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDbEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sR0FBSSxJQUFJLENBQUM7UUFDOUIsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLFFBQVEsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ25DLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxRQUFRLEdBQUksSUFBSSxDQUFDO1FBQy9CLE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTCxpQkFBQztBQUFELENBdEJBLEFBc0JDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX3Byb3RvYnVmID1yZXF1aXJlKFwiLi9wcm90b2J1ZlwiKTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNc2dFbmNvZGVyICB7XHJcbiAgICBlbmNvZGUobk1zZ0NvZGU6bnVtYmVyLG9Nc2dCb2R5OmFueSk6VWludDhBcnJheXtcclxuICAgICAgICBpZihuTXNnQ29kZTwwfHxudWxsPT1vTXNnQm9keSl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvV3JpdGVyPW1vZF9wcm90b2J1Zi5Xcml0ZXIuY3JlYXRlKCk7XHJcbiAgICAgICAgb1dyaXRlci5ieXRlcygwKTtcclxuICAgICAgICBvV3JpdGVyLmJ5dGVzKDApO1xyXG4gICAgICAgIG9Xcml0ZXIuYnl0ZXMoMCk7XHJcbiAgICAgICAgb1dyaXRlci5ieXRlcygwKTtcclxuXHJcbiAgICAgICAgbGV0IG9CeXRlQXR0YXk9b01zZ0JvZHkuY29uc3RydWN0b3IuZW5jb2RlKG9Nc2dCb2R5LG9Xcml0ZXIpLmZpbmlzaCgpO1xyXG5cclxuICAgICAgICBsZXQgbk1zZ0xlbj1vQnl0ZUF0dGF5LmJ5dGVMZW5ndGg9MjtcclxuICAgICAgICBvQnl0ZUF0dGF5WzBdPW5Nc2dMZW4gPj4gOCAmIDB4ZmY7XHJcbiAgICAgICAgb0J5dGVBdHRheVsxXT1uTXNnTGVuICAmIDB4ZmY7XHJcbiAgICAgICAgb0J5dGVBdHRheVsyXT1uTXNnQ29kZSA+PiA4ICYgMHhmZjtcclxuICAgICAgICBvQnl0ZUF0dGF5WzNdPW5Nc2dDb2RlICAmIDB4ZmY7XHJcbiAgICAgICAgcmV0dXJuIG9CeXRlQXR0YXk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgDecoder.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f7611y8rnhIzp1CEXC2Al/u', 'MsgDecoder');
// msg/MsgDecoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProcotol = require("./GameMsgProtocol");
var MsgDecoder = /** @class */ (function () {
    function MsgDecoder() {
    }
    MsgDecoder.prototype.getMsgCode = function (oUint8Array) {
        if (oUint8Array == null || oUint8Array.byteLength < 4) {
            return -1;
        }
        var nMsgCode = 0;
        nMsgCode |= (oUint8Array[2] & 0xFF) << 8;
        nMsgCode |= (oUint8Array[3] & 0xFF);
        return nMsgCode;
    };
    MsgDecoder.prototype.decode = function (nMsgCode, oUint8Array) {
        if (nMsgCode < 0 || null == oUint8Array || oUint8Array.byteLength <= 0) {
            return;
        }
        var strMsgName = mod_GameMsgProcotol.msg.MsgCode[nMsgCode];
        if (strMsgName == null) {
            console.log("nMsgCode:" + nMsgCode + "\u5BF9\u5E94msg\u540D\u79F0\u4E0D\u5B58\u5728");
        }
        var oTempArray = strMsgName.split("_");
        strMsgName = "";
        for (var _i = 0, oTempArray_1 = oTempArray; _i < oTempArray_1.length; _i++) {
            var strTemp = oTempArray_1[_i];
            strMsgName += strTemp.charAt(0) + strTemp.substr(1).toLowerCase();
        }
        var oMsgClazz = mod_GameMsgProcotol.msg[strMsgName];
        if (null == oMsgClazz || typeof (oMsgClazz['decode']) != "function") {
            console.log("strMsgName:" + strMsgName + " \u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7684\u7C7B");
            return;
        }
        return oMsgClazz.decode(oUint8Array);
    };
    return MsgDecoder;
}());
exports.default = MsgDecoder;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dEZWNvZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdURBQXdEO0FBR3hEO0lBQUE7SUFpQ0EsQ0FBQztJQWhDRywrQkFBVSxHQUFWLFVBQVcsV0FBc0I7UUFDN0IsSUFBRyxXQUFXLElBQUUsSUFBSSxJQUFFLFdBQVcsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxFQUFDO1lBQzNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDYjtRQUVELElBQUksUUFBUSxHQUFDLENBQUMsQ0FBQztRQUNmLFFBQVEsSUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBRyxDQUFDLENBQUM7UUFDcEMsUUFBUSxJQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFFO1FBRWpDLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sUUFBZSxFQUFDLFdBQXNCO1FBQ3pDLElBQUcsUUFBUSxHQUFDLENBQUMsSUFBRSxJQUFJLElBQUUsV0FBVyxJQUFFLFdBQVcsQ0FBQyxVQUFVLElBQUUsQ0FBQyxFQUFDO1lBQ3hELE9BQU87U0FDVjtRQUNELElBQUksVUFBVSxHQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekQsSUFBSSxVQUFVLElBQUksSUFBSSxFQUFFO1lBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBWSxRQUFRLGtEQUFZLENBQUMsQ0FBQztTQUNqRDtRQUNELElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkMsVUFBVSxHQUFDLEVBQUUsQ0FBQztRQUNkLEtBQW9CLFVBQVUsRUFBVix5QkFBVSxFQUFWLHdCQUFVLEVBQVYsSUFBVSxFQUFFO1lBQTNCLElBQUksT0FBTyxtQkFBQTtZQUNaLFVBQVUsSUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakU7UUFDRCxJQUFJLFNBQVMsR0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbEQsSUFBRyxJQUFJLElBQUUsU0FBUyxJQUFFLE9BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBRSxVQUFVLEVBQUU7WUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxVQUFVLHNEQUFXLENBQUMsQ0FBQTtZQUNoRCxPQUFPO1NBQ1Y7UUFDRCxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNMLGlCQUFDO0FBQUQsQ0FqQ0EsQUFpQ0MsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb2NvdG9sPXJlcXVpcmUoXCIuL0dhbWVNc2dQcm90b2NvbFwiKTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNc2dEZWNvZGVyICB7XHJcbiAgICBnZXRNc2dDb2RlKG9VaW50OEFycmF5OlVpbnQ4QXJyYXkpOm51bWJlcntcclxuICAgICAgICBpZihvVWludDhBcnJheT09bnVsbHx8b1VpbnQ4QXJyYXkuYnl0ZUxlbmd0aDw0KXtcclxuICAgICAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5Nc2dDb2RlPTA7XHJcbiAgICAgICAgbk1zZ0NvZGV8PShvVWludDhBcnJheVsyXSYweEZGKSA8PDg7XHJcbiAgICAgICAgbk1zZ0NvZGV8PShvVWludDhBcnJheVszXSYweEZGKSA7XHJcblxyXG4gICAgICAgIHJldHVybiBuTXNnQ29kZTtcclxuICAgIH1cclxuXHJcbiAgICBkZWNvZGUobk1zZ0NvZGU6bnVtYmVyLG9VaW50OEFycmF5OlVpbnQ4QXJyYXkpOmFueXtcclxuICAgICAgICBpZihuTXNnQ29kZTwwfHxudWxsPT1vVWludDhBcnJheXx8b1VpbnQ4QXJyYXkuYnl0ZUxlbmd0aDw9MCl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHN0ck1zZ05hbWU9bW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZVtuTXNnQ29kZV07XHJcbiAgICAgICAgaWYgKHN0ck1zZ05hbWUgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgbk1zZ0NvZGU6JHtuTXNnQ29kZX3lr7nlupRtc2flkI3np7DkuI3lrZjlnKhgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IG9UZW1wQXJyYXkgPSBzdHJNc2dOYW1lLnNwbGl0KFwiX1wiKTtcclxuICAgICAgICBzdHJNc2dOYW1lPVwiXCI7XHJcbiAgICAgICAgZm9yIChsZXQgc3RyVGVtcCBvZiBvVGVtcEFycmF5KSB7XHJcbiAgICAgICAgICAgIHN0ck1zZ05hbWUrPXN0clRlbXAuY2hhckF0KDApK3N0clRlbXAuc3Vic3RyKDEpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBvTXNnQ2xheno9bW9kX0dhbWVNc2dQcm9jb3RvbC5tc2dbc3RyTXNnTmFtZV07XHJcbiAgICAgICAgaWYobnVsbD09b01zZ0NsYXp6fHx0eXBlb2Yob01zZ0NsYXp6WydkZWNvZGUnXSkhPVwiZnVuY3Rpb25cIiApe1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgc3RyTXNnTmFtZToke3N0ck1zZ05hbWV9IOayoeacieaJvuWIsOWvueW6lOeahOexu2ApXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG9Nc2dDbGF6ei5kZWNvZGUob1VpbnQ4QXJyYXkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserEntryResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '34a19lm1H9JGbAT609CM1c5', 'UserEntryResultHandler');
// resultHandler/UserEntryResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var WebUtil_1 = require("../script/xiaojingling/WebUtil");
var Common_1 = require("../script/xiaojingling/Common");
var FightScene_1 = require("../script/xiaojingling/FightScene");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserEntryResultHandler = /** @class */ (function () {
    function UserEntryResultHandler() {
    }
    UserEntryResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.heroAvatar + ",id=" + oResult.userId + "\u5165\u573A");
        HeroFactory_1.default.createAsync(oResult.heroAvatar, function (heroNode) {
            if (heroNode == null) {
                return;
            }
            var nMyUserId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            //oResult是后台传的英雄对象，nMyUserId是url地址里写的用户id，oMyHeroComp是通过后台传入的oResult的名称加载出来的预制体
            var oMyHeroComp = heroNode.getComponent(Common_1.default);
            if (oResult.userId == nMyUserId) {
                cc.Canvas.instance.node.getComponent(FightScene_1.default)._oMyHreo = oMyHeroComp;
            }
            cc.Canvas.instance.node.addChild(heroNode);
            // heroNode.x = 300 * Math.random();
            // heroNode.y = 300 * Math.random();
            // heroNode.x = -200;
            // heroNode.y = 0;
            // heroNode.active = true;
            var skeleton = heroNode.getComponent(sp.Skeleton);
            skeleton.setAnimation(1, 'stand', true);
            UserManager_1.default.putMyHeroComp(oResult.userId, oMyHeroComp);
        });
    };
    return UserEntryResultHandler;
}());
exports.default = UserEntryResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlckVudHJ5UmVzdWx0SGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLGtFQUE2RDtBQUM3RCwwREFBcUQ7QUFDckQsd0RBQW1EO0FBQ25ELGdFQUEyRDtBQUMzRCxrRUFBNkQ7QUFFN0Q7SUFBQTtJQTRCQSxDQUFDO0lBM0JHLHVDQUFNLEdBQU4sVUFBTyxPQUErQztRQUNsRCxFQUFFLENBQUMsR0FBRyxDQUFDLHVCQUFNLE9BQU8sQ0FBQyxVQUFVLFlBQU8sT0FBTyxDQUFDLE1BQU0saUJBQUksQ0FBQyxDQUFDO1FBQzFELHFCQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsVUFBQyxRQUFRO1lBQ2pELElBQUcsUUFBUSxJQUFFLElBQUksRUFBQztnQkFDZCxPQUFPO2FBQ1Y7WUFFRCxJQUFJLFNBQVMsR0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0QsK0VBQStFO1lBQy9FLElBQUksV0FBVyxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDO1lBQ2hELElBQUcsT0FBTyxDQUFDLE1BQU0sSUFBRSxTQUFTLEVBQUM7Z0JBQ3pCLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQVUsQ0FBQyxDQUFDLFFBQVEsR0FBQyxXQUFXLENBQUM7YUFDekU7WUFHRCxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNDLG9DQUFvQztZQUNwQyxvQ0FBb0M7WUFDcEMscUJBQXFCO1lBQ3JCLGtCQUFrQjtZQUNsQiwwQkFBMEI7WUFDMUIsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEQsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3hDLHFCQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUMsV0FBVyxDQUFDLENBQUM7UUFDMUQsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUwsNkJBQUM7QUFBRCxDQTVCQSxBQTRCQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vZF9HYW1lTXNnUHJvdG9jb2wgPSByZXF1aXJlKCcuLi9tc2cvR2FtZU1zZ1Byb3RvY29sJyk7XHJcbmltcG9ydCBIZXJvRmFjdG9yeSBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9IZXJvRmFjdG9yeVwiO1xyXG5pbXBvcnQgV2ViVXRpbCBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9XZWJVdGlsXCI7XHJcbmltcG9ydCBDb21tb24gZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvQ29tbW9uXCI7XHJcbmltcG9ydCBGaWdodFNjZW5lIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL0ZpZ2h0U2NlbmVcIjtcclxuaW1wb3J0IFVzZXJNYW5hZ2VyIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL1VzZXJNYW5hZ2VyXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyRW50cnlSZXN1bHRIYW5kbGVyICB7XHJcbiAgICBoYW5kbGUob1Jlc3VsdDptb2RfR2FtZU1zZ1Byb3RvY29sLm1zZy5Vc2VyRW50cnlSZXN1bHQpOnZvaWR7XHJcbiAgICAgICAgY2MubG9nKGDnlKjmiLfvvJoke29SZXN1bHQuaGVyb0F2YXRhcn0saWQ9JHtvUmVzdWx0LnVzZXJJZH3lhaXlnLpgKTtcclxuICAgICAgICBIZXJvRmFjdG9yeS5jcmVhdGVBc3luYyhvUmVzdWx0Lmhlcm9BdmF0YXIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgICAgICBpZihoZXJvTm9kZT09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBuTXlVc2VySWQ9TnVtYmVyLnBhcnNlSW50KFdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcInVzZXJJZFwiKSk7XHJcbiAgICAgICAgICAgIC8vb1Jlc3VsdOaYr+WQjuWPsOS8oOeahOiLsembhOWvueixoe+8jG5NeVVzZXJJZOaYr3VybOWcsOWdgOmHjOWGmeeahOeUqOaIt2lk77yMb015SGVyb0NvbXDmmK/pgJrov4flkI7lj7DkvKDlhaXnmoRvUmVzdWx055qE5ZCN56ew5Yqg6L295Ye65p2l55qE6aKE5Yi25L2TXHJcbiAgICAgICAgICAgIGxldCBvTXlIZXJvQ29tcCA9IGhlcm9Ob2RlLmdldENvbXBvbmVudChDb21tb24pO1xyXG4gICAgICAgICAgICBpZihvUmVzdWx0LnVzZXJJZD09bk15VXNlcklkKXtcclxuICAgICAgICAgICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLmdldENvbXBvbmVudChGaWdodFNjZW5lKS5fb015SHJlbz1vTXlIZXJvQ29tcDtcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLmFkZENoaWxkKGhlcm9Ob2RlKTtcclxuICAgICAgICAgICAgLy8gaGVyb05vZGUueCA9IDMwMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgICAgIC8vIGhlcm9Ob2RlLnkgPSAzMDAgKiBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgICAgICAvLyBoZXJvTm9kZS54ID0gLTIwMDtcclxuICAgICAgICAgICAgLy8gaGVyb05vZGUueSA9IDA7XHJcbiAgICAgICAgICAgIC8vIGhlcm9Ob2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGxldCBza2VsZXRvbiA9IGhlcm9Ob2RlLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCAnc3RhbmQnLCB0cnVlKTtcclxuICAgICAgICAgICAgVXNlck1hbmFnZXIucHV0TXlIZXJvQ29tcChvUmVzdWx0LnVzZXJJZCxvTXlIZXJvQ29tcCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/AllHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9f8efav/TRDiIt8ruVLlakl', 'AllHandler');
// resultHandler/AllHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProtocol = require("../msg/GameMsgProtocol");
var UserEntryResultHandler_1 = require("./UserEntryResultHandler");
var WhoElseIsHereHandler_1 = require("./WhoElseIsHereHandler");
var UserQuitResultHandler_1 = require("./UserQuitResultHandler");
var UserMoveToResultHandler_1 = require("./UserMoveToResultHandler");
var AllHandler = /** @class */ (function () {
    function AllHandler() {
        this._oHandlerMap = {};
        var oMsgCode = mod_GameMsgProtocol.msg.MsgCode;
        this._oHandlerMap[oMsgCode.USER_ENTRY_RESULT] = new UserEntryResultHandler_1.default();
        this._oHandlerMap[oMsgCode.WHO_ELSE_IS_HERE_RESULT] = new WhoElseIsHereHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_MOVE_TO_RESULT] = new UserMoveToResultHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_QUIT_RESULT] = new UserQuitResultHandler_1.default();
    }
    AllHandler.prototype.handle = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || oMsgBody == null) {
            return;
        }
        var oHandler = this._oHandlerMap[nMsgCode];
        if (oHandler == null) {
            cc.error("nMsgCode:" + nMsgCode + "\u627E\u4E0D\u5230\u5BF9\u5E94handler");
            return;
        }
        oHandler.handle(oMsgBody);
    };
    return AllHandler;
}());
exports.default = AllHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcQWxsSGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDREQUErRDtBQUMvRCxtRUFBOEQ7QUFDOUQsK0RBQTBEO0FBQzFELGlFQUE0RDtBQUM1RCxxRUFBZ0U7QUFFaEU7SUFFSTtRQURpQixpQkFBWSxHQUF5QixFQUFFLENBQUM7UUFFckQsSUFBSSxRQUFRLEdBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUM3QyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFDLElBQUksZ0NBQXNCLEVBQUUsQ0FBQztRQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFDLElBQUksOEJBQW9CLEVBQUUsQ0FBQztRQUMvRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFDLElBQUksaUNBQXVCLEVBQUUsQ0FBQztRQUM5RSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFDLElBQUksK0JBQXFCLEVBQUUsQ0FBQztJQUU3RSxDQUFDO0lBQ0QsMkJBQU0sR0FBTixVQUFPLFFBQWUsRUFBQyxRQUFZO1FBQy9CLElBQUcsUUFBUSxHQUFDLENBQUMsSUFBRSxRQUFRLElBQUUsSUFBSSxFQUFDO1lBQzFCLE9BQU87U0FDVjtRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0MsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO1lBQ2xCLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBWSxRQUFRLDBDQUFjLENBQUMsQ0FBQztZQUM3QyxPQUFPO1NBQ1Y7UUFFRCxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFTCxpQkFBQztBQUFELENBdkJBLEFBdUJDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX0dhbWVNc2dQcm90b2NvbCA9IHJlcXVpcmUoJy4uL21zZy9HYW1lTXNnUHJvdG9jb2wnKTtcclxuaW1wb3J0IFVzZXJFbnRyeVJlc3VsdEhhbmRsZXIgZnJvbSAnLi9Vc2VyRW50cnlSZXN1bHRIYW5kbGVyJztcclxuaW1wb3J0IFdob0Vsc2VJc0hlcmVIYW5kbGVyIGZyb20gXCIuL1dob0Vsc2VJc0hlcmVIYW5kbGVyXCI7XHJcbmltcG9ydCBVc2VyUXVpdFJlc3VsdEhhbmRsZXIgZnJvbSBcIi4vVXNlclF1aXRSZXN1bHRIYW5kbGVyXCI7XHJcbmltcG9ydCBVc2VyTW92ZVRvUmVzdWx0SGFuZGxlciBmcm9tIFwiLi9Vc2VyTW92ZVRvUmVzdWx0SGFuZGxlclwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQWxsSGFuZGxlciAge1xyXG4gICAgcHJpdmF0ZSByZWFkb25seSBfb0hhbmRsZXJNYXA6e1tuTXNnQ29kZTpudW1iZXJdOmFueX09e307XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBsZXQgb01zZ0NvZGU9bW9kX0dhbWVNc2dQcm90b2NvbC5tc2cuTXNnQ29kZTtcclxuICAgICAgICB0aGlzLl9vSGFuZGxlck1hcFtvTXNnQ29kZS5VU0VSX0VOVFJZX1JFU1VMVF09bmV3IFVzZXJFbnRyeVJlc3VsdEhhbmRsZXIoKTtcclxuICAgICAgICB0aGlzLl9vSGFuZGxlck1hcFtvTXNnQ29kZS5XSE9fRUxTRV9JU19IRVJFX1JFU1VMVF09bmV3IFdob0Vsc2VJc0hlcmVIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fb0hhbmRsZXJNYXBbb01zZ0NvZGUuVVNFUl9NT1ZFX1RPX1JFU1VMVF09bmV3IFVzZXJNb3ZlVG9SZXN1bHRIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fb0hhbmRsZXJNYXBbb01zZ0NvZGUuVVNFUl9RVUlUX1JFU1VMVF09bmV3IFVzZXJRdWl0UmVzdWx0SGFuZGxlcigpO1xyXG5cclxuICAgIH1cclxuICAgIGhhbmRsZShuTXNnQ29kZTpudW1iZXIsb01zZ0JvZHk6YW55KTp2b2lke1xyXG4gICAgICAgIGlmKG5Nc2dDb2RlPDB8fG9Nc2dCb2R5PT1udWxsKXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgb0hhbmRsZXIgPSB0aGlzLl9vSGFuZGxlck1hcFtuTXNnQ29kZV07XHJcbiAgICAgICAgaWYgKG9IYW5kbGVyID09IG51bGwpIHtcclxuICAgICAgICAgICAgY2MuZXJyb3IoYG5Nc2dDb2RlOiR7bk1zZ0NvZGV95om+5LiN5Yiw5a+55bqUaGFuZGxlcmApO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBvSGFuZGxlci5oYW5kbGUob01zZ0JvZHkpO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/WebUtil.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '05cc91PUd9Kh5kREoGE76Jh', 'WebUtil');
// script/xiaojingling/WebUtil.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var WebUtil = /** @class */ (function () {
    function WebUtil() {
    }
    WebUtil.getQueryParam = function (strName) {
        if (strName == null) {
            return null;
        }
        var oResult = window.location.search.match(new RegExp("[\?\&]" + strName + "=([^\&]+)", "i"));
        if (null == oResult || oResult.length < 1) {
            return null;
        }
        return oResult[1];
    };
    return WebUtil;
}());
exports.default = WebUtil;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXFdlYlV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLG9CQUFvQjtBQUNwQix3RUFBd0U7QUFDeEUsbUJBQW1CO0FBQ25CLGtGQUFrRjtBQUNsRiw4QkFBOEI7QUFDOUIsa0ZBQWtGOztBQUlsRjtJQUNJO0lBQ0EsQ0FBQztJQUVNLHFCQUFhLEdBQXBCLFVBQXFCLE9BQWM7UUFDL0IsSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO1lBQ2pCLE9BQU8sSUFBSSxDQUFDO1NBQ2Y7UUFDRCxJQUFJLE9BQU8sR0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxNQUFNLENBQUMsUUFBUSxHQUFDLE9BQU8sR0FBQyxXQUFXLEVBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUN2RixJQUFHLElBQUksSUFBRSxPQUFPLElBQUUsT0FBTyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUM7WUFDL0IsT0FBTyxJQUFJLENBQUM7U0FDZjtRQUNELE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3RCLENBQUM7SUFJTCxjQUFDO0FBQUQsQ0FqQkEsQUFpQkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmltcG9ydCBBc3luYyBmcm9tIFwiLi9Bc3luY1wiXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXZWJVdGlsIHtcclxuICAgIHByaXZhdGUgY29uc3RydWN0b3IoKSB7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIGdldFF1ZXJ5UGFyYW0oc3RyTmFtZTpzdHJpbmcpOnN0cmluZ3tcclxuICAgICAgICBpZiAoc3RyTmFtZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgb1Jlc3VsdD13aW5kb3cubG9jYXRpb24uc2VhcmNoLm1hdGNoKG5ldyBSZWdFeHAoXCJbXFw/XFwmXVwiK3N0ck5hbWUrXCI9KFteXFwmXSspXCIsXCJpXCIpKTtcclxuICAgICAgICBpZihudWxsPT1vUmVzdWx0fHxvUmVzdWx0Lmxlbmd0aDwxKXtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBvUmVzdWx0WzFdO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/WhoElseIsHereHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '26c6aE+vLVIZIyZI+yQVbXX', 'WhoElseIsHereHandler');
// resultHandler/WhoElseIsHereHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var Common_1 = require("../script/xiaojingling/Common");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var WhoElseIsHereHandler = /** @class */ (function () {
    function WhoElseIsHereHandler() {
    }
    WhoElseIsHereHandler.prototype.handle = function (oResult) {
        var oUserInfoArray = oResult.userInfo;
        var _loop_1 = function (oUserInfo) {
            if (oUserInfo == null) {
                return "continue";
            }
            var heroAvatar = oUserInfo.heroAvatar;
            HeroFactory_1.default.createAsync(heroAvatar, function (heroNode) {
                if (heroNode == null) {
                    return;
                }
                cc.Canvas.instance.node.addChild(heroNode);
                // heroNode.x = 300 * Math.random();
                // heroNode.y = 300 * Math.random();
                // heroNode.x = -200;
                // heroNode.y = 0;
                // heroNode.active = true;
                var skeleton = heroNode.getComponent(sp.Skeleton);
                skeleton.setAnimation(1, 'stand', true);
                UserManager_1.default.putMyHeroComp(oUserInfo.userId, heroNode.getComponent(Common_1.default));
            });
        };
        for (var _i = 0, oUserInfoArray_1 = oUserInfoArray; _i < oUserInfoArray_1.length; _i++) {
            var oUserInfo = oUserInfoArray_1[_i];
            _loop_1(oUserInfo);
        }
    };
    return WhoElseIsHereHandler;
}());
exports.default = WhoElseIsHereHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcV2hvRWxzZUlzSGVyZUhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxrRUFBNkQ7QUFFN0Qsd0RBQW1EO0FBRW5ELGtFQUE2RDtBQUU3RDtJQUFBO0lBMEJBLENBQUM7SUF6QkcscUNBQU0sR0FBTixVQUFPLE9BQW1EO1FBQ3RELElBQUksY0FBYyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7Z0NBQzdCLFNBQVM7WUFDZCxJQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUU7O2FBRXRCO1lBQ0QsSUFBSSxVQUFVLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQztZQUN0QyxxQkFBVyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsVUFBQyxRQUFRO2dCQUN6QyxJQUFHLFFBQVEsSUFBRSxJQUFJLEVBQUM7b0JBQ2QsT0FBTztpQkFDVjtnQkFFRCxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQyxvQ0FBb0M7Z0JBQ3BDLG9DQUFvQztnQkFDcEMscUJBQXFCO2dCQUNyQixrQkFBa0I7Z0JBQ2xCLDBCQUEwQjtnQkFDMUIsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2xELFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEMscUJBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxRQUFRLENBQUMsWUFBWSxDQUFDLGdCQUFNLENBQUMsQ0FBQyxDQUFDO1lBQzlFLENBQUMsQ0FBQyxDQUFDOztRQW5CUCxLQUFzQixVQUFjLEVBQWQsaUNBQWMsRUFBZCw0QkFBYyxFQUFkLElBQWM7WUFBL0IsSUFBSSxTQUFTLHVCQUFBO29CQUFULFNBQVM7U0FvQmpCO0lBQ0wsQ0FBQztJQUVMLDJCQUFDO0FBQUQsQ0ExQkEsQUEwQkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb3RvY29sID0gcmVxdWlyZSgnLi4vbXNnL0dhbWVNc2dQcm90b2NvbCcpO1xyXG5pbXBvcnQgSGVyb0ZhY3RvcnkgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvSGVyb0ZhY3RvcnlcIjtcclxuaW1wb3J0IFdlYlV0aWwgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvV2ViVXRpbFwiO1xyXG5pbXBvcnQgQ29tbW9uIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL0NvbW1vblwiO1xyXG5pbXBvcnQgRmlnaHRTY2VuZSBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9GaWdodFNjZW5lXCI7XHJcbmltcG9ydCBVc2VyTWFuYWdlciBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9Vc2VyTWFuYWdlclwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgV2hvRWxzZUlzSGVyZUhhbmRsZXIgIHtcclxuICAgIGhhbmRsZShvUmVzdWx0Om1vZF9HYW1lTXNnUHJvdG9jb2wubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQpOnZvaWR7XHJcbiAgICAgICAgbGV0IG9Vc2VySW5mb0FycmF5ID0gb1Jlc3VsdC51c2VySW5mbztcclxuICAgICAgICBmb3IgKGxldCBvVXNlckluZm8gb2Ygb1VzZXJJbmZvQXJyYXkpIHtcclxuICAgICAgICAgICAgaWYgKG9Vc2VySW5mbyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgaGVyb0F2YXRhciA9IG9Vc2VySW5mby5oZXJvQXZhdGFyO1xyXG4gICAgICAgICAgICBIZXJvRmFjdG9yeS5jcmVhdGVBc3luYyhoZXJvQXZhdGFyLCAoaGVyb05vZGUpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmKGhlcm9Ob2RlPT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuYWRkQ2hpbGQoaGVyb05vZGUpO1xyXG4gICAgICAgICAgICAgICAgLy8gaGVyb05vZGUueCA9IDMwMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgICAgICAgICAvLyBoZXJvTm9kZS55ID0gMzAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAgICAgICAgIC8vIGhlcm9Ob2RlLnggPSAtMjAwO1xyXG4gICAgICAgICAgICAgICAgLy8gaGVyb05vZGUueSA9IDA7XHJcbiAgICAgICAgICAgICAgICAvLyBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IHNrZWxldG9uID0gaGVyb05vZGUuZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCAnc3RhbmQnLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIFVzZXJNYW5hZ2VyLnB1dE15SGVyb0NvbXAob1VzZXJJbmZvLnVzZXJJZCxoZXJvTm9kZS5nZXRDb21wb25lbnQoQ29tbW9uKSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserMoveToResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '743f3GBFqFEgYbAE+WsIG/e', 'UserMoveToResultHandler');
// resultHandler/UserMoveToResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserMoveToResultHandler = /** @class */ (function () {
    function UserMoveToResultHandler() {
    }
    UserMoveToResultHandler.prototype.handle = function (oResult) {
        if (oResult == null) {
            return;
        }
        var userId = oResult.moveUserId;
        var oHreoComp = UserManager_1.default.getMyHeroComp(userId);
        // let oHreoComp =find();
        oHreoComp.moveTo(oResult.moveToPosX, oResult.moveToPosY);
    };
    return UserMoveToResultHandler;
}());
exports.default = UserMoveToResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlck1vdmVUb1Jlc3VsdEhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxrRUFBNkQ7QUFFN0Q7SUFBQTtJQWNBLENBQUM7SUFiRyx3Q0FBTSxHQUFOLFVBQU8sT0FBZ0Q7UUFDbkQsSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO1lBQ2pCLE9BQU87U0FDVjtRQUNELElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7UUFFaEMsSUFBSSxTQUFTLEdBQUcscUJBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbEQseUJBQXlCO1FBR3pCLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7SUFDM0QsQ0FBQztJQUVMLDhCQUFDO0FBQUQsQ0FkQSxBQWNDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX0dhbWVNc2dQcm90b2NvbCA9IHJlcXVpcmUoJy4uL21zZy9HYW1lTXNnUHJvdG9jb2wnKTtcclxuaW1wb3J0IFVzZXJNYW5hZ2VyIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL1VzZXJNYW5hZ2VyXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyTW92ZVRvUmVzdWx0SGFuZGxlciAge1xyXG4gICAgaGFuZGxlKG9SZXN1bHQ6bW9kX0dhbWVNc2dQcm90b2NvbC5tc2cuVXNlck1vdmVUb1Jlc3VsdCk6dm9pZHtcclxuICAgICAgICBpZiAob1Jlc3VsdCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHVzZXJJZCA9IG9SZXN1bHQubW92ZVVzZXJJZDtcclxuXHJcbiAgICAgICAgbGV0IG9IcmVvQ29tcCA9IFVzZXJNYW5hZ2VyLmdldE15SGVyb0NvbXAodXNlcklkKTtcclxuICAgICAgICAvLyBsZXQgb0hyZW9Db21wID1maW5kKCk7XHJcblxyXG5cclxuICAgICAgICBvSHJlb0NvbXAubW92ZVRvKG9SZXN1bHQubW92ZVRvUG9zWCxvUmVzdWx0Lm1vdmVUb1Bvc1kpXHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserQuitResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e7d6c5P7VBHVa9cf53adggG', 'UserQuitResultHandler');
// resultHandler/UserQuitResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserQuitResultHandler = /** @class */ (function () {
    function UserQuitResultHandler() {
    }
    UserQuitResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.quitUserId + "\u79BB\u573A");
        var myHeroComp = UserManager_1.default.getMyHeroComp(oResult.quitUserId);
    };
    return UserQuitResultHandler;
}());
exports.default = UserQuitResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlclF1aXRSZXN1bHRIYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0Esa0VBQTZEO0FBRzdEO0lBQUE7SUFPQSxDQUFDO0lBTkcsc0NBQU0sR0FBTixVQUFPLE9BQThDO1FBQ2pELEVBQUUsQ0FBQyxHQUFHLENBQUMsdUJBQU0sT0FBTyxDQUFDLFVBQVUsaUJBQUksQ0FBQyxDQUFDO1FBQ3JDLElBQUksVUFBVSxHQUFHLHFCQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUVuRSxDQUFDO0lBRUwsNEJBQUM7QUFBRCxDQVBBLEFBT0MsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb3RvY29sID0gcmVxdWlyZSgnLi4vbXNnL0dhbWVNc2dQcm90b2NvbCcpO1xyXG5pbXBvcnQgVXNlck1hbmFnZXIgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvVXNlck1hbmFnZXJcIjtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyUXVpdFJlc3VsdEhhbmRsZXIgIHtcclxuICAgIGhhbmRsZShvUmVzdWx0Om1vZF9HYW1lTXNnUHJvdG9jb2wubXNnLlVzZXJRdWl0UmVzdWx0KTp2b2lke1xyXG4gICAgICAgIGNjLmxvZyhg55So5oi377yaJHtvUmVzdWx0LnF1aXRVc2VySWR956a75Zy6YCk7XHJcbiAgICAgICAgbGV0IG15SGVyb0NvbXAgPSBVc2VyTWFuYWdlci5nZXRNeUhlcm9Db21wKG9SZXN1bHQucXVpdFVzZXJJZCk7XHJcblxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/UserManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '08b99EkpNdBM6ZRPy2yEff1', 'UserManager');
// script/xiaojingling/UserManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager = /** @class */ (function () {
    function UserManager() {
    }
    UserManager.putMyHeroComp = function (nUserId, oMyHeroComp) {
        UserManager._oMyHeroCompMap[nUserId] = oMyHeroComp;
    };
    UserManager.getMyHeroComp = function (nUserId) {
        return UserManager._oMyHeroCompMap[nUserId];
    };
    UserManager._oMyHeroCompMap = {};
    return UserManager;
}());
exports.default = UserManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXFVzZXJNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7SUFHSTtJQUNBLENBQUM7SUFFTSx5QkFBYSxHQUFwQixVQUFxQixPQUFjLEVBQUMsV0FBa0I7UUFDbEQsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBQyxXQUFXLENBQUM7SUFDckQsQ0FBQztJQUVNLHlCQUFhLEdBQXBCLFVBQXFCLE9BQWM7UUFDL0IsT0FBTyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFYdUIsMkJBQWUsR0FBMkIsRUFBRSxDQUFDO0lBWXpFLGtCQUFDO0NBYkQsQUFhQyxJQUFBO2tCQWJxQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IENvbW1vbiBmcm9tIFwiLi9Db21tb25cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0ICBjbGFzcyBVc2VyTWFuYWdlciB7XHJcbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBfb015SGVyb0NvbXBNYXA6e1tuVXNlcklkOm51bWJlcl06Q29tbW9ufT17fTtcclxuXHJcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBwdXRNeUhlcm9Db21wKG5Vc2VySWQ6bnVtYmVyLG9NeUhlcm9Db21wOkNvbW1vbik6dm9pZHtcclxuICAgICAgICBVc2VyTWFuYWdlci5fb015SGVyb0NvbXBNYXBbblVzZXJJZF09b015SGVyb0NvbXA7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIGdldE15SGVyb0NvbXAoblVzZXJJZDpudW1iZXIpOkNvbW1vbntcclxuICAgICAgICByZXR1cm4gVXNlck1hbmFnZXIuX29NeUhlcm9Db21wTWFwW25Vc2VySWRdO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/GameMsgProtocol.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ba045tgZHNPO4OQ1rgbD/8K', 'GameMsgProtocol');
// msg/GameMsgProtocol.js

/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
"use strict";

exports.__esModule = true;
exports.msg = void 0;

var $protobuf = require("./protobuf"); // Common aliases


var $Reader = $protobuf.Reader,
    $Writer = $protobuf.Writer,
    $util = $protobuf.util; // Exported root namespace

var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

var msg = $root.msg = function () {
  /**
   * Namespace msg.
   * @exports msg
   * @namespace
   */
  var msg = {};
  /**
   * MsgCode enum.
   * @name msg.MsgCode
   * @enum {number}
   * @property {number} USER_ENTRY_CMD=0 USER_ENTRY_CMD value
   * @property {number} USER_ENTRY_RESULT=1 USER_ENTRY_RESULT value
   * @property {number} WHO_ELSE_IS_HERE_CMD=2 WHO_ELSE_IS_HERE_CMD value
   * @property {number} WHO_ELSE_IS_HERE_RESULT=3 WHO_ELSE_IS_HERE_RESULT value
   * @property {number} USER_MOVE_TO_CMD=4 USER_MOVE_TO_CMD value
   * @property {number} USER_MOVE_TO_RESULT=5 USER_MOVE_TO_RESULT value
   * @property {number} USER_QUIT_RESULT=6 USER_QUIT_RESULT value
   * @property {number} USER_STOP_CMD=7 USER_STOP_CMD value
   * @property {number} USER_STOP_RESULT=8 USER_STOP_RESULT value
   * @property {number} USER_ATTK_CMD=9 USER_ATTK_CMD value
   * @property {number} USER_ATTK_RESULT=10 USER_ATTK_RESULT value
   * @property {number} USER_SUBTRACT_HP_RESULT=11 USER_SUBTRACT_HP_RESULT value
   * @property {number} USER_DIE_RESULT=12 USER_DIE_RESULT value
   */

  msg.MsgCode = function () {
    var valuesById = {},
        values = Object.create(valuesById);
    values[valuesById[0] = "USER_ENTRY_CMD"] = 0;
    values[valuesById[1] = "USER_ENTRY_RESULT"] = 1;
    values[valuesById[2] = "WHO_ELSE_IS_HERE_CMD"] = 2;
    values[valuesById[3] = "WHO_ELSE_IS_HERE_RESULT"] = 3;
    values[valuesById[4] = "USER_MOVE_TO_CMD"] = 4;
    values[valuesById[5] = "USER_MOVE_TO_RESULT"] = 5;
    values[valuesById[6] = "USER_QUIT_RESULT"] = 6;
    values[valuesById[7] = "USER_STOP_CMD"] = 7;
    values[valuesById[8] = "USER_STOP_RESULT"] = 8;
    values[valuesById[9] = "USER_ATTK_CMD"] = 9;
    values[valuesById[10] = "USER_ATTK_RESULT"] = 10;
    values[valuesById[11] = "USER_SUBTRACT_HP_RESULT"] = 11;
    values[valuesById[12] = "USER_DIE_RESULT"] = 12;
    return values;
  }();

  msg.UserEntryCmd = function () {
    /**
     * Properties of a UserEntryCmd.
     * @memberof msg
     * @interface IUserEntryCmd
     * @property {number|null} [userId] UserEntryCmd userId
     * @property {string|null} [heroAvatar] UserEntryCmd heroAvatar
     */

    /**
     * Constructs a new UserEntryCmd.
     * @memberof msg
     * @classdesc Represents a UserEntryCmd.
     * @implements IUserEntryCmd
     * @constructor
     * @param {msg.IUserEntryCmd=} [properties] Properties to set
     */
    function UserEntryCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserEntryCmd userId.
     * @member {number} userId
     * @memberof msg.UserEntryCmd
     * @instance
     */


    UserEntryCmd.prototype.userId = 0;
    /**
     * UserEntryCmd heroAvatar.
     * @member {string} heroAvatar
     * @memberof msg.UserEntryCmd
     * @instance
     */

    UserEntryCmd.prototype.heroAvatar = "";
    /**
     * Creates a new UserEntryCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd=} [properties] Properties to set
     * @returns {msg.UserEntryCmd} UserEntryCmd instance
     */

    UserEntryCmd.create = function create(properties) {
      return new UserEntryCmd(properties);
    };
    /**
     * Encodes the specified UserEntryCmd message. Does not implicitly {@link msg.UserEntryCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd} message UserEntryCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.userId);
      if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
      /* id 2, wireType 2 =*/
      18).string(message.heroAvatar);
      return writer;
    };
    /**
     * Encodes the specified UserEntryCmd message, length delimited. Does not implicitly {@link msg.UserEntryCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd} message UserEntryCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserEntryCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserEntryCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserEntryCmd} UserEntryCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserEntryCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.userId = reader.uint32();
            break;

          case 2:
            message.heroAvatar = reader.string();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserEntryCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserEntryCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserEntryCmd} UserEntryCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserEntryCmd message.
     * @function verify
     * @memberof msg.UserEntryCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserEntryCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";
      return null;
    };
    /**
     * Creates a UserEntryCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserEntryCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserEntryCmd} UserEntryCmd
     */


    UserEntryCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserEntryCmd) return object;
      var message = new $root.msg.UserEntryCmd();
      if (object.userId != null) message.userId = object.userId >>> 0;
      if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);
      return message;
    };
    /**
     * Creates a plain object from a UserEntryCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.UserEntryCmd} message UserEntryCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserEntryCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.userId = 0;
        object.heroAvatar = "";
      }

      if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
      return object;
    };
    /**
     * Converts this UserEntryCmd to JSON.
     * @function toJSON
     * @memberof msg.UserEntryCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserEntryCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserEntryCmd;
  }();

  msg.UserEntryResult = function () {
    /**
     * Properties of a UserEntryResult.
     * @memberof msg
     * @interface IUserEntryResult
     * @property {number|null} [userId] UserEntryResult userId
     * @property {string|null} [heroAvatar] UserEntryResult heroAvatar
     */

    /**
     * Constructs a new UserEntryResult.
     * @memberof msg
     * @classdesc Represents a UserEntryResult.
     * @implements IUserEntryResult
     * @constructor
     * @param {msg.IUserEntryResult=} [properties] Properties to set
     */
    function UserEntryResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserEntryResult userId.
     * @member {number} userId
     * @memberof msg.UserEntryResult
     * @instance
     */


    UserEntryResult.prototype.userId = 0;
    /**
     * UserEntryResult heroAvatar.
     * @member {string} heroAvatar
     * @memberof msg.UserEntryResult
     * @instance
     */

    UserEntryResult.prototype.heroAvatar = "";
    /**
     * Creates a new UserEntryResult instance using the specified properties.
     * @function create
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult=} [properties] Properties to set
     * @returns {msg.UserEntryResult} UserEntryResult instance
     */

    UserEntryResult.create = function create(properties) {
      return new UserEntryResult(properties);
    };
    /**
     * Encodes the specified UserEntryResult message. Does not implicitly {@link msg.UserEntryResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult} message UserEntryResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.userId);
      if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
      /* id 2, wireType 2 =*/
      18).string(message.heroAvatar);
      return writer;
    };
    /**
     * Encodes the specified UserEntryResult message, length delimited. Does not implicitly {@link msg.UserEntryResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult} message UserEntryResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserEntryResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserEntryResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserEntryResult} UserEntryResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserEntryResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.userId = reader.uint32();
            break;

          case 2:
            message.heroAvatar = reader.string();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserEntryResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserEntryResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserEntryResult} UserEntryResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserEntryResult message.
     * @function verify
     * @memberof msg.UserEntryResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserEntryResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";
      return null;
    };
    /**
     * Creates a UserEntryResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserEntryResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserEntryResult} UserEntryResult
     */


    UserEntryResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserEntryResult) return object;
      var message = new $root.msg.UserEntryResult();
      if (object.userId != null) message.userId = object.userId >>> 0;
      if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);
      return message;
    };
    /**
     * Creates a plain object from a UserEntryResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.UserEntryResult} message UserEntryResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserEntryResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.userId = 0;
        object.heroAvatar = "";
      }

      if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
      return object;
    };
    /**
     * Converts this UserEntryResult to JSON.
     * @function toJSON
     * @memberof msg.UserEntryResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserEntryResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserEntryResult;
  }();

  msg.WhoElseIsHereCmd = function () {
    /**
     * Properties of a WhoElseIsHereCmd.
     * @memberof msg
     * @interface IWhoElseIsHereCmd
     */

    /**
     * Constructs a new WhoElseIsHereCmd.
     * @memberof msg
     * @classdesc Represents a WhoElseIsHereCmd.
     * @implements IWhoElseIsHereCmd
     * @constructor
     * @param {msg.IWhoElseIsHereCmd=} [properties] Properties to set
     */
    function WhoElseIsHereCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * Creates a new WhoElseIsHereCmd instance using the specified properties.
     * @function create
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd=} [properties] Properties to set
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd instance
     */


    WhoElseIsHereCmd.create = function create(properties) {
      return new WhoElseIsHereCmd(properties);
    };
    /**
     * Encodes the specified WhoElseIsHereCmd message. Does not implicitly {@link msg.WhoElseIsHereCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd} message WhoElseIsHereCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      return writer;
    };
    /**
     * Encodes the specified WhoElseIsHereCmd message, length delimited. Does not implicitly {@link msg.WhoElseIsHereCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd} message WhoElseIsHereCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a WhoElseIsHereCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.WhoElseIsHereCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a WhoElseIsHereCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a WhoElseIsHereCmd message.
     * @function verify
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    WhoElseIsHereCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      return null;
    };
    /**
     * Creates a WhoElseIsHereCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     */


    WhoElseIsHereCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.WhoElseIsHereCmd) return object;
      return new $root.msg.WhoElseIsHereCmd();
    };
    /**
     * Creates a plain object from a WhoElseIsHereCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.WhoElseIsHereCmd} message WhoElseIsHereCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    WhoElseIsHereCmd.toObject = function toObject() {
      return {};
    };
    /**
     * Converts this WhoElseIsHereCmd to JSON.
     * @function toJSON
     * @memberof msg.WhoElseIsHereCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    WhoElseIsHereCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return WhoElseIsHereCmd;
  }();

  msg.WhoElseIsHereResult = function () {
    /**
     * Properties of a WhoElseIsHereResult.
     * @memberof msg
     * @interface IWhoElseIsHereResult
     * @property {Array.<msg.WhoElseIsHereResult.IUserInfo>|null} [userInfo] WhoElseIsHereResult userInfo
     */

    /**
     * Constructs a new WhoElseIsHereResult.
     * @memberof msg
     * @classdesc Represents a WhoElseIsHereResult.
     * @implements IWhoElseIsHereResult
     * @constructor
     * @param {msg.IWhoElseIsHereResult=} [properties] Properties to set
     */
    function WhoElseIsHereResult(properties) {
      this.userInfo = [];
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * WhoElseIsHereResult userInfo.
     * @member {Array.<msg.WhoElseIsHereResult.IUserInfo>} userInfo
     * @memberof msg.WhoElseIsHereResult
     * @instance
     */


    WhoElseIsHereResult.prototype.userInfo = $util.emptyArray;
    /**
     * Creates a new WhoElseIsHereResult instance using the specified properties.
     * @function create
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult=} [properties] Properties to set
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult instance
     */

    WhoElseIsHereResult.create = function create(properties) {
      return new WhoElseIsHereResult(properties);
    };
    /**
     * Encodes the specified WhoElseIsHereResult message. Does not implicitly {@link msg.WhoElseIsHereResult.verify|verify} messages.
     * @function encode
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult} message WhoElseIsHereResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userInfo != null && message.userInfo.length) for (var i = 0; i < message.userInfo.length; ++i) {
        $root.msg.WhoElseIsHereResult.UserInfo.encode(message.userInfo[i], writer.uint32(
        /* id 1, wireType 2 =*/
        10).fork()).ldelim();
      }
      return writer;
    };
    /**
     * Encodes the specified WhoElseIsHereResult message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult} message WhoElseIsHereResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a WhoElseIsHereResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.WhoElseIsHereResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            if (!(message.userInfo && message.userInfo.length)) message.userInfo = [];
            message.userInfo.push($root.msg.WhoElseIsHereResult.UserInfo.decode(reader, reader.uint32()));
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a WhoElseIsHereResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a WhoElseIsHereResult message.
     * @function verify
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    WhoElseIsHereResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";

      if (message.userInfo != null && message.hasOwnProperty("userInfo")) {
        if (!Array.isArray(message.userInfo)) return "userInfo: array expected";

        for (var i = 0; i < message.userInfo.length; ++i) {
          var error = $root.msg.WhoElseIsHereResult.UserInfo.verify(message.userInfo[i]);
          if (error) return "userInfo." + error;
        }
      }

      return null;
    };
    /**
     * Creates a WhoElseIsHereResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     */


    WhoElseIsHereResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.WhoElseIsHereResult) return object;
      var message = new $root.msg.WhoElseIsHereResult();

      if (object.userInfo) {
        if (!Array.isArray(object.userInfo)) throw TypeError(".msg.WhoElseIsHereResult.userInfo: array expected");
        message.userInfo = [];

        for (var i = 0; i < object.userInfo.length; ++i) {
          if (typeof object.userInfo[i] !== "object") throw TypeError(".msg.WhoElseIsHereResult.userInfo: object expected");
          message.userInfo[i] = $root.msg.WhoElseIsHereResult.UserInfo.fromObject(object.userInfo[i]);
        }
      }

      return message;
    };
    /**
     * Creates a plain object from a WhoElseIsHereResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.WhoElseIsHereResult} message WhoElseIsHereResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    WhoElseIsHereResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.arrays || options.defaults) object.userInfo = [];

      if (message.userInfo && message.userInfo.length) {
        object.userInfo = [];

        for (var j = 0; j < message.userInfo.length; ++j) {
          object.userInfo[j] = $root.msg.WhoElseIsHereResult.UserInfo.toObject(message.userInfo[j], options);
        }
      }

      return object;
    };
    /**
     * Converts this WhoElseIsHereResult to JSON.
     * @function toJSON
     * @memberof msg.WhoElseIsHereResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    WhoElseIsHereResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    WhoElseIsHereResult.UserInfo = function () {
      /**
       * Properties of a UserInfo.
       * @memberof msg.WhoElseIsHereResult
       * @interface IUserInfo
       * @property {number|null} [userId] UserInfo userId
       * @property {string|null} [heroAvatar] UserInfo heroAvatar
       * @property {msg.WhoElseIsHereResult.UserInfo.IMoveState|null} [moveState] UserInfo moveState
       */

      /**
       * Constructs a new UserInfo.
       * @memberof msg.WhoElseIsHereResult
       * @classdesc Represents a UserInfo.
       * @implements IUserInfo
       * @constructor
       * @param {msg.WhoElseIsHereResult.IUserInfo=} [properties] Properties to set
       */
      function UserInfo(properties) {
        if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
          if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
        }
      }
      /**
       * UserInfo userId.
       * @member {number} userId
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */


      UserInfo.prototype.userId = 0;
      /**
       * UserInfo heroAvatar.
       * @member {string} heroAvatar
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */

      UserInfo.prototype.heroAvatar = "";
      /**
       * UserInfo moveState.
       * @member {msg.WhoElseIsHereResult.UserInfo.IMoveState|null|undefined} moveState
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */

      UserInfo.prototype.moveState = null;
      /**
       * Creates a new UserInfo instance using the specified properties.
       * @function create
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo=} [properties] Properties to set
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo instance
       */

      UserInfo.create = function create(properties) {
        return new UserInfo(properties);
      };
      /**
       * Encodes the specified UserInfo message. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.verify|verify} messages.
       * @function encode
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo} message UserInfo message or plain object to encode
       * @param {$protobuf.Writer} [writer] Writer to encode to
       * @returns {$protobuf.Writer} Writer
       */


      UserInfo.encode = function encode(message, writer) {
        if (!writer) writer = $Writer.create();
        if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
        /* id 1, wireType 0 =*/
        8).uint32(message.userId);
        if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
        /* id 2, wireType 2 =*/
        18).string(message.heroAvatar);
        if (message.moveState != null && Object.hasOwnProperty.call(message, "moveState")) $root.msg.WhoElseIsHereResult.UserInfo.MoveState.encode(message.moveState, writer.uint32(
        /* id 3, wireType 2 =*/
        26).fork()).ldelim();
        return writer;
      };
      /**
       * Encodes the specified UserInfo message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.verify|verify} messages.
       * @function encodeDelimited
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo} message UserInfo message or plain object to encode
       * @param {$protobuf.Writer} [writer] Writer to encode to
       * @returns {$protobuf.Writer} Writer
       */


      UserInfo.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      /**
       * Decodes a UserInfo message from the specified reader or buffer.
       * @function decode
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
       * @param {number} [length] Message length if known beforehand
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       * @throws {Error} If the payload is not a reader or valid buffer
       * @throws {$protobuf.util.ProtocolError} If required fields are missing
       */


      UserInfo.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
        var end = length === undefined ? reader.len : reader.pos + length,
            message = new $root.msg.WhoElseIsHereResult.UserInfo();

        while (reader.pos < end) {
          var tag = reader.uint32();

          switch (tag >>> 3) {
            case 1:
              message.userId = reader.uint32();
              break;

            case 2:
              message.heroAvatar = reader.string();
              break;

            case 3:
              message.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.decode(reader, reader.uint32());
              break;

            default:
              reader.skipType(tag & 7);
              break;
          }
        }

        return message;
      };
      /**
       * Decodes a UserInfo message from the specified reader or buffer, length delimited.
       * @function decodeDelimited
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       * @throws {Error} If the payload is not a reader or valid buffer
       * @throws {$protobuf.util.ProtocolError} If required fields are missing
       */


      UserInfo.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader)) reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      /**
       * Verifies a UserInfo message.
       * @function verify
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {Object.<string,*>} message Plain object to verify
       * @returns {string|null} `null` if valid, otherwise the reason why it is not
       */


      UserInfo.verify = function verify(message) {
        if (typeof message !== "object" || message === null) return "object expected";
        if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
        if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";

        if (message.moveState != null && message.hasOwnProperty("moveState")) {
          var error = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.verify(message.moveState);
          if (error) return "moveState." + error;
        }

        return null;
      };
      /**
       * Creates a UserInfo message from a plain object. Also converts values to their respective internal types.
       * @function fromObject
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {Object.<string,*>} object Plain object
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       */


      UserInfo.fromObject = function fromObject(object) {
        if (object instanceof $root.msg.WhoElseIsHereResult.UserInfo) return object;
        var message = new $root.msg.WhoElseIsHereResult.UserInfo();
        if (object.userId != null) message.userId = object.userId >>> 0;
        if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);

        if (object.moveState != null) {
          if (typeof object.moveState !== "object") throw TypeError(".msg.WhoElseIsHereResult.UserInfo.moveState: object expected");
          message.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.fromObject(object.moveState);
        }

        return message;
      };
      /**
       * Creates a plain object from a UserInfo message. Also converts values to other types if specified.
       * @function toObject
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.UserInfo} message UserInfo
       * @param {$protobuf.IConversionOptions} [options] Conversion options
       * @returns {Object.<string,*>} Plain object
       */


      UserInfo.toObject = function toObject(message, options) {
        if (!options) options = {};
        var object = {};

        if (options.defaults) {
          object.userId = 0;
          object.heroAvatar = "";
          object.moveState = null;
        }

        if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
        if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
        if (message.moveState != null && message.hasOwnProperty("moveState")) object.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.toObject(message.moveState, options);
        return object;
      };
      /**
       * Converts this UserInfo to JSON.
       * @function toJSON
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       * @returns {Object.<string,*>} JSON object
       */


      UserInfo.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };

      UserInfo.MoveState = function () {
        /**
         * Properties of a MoveState.
         * @memberof msg.WhoElseIsHereResult.UserInfo
         * @interface IMoveState
         * @property {number|null} [fromPosX] MoveState fromPosX
         * @property {number|null} [fromPosY] MoveState fromPosY
         * @property {number|null} [toPosX] MoveState toPosX
         * @property {number|null} [toPosY] MoveState toPosY
         * @property {number|Long|null} [startTime] MoveState startTime
         */

        /**
         * Constructs a new MoveState.
         * @memberof msg.WhoElseIsHereResult.UserInfo
         * @classdesc Represents a MoveState.
         * @implements IMoveState
         * @constructor
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState=} [properties] Properties to set
         */
        function MoveState(properties) {
          if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
            if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
          }
        }
        /**
         * MoveState fromPosX.
         * @member {number} fromPosX
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */


        MoveState.prototype.fromPosX = 0;
        /**
         * MoveState fromPosY.
         * @member {number} fromPosY
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.fromPosY = 0;
        /**
         * MoveState toPosX.
         * @member {number} toPosX
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.toPosX = 0;
        /**
         * MoveState toPosY.
         * @member {number} toPosY
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.toPosY = 0;
        /**
         * MoveState startTime.
         * @member {number|Long} startTime
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.startTime = $util.Long ? $util.Long.fromBits(0, 0, true) : 0;
        /**
         * Creates a new MoveState instance using the specified properties.
         * @function create
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState=} [properties] Properties to set
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState instance
         */

        MoveState.create = function create(properties) {
          return new MoveState(properties);
        };
        /**
         * Encodes the specified MoveState message. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.MoveState.verify|verify} messages.
         * @function encode
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState} message MoveState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */


        MoveState.encode = function encode(message, writer) {
          if (!writer) writer = $Writer.create();
          if (message.fromPosX != null && Object.hasOwnProperty.call(message, "fromPosX")) writer.uint32(
          /* id 1, wireType 5 =*/
          13)["float"](message.fromPosX);
          if (message.fromPosY != null && Object.hasOwnProperty.call(message, "fromPosY")) writer.uint32(
          /* id 2, wireType 5 =*/
          21)["float"](message.fromPosY);
          if (message.toPosX != null && Object.hasOwnProperty.call(message, "toPosX")) writer.uint32(
          /* id 3, wireType 5 =*/
          29)["float"](message.toPosX);
          if (message.toPosY != null && Object.hasOwnProperty.call(message, "toPosY")) writer.uint32(
          /* id 4, wireType 5 =*/
          37)["float"](message.toPosY);
          if (message.startTime != null && Object.hasOwnProperty.call(message, "startTime")) writer.uint32(
          /* id 5, wireType 0 =*/
          40).uint64(message.startTime);
          return writer;
        };
        /**
         * Encodes the specified MoveState message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.MoveState.verify|verify} messages.
         * @function encodeDelimited
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState} message MoveState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */


        MoveState.encodeDelimited = function encodeDelimited(message, writer) {
          return this.encode(message, writer).ldelim();
        };
        /**
         * Decodes a MoveState message from the specified reader or buffer.
         * @function decode
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */


        MoveState.decode = function decode(reader, length) {
          if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
          var end = length === undefined ? reader.len : reader.pos + length,
              message = new $root.msg.WhoElseIsHereResult.UserInfo.MoveState();

          while (reader.pos < end) {
            var tag = reader.uint32();

            switch (tag >>> 3) {
              case 1:
                message.fromPosX = reader["float"]();
                break;

              case 2:
                message.fromPosY = reader["float"]();
                break;

              case 3:
                message.toPosX = reader["float"]();
                break;

              case 4:
                message.toPosY = reader["float"]();
                break;

              case 5:
                message.startTime = reader.uint64();
                break;

              default:
                reader.skipType(tag & 7);
                break;
            }
          }

          return message;
        };
        /**
         * Decodes a MoveState message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */


        MoveState.decodeDelimited = function decodeDelimited(reader) {
          if (!(reader instanceof $Reader)) reader = new $Reader(reader);
          return this.decode(reader, reader.uint32());
        };
        /**
         * Verifies a MoveState message.
         * @function verify
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */


        MoveState.verify = function verify(message) {
          if (typeof message !== "object" || message === null) return "object expected";
          if (message.fromPosX != null && message.hasOwnProperty("fromPosX")) if (typeof message.fromPosX !== "number") return "fromPosX: number expected";
          if (message.fromPosY != null && message.hasOwnProperty("fromPosY")) if (typeof message.fromPosY !== "number") return "fromPosY: number expected";
          if (message.toPosX != null && message.hasOwnProperty("toPosX")) if (typeof message.toPosX !== "number") return "toPosX: number expected";
          if (message.toPosY != null && message.hasOwnProperty("toPosY")) if (typeof message.toPosY !== "number") return "toPosY: number expected";
          if (message.startTime != null && message.hasOwnProperty("startTime")) if (!$util.isInteger(message.startTime) && !(message.startTime && $util.isInteger(message.startTime.low) && $util.isInteger(message.startTime.high))) return "startTime: integer|Long expected";
          return null;
        };
        /**
         * Creates a MoveState message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         */


        MoveState.fromObject = function fromObject(object) {
          if (object instanceof $root.msg.WhoElseIsHereResult.UserInfo.MoveState) return object;
          var message = new $root.msg.WhoElseIsHereResult.UserInfo.MoveState();
          if (object.fromPosX != null) message.fromPosX = Number(object.fromPosX);
          if (object.fromPosY != null) message.fromPosY = Number(object.fromPosY);
          if (object.toPosX != null) message.toPosX = Number(object.toPosX);
          if (object.toPosY != null) message.toPosY = Number(object.toPosY);
          if (object.startTime != null) if ($util.Long) (message.startTime = $util.Long.fromValue(object.startTime)).unsigned = true;else if (typeof object.startTime === "string") message.startTime = parseInt(object.startTime, 10);else if (typeof object.startTime === "number") message.startTime = object.startTime;else if (typeof object.startTime === "object") message.startTime = new $util.LongBits(object.startTime.low >>> 0, object.startTime.high >>> 0).toNumber(true);
          return message;
        };
        /**
         * Creates a plain object from a MoveState message. Also converts values to other types if specified.
         * @function toObject
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.MoveState} message MoveState
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */


        MoveState.toObject = function toObject(message, options) {
          if (!options) options = {};
          var object = {};

          if (options.defaults) {
            object.fromPosX = 0;
            object.fromPosY = 0;
            object.toPosX = 0;
            object.toPosY = 0;

            if ($util.Long) {
              var _long = new $util.Long(0, 0, true);

              object.startTime = options.longs === String ? _long.toString() : options.longs === Number ? _long.toNumber() : _long;
            } else object.startTime = options.longs === String ? "0" : 0;
          }

          if (message.fromPosX != null && message.hasOwnProperty("fromPosX")) object.fromPosX = options.json && !isFinite(message.fromPosX) ? String(message.fromPosX) : message.fromPosX;
          if (message.fromPosY != null && message.hasOwnProperty("fromPosY")) object.fromPosY = options.json && !isFinite(message.fromPosY) ? String(message.fromPosY) : message.fromPosY;
          if (message.toPosX != null && message.hasOwnProperty("toPosX")) object.toPosX = options.json && !isFinite(message.toPosX) ? String(message.toPosX) : message.toPosX;
          if (message.toPosY != null && message.hasOwnProperty("toPosY")) object.toPosY = options.json && !isFinite(message.toPosY) ? String(message.toPosY) : message.toPosY;
          if (message.startTime != null && message.hasOwnProperty("startTime")) if (typeof message.startTime === "number") object.startTime = options.longs === String ? String(message.startTime) : message.startTime;else object.startTime = options.longs === String ? $util.Long.prototype.toString.call(message.startTime) : options.longs === Number ? new $util.LongBits(message.startTime.low >>> 0, message.startTime.high >>> 0).toNumber(true) : message.startTime;
          return object;
        };
        /**
         * Converts this MoveState to JSON.
         * @function toJSON
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         * @returns {Object.<string,*>} JSON object
         */


        MoveState.prototype.toJSON = function toJSON() {
          return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return MoveState;
      }();

      return UserInfo;
    }();

    return WhoElseIsHereResult;
  }();

  msg.UserMoveToCmd = function () {
    /**
     * Properties of a UserMoveToCmd.
     * @memberof msg
     * @interface IUserMoveToCmd
     * @property {number|null} [moveFromPosX] UserMoveToCmd moveFromPosX
     * @property {number|null} [moveFromPosY] UserMoveToCmd moveFromPosY
     * @property {number|null} [moveToPosX] UserMoveToCmd moveToPosX
     * @property {number|null} [moveToPosY] UserMoveToCmd moveToPosY
     */

    /**
     * Constructs a new UserMoveToCmd.
     * @memberof msg
     * @classdesc Represents a UserMoveToCmd.
     * @implements IUserMoveToCmd
     * @constructor
     * @param {msg.IUserMoveToCmd=} [properties] Properties to set
     */
    function UserMoveToCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserMoveToCmd moveFromPosX.
     * @member {number} moveFromPosX
     * @memberof msg.UserMoveToCmd
     * @instance
     */


    UserMoveToCmd.prototype.moveFromPosX = 0;
    /**
     * UserMoveToCmd moveFromPosY.
     * @member {number} moveFromPosY
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveFromPosY = 0;
    /**
     * UserMoveToCmd moveToPosX.
     * @member {number} moveToPosX
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveToPosX = 0;
    /**
     * UserMoveToCmd moveToPosY.
     * @member {number} moveToPosY
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveToPosY = 0;
    /**
     * Creates a new UserMoveToCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd=} [properties] Properties to set
     * @returns {msg.UserMoveToCmd} UserMoveToCmd instance
     */

    UserMoveToCmd.create = function create(properties) {
      return new UserMoveToCmd(properties);
    };
    /**
     * Encodes the specified UserMoveToCmd message. Does not implicitly {@link msg.UserMoveToCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd} message UserMoveToCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.moveFromPosX != null && Object.hasOwnProperty.call(message, "moveFromPosX")) writer.uint32(
      /* id 1, wireType 5 =*/
      13)["float"](message.moveFromPosX);
      if (message.moveFromPosY != null && Object.hasOwnProperty.call(message, "moveFromPosY")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.moveFromPosY);
      if (message.moveToPosX != null && Object.hasOwnProperty.call(message, "moveToPosX")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.moveToPosX);
      if (message.moveToPosY != null && Object.hasOwnProperty.call(message, "moveToPosY")) writer.uint32(
      /* id 4, wireType 5 =*/
      37)["float"](message.moveToPosY);
      return writer;
    };
    /**
     * Encodes the specified UserMoveToCmd message, length delimited. Does not implicitly {@link msg.UserMoveToCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd} message UserMoveToCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserMoveToCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserMoveToCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.moveFromPosX = reader["float"]();
            break;

          case 2:
            message.moveFromPosY = reader["float"]();
            break;

          case 3:
            message.moveToPosX = reader["float"]();
            break;

          case 4:
            message.moveToPosY = reader["float"]();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserMoveToCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserMoveToCmd message.
     * @function verify
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserMoveToCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) if (typeof message.moveFromPosX !== "number") return "moveFromPosX: number expected";
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) if (typeof message.moveFromPosY !== "number") return "moveFromPosY: number expected";
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) if (typeof message.moveToPosX !== "number") return "moveToPosX: number expected";
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) if (typeof message.moveToPosY !== "number") return "moveToPosY: number expected";
      return null;
    };
    /**
     * Creates a UserMoveToCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     */


    UserMoveToCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserMoveToCmd) return object;
      var message = new $root.msg.UserMoveToCmd();
      if (object.moveFromPosX != null) message.moveFromPosX = Number(object.moveFromPosX);
      if (object.moveFromPosY != null) message.moveFromPosY = Number(object.moveFromPosY);
      if (object.moveToPosX != null) message.moveToPosX = Number(object.moveToPosX);
      if (object.moveToPosY != null) message.moveToPosY = Number(object.moveToPosY);
      return message;
    };
    /**
     * Creates a plain object from a UserMoveToCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.UserMoveToCmd} message UserMoveToCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserMoveToCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.moveFromPosX = 0;
        object.moveFromPosY = 0;
        object.moveToPosX = 0;
        object.moveToPosY = 0;
      }

      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) object.moveFromPosX = options.json && !isFinite(message.moveFromPosX) ? String(message.moveFromPosX) : message.moveFromPosX;
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) object.moveFromPosY = options.json && !isFinite(message.moveFromPosY) ? String(message.moveFromPosY) : message.moveFromPosY;
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) object.moveToPosX = options.json && !isFinite(message.moveToPosX) ? String(message.moveToPosX) : message.moveToPosX;
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) object.moveToPosY = options.json && !isFinite(message.moveToPosY) ? String(message.moveToPosY) : message.moveToPosY;
      return object;
    };
    /**
     * Converts this UserMoveToCmd to JSON.
     * @function toJSON
     * @memberof msg.UserMoveToCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserMoveToCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserMoveToCmd;
  }();

  msg.UserMoveToResult = function () {
    /**
     * Properties of a UserMoveToResult.
     * @memberof msg
     * @interface IUserMoveToResult
     * @property {number|null} [moveUserId] UserMoveToResult moveUserId
     * @property {number|null} [moveFromPosX] UserMoveToResult moveFromPosX
     * @property {number|null} [moveFromPosY] UserMoveToResult moveFromPosY
     * @property {number|null} [moveToPosX] UserMoveToResult moveToPosX
     * @property {number|null} [moveToPosY] UserMoveToResult moveToPosY
     * @property {number|Long|null} [moveStartTime] UserMoveToResult moveStartTime
     */

    /**
     * Constructs a new UserMoveToResult.
     * @memberof msg
     * @classdesc Represents a UserMoveToResult.
     * @implements IUserMoveToResult
     * @constructor
     * @param {msg.IUserMoveToResult=} [properties] Properties to set
     */
    function UserMoveToResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserMoveToResult moveUserId.
     * @member {number} moveUserId
     * @memberof msg.UserMoveToResult
     * @instance
     */


    UserMoveToResult.prototype.moveUserId = 0;
    /**
     * UserMoveToResult moveFromPosX.
     * @member {number} moveFromPosX
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveFromPosX = 0;
    /**
     * UserMoveToResult moveFromPosY.
     * @member {number} moveFromPosY
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveFromPosY = 0;
    /**
     * UserMoveToResult moveToPosX.
     * @member {number} moveToPosX
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveToPosX = 0;
    /**
     * UserMoveToResult moveToPosY.
     * @member {number} moveToPosY
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveToPosY = 0;
    /**
     * UserMoveToResult moveStartTime.
     * @member {number|Long} moveStartTime
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveStartTime = $util.Long ? $util.Long.fromBits(0, 0, true) : 0;
    /**
     * Creates a new UserMoveToResult instance using the specified properties.
     * @function create
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult=} [properties] Properties to set
     * @returns {msg.UserMoveToResult} UserMoveToResult instance
     */

    UserMoveToResult.create = function create(properties) {
      return new UserMoveToResult(properties);
    };
    /**
     * Encodes the specified UserMoveToResult message. Does not implicitly {@link msg.UserMoveToResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult} message UserMoveToResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.moveUserId != null && Object.hasOwnProperty.call(message, "moveUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.moveUserId);
      if (message.moveFromPosX != null && Object.hasOwnProperty.call(message, "moveFromPosX")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.moveFromPosX);
      if (message.moveFromPosY != null && Object.hasOwnProperty.call(message, "moveFromPosY")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.moveFromPosY);
      if (message.moveToPosX != null && Object.hasOwnProperty.call(message, "moveToPosX")) writer.uint32(
      /* id 4, wireType 5 =*/
      37)["float"](message.moveToPosX);
      if (message.moveToPosY != null && Object.hasOwnProperty.call(message, "moveToPosY")) writer.uint32(
      /* id 5, wireType 5 =*/
      45)["float"](message.moveToPosY);
      if (message.moveStartTime != null && Object.hasOwnProperty.call(message, "moveStartTime")) writer.uint32(
      /* id 6, wireType 0 =*/
      48).uint64(message.moveStartTime);
      return writer;
    };
    /**
     * Encodes the specified UserMoveToResult message, length delimited. Does not implicitly {@link msg.UserMoveToResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult} message UserMoveToResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserMoveToResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserMoveToResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserMoveToResult} UserMoveToResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserMoveToResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.moveUserId = reader.uint32();
            break;

          case 2:
            message.moveFromPosX = reader["float"]();
            break;

          case 3:
            message.moveFromPosY = reader["float"]();
            break;

          case 4:
            message.moveToPosX = reader["float"]();
            break;

          case 5:
            message.moveToPosY = reader["float"]();
            break;

          case 6:
            message.moveStartTime = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserMoveToResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserMoveToResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserMoveToResult} UserMoveToResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserMoveToResult message.
     * @function verify
     * @memberof msg.UserMoveToResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserMoveToResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.moveUserId != null && message.hasOwnProperty("moveUserId")) if (!$util.isInteger(message.moveUserId)) return "moveUserId: integer expected";
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) if (typeof message.moveFromPosX !== "number") return "moveFromPosX: number expected";
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) if (typeof message.moveFromPosY !== "number") return "moveFromPosY: number expected";
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) if (typeof message.moveToPosX !== "number") return "moveToPosX: number expected";
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) if (typeof message.moveToPosY !== "number") return "moveToPosY: number expected";
      if (message.moveStartTime != null && message.hasOwnProperty("moveStartTime")) if (!$util.isInteger(message.moveStartTime) && !(message.moveStartTime && $util.isInteger(message.moveStartTime.low) && $util.isInteger(message.moveStartTime.high))) return "moveStartTime: integer|Long expected";
      return null;
    };
    /**
     * Creates a UserMoveToResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserMoveToResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserMoveToResult} UserMoveToResult
     */


    UserMoveToResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserMoveToResult) return object;
      var message = new $root.msg.UserMoveToResult();
      if (object.moveUserId != null) message.moveUserId = object.moveUserId >>> 0;
      if (object.moveFromPosX != null) message.moveFromPosX = Number(object.moveFromPosX);
      if (object.moveFromPosY != null) message.moveFromPosY = Number(object.moveFromPosY);
      if (object.moveToPosX != null) message.moveToPosX = Number(object.moveToPosX);
      if (object.moveToPosY != null) message.moveToPosY = Number(object.moveToPosY);
      if (object.moveStartTime != null) if ($util.Long) (message.moveStartTime = $util.Long.fromValue(object.moveStartTime)).unsigned = true;else if (typeof object.moveStartTime === "string") message.moveStartTime = parseInt(object.moveStartTime, 10);else if (typeof object.moveStartTime === "number") message.moveStartTime = object.moveStartTime;else if (typeof object.moveStartTime === "object") message.moveStartTime = new $util.LongBits(object.moveStartTime.low >>> 0, object.moveStartTime.high >>> 0).toNumber(true);
      return message;
    };
    /**
     * Creates a plain object from a UserMoveToResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.UserMoveToResult} message UserMoveToResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserMoveToResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.moveUserId = 0;
        object.moveFromPosX = 0;
        object.moveFromPosY = 0;
        object.moveToPosX = 0;
        object.moveToPosY = 0;

        if ($util.Long) {
          var _long2 = new $util.Long(0, 0, true);

          object.moveStartTime = options.longs === String ? _long2.toString() : options.longs === Number ? _long2.toNumber() : _long2;
        } else object.moveStartTime = options.longs === String ? "0" : 0;
      }

      if (message.moveUserId != null && message.hasOwnProperty("moveUserId")) object.moveUserId = message.moveUserId;
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) object.moveFromPosX = options.json && !isFinite(message.moveFromPosX) ? String(message.moveFromPosX) : message.moveFromPosX;
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) object.moveFromPosY = options.json && !isFinite(message.moveFromPosY) ? String(message.moveFromPosY) : message.moveFromPosY;
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) object.moveToPosX = options.json && !isFinite(message.moveToPosX) ? String(message.moveToPosX) : message.moveToPosX;
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) object.moveToPosY = options.json && !isFinite(message.moveToPosY) ? String(message.moveToPosY) : message.moveToPosY;
      if (message.moveStartTime != null && message.hasOwnProperty("moveStartTime")) if (typeof message.moveStartTime === "number") object.moveStartTime = options.longs === String ? String(message.moveStartTime) : message.moveStartTime;else object.moveStartTime = options.longs === String ? $util.Long.prototype.toString.call(message.moveStartTime) : options.longs === Number ? new $util.LongBits(message.moveStartTime.low >>> 0, message.moveStartTime.high >>> 0).toNumber(true) : message.moveStartTime;
      return object;
    };
    /**
     * Converts this UserMoveToResult to JSON.
     * @function toJSON
     * @memberof msg.UserMoveToResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserMoveToResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserMoveToResult;
  }();

  msg.UserQuitResult = function () {
    /**
     * Properties of a UserQuitResult.
     * @memberof msg
     * @interface IUserQuitResult
     * @property {number|null} [quitUserId] UserQuitResult quitUserId
     */

    /**
     * Constructs a new UserQuitResult.
     * @memberof msg
     * @classdesc Represents a UserQuitResult.
     * @implements IUserQuitResult
     * @constructor
     * @param {msg.IUserQuitResult=} [properties] Properties to set
     */
    function UserQuitResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserQuitResult quitUserId.
     * @member {number} quitUserId
     * @memberof msg.UserQuitResult
     * @instance
     */


    UserQuitResult.prototype.quitUserId = 0;
    /**
     * Creates a new UserQuitResult instance using the specified properties.
     * @function create
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult=} [properties] Properties to set
     * @returns {msg.UserQuitResult} UserQuitResult instance
     */

    UserQuitResult.create = function create(properties) {
      return new UserQuitResult(properties);
    };
    /**
     * Encodes the specified UserQuitResult message. Does not implicitly {@link msg.UserQuitResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult} message UserQuitResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserQuitResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.quitUserId != null && Object.hasOwnProperty.call(message, "quitUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.quitUserId);
      return writer;
    };
    /**
     * Encodes the specified UserQuitResult message, length delimited. Does not implicitly {@link msg.UserQuitResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult} message UserQuitResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserQuitResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserQuitResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserQuitResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserQuitResult} UserQuitResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserQuitResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserQuitResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.quitUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserQuitResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserQuitResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserQuitResult} UserQuitResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserQuitResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserQuitResult message.
     * @function verify
     * @memberof msg.UserQuitResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserQuitResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.quitUserId != null && message.hasOwnProperty("quitUserId")) if (!$util.isInteger(message.quitUserId)) return "quitUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserQuitResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserQuitResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserQuitResult} UserQuitResult
     */


    UserQuitResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserQuitResult) return object;
      var message = new $root.msg.UserQuitResult();
      if (object.quitUserId != null) message.quitUserId = object.quitUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserQuitResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.UserQuitResult} message UserQuitResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserQuitResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.quitUserId = 0;
      if (message.quitUserId != null && message.hasOwnProperty("quitUserId")) object.quitUserId = message.quitUserId;
      return object;
    };
    /**
     * Converts this UserQuitResult to JSON.
     * @function toJSON
     * @memberof msg.UserQuitResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserQuitResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserQuitResult;
  }();

  msg.UserStopCmd = function () {
    /**
     * Properties of a UserStopCmd.
     * @memberof msg
     * @interface IUserStopCmd
     */

    /**
     * Constructs a new UserStopCmd.
     * @memberof msg
     * @classdesc Represents a UserStopCmd.
     * @implements IUserStopCmd
     * @constructor
     * @param {msg.IUserStopCmd=} [properties] Properties to set
     */
    function UserStopCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * Creates a new UserStopCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd=} [properties] Properties to set
     * @returns {msg.UserStopCmd} UserStopCmd instance
     */


    UserStopCmd.create = function create(properties) {
      return new UserStopCmd(properties);
    };
    /**
     * Encodes the specified UserStopCmd message. Does not implicitly {@link msg.UserStopCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd} message UserStopCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      return writer;
    };
    /**
     * Encodes the specified UserStopCmd message, length delimited. Does not implicitly {@link msg.UserStopCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd} message UserStopCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserStopCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserStopCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserStopCmd} UserStopCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserStopCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserStopCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserStopCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserStopCmd} UserStopCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserStopCmd message.
     * @function verify
     * @memberof msg.UserStopCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserStopCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      return null;
    };
    /**
     * Creates a UserStopCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserStopCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserStopCmd} UserStopCmd
     */


    UserStopCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserStopCmd) return object;
      return new $root.msg.UserStopCmd();
    };
    /**
     * Creates a plain object from a UserStopCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.UserStopCmd} message UserStopCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserStopCmd.toObject = function toObject() {
      return {};
    };
    /**
     * Converts this UserStopCmd to JSON.
     * @function toJSON
     * @memberof msg.UserStopCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserStopCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserStopCmd;
  }();

  msg.UserStopResult = function () {
    /**
     * Properties of a UserStopResult.
     * @memberof msg
     * @interface IUserStopResult
     * @property {number|null} [stopUserId] UserStopResult stopUserId
     * @property {number|null} [stopAtPosX] UserStopResult stopAtPosX
     * @property {number|null} [stopAtPosY] UserStopResult stopAtPosY
     */

    /**
     * Constructs a new UserStopResult.
     * @memberof msg
     * @classdesc Represents a UserStopResult.
     * @implements IUserStopResult
     * @constructor
     * @param {msg.IUserStopResult=} [properties] Properties to set
     */
    function UserStopResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserStopResult stopUserId.
     * @member {number} stopUserId
     * @memberof msg.UserStopResult
     * @instance
     */


    UserStopResult.prototype.stopUserId = 0;
    /**
     * UserStopResult stopAtPosX.
     * @member {number} stopAtPosX
     * @memberof msg.UserStopResult
     * @instance
     */

    UserStopResult.prototype.stopAtPosX = 0;
    /**
     * UserStopResult stopAtPosY.
     * @member {number} stopAtPosY
     * @memberof msg.UserStopResult
     * @instance
     */

    UserStopResult.prototype.stopAtPosY = 0;
    /**
     * Creates a new UserStopResult instance using the specified properties.
     * @function create
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult=} [properties] Properties to set
     * @returns {msg.UserStopResult} UserStopResult instance
     */

    UserStopResult.create = function create(properties) {
      return new UserStopResult(properties);
    };
    /**
     * Encodes the specified UserStopResult message. Does not implicitly {@link msg.UserStopResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult} message UserStopResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.stopUserId != null && Object.hasOwnProperty.call(message, "stopUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.stopUserId);
      if (message.stopAtPosX != null && Object.hasOwnProperty.call(message, "stopAtPosX")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.stopAtPosX);
      if (message.stopAtPosY != null && Object.hasOwnProperty.call(message, "stopAtPosY")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.stopAtPosY);
      return writer;
    };
    /**
     * Encodes the specified UserStopResult message, length delimited. Does not implicitly {@link msg.UserStopResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult} message UserStopResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserStopResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserStopResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserStopResult} UserStopResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserStopResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.stopUserId = reader.uint32();
            break;

          case 2:
            message.stopAtPosX = reader["float"]();
            break;

          case 3:
            message.stopAtPosY = reader["float"]();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserStopResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserStopResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserStopResult} UserStopResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserStopResult message.
     * @function verify
     * @memberof msg.UserStopResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserStopResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.stopUserId != null && message.hasOwnProperty("stopUserId")) if (!$util.isInteger(message.stopUserId)) return "stopUserId: integer expected";
      if (message.stopAtPosX != null && message.hasOwnProperty("stopAtPosX")) if (typeof message.stopAtPosX !== "number") return "stopAtPosX: number expected";
      if (message.stopAtPosY != null && message.hasOwnProperty("stopAtPosY")) if (typeof message.stopAtPosY !== "number") return "stopAtPosY: number expected";
      return null;
    };
    /**
     * Creates a UserStopResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserStopResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserStopResult} UserStopResult
     */


    UserStopResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserStopResult) return object;
      var message = new $root.msg.UserStopResult();
      if (object.stopUserId != null) message.stopUserId = object.stopUserId >>> 0;
      if (object.stopAtPosX != null) message.stopAtPosX = Number(object.stopAtPosX);
      if (object.stopAtPosY != null) message.stopAtPosY = Number(object.stopAtPosY);
      return message;
    };
    /**
     * Creates a plain object from a UserStopResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.UserStopResult} message UserStopResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserStopResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.stopUserId = 0;
        object.stopAtPosX = 0;
        object.stopAtPosY = 0;
      }

      if (message.stopUserId != null && message.hasOwnProperty("stopUserId")) object.stopUserId = message.stopUserId;
      if (message.stopAtPosX != null && message.hasOwnProperty("stopAtPosX")) object.stopAtPosX = options.json && !isFinite(message.stopAtPosX) ? String(message.stopAtPosX) : message.stopAtPosX;
      if (message.stopAtPosY != null && message.hasOwnProperty("stopAtPosY")) object.stopAtPosY = options.json && !isFinite(message.stopAtPosY) ? String(message.stopAtPosY) : message.stopAtPosY;
      return object;
    };
    /**
     * Converts this UserStopResult to JSON.
     * @function toJSON
     * @memberof msg.UserStopResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserStopResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserStopResult;
  }();

  msg.UserAttkCmd = function () {
    /**
     * Properties of a UserAttkCmd.
     * @memberof msg
     * @interface IUserAttkCmd
     * @property {number|null} [targetUserId] UserAttkCmd targetUserId
     */

    /**
     * Constructs a new UserAttkCmd.
     * @memberof msg
     * @classdesc Represents a UserAttkCmd.
     * @implements IUserAttkCmd
     * @constructor
     * @param {msg.IUserAttkCmd=} [properties] Properties to set
     */
    function UserAttkCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserAttkCmd targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserAttkCmd
     * @instance
     */


    UserAttkCmd.prototype.targetUserId = 0;
    /**
     * Creates a new UserAttkCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd=} [properties] Properties to set
     * @returns {msg.UserAttkCmd} UserAttkCmd instance
     */

    UserAttkCmd.create = function create(properties) {
      return new UserAttkCmd(properties);
    };
    /**
     * Encodes the specified UserAttkCmd message. Does not implicitly {@link msg.UserAttkCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd} message UserAttkCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserAttkCmd message, length delimited. Does not implicitly {@link msg.UserAttkCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd} message UserAttkCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserAttkCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserAttkCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserAttkCmd} UserAttkCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserAttkCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserAttkCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserAttkCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserAttkCmd} UserAttkCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserAttkCmd message.
     * @function verify
     * @memberof msg.UserAttkCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserAttkCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserAttkCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserAttkCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserAttkCmd} UserAttkCmd
     */


    UserAttkCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserAttkCmd) return object;
      var message = new $root.msg.UserAttkCmd();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserAttkCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.UserAttkCmd} message UserAttkCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserAttkCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.targetUserId = 0;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserAttkCmd to JSON.
     * @function toJSON
     * @memberof msg.UserAttkCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserAttkCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserAttkCmd;
  }();

  msg.UserAttkResult = function () {
    /**
     * Properties of a UserAttkResult.
     * @memberof msg
     * @interface IUserAttkResult
     * @property {number|null} [attkUserId] UserAttkResult attkUserId
     * @property {number|null} [targetUserId] UserAttkResult targetUserId
     */

    /**
     * Constructs a new UserAttkResult.
     * @memberof msg
     * @classdesc Represents a UserAttkResult.
     * @implements IUserAttkResult
     * @constructor
     * @param {msg.IUserAttkResult=} [properties] Properties to set
     */
    function UserAttkResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserAttkResult attkUserId.
     * @member {number} attkUserId
     * @memberof msg.UserAttkResult
     * @instance
     */


    UserAttkResult.prototype.attkUserId = 0;
    /**
     * UserAttkResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserAttkResult
     * @instance
     */

    UserAttkResult.prototype.targetUserId = 0;
    /**
     * Creates a new UserAttkResult instance using the specified properties.
     * @function create
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult=} [properties] Properties to set
     * @returns {msg.UserAttkResult} UserAttkResult instance
     */

    UserAttkResult.create = function create(properties) {
      return new UserAttkResult(properties);
    };
    /**
     * Encodes the specified UserAttkResult message. Does not implicitly {@link msg.UserAttkResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult} message UserAttkResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.attkUserId != null && Object.hasOwnProperty.call(message, "attkUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.attkUserId);
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 2, wireType 0 =*/
      16).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserAttkResult message, length delimited. Does not implicitly {@link msg.UserAttkResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult} message UserAttkResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserAttkResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserAttkResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserAttkResult} UserAttkResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserAttkResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.attkUserId = reader.uint32();
            break;

          case 2:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserAttkResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserAttkResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserAttkResult} UserAttkResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserAttkResult message.
     * @function verify
     * @memberof msg.UserAttkResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserAttkResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.attkUserId != null && message.hasOwnProperty("attkUserId")) if (!$util.isInteger(message.attkUserId)) return "attkUserId: integer expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserAttkResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserAttkResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserAttkResult} UserAttkResult
     */


    UserAttkResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserAttkResult) return object;
      var message = new $root.msg.UserAttkResult();
      if (object.attkUserId != null) message.attkUserId = object.attkUserId >>> 0;
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserAttkResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.UserAttkResult} message UserAttkResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserAttkResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.attkUserId = 0;
        object.targetUserId = 0;
      }

      if (message.attkUserId != null && message.hasOwnProperty("attkUserId")) object.attkUserId = message.attkUserId;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserAttkResult to JSON.
     * @function toJSON
     * @memberof msg.UserAttkResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserAttkResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserAttkResult;
  }();

  msg.UserSubtractHpResult = function () {
    /**
     * Properties of a UserSubtractHpResult.
     * @memberof msg
     * @interface IUserSubtractHpResult
     * @property {number|null} [targetUserId] UserSubtractHpResult targetUserId
     * @property {number|null} [subtractHp] UserSubtractHpResult subtractHp
     */

    /**
     * Constructs a new UserSubtractHpResult.
     * @memberof msg
     * @classdesc Represents a UserSubtractHpResult.
     * @implements IUserSubtractHpResult
     * @constructor
     * @param {msg.IUserSubtractHpResult=} [properties] Properties to set
     */
    function UserSubtractHpResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserSubtractHpResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserSubtractHpResult
     * @instance
     */


    UserSubtractHpResult.prototype.targetUserId = 0;
    /**
     * UserSubtractHpResult subtractHp.
     * @member {number} subtractHp
     * @memberof msg.UserSubtractHpResult
     * @instance
     */

    UserSubtractHpResult.prototype.subtractHp = 0;
    /**
     * Creates a new UserSubtractHpResult instance using the specified properties.
     * @function create
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult=} [properties] Properties to set
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult instance
     */

    UserSubtractHpResult.create = function create(properties) {
      return new UserSubtractHpResult(properties);
    };
    /**
     * Encodes the specified UserSubtractHpResult message. Does not implicitly {@link msg.UserSubtractHpResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult} message UserSubtractHpResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserSubtractHpResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      if (message.subtractHp != null && Object.hasOwnProperty.call(message, "subtractHp")) writer.uint32(
      /* id 2, wireType 0 =*/
      16).uint32(message.subtractHp);
      return writer;
    };
    /**
     * Encodes the specified UserSubtractHpResult message, length delimited. Does not implicitly {@link msg.UserSubtractHpResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult} message UserSubtractHpResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserSubtractHpResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserSubtractHpResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserSubtractHpResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserSubtractHpResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          case 2:
            message.subtractHp = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserSubtractHpResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserSubtractHpResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserSubtractHpResult message.
     * @function verify
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserSubtractHpResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      if (message.subtractHp != null && message.hasOwnProperty("subtractHp")) if (!$util.isInteger(message.subtractHp)) return "subtractHp: integer expected";
      return null;
    };
    /**
     * Creates a UserSubtractHpResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     */


    UserSubtractHpResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserSubtractHpResult) return object;
      var message = new $root.msg.UserSubtractHpResult();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      if (object.subtractHp != null) message.subtractHp = object.subtractHp >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserSubtractHpResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.UserSubtractHpResult} message UserSubtractHpResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserSubtractHpResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.targetUserId = 0;
        object.subtractHp = 0;
      }

      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      if (message.subtractHp != null && message.hasOwnProperty("subtractHp")) object.subtractHp = message.subtractHp;
      return object;
    };
    /**
     * Converts this UserSubtractHpResult to JSON.
     * @function toJSON
     * @memberof msg.UserSubtractHpResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserSubtractHpResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserSubtractHpResult;
  }();

  msg.UserDieResult = function () {
    /**
     * Properties of a UserDieResult.
     * @memberof msg
     * @interface IUserDieResult
     * @property {number|null} [targetUserId] UserDieResult targetUserId
     */

    /**
     * Constructs a new UserDieResult.
     * @memberof msg
     * @classdesc Represents a UserDieResult.
     * @implements IUserDieResult
     * @constructor
     * @param {msg.IUserDieResult=} [properties] Properties to set
     */
    function UserDieResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserDieResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserDieResult
     * @instance
     */


    UserDieResult.prototype.targetUserId = 0;
    /**
     * Creates a new UserDieResult instance using the specified properties.
     * @function create
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult=} [properties] Properties to set
     * @returns {msg.UserDieResult} UserDieResult instance
     */

    UserDieResult.create = function create(properties) {
      return new UserDieResult(properties);
    };
    /**
     * Encodes the specified UserDieResult message. Does not implicitly {@link msg.UserDieResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult} message UserDieResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserDieResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserDieResult message, length delimited. Does not implicitly {@link msg.UserDieResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult} message UserDieResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserDieResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserDieResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserDieResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserDieResult} UserDieResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserDieResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserDieResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserDieResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserDieResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserDieResult} UserDieResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserDieResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserDieResult message.
     * @function verify
     * @memberof msg.UserDieResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserDieResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserDieResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserDieResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserDieResult} UserDieResult
     */


    UserDieResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserDieResult) return object;
      var message = new $root.msg.UserDieResult();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserDieResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.UserDieResult} message UserDieResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserDieResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.targetUserId = 0;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserDieResult to JSON.
     * @function toJSON
     * @memberof msg.UserDieResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserDieResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserDieResult;
  }();

  return msg;
}();

exports.msg = msg;
module.exports = $root;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxHYW1lTXNnUHJvdG9jb2wuanMiXSwibmFtZXMiOlsiJHByb3RvYnVmIiwicmVxdWlyZSIsIiRSZWFkZXIiLCJSZWFkZXIiLCIkV3JpdGVyIiwiV3JpdGVyIiwiJHV0aWwiLCJ1dGlsIiwiJHJvb3QiLCJyb290cyIsIm1zZyIsIk1zZ0NvZGUiLCJ2YWx1ZXNCeUlkIiwidmFsdWVzIiwiT2JqZWN0IiwiY3JlYXRlIiwiVXNlckVudHJ5Q21kIiwicHJvcGVydGllcyIsImtleXMiLCJpIiwibGVuZ3RoIiwicHJvdG90eXBlIiwidXNlcklkIiwiaGVyb0F2YXRhciIsImVuY29kZSIsIm1lc3NhZ2UiLCJ3cml0ZXIiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJ1aW50MzIiLCJzdHJpbmciLCJlbmNvZGVEZWxpbWl0ZWQiLCJsZGVsaW0iLCJkZWNvZGUiLCJyZWFkZXIiLCJlbmQiLCJ1bmRlZmluZWQiLCJsZW4iLCJwb3MiLCJ0YWciLCJza2lwVHlwZSIsImRlY29kZURlbGltaXRlZCIsInZlcmlmeSIsImlzSW50ZWdlciIsImlzU3RyaW5nIiwiZnJvbU9iamVjdCIsIm9iamVjdCIsIlN0cmluZyIsInRvT2JqZWN0Iiwib3B0aW9ucyIsImRlZmF1bHRzIiwidG9KU09OIiwiY29uc3RydWN0b3IiLCJ0b0pTT05PcHRpb25zIiwiVXNlckVudHJ5UmVzdWx0IiwiV2hvRWxzZUlzSGVyZUNtZCIsIldob0Vsc2VJc0hlcmVSZXN1bHQiLCJ1c2VySW5mbyIsImVtcHR5QXJyYXkiLCJVc2VySW5mbyIsImZvcmsiLCJwdXNoIiwiQXJyYXkiLCJpc0FycmF5IiwiZXJyb3IiLCJUeXBlRXJyb3IiLCJhcnJheXMiLCJqIiwibW92ZVN0YXRlIiwiTW92ZVN0YXRlIiwiZnJvbVBvc1giLCJmcm9tUG9zWSIsInRvUG9zWCIsInRvUG9zWSIsInN0YXJ0VGltZSIsIkxvbmciLCJmcm9tQml0cyIsInVpbnQ2NCIsImxvdyIsImhpZ2giLCJOdW1iZXIiLCJmcm9tVmFsdWUiLCJ1bnNpZ25lZCIsInBhcnNlSW50IiwiTG9uZ0JpdHMiLCJ0b051bWJlciIsImxvbmciLCJsb25ncyIsInRvU3RyaW5nIiwianNvbiIsImlzRmluaXRlIiwiVXNlck1vdmVUb0NtZCIsIm1vdmVGcm9tUG9zWCIsIm1vdmVGcm9tUG9zWSIsIm1vdmVUb1Bvc1giLCJtb3ZlVG9Qb3NZIiwiVXNlck1vdmVUb1Jlc3VsdCIsIm1vdmVVc2VySWQiLCJtb3ZlU3RhcnRUaW1lIiwiVXNlclF1aXRSZXN1bHQiLCJxdWl0VXNlcklkIiwiVXNlclN0b3BDbWQiLCJVc2VyU3RvcFJlc3VsdCIsInN0b3BVc2VySWQiLCJzdG9wQXRQb3NYIiwic3RvcEF0UG9zWSIsIlVzZXJBdHRrQ21kIiwidGFyZ2V0VXNlcklkIiwiVXNlckF0dGtSZXN1bHQiLCJhdHRrVXNlcklkIiwiVXNlclN1YnRyYWN0SHBSZXN1bHQiLCJzdWJ0cmFjdEhwIiwiVXNlckRpZVJlc3VsdCIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7Ozs7O0FBRUEsSUFBSUEsU0FBUyxHQUFHQyxPQUFPLENBQUMsWUFBRCxDQUF2QixFQUVBOzs7QUFDQSxJQUFNQyxPQUFPLEdBQUdGLFNBQVMsQ0FBQ0csTUFBMUI7QUFBQSxJQUFrQ0MsT0FBTyxHQUFHSixTQUFTLENBQUNLLE1BQXREO0FBQUEsSUFBOERDLEtBQUssR0FBR04sU0FBUyxDQUFDTyxJQUFoRixFQUVBOztBQUNBLElBQU1DLEtBQUssR0FBR1IsU0FBUyxDQUFDUyxLQUFWLENBQWdCLFNBQWhCLE1BQStCVCxTQUFTLENBQUNTLEtBQVYsQ0FBZ0IsU0FBaEIsSUFBNkIsRUFBNUQsQ0FBZDs7QUFFTyxJQUFNQyxHQUFHLEdBQUdGLEtBQUssQ0FBQ0UsR0FBTixHQUFhLFlBQU07QUFFbEM7Ozs7O0FBS0EsTUFBTUEsR0FBRyxHQUFHLEVBQVo7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQUEsRUFBQUEsR0FBRyxDQUFDQyxPQUFKLEdBQWUsWUFBVztBQUN0QixRQUFNQyxVQUFVLEdBQUcsRUFBbkI7QUFBQSxRQUF1QkMsTUFBTSxHQUFHQyxNQUFNLENBQUNDLE1BQVAsQ0FBY0gsVUFBZCxDQUFoQztBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0IsZ0JBQWpCLENBQU4sR0FBMkMsQ0FBM0M7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLG1CQUFqQixDQUFOLEdBQThDLENBQTlDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixzQkFBakIsQ0FBTixHQUFpRCxDQUFqRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0IseUJBQWpCLENBQU4sR0FBb0QsQ0FBcEQ7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGtCQUFqQixDQUFOLEdBQTZDLENBQTdDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixxQkFBakIsQ0FBTixHQUFnRCxDQUFoRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0Isa0JBQWpCLENBQU4sR0FBNkMsQ0FBN0M7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGVBQWpCLENBQU4sR0FBMEMsQ0FBMUM7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGtCQUFqQixDQUFOLEdBQTZDLENBQTdDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixlQUFqQixDQUFOLEdBQTBDLENBQTFDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLEVBQUQsQ0FBVixHQUFpQixrQkFBbEIsQ0FBTixHQUE4QyxFQUE5QztBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxFQUFELENBQVYsR0FBaUIseUJBQWxCLENBQU4sR0FBcUQsRUFBckQ7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsRUFBRCxDQUFWLEdBQWlCLGlCQUFsQixDQUFOLEdBQTZDLEVBQTdDO0FBQ0EsV0FBT0MsTUFBUDtBQUNILEdBaEJhLEVBQWQ7O0FBa0JBSCxFQUFBQSxHQUFHLENBQUNNLFlBQUosR0FBb0IsWUFBVztBQUUzQjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxZQUFULENBQXNCQyxVQUF0QixFQUFrQztBQUM5QixVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFILElBQUFBLFlBQVksQ0FBQ0ssU0FBYixDQUF1QkMsTUFBdkIsR0FBZ0MsQ0FBaEM7QUFFQTs7Ozs7OztBQU1BTixJQUFBQSxZQUFZLENBQUNLLFNBQWIsQ0FBdUJFLFVBQXZCLEdBQW9DLEVBQXBDO0FBRUE7Ozs7Ozs7OztBQVFBUCxJQUFBQSxZQUFZLENBQUNELE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDOUMsYUFBTyxJQUFJRCxZQUFKLENBQWlCQyxVQUFqQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBRCxJQUFBQSxZQUFZLENBQUNRLE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ25ELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixhQUFPRyxNQUFQO0FBQ0gsS0FSRDtBQVVBOzs7Ozs7Ozs7OztBQVNBVixJQUFBQSxZQUFZLENBQUNlLGVBQWIsR0FBK0IsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3JFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBaEIsSUFBQUEsWUFBWSxDQUFDaUIsTUFBYixHQUFzQixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDbEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVTSxZQUFkLEVBQTdFOztBQUNBLGFBQU9rQixNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ0gsTUFBUixHQUFpQlksTUFBTSxDQUFDTCxNQUFQLEVBQWpCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQlcsTUFBTSxDQUFDSixNQUFQLEVBQXJCO0FBQ0E7O0FBQ0o7QUFDSUksWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQVRKO0FBV0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7Ozs7QUFVQVQsSUFBQUEsWUFBWSxDQUFDeUIsZUFBYixHQUErQixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM1RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUFiLElBQUFBLFlBQVksQ0FBQzBCLE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzNDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQkcsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ0gsTUFBeEIsQ0FBTCxFQUNJLE9BQU8sMEJBQVA7QUFDUixVQUFJRyxPQUFPLENBQUNGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3NDLFFBQU4sQ0FBZW5CLE9BQU8sQ0FBQ0YsVUFBdkIsQ0FBTCxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVZEO0FBWUE7Ozs7Ozs7Ozs7QUFRQVAsSUFBQUEsWUFBWSxDQUFDNkIsVUFBYixHQUEwQixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNsRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVU0sWUFBaEMsRUFDSSxPQUFPOEIsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVTSxZQUFkLEVBQWQ7QUFDQSxVQUFJOEIsTUFBTSxDQUFDeEIsTUFBUCxJQUFpQixJQUFyQixFQUNJRyxPQUFPLENBQUNILE1BQVIsR0FBaUJ3QixNQUFNLENBQUN4QixNQUFQLEtBQWtCLENBQW5DO0FBQ0osVUFBSXdCLE1BQU0sQ0FBQ3ZCLFVBQVAsSUFBcUIsSUFBekIsRUFDSUUsT0FBTyxDQUFDRixVQUFSLEdBQXFCd0IsTUFBTSxDQUFDRCxNQUFNLENBQUN2QixVQUFSLENBQTNCO0FBQ0osYUFBT0UsT0FBUDtBQUNILEtBVEQ7QUFXQTs7Ozs7Ozs7Ozs7QUFTQVQsSUFBQUEsWUFBWSxDQUFDZ0MsUUFBYixHQUF3QixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUN4RCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3hCLE1BQVAsR0FBZ0IsQ0FBaEI7QUFDQXdCLFFBQUFBLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0IsRUFBcEI7QUFDSDs7QUFDRCxVQUFJRSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJbUIsTUFBTSxDQUFDeEIsTUFBUCxHQUFnQkcsT0FBTyxDQUFDSCxNQUF4QjtBQUNKLFVBQUlHLE9BQU8sQ0FBQ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QkUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUN2QixVQUFQLEdBQW9CRSxPQUFPLENBQUNGLFVBQTVCO0FBQ0osYUFBT3VCLE1BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7OztBQU9BOUIsSUFBQUEsWUFBWSxDQUFDSyxTQUFiLENBQXVCOEIsTUFBdkIsR0FBZ0MsU0FBU0EsTUFBVCxHQUFrQjtBQUM5QyxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPckMsWUFBUDtBQUNILEdBaE5rQixFQUFuQjs7QUFrTkFOLEVBQUFBLEdBQUcsQ0FBQzRDLGVBQUosR0FBdUIsWUFBVztBQUU5Qjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxlQUFULENBQXlCckMsVUFBekIsRUFBcUM7QUFDakMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BbUMsSUFBQUEsZUFBZSxDQUFDakMsU0FBaEIsQ0FBMEJDLE1BQTFCLEdBQW1DLENBQW5DO0FBRUE7Ozs7Ozs7QUFNQWdDLElBQUFBLGVBQWUsQ0FBQ2pDLFNBQWhCLENBQTBCRSxVQUExQixHQUF1QyxFQUF2QztBQUVBOzs7Ozs7Ozs7QUFRQStCLElBQUFBLGVBQWUsQ0FBQ3ZDLE1BQWhCLEdBQXlCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2pELGFBQU8sSUFBSXFDLGVBQUosQ0FBb0JyQyxVQUFwQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBcUMsSUFBQUEsZUFBZSxDQUFDOUIsTUFBaEIsR0FBeUIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ3RELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixhQUFPRyxNQUFQO0FBQ0gsS0FSRDtBQVVBOzs7Ozs7Ozs7OztBQVNBNEIsSUFBQUEsZUFBZSxDQUFDdkIsZUFBaEIsR0FBa0MsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3hFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBc0IsSUFBQUEsZUFBZSxDQUFDckIsTUFBaEIsR0FBeUIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3JELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVTRDLGVBQWQsRUFBN0U7O0FBQ0EsYUFBT3BCLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDSCxNQUFSLEdBQWlCWSxNQUFNLENBQUNMLE1BQVAsRUFBakI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSUosWUFBQUEsT0FBTyxDQUFDRixVQUFSLEdBQXFCVyxNQUFNLENBQUNKLE1BQVAsRUFBckI7QUFDQTs7QUFDSjtBQUNJSSxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBVEo7QUFXSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FuQkQ7QUFxQkE7Ozs7Ozs7Ozs7OztBQVVBNkIsSUFBQUEsZUFBZSxDQUFDYixlQUFoQixHQUFrQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUMvRCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUF5QixJQUFBQSxlQUFlLENBQUNaLE1BQWhCLEdBQXlCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM5QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNILE1BQXhCLENBQUwsRUFDSSxPQUFPLDBCQUFQO0FBQ1IsVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNzQyxRQUFOLENBQWVuQixPQUFPLENBQUNGLFVBQXZCLENBQUwsRUFDSSxPQUFPLDZCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FWRDtBQVlBOzs7Ozs7Ozs7O0FBUUErQixJQUFBQSxlQUFlLENBQUNULFVBQWhCLEdBQTZCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ3JELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVNEMsZUFBaEMsRUFDSSxPQUFPUixNQUFQO0FBQ0osVUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU0QyxlQUFkLEVBQWQ7QUFDQSxVQUFJUixNQUFNLENBQUN4QixNQUFQLElBQWlCLElBQXJCLEVBQ0lHLE9BQU8sQ0FBQ0gsTUFBUixHQUFpQndCLE1BQU0sQ0FBQ3hCLE1BQVAsS0FBa0IsQ0FBbkM7QUFDSixVQUFJd0IsTUFBTSxDQUFDdkIsVUFBUCxJQUFxQixJQUF6QixFQUNJRSxPQUFPLENBQUNGLFVBQVIsR0FBcUJ3QixNQUFNLENBQUNELE1BQU0sQ0FBQ3ZCLFVBQVIsQ0FBM0I7QUFDSixhQUFPRSxPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBNkIsSUFBQUEsZUFBZSxDQUFDTixRQUFoQixHQUEyQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMzRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3hCLE1BQVAsR0FBZ0IsQ0FBaEI7QUFDQXdCLFFBQUFBLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0IsRUFBcEI7QUFDSDs7QUFDRCxVQUFJRSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJbUIsTUFBTSxDQUFDeEIsTUFBUCxHQUFnQkcsT0FBTyxDQUFDSCxNQUF4QjtBQUNKLFVBQUlHLE9BQU8sQ0FBQ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QkUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUN2QixVQUFQLEdBQW9CRSxPQUFPLENBQUNGLFVBQTVCO0FBQ0osYUFBT3VCLE1BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7OztBQU9BUSxJQUFBQSxlQUFlLENBQUNqQyxTQUFoQixDQUEwQjhCLE1BQTFCLEdBQW1DLFNBQVNBLE1BQVQsR0FBa0I7QUFDakQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBT0MsZUFBUDtBQUNILEdBaE5xQixFQUF0Qjs7QUFrTkE1QyxFQUFBQSxHQUFHLENBQUM2QyxnQkFBSixHQUF3QixZQUFXO0FBRS9COzs7Ozs7QUFNQTs7Ozs7Ozs7QUFRQSxhQUFTQSxnQkFBVCxDQUEwQnRDLFVBQTFCLEVBQXNDO0FBQ2xDLFVBQUlBLFVBQUosRUFDSSxLQUFLLElBQUlDLElBQUksR0FBR0osTUFBTSxDQUFDSSxJQUFQLENBQVlELFVBQVosQ0FBWCxFQUFvQ0UsQ0FBQyxHQUFHLENBQTdDLEVBQWdEQSxDQUFDLEdBQUdELElBQUksQ0FBQ0UsTUFBekQsRUFBaUUsRUFBRUQsQ0FBbkU7QUFDSSxZQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7OztBQVFBb0MsSUFBQUEsZ0JBQWdCLENBQUN4QyxNQUFqQixHQUEwQixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUNsRCxhQUFPLElBQUlzQyxnQkFBSixDQUFxQnRDLFVBQXJCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FzQyxJQUFBQSxnQkFBZ0IsQ0FBQy9CLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUN2RCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixhQUFPVyxNQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBNkIsSUFBQUEsZ0JBQWdCLENBQUN4QixlQUFqQixHQUFtQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDekUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0F1QixJQUFBQSxnQkFBZ0IsQ0FBQ3RCLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUN0RCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBZCxFQUE3RTs7QUFDQSxhQUFPckIsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBO0FBQ0lMLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFISjtBQUtIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7OztBQVVBOEIsSUFBQUEsZ0JBQWdCLENBQUNkLGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQ2hFLFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQTBCLElBQUFBLGdCQUFnQixDQUFDYixNQUFqQixHQUEwQixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDL0MsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osYUFBTyxJQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUE4QixJQUFBQSxnQkFBZ0IsQ0FBQ1YsVUFBakIsR0FBOEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDdEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBaEMsRUFDSSxPQUFPVCxNQUFQO0FBQ0osYUFBTyxJQUFJdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBZCxFQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ1AsUUFBakIsR0FBNEIsU0FBU0EsUUFBVCxHQUFvQjtBQUM1QyxhQUFPLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7OztBQU9BTyxJQUFBQSxnQkFBZ0IsQ0FBQ2xDLFNBQWpCLENBQTJCOEIsTUFBM0IsR0FBb0MsU0FBU0EsTUFBVCxHQUFrQjtBQUNsRCxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPRSxnQkFBUDtBQUNILEdBOUpzQixFQUF2Qjs7QUFnS0E3QyxFQUFBQSxHQUFHLENBQUM4QyxtQkFBSixHQUEyQixZQUFXO0FBRWxDOzs7Ozs7O0FBT0E7Ozs7Ozs7O0FBUUEsYUFBU0EsbUJBQVQsQ0FBNkJ2QyxVQUE3QixFQUF5QztBQUNyQyxXQUFLd0MsUUFBTCxHQUFnQixFQUFoQjtBQUNBLFVBQUl4QyxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFxQyxJQUFBQSxtQkFBbUIsQ0FBQ25DLFNBQXBCLENBQThCb0MsUUFBOUIsR0FBeUNuRCxLQUFLLENBQUNvRCxVQUEvQztBQUVBOzs7Ozs7Ozs7QUFRQUYsSUFBQUEsbUJBQW1CLENBQUN6QyxNQUFwQixHQUE2QixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUNyRCxhQUFPLElBQUl1QyxtQkFBSixDQUF3QnZDLFVBQXhCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0F1QyxJQUFBQSxtQkFBbUIsQ0FBQ2hDLE1BQXBCLEdBQTZCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUMxRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUNnQyxRQUFSLElBQW9CLElBQXBCLElBQTRCaEMsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnJDLE1BQWpELEVBQ0ksS0FBSyxJQUFJRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHTSxPQUFPLENBQUNnQyxRQUFSLENBQWlCckMsTUFBckMsRUFBNkMsRUFBRUQsQ0FBL0M7QUFDSVgsUUFBQUEsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNuQyxNQUF2QyxDQUE4Q0MsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnRDLENBQWpCLENBQTlDLEVBQW1FTyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixVQUFyQyxFQUF5QytCLElBQXpDLEVBQW5FLEVBQW9INUIsTUFBcEg7QUFESjtBQUVKLGFBQU9OLE1BQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7O0FBU0E4QixJQUFBQSxtQkFBbUIsQ0FBQ3pCLGVBQXBCLEdBQXNDLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUM1RSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQXdCLElBQUFBLG1CQUFtQixDQUFDdkIsTUFBcEIsR0FBNkIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3pELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFkLEVBQTdFOztBQUNBLGFBQU90QixNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0ksZ0JBQUksRUFBRWQsT0FBTyxDQUFDZ0MsUUFBUixJQUFvQmhDLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUF2QyxDQUFKLEVBQ0lLLE9BQU8sQ0FBQ2dDLFFBQVIsR0FBbUIsRUFBbkI7QUFDSmhDLFlBQUFBLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJJLElBQWpCLENBQXNCckQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUMxQixNQUF2QyxDQUE4Q0MsTUFBOUMsRUFBc0RBLE1BQU0sQ0FBQ0wsTUFBUCxFQUF0RCxDQUF0QjtBQUNBOztBQUNKO0FBQ0lLLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFSSjtBQVVIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWxCRDtBQW9CQTs7Ozs7Ozs7Ozs7O0FBVUErQixJQUFBQSxtQkFBbUIsQ0FBQ2YsZUFBcEIsR0FBc0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDbkUsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBMkIsSUFBQUEsbUJBQW1CLENBQUNkLE1BQXBCLEdBQTZCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUNsRCxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7O0FBQ0osVUFBSUEsT0FBTyxDQUFDZ0MsUUFBUixJQUFvQixJQUFwQixJQUE0QmhDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUFvRTtBQUNoRSxZQUFJLENBQUNtQyxLQUFLLENBQUNDLE9BQU4sQ0FBY3RDLE9BQU8sQ0FBQ2dDLFFBQXRCLENBQUwsRUFDSSxPQUFPLDBCQUFQOztBQUNKLGFBQUssSUFBSXRDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdNLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUFyQyxFQUE2QyxFQUFFRCxDQUEvQyxFQUFrRDtBQUM5QyxjQUFJNkMsS0FBSyxHQUFHeEQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNqQixNQUF2QyxDQUE4Q2pCLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJ0QyxDQUFqQixDQUE5QyxDQUFaO0FBQ0EsY0FBSTZDLEtBQUosRUFDSSxPQUFPLGNBQWNBLEtBQXJCO0FBQ1A7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7QUFRQVIsSUFBQUEsbUJBQW1CLENBQUNYLFVBQXBCLEdBQWlDLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ3pELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQWhDLEVBQ0ksT0FBT1YsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQWQsRUFBZDs7QUFDQSxVQUFJVixNQUFNLENBQUNXLFFBQVgsRUFBcUI7QUFDakIsWUFBSSxDQUFDSyxLQUFLLENBQUNDLE9BQU4sQ0FBY2pCLE1BQU0sQ0FBQ1csUUFBckIsQ0FBTCxFQUNJLE1BQU1RLFNBQVMsQ0FBQyxtREFBRCxDQUFmO0FBQ0p4QyxRQUFBQSxPQUFPLENBQUNnQyxRQUFSLEdBQW1CLEVBQW5COztBQUNBLGFBQUssSUFBSXRDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcyQixNQUFNLENBQUNXLFFBQVAsQ0FBZ0JyQyxNQUFwQyxFQUE0QyxFQUFFRCxDQUE5QyxFQUFpRDtBQUM3QyxjQUFJLE9BQU8yQixNQUFNLENBQUNXLFFBQVAsQ0FBZ0J0QyxDQUFoQixDQUFQLEtBQThCLFFBQWxDLEVBQ0ksTUFBTThDLFNBQVMsQ0FBQyxvREFBRCxDQUFmO0FBQ0p4QyxVQUFBQSxPQUFPLENBQUNnQyxRQUFSLENBQWlCdEMsQ0FBakIsSUFBc0JYLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDZCxVQUF2QyxDQUFrREMsTUFBTSxDQUFDVyxRQUFQLENBQWdCdEMsQ0FBaEIsQ0FBbEQsQ0FBdEI7QUFDSDtBQUNKOztBQUNELGFBQU9NLE9BQVA7QUFDSCxLQWZEO0FBaUJBOzs7Ozs7Ozs7OztBQVNBK0IsSUFBQUEsbUJBQW1CLENBQUNSLFFBQXBCLEdBQStCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQy9ELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiO0FBQ0EsVUFBSUcsT0FBTyxDQUFDaUIsTUFBUixJQUFrQmpCLE9BQU8sQ0FBQ0MsUUFBOUIsRUFDSUosTUFBTSxDQUFDVyxRQUFQLEdBQWtCLEVBQWxCOztBQUNKLFVBQUloQyxPQUFPLENBQUNnQyxRQUFSLElBQW9CaEMsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnJDLE1BQXpDLEVBQWlEO0FBQzdDMEIsUUFBQUEsTUFBTSxDQUFDVyxRQUFQLEdBQWtCLEVBQWxCOztBQUNBLGFBQUssSUFBSVUsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzFDLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUFyQyxFQUE2QyxFQUFFK0MsQ0FBL0M7QUFDSXJCLFVBQUFBLE1BQU0sQ0FBQ1csUUFBUCxDQUFnQlUsQ0FBaEIsSUFBcUIzRCxLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUE5QixDQUF1Q1gsUUFBdkMsQ0FBZ0R2QixPQUFPLENBQUNnQyxRQUFSLENBQWlCVSxDQUFqQixDQUFoRCxFQUFxRWxCLE9BQXJFLENBQXJCO0FBREo7QUFFSDs7QUFDRCxhQUFPSCxNQUFQO0FBQ0gsS0FaRDtBQWNBOzs7Ozs7Ozs7QUFPQVUsSUFBQUEsbUJBQW1CLENBQUNuQyxTQUFwQixDQUE4QjhCLE1BQTlCLEdBQXVDLFNBQVNBLE1BQVQsR0FBa0I7QUFDckQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUFHLElBQUFBLG1CQUFtQixDQUFDRyxRQUFwQixHQUFnQyxZQUFXO0FBRXZDOzs7Ozs7Ozs7QUFTQTs7Ozs7Ozs7QUFRQSxlQUFTQSxRQUFULENBQWtCMUMsVUFBbEIsRUFBOEI7QUFDMUIsWUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLGNBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1Bd0MsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQkMsTUFBbkIsR0FBNEIsQ0FBNUI7QUFFQTs7Ozs7OztBQU1BcUMsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQkUsVUFBbkIsR0FBZ0MsRUFBaEM7QUFFQTs7Ozs7OztBQU1Bb0MsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQitDLFNBQW5CLEdBQStCLElBQS9CO0FBRUE7Ozs7Ozs7OztBQVFBVCxNQUFBQSxRQUFRLENBQUM1QyxNQUFULEdBQWtCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQzFDLGVBQU8sSUFBSTBDLFFBQUosQ0FBYTFDLFVBQWIsQ0FBUDtBQUNILE9BRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQTBDLE1BQUFBLFFBQVEsQ0FBQ25DLE1BQVQsR0FBa0IsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQy9DLFlBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFlBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsU0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixVQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixZQUFJRSxPQUFPLENBQUMyQyxTQUFSLElBQXFCLElBQXJCLElBQTZCdEQsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsV0FBcEMsQ0FBakMsRUFDSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUF2QyxDQUFpRDdDLE1BQWpELENBQXdEQyxPQUFPLENBQUMyQyxTQUFoRSxFQUEyRTFDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFVBQXJDLEVBQXlDK0IsSUFBekMsRUFBM0UsRUFBNEg1QixNQUE1SDtBQUNKLGVBQU9OLE1BQVA7QUFDSCxPQVZEO0FBWUE7Ozs7Ozs7Ozs7O0FBU0FpQyxNQUFBQSxRQUFRLENBQUM1QixlQUFULEdBQTJCLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUNqRSxlQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxPQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQTJCLE1BQUFBLFFBQVEsQ0FBQzFCLE1BQVQsR0FBa0IsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQzlDLFlBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixZQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxZQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUFsQyxFQUE3RTs7QUFDQSxlQUFPekIsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLGNBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0Esa0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGlCQUFLLENBQUw7QUFDSWQsY0FBQUEsT0FBTyxDQUFDSCxNQUFSLEdBQWlCWSxNQUFNLENBQUNMLE1BQVAsRUFBakI7QUFDQTs7QUFDSixpQkFBSyxDQUFMO0FBQ0lKLGNBQUFBLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQlcsTUFBTSxDQUFDSixNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJTCxjQUFBQSxPQUFPLENBQUMyQyxTQUFSLEdBQW9CNUQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQXZDLENBQWlEcEMsTUFBakQsQ0FBd0RDLE1BQXhELEVBQWdFQSxNQUFNLENBQUNMLE1BQVAsRUFBaEUsQ0FBcEI7QUFDQTs7QUFDSjtBQUNJSyxjQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBWko7QUFjSDs7QUFDRCxlQUFPZCxPQUFQO0FBQ0gsT0F0QkQ7QUF3QkE7Ozs7Ozs7Ozs7OztBQVVBa0MsTUFBQUEsUUFBUSxDQUFDbEIsZUFBVCxHQUEyQixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUN4RCxZQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osZUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsT0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUE4QixNQUFBQSxRQUFRLENBQUNqQixNQUFULEdBQWtCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUN2QyxZQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixZQUFJQSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNILE1BQXhCLENBQUwsRUFDSSxPQUFPLDBCQUFQO0FBQ1IsWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNzQyxRQUFOLENBQWVuQixPQUFPLENBQUNGLFVBQXZCLENBQUwsRUFDSSxPQUFPLDZCQUFQOztBQUNSLFlBQUlFLE9BQU8sQ0FBQzJDLFNBQVIsSUFBcUIsSUFBckIsSUFBNkIzQyxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsV0FBdkIsQ0FBakMsRUFBc0U7QUFDbEUsY0FBSXFDLEtBQUssR0FBR3hELEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUF2QyxDQUFpRDNCLE1BQWpELENBQXdEakIsT0FBTyxDQUFDMkMsU0FBaEUsQ0FBWjtBQUNBLGNBQUlKLEtBQUosRUFDSSxPQUFPLGVBQWVBLEtBQXRCO0FBQ1A7O0FBQ0QsZUFBTyxJQUFQO0FBQ0gsT0FmRDtBQWlCQTs7Ozs7Ozs7OztBQVFBTCxNQUFBQSxRQUFRLENBQUNkLFVBQVQsR0FBc0IsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDOUMsWUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBcEQsRUFDSSxPQUFPYixNQUFQO0FBQ0osWUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBbEMsRUFBZDtBQUNBLFlBQUliLE1BQU0sQ0FBQ3hCLE1BQVAsSUFBaUIsSUFBckIsRUFDSUcsT0FBTyxDQUFDSCxNQUFSLEdBQWlCd0IsTUFBTSxDQUFDeEIsTUFBUCxLQUFrQixDQUFuQztBQUNKLFlBQUl3QixNQUFNLENBQUN2QixVQUFQLElBQXFCLElBQXpCLEVBQ0lFLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQndCLE1BQU0sQ0FBQ0QsTUFBTSxDQUFDdkIsVUFBUixDQUEzQjs7QUFDSixZQUFJdUIsTUFBTSxDQUFDc0IsU0FBUCxJQUFvQixJQUF4QixFQUE4QjtBQUMxQixjQUFJLE9BQU90QixNQUFNLENBQUNzQixTQUFkLEtBQTRCLFFBQWhDLEVBQ0ksTUFBTUgsU0FBUyxDQUFDLDhEQUFELENBQWY7QUFDSnhDLFVBQUFBLE9BQU8sQ0FBQzJDLFNBQVIsR0FBb0I1RCxLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUE5QixDQUF1Q1UsU0FBdkMsQ0FBaUR4QixVQUFqRCxDQUE0REMsTUFBTSxDQUFDc0IsU0FBbkUsQ0FBcEI7QUFDSDs7QUFDRCxlQUFPM0MsT0FBUDtBQUNILE9BZEQ7QUFnQkE7Ozs7Ozs7Ozs7O0FBU0FrQyxNQUFBQSxRQUFRLENBQUNYLFFBQVQsR0FBb0IsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDcEQsWUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osWUFBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsWUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixVQUFBQSxNQUFNLENBQUN4QixNQUFQLEdBQWdCLENBQWhCO0FBQ0F3QixVQUFBQSxNQUFNLENBQUN2QixVQUFQLEdBQW9CLEVBQXBCO0FBQ0F1QixVQUFBQSxNQUFNLENBQUNzQixTQUFQLEdBQW1CLElBQW5CO0FBQ0g7O0FBQ0QsWUFBSTNDLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQkcsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ltQixNQUFNLENBQUN4QixNQUFQLEdBQWdCRyxPQUFPLENBQUNILE1BQXhCO0FBQ0osWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0JFLE9BQU8sQ0FBQ0YsVUFBNUI7QUFDSixZQUFJRSxPQUFPLENBQUMyQyxTQUFSLElBQXFCLElBQXJCLElBQTZCM0MsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFdBQXZCLENBQWpDLEVBQ0ltQixNQUFNLENBQUNzQixTQUFQLEdBQW1CNUQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQXZDLENBQWlEckIsUUFBakQsQ0FBMER2QixPQUFPLENBQUMyQyxTQUFsRSxFQUE2RW5CLE9BQTdFLENBQW5CO0FBQ0osZUFBT0gsTUFBUDtBQUNILE9BaEJEO0FBa0JBOzs7Ozs7Ozs7QUFPQWEsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQjhCLE1BQW5CLEdBQTRCLFNBQVNBLE1BQVQsR0FBa0I7QUFDMUMsZUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILE9BRkQ7O0FBSUFNLE1BQUFBLFFBQVEsQ0FBQ1UsU0FBVCxHQUFzQixZQUFXO0FBRTdCOzs7Ozs7Ozs7OztBQVdBOzs7Ozs7OztBQVFBLGlCQUFTQSxTQUFULENBQW1CcEQsVUFBbkIsRUFBK0I7QUFDM0IsY0FBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLGdCQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7QUFNQWtELFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JpRCxRQUFwQixHQUErQixDQUEvQjtBQUVBOzs7Ozs7O0FBTUFELFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JrRCxRQUFwQixHQUErQixDQUEvQjtBQUVBOzs7Ozs7O0FBTUFGLFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JtRCxNQUFwQixHQUE2QixDQUE3QjtBQUVBOzs7Ozs7O0FBTUFILFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JvRCxNQUFwQixHQUE2QixDQUE3QjtBQUVBOzs7Ozs7O0FBTUFKLFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JxRCxTQUFwQixHQUFnQ3BFLEtBQUssQ0FBQ3FFLElBQU4sR0FBYXJFLEtBQUssQ0FBQ3FFLElBQU4sQ0FBV0MsUUFBWCxDQUFvQixDQUFwQixFQUFzQixDQUF0QixFQUF3QixJQUF4QixDQUFiLEdBQTZDLENBQTdFO0FBRUE7Ozs7Ozs7OztBQVFBUCxRQUFBQSxTQUFTLENBQUN0RCxNQUFWLEdBQW1CLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQzNDLGlCQUFPLElBQUlvRCxTQUFKLENBQWNwRCxVQUFkLENBQVA7QUFDSCxTQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FvRCxRQUFBQSxTQUFTLENBQUM3QyxNQUFWLEdBQW1CLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNoRCxjQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixjQUFJVSxPQUFPLENBQUM2QyxRQUFSLElBQW9CLElBQXBCLElBQTRCeEQsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsVUFBcEMsQ0FBaEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsWUFBckMsV0FBK0NKLE9BQU8sQ0FBQzZDLFFBQXZEO0FBQ0osY0FBSTdDLE9BQU8sQ0FBQzhDLFFBQVIsSUFBb0IsSUFBcEIsSUFBNEJ6RCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxVQUFwQyxDQUFoQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixZQUFyQyxXQUErQ0osT0FBTyxDQUFDOEMsUUFBdkQ7QUFDSixjQUFJOUMsT0FBTyxDQUFDK0MsTUFBUixJQUFrQixJQUFsQixJQUEwQjFELE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFFBQXBDLENBQTlCLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFlBQXJDLFdBQStDSixPQUFPLENBQUMrQyxNQUF2RDtBQUNKLGNBQUkvQyxPQUFPLENBQUNnRCxNQUFSLElBQWtCLElBQWxCLElBQTBCM0QsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsWUFBckMsV0FBK0NKLE9BQU8sQ0FBQ2dELE1BQXZEO0FBQ0osY0FBSWhELE9BQU8sQ0FBQ2lELFNBQVIsSUFBcUIsSUFBckIsSUFBNkI1RCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxXQUFwQyxDQUFqQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixZQUFyQyxFQUF5Q2dELE1BQXpDLENBQWdEcEQsT0FBTyxDQUFDaUQsU0FBeEQ7QUFDSixpQkFBT2hELE1BQVA7QUFDSCxTQWREO0FBZ0JBOzs7Ozs7Ozs7OztBQVNBMkMsUUFBQUEsU0FBUyxDQUFDdEMsZUFBVixHQUE0QixTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDbEUsaUJBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILFNBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBcUMsUUFBQUEsU0FBUyxDQUFDcEMsTUFBVixHQUFtQixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDL0MsY0FBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLGNBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLGNBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUEzQyxFQUE3RTs7QUFDQSxpQkFBT25DLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixnQkFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxvQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsbUJBQUssQ0FBTDtBQUNJZCxnQkFBQUEsT0FBTyxDQUFDNkMsUUFBUixHQUFtQnBDLE1BQU0sU0FBTixFQUFuQjtBQUNBOztBQUNKLG1CQUFLLENBQUw7QUFDSVQsZ0JBQUFBLE9BQU8sQ0FBQzhDLFFBQVIsR0FBbUJyQyxNQUFNLFNBQU4sRUFBbkI7QUFDQTs7QUFDSixtQkFBSyxDQUFMO0FBQ0lULGdCQUFBQSxPQUFPLENBQUMrQyxNQUFSLEdBQWlCdEMsTUFBTSxTQUFOLEVBQWpCO0FBQ0E7O0FBQ0osbUJBQUssQ0FBTDtBQUNJVCxnQkFBQUEsT0FBTyxDQUFDZ0QsTUFBUixHQUFpQnZDLE1BQU0sU0FBTixFQUFqQjtBQUNBOztBQUNKLG1CQUFLLENBQUw7QUFDSVQsZ0JBQUFBLE9BQU8sQ0FBQ2lELFNBQVIsR0FBb0J4QyxNQUFNLENBQUMyQyxNQUFQLEVBQXBCO0FBQ0E7O0FBQ0o7QUFDSTNDLGdCQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBbEJKO0FBb0JIOztBQUNELGlCQUFPZCxPQUFQO0FBQ0gsU0E1QkQ7QUE4QkE7Ozs7Ozs7Ozs7OztBQVVBNEMsUUFBQUEsU0FBUyxDQUFDNUIsZUFBVixHQUE0QixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUN6RCxjQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osaUJBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILFNBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBd0MsUUFBQUEsU0FBUyxDQUFDM0IsTUFBVixHQUFtQixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDeEMsY0FBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osY0FBSUEsT0FBTyxDQUFDNkMsUUFBUixJQUFvQixJQUFwQixJQUE0QjdDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDNkMsUUFBZixLQUE0QixRQUFoQyxFQUNJLE9BQU8sMkJBQVA7QUFDUixjQUFJN0MsT0FBTyxDQUFDOEMsUUFBUixJQUFvQixJQUFwQixJQUE0QjlDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDOEMsUUFBZixLQUE0QixRQUFoQyxFQUNJLE9BQU8sMkJBQVA7QUFDUixjQUFJOUMsT0FBTyxDQUFDK0MsTUFBUixJQUFrQixJQUFsQixJQUEwQi9DLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDK0MsTUFBZixLQUEwQixRQUE5QixFQUNJLE9BQU8seUJBQVA7QUFDUixjQUFJL0MsT0FBTyxDQUFDZ0QsTUFBUixJQUFrQixJQUFsQixJQUEwQmhELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDZ0QsTUFBZixLQUEwQixRQUE5QixFQUNJLE9BQU8seUJBQVA7QUFDUixjQUFJaEQsT0FBTyxDQUFDaUQsU0FBUixJQUFxQixJQUFyQixJQUE2QmpELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixXQUF2QixDQUFqQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNpRCxTQUF4QixDQUFELElBQXVDLEVBQUVqRCxPQUFPLENBQUNpRCxTQUFSLElBQXFCcEUsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JJLEdBQWxDLENBQXJCLElBQStEeEUsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JLLElBQWxDLENBQWpFLENBQTNDLEVBQ0ksT0FBTyxrQ0FBUDtBQUNSLGlCQUFPLElBQVA7QUFDSCxTQW5CRDtBQXFCQTs7Ozs7Ozs7OztBQVFBVixRQUFBQSxTQUFTLENBQUN4QixVQUFWLEdBQXVCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQy9DLGNBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUE3RCxFQUNJLE9BQU92QixNQUFQO0FBQ0osY0FBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQTNDLEVBQWQ7QUFDQSxjQUFJdkIsTUFBTSxDQUFDd0IsUUFBUCxJQUFtQixJQUF2QixFQUNJN0MsT0FBTyxDQUFDNkMsUUFBUixHQUFtQlUsTUFBTSxDQUFDbEMsTUFBTSxDQUFDd0IsUUFBUixDQUF6QjtBQUNKLGNBQUl4QixNQUFNLENBQUN5QixRQUFQLElBQW1CLElBQXZCLEVBQ0k5QyxPQUFPLENBQUM4QyxRQUFSLEdBQW1CUyxNQUFNLENBQUNsQyxNQUFNLENBQUN5QixRQUFSLENBQXpCO0FBQ0osY0FBSXpCLE1BQU0sQ0FBQzBCLE1BQVAsSUFBaUIsSUFBckIsRUFDSS9DLE9BQU8sQ0FBQytDLE1BQVIsR0FBaUJRLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQzBCLE1BQVIsQ0FBdkI7QUFDSixjQUFJMUIsTUFBTSxDQUFDMkIsTUFBUCxJQUFpQixJQUFyQixFQUNJaEQsT0FBTyxDQUFDZ0QsTUFBUixHQUFpQk8sTUFBTSxDQUFDbEMsTUFBTSxDQUFDMkIsTUFBUixDQUF2QjtBQUNKLGNBQUkzQixNQUFNLENBQUM0QixTQUFQLElBQW9CLElBQXhCLEVBQ0ksSUFBSXBFLEtBQUssQ0FBQ3FFLElBQVYsRUFDSSxDQUFDbEQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQnBFLEtBQUssQ0FBQ3FFLElBQU4sQ0FBV00sU0FBWCxDQUFxQm5DLE1BQU0sQ0FBQzRCLFNBQTVCLENBQXJCLEVBQTZEUSxRQUE3RCxHQUF3RSxJQUF4RSxDQURKLEtBRUssSUFBSSxPQUFPcEMsTUFBTSxDQUFDNEIsU0FBZCxLQUE0QixRQUFoQyxFQUNEakQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQlMsUUFBUSxDQUFDckMsTUFBTSxDQUFDNEIsU0FBUixFQUFtQixFQUFuQixDQUE1QixDQURDLEtBRUEsSUFBSSxPQUFPNUIsTUFBTSxDQUFDNEIsU0FBZCxLQUE0QixRQUFoQyxFQUNEakQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQjVCLE1BQU0sQ0FBQzRCLFNBQTNCLENBREMsS0FFQSxJQUFJLE9BQU81QixNQUFNLENBQUM0QixTQUFkLEtBQTRCLFFBQWhDLEVBQ0RqRCxPQUFPLENBQUNpRCxTQUFSLEdBQW9CLElBQUlwRSxLQUFLLENBQUM4RSxRQUFWLENBQW1CdEMsTUFBTSxDQUFDNEIsU0FBUCxDQUFpQkksR0FBakIsS0FBeUIsQ0FBNUMsRUFBK0NoQyxNQUFNLENBQUM0QixTQUFQLENBQWlCSyxJQUFqQixLQUEwQixDQUF6RSxFQUE0RU0sUUFBNUUsQ0FBcUYsSUFBckYsQ0FBcEI7QUFDUixpQkFBTzVELE9BQVA7QUFDSCxTQXRCRDtBQXdCQTs7Ozs7Ozs7Ozs7QUFTQTRDLFFBQUFBLFNBQVMsQ0FBQ3JCLFFBQVYsR0FBcUIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDckQsY0FBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osY0FBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsY0FBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixZQUFBQSxNQUFNLENBQUN3QixRQUFQLEdBQWtCLENBQWxCO0FBQ0F4QixZQUFBQSxNQUFNLENBQUN5QixRQUFQLEdBQWtCLENBQWxCO0FBQ0F6QixZQUFBQSxNQUFNLENBQUMwQixNQUFQLEdBQWdCLENBQWhCO0FBQ0ExQixZQUFBQSxNQUFNLENBQUMyQixNQUFQLEdBQWdCLENBQWhCOztBQUNBLGdCQUFJbkUsS0FBSyxDQUFDcUUsSUFBVixFQUFnQjtBQUNaLGtCQUFJVyxLQUFJLEdBQUcsSUFBSWhGLEtBQUssQ0FBQ3FFLElBQVYsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCLElBQXJCLENBQVg7O0FBQ0E3QixjQUFBQSxNQUFNLENBQUM0QixTQUFQLEdBQW1CekIsT0FBTyxDQUFDc0MsS0FBUixLQUFrQnhDLE1BQWxCLEdBQTJCdUMsS0FBSSxDQUFDRSxRQUFMLEVBQTNCLEdBQTZDdkMsT0FBTyxDQUFDc0MsS0FBUixLQUFrQlAsTUFBbEIsR0FBMkJNLEtBQUksQ0FBQ0QsUUFBTCxFQUEzQixHQUE2Q0MsS0FBN0c7QUFDSCxhQUhELE1BSUl4QyxNQUFNLENBQUM0QixTQUFQLEdBQW1CekIsT0FBTyxDQUFDc0MsS0FBUixLQUFrQnhDLE1BQWxCLEdBQTJCLEdBQTNCLEdBQWlDLENBQXBEO0FBQ1A7O0FBQ0QsY0FBSXRCLE9BQU8sQ0FBQzZDLFFBQVIsSUFBb0IsSUFBcEIsSUFBNEI3QyxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsVUFBdkIsQ0FBaEMsRUFDSW1CLE1BQU0sQ0FBQ3dCLFFBQVAsR0FBa0JyQixPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQzZDLFFBQVQsQ0FBekIsR0FBOEN2QixNQUFNLENBQUN0QixPQUFPLENBQUM2QyxRQUFULENBQXBELEdBQXlFN0MsT0FBTyxDQUFDNkMsUUFBbkc7QUFDSixjQUFJN0MsT0FBTyxDQUFDOEMsUUFBUixJQUFvQixJQUFwQixJQUE0QjlDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJbUIsTUFBTSxDQUFDeUIsUUFBUCxHQUFrQnRCLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDOEMsUUFBVCxDQUF6QixHQUE4Q3hCLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQzhDLFFBQVQsQ0FBcEQsR0FBeUU5QyxPQUFPLENBQUM4QyxRQUFuRztBQUNKLGNBQUk5QyxPQUFPLENBQUMrQyxNQUFSLElBQWtCLElBQWxCLElBQTBCL0MsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ltQixNQUFNLENBQUMwQixNQUFQLEdBQWdCdkIsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUMrQyxNQUFULENBQXpCLEdBQTRDekIsTUFBTSxDQUFDdEIsT0FBTyxDQUFDK0MsTUFBVCxDQUFsRCxHQUFxRS9DLE9BQU8sQ0FBQytDLE1BQTdGO0FBQ0osY0FBSS9DLE9BQU8sQ0FBQ2dELE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJoRCxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsUUFBdkIsQ0FBOUIsRUFDSW1CLE1BQU0sQ0FBQzJCLE1BQVAsR0FBZ0J4QixPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ2dELE1BQVQsQ0FBekIsR0FBNEMxQixNQUFNLENBQUN0QixPQUFPLENBQUNnRCxNQUFULENBQWxELEdBQXFFaEQsT0FBTyxDQUFDZ0QsTUFBN0Y7QUFDSixjQUFJaEQsT0FBTyxDQUFDaUQsU0FBUixJQUFxQixJQUFyQixJQUE2QmpELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixXQUF2QixDQUFqQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDaUQsU0FBZixLQUE2QixRQUFqQyxFQUNJNUIsTUFBTSxDQUFDNEIsU0FBUCxHQUFtQnpCLE9BQU8sQ0FBQ3NDLEtBQVIsS0FBa0J4QyxNQUFsQixHQUEyQkEsTUFBTSxDQUFDdEIsT0FBTyxDQUFDaUQsU0FBVCxDQUFqQyxHQUF1RGpELE9BQU8sQ0FBQ2lELFNBQWxGLENBREosS0FHSTVCLE1BQU0sQ0FBQzRCLFNBQVAsR0FBbUJ6QixPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ6QyxLQUFLLENBQUNxRSxJQUFOLENBQVd0RCxTQUFYLENBQXFCbUUsUUFBckIsQ0FBOEI1RCxJQUE5QixDQUFtQ0gsT0FBTyxDQUFDaUQsU0FBM0MsQ0FBM0IsR0FBbUZ6QixPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQixJQUFJMUUsS0FBSyxDQUFDOEUsUUFBVixDQUFtQjNELE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JJLEdBQWxCLEtBQTBCLENBQTdDLEVBQWdEckQsT0FBTyxDQUFDaUQsU0FBUixDQUFrQkssSUFBbEIsS0FBMkIsQ0FBM0UsRUFBOEVNLFFBQTlFLENBQXVGLElBQXZGLENBQTNCLEdBQTBINUQsT0FBTyxDQUFDaUQsU0FBeE87QUFDUixpQkFBTzVCLE1BQVA7QUFDSCxTQTdCRDtBQStCQTs7Ozs7Ozs7O0FBT0F1QixRQUFBQSxTQUFTLENBQUNoRCxTQUFWLENBQW9COEIsTUFBcEIsR0FBNkIsU0FBU0EsTUFBVCxHQUFrQjtBQUMzQyxpQkFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILFNBRkQ7O0FBSUEsZUFBT2dCLFNBQVA7QUFDSCxPQWhTb0IsRUFBckI7O0FBa1NBLGFBQU9WLFFBQVA7QUFDSCxLQTdnQjhCLEVBQS9COztBQStnQkEsV0FBT0gsbUJBQVA7QUFDSCxHQTd0QnlCLEVBQTFCOztBQSt0QkE5QyxFQUFBQSxHQUFHLENBQUNpRixhQUFKLEdBQXFCLFlBQVc7QUFFNUI7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7QUFRQSxhQUFTQSxhQUFULENBQXVCMUUsVUFBdkIsRUFBbUM7QUFDL0IsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1Bd0UsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QnVFLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QndFLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7QUFNQUYsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QnlFLFVBQXhCLEdBQXFDLENBQXJDO0FBRUE7Ozs7Ozs7QUFNQUgsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QjBFLFVBQXhCLEdBQXFDLENBQXJDO0FBRUE7Ozs7Ozs7OztBQVFBSixJQUFBQSxhQUFhLENBQUM1RSxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQy9DLGFBQU8sSUFBSTBFLGFBQUosQ0FBa0IxRSxVQUFsQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBMEUsSUFBQUEsYUFBYSxDQUFDbkUsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDcEQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQzlFLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNtRSxZQUF2RDtBQUNKLFVBQUluRSxPQUFPLENBQUNvRSxZQUFSLElBQXdCLElBQXhCLElBQWdDL0UsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsY0FBcEMsQ0FBcEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQ29FLFlBQXZEO0FBQ0osVUFBSXBFLE9BQU8sQ0FBQ3FFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJoRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDcUUsVUFBdkQ7QUFDSixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QmpGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNzRSxVQUF2RDtBQUNKLGFBQU9yRSxNQUFQO0FBQ0gsS0FaRDtBQWNBOzs7Ozs7Ozs7OztBQVNBaUUsSUFBQUEsYUFBYSxDQUFDNUQsZUFBZCxHQUFnQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDdEUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0EyRCxJQUFBQSxhQUFhLENBQUMxRCxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNuRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVVpRixhQUFkLEVBQTdFOztBQUNBLGFBQU96RCxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ21FLFlBQVIsR0FBdUIxRCxNQUFNLFNBQU4sRUFBdkI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDb0UsWUFBUixHQUF1QjNELE1BQU0sU0FBTixFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUNxRSxVQUFSLEdBQXFCNUQsTUFBTSxTQUFOLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lULFlBQUFBLE9BQU8sQ0FBQ3NFLFVBQVIsR0FBcUI3RCxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSjtBQUNJQSxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBZko7QUFpQkg7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBekJEO0FBMkJBOzs7Ozs7Ozs7Ozs7QUFVQWtFLElBQUFBLGFBQWEsQ0FBQ2xELGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDN0QsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBOEQsSUFBQUEsYUFBYSxDQUFDakQsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDNUMsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQ25FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDbUUsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDb0UsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJcEUsT0FBTyxDQUFDcUUsVUFBUixJQUFzQixJQUF0QixJQUE4QnJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDcUUsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnRFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDc0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQWhCRDtBQWtCQTs7Ozs7Ozs7OztBQVFBSixJQUFBQSxhQUFhLENBQUM5QyxVQUFkLEdBQTJCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ25ELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVaUYsYUFBaEMsRUFDSSxPQUFPN0MsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVaUYsYUFBZCxFQUFkO0FBQ0EsVUFBSTdDLE1BQU0sQ0FBQzhDLFlBQVAsSUFBdUIsSUFBM0IsRUFDSW5FLE9BQU8sQ0FBQ21FLFlBQVIsR0FBdUJaLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQzhDLFlBQVIsQ0FBN0I7QUFDSixVQUFJOUMsTUFBTSxDQUFDK0MsWUFBUCxJQUF1QixJQUEzQixFQUNJcEUsT0FBTyxDQUFDb0UsWUFBUixHQUF1QmIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDK0MsWUFBUixDQUE3QjtBQUNKLFVBQUkvQyxNQUFNLENBQUNnRCxVQUFQLElBQXFCLElBQXpCLEVBQ0lyRSxPQUFPLENBQUNxRSxVQUFSLEdBQXFCZCxNQUFNLENBQUNsQyxNQUFNLENBQUNnRCxVQUFSLENBQTNCO0FBQ0osVUFBSWhELE1BQU0sQ0FBQ2lELFVBQVAsSUFBcUIsSUFBekIsRUFDSXRFLE9BQU8sQ0FBQ3NFLFVBQVIsR0FBcUJmLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQ2lELFVBQVIsQ0FBM0I7QUFDSixhQUFPdEUsT0FBUDtBQUNILEtBYkQ7QUFlQTs7Ozs7Ozs7Ozs7QUFTQWtFLElBQUFBLGFBQWEsQ0FBQzNDLFFBQWQsR0FBeUIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDekQsVUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osVUFBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsVUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixRQUFBQSxNQUFNLENBQUM4QyxZQUFQLEdBQXNCLENBQXRCO0FBQ0E5QyxRQUFBQSxNQUFNLENBQUMrQyxZQUFQLEdBQXNCLENBQXRCO0FBQ0EvQyxRQUFBQSxNQUFNLENBQUNnRCxVQUFQLEdBQW9CLENBQXBCO0FBQ0FoRCxRQUFBQSxNQUFNLENBQUNpRCxVQUFQLEdBQW9CLENBQXBCO0FBQ0g7O0FBQ0QsVUFBSXRFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NuRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzhDLFlBQVAsR0FBc0IzQyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ21FLFlBQVQsQ0FBekIsR0FBa0Q3QyxNQUFNLENBQUN0QixPQUFPLENBQUNtRSxZQUFULENBQXhELEdBQWlGbkUsT0FBTyxDQUFDbUUsWUFBL0c7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQjVDLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDb0UsWUFBVCxDQUF6QixHQUFrRDlDLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ29FLFlBQVQsQ0FBeEQsR0FBaUZwRSxPQUFPLENBQUNvRSxZQUEvRztBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCckUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNnRCxVQUFQLEdBQW9CN0MsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUNxRSxVQUFULENBQXpCLEdBQWdEL0MsTUFBTSxDQUFDdEIsT0FBTyxDQUFDcUUsVUFBVCxDQUF0RCxHQUE2RXJFLE9BQU8sQ0FBQ3FFLFVBQXpHO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lELFVBQVAsR0FBb0I5QyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ3NFLFVBQVQsQ0FBekIsR0FBZ0RoRCxNQUFNLENBQUN0QixPQUFPLENBQUNzRSxVQUFULENBQXRELEdBQTZFdEUsT0FBTyxDQUFDc0UsVUFBekc7QUFDSixhQUFPakQsTUFBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7QUFPQTZDLElBQUFBLGFBQWEsQ0FBQ3RFLFNBQWQsQ0FBd0I4QixNQUF4QixHQUFpQyxTQUFTQSxNQUFULEdBQWtCO0FBQy9DLGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU9zQyxhQUFQO0FBQ0gsR0E1UG1CLEVBQXBCOztBQThQQWpGLEVBQUFBLEdBQUcsQ0FBQ3NGLGdCQUFKLEdBQXdCLFlBQVc7QUFFL0I7Ozs7Ozs7Ozs7OztBQVlBOzs7Ozs7OztBQVFBLGFBQVNBLGdCQUFULENBQTBCL0UsVUFBMUIsRUFBc0M7QUFDbEMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BNkUsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjRFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQnVFLFlBQTNCLEdBQTBDLENBQTFDO0FBRUE7Ozs7Ozs7QUFNQUksSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQndFLFlBQTNCLEdBQTBDLENBQTFDO0FBRUE7Ozs7Ozs7QUFNQUcsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQnlFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUUsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjBFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUMsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjZFLGFBQTNCLEdBQTJDNUYsS0FBSyxDQUFDcUUsSUFBTixHQUFhckUsS0FBSyxDQUFDcUUsSUFBTixDQUFXQyxRQUFYLENBQW9CLENBQXBCLEVBQXNCLENBQXRCLEVBQXdCLElBQXhCLENBQWIsR0FBNkMsQ0FBeEY7QUFFQTs7Ozs7Ozs7O0FBUUFvQixJQUFBQSxnQkFBZ0IsQ0FBQ2pGLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2xELGFBQU8sSUFBSStFLGdCQUFKLENBQXFCL0UsVUFBckIsQ0FBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQStFLElBQUFBLGdCQUFnQixDQUFDeEUsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ3ZELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ3dFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJuRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixPQUFyQyxFQUF3Q0EsTUFBeEMsQ0FBK0NKLE9BQU8sQ0FBQ3dFLFVBQXZEO0FBQ0osVUFBSXhFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0M5RSxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxjQUFwQyxDQUFwQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDbUUsWUFBdkQ7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQy9FLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNvRSxZQUF2RDtBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCaEYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQ3FFLFVBQXZEO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJqRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDc0UsVUFBdkQ7QUFDSixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3BGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGVBQXBDLENBQXJDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDZ0QsTUFBekMsQ0FBZ0RwRCxPQUFPLENBQUN5RSxhQUF4RDtBQUNKLGFBQU94RSxNQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7Ozs7O0FBU0FzRSxJQUFBQSxnQkFBZ0IsQ0FBQ2pFLGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUN6RSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQWdFLElBQUFBLGdCQUFnQixDQUFDL0QsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3RELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVXNGLGdCQUFkLEVBQTdFOztBQUNBLGFBQU85RCxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ3dFLFVBQVIsR0FBcUIvRCxNQUFNLENBQUNMLE1BQVAsRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSUosWUFBQUEsT0FBTyxDQUFDbUUsWUFBUixHQUF1QjFELE1BQU0sU0FBTixFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUNvRSxZQUFSLEdBQXVCM0QsTUFBTSxTQUFOLEVBQXZCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lULFlBQUFBLE9BQU8sQ0FBQ3FFLFVBQVIsR0FBcUI1RCxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDc0UsVUFBUixHQUFxQjdELE1BQU0sU0FBTixFQUFyQjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUN5RSxhQUFSLEdBQXdCaEUsTUFBTSxDQUFDMkMsTUFBUCxFQUF4QjtBQUNBOztBQUNKO0FBQ0kzQyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBckJKO0FBdUJIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQS9CRDtBQWlDQTs7Ozs7Ozs7Ozs7O0FBVUF1RSxJQUFBQSxnQkFBZ0IsQ0FBQ3ZELGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQ2hFLFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQW1FLElBQUFBLGdCQUFnQixDQUFDdEQsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQy9DLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ3dFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ4RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDd0UsVUFBeEIsQ0FBTCxFQUNJLE9BQU8sOEJBQVA7QUFDUixVQUFJeEUsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQ25FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDbUUsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDb0UsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJcEUsT0FBTyxDQUFDcUUsVUFBUixJQUFzQixJQUF0QixJQUE4QnJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDcUUsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnRFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDc0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3pFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixlQUF2QixDQUFyQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUN5RSxhQUF4QixDQUFELElBQTJDLEVBQUV6RSxPQUFPLENBQUN5RSxhQUFSLElBQXlCNUYsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JwQixHQUF0QyxDQUF6QixJQUF1RXhFLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUN5RSxhQUFSLENBQXNCbkIsSUFBdEMsQ0FBekUsQ0FBL0MsRUFDSSxPQUFPLHNDQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0F0QkQ7QUF3QkE7Ozs7Ozs7Ozs7QUFRQWlCLElBQUFBLGdCQUFnQixDQUFDbkQsVUFBakIsR0FBOEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDdEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVVzRixnQkFBaEMsRUFDSSxPQUFPbEQsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0YsZ0JBQWQsRUFBZDtBQUNBLFVBQUlsRCxNQUFNLENBQUNtRCxVQUFQLElBQXFCLElBQXpCLEVBQ0l4RSxPQUFPLENBQUN3RSxVQUFSLEdBQXFCbkQsTUFBTSxDQUFDbUQsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUluRCxNQUFNLENBQUM4QyxZQUFQLElBQXVCLElBQTNCLEVBQ0luRSxPQUFPLENBQUNtRSxZQUFSLEdBQXVCWixNQUFNLENBQUNsQyxNQUFNLENBQUM4QyxZQUFSLENBQTdCO0FBQ0osVUFBSTlDLE1BQU0sQ0FBQytDLFlBQVAsSUFBdUIsSUFBM0IsRUFDSXBFLE9BQU8sQ0FBQ29FLFlBQVIsR0FBdUJiLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQytDLFlBQVIsQ0FBN0I7QUFDSixVQUFJL0MsTUFBTSxDQUFDZ0QsVUFBUCxJQUFxQixJQUF6QixFQUNJckUsT0FBTyxDQUFDcUUsVUFBUixHQUFxQmQsTUFBTSxDQUFDbEMsTUFBTSxDQUFDZ0QsVUFBUixDQUEzQjtBQUNKLFVBQUloRCxNQUFNLENBQUNpRCxVQUFQLElBQXFCLElBQXpCLEVBQ0l0RSxPQUFPLENBQUNzRSxVQUFSLEdBQXFCZixNQUFNLENBQUNsQyxNQUFNLENBQUNpRCxVQUFSLENBQTNCO0FBQ0osVUFBSWpELE1BQU0sQ0FBQ29ELGFBQVAsSUFBd0IsSUFBNUIsRUFDSSxJQUFJNUYsS0FBSyxDQUFDcUUsSUFBVixFQUNJLENBQUNsRCxPQUFPLENBQUN5RSxhQUFSLEdBQXdCNUYsS0FBSyxDQUFDcUUsSUFBTixDQUFXTSxTQUFYLENBQXFCbkMsTUFBTSxDQUFDb0QsYUFBNUIsQ0FBekIsRUFBcUVoQixRQUFyRSxHQUFnRixJQUFoRixDQURKLEtBRUssSUFBSSxPQUFPcEMsTUFBTSxDQUFDb0QsYUFBZCxLQUFnQyxRQUFwQyxFQUNEekUsT0FBTyxDQUFDeUUsYUFBUixHQUF3QmYsUUFBUSxDQUFDckMsTUFBTSxDQUFDb0QsYUFBUixFQUF1QixFQUF2QixDQUFoQyxDQURDLEtBRUEsSUFBSSxPQUFPcEQsTUFBTSxDQUFDb0QsYUFBZCxLQUFnQyxRQUFwQyxFQUNEekUsT0FBTyxDQUFDeUUsYUFBUixHQUF3QnBELE1BQU0sQ0FBQ29ELGFBQS9CLENBREMsS0FFQSxJQUFJLE9BQU9wRCxNQUFNLENBQUNvRCxhQUFkLEtBQWdDLFFBQXBDLEVBQ0R6RSxPQUFPLENBQUN5RSxhQUFSLEdBQXdCLElBQUk1RixLQUFLLENBQUM4RSxRQUFWLENBQW1CdEMsTUFBTSxDQUFDb0QsYUFBUCxDQUFxQnBCLEdBQXJCLEtBQTZCLENBQWhELEVBQW1EaEMsTUFBTSxDQUFDb0QsYUFBUCxDQUFxQm5CLElBQXJCLEtBQThCLENBQWpGLEVBQW9GTSxRQUFwRixDQUE2RixJQUE3RixDQUF4QjtBQUNSLGFBQU81RCxPQUFQO0FBQ0gsS0F4QkQ7QUEwQkE7Ozs7Ozs7Ozs7O0FBU0F1RSxJQUFBQSxnQkFBZ0IsQ0FBQ2hELFFBQWpCLEdBQTRCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQzVELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiOztBQUNBLFVBQUlHLE9BQU8sQ0FBQ0MsUUFBWixFQUFzQjtBQUNsQkosUUFBQUEsTUFBTSxDQUFDbUQsVUFBUCxHQUFvQixDQUFwQjtBQUNBbkQsUUFBQUEsTUFBTSxDQUFDOEMsWUFBUCxHQUFzQixDQUF0QjtBQUNBOUMsUUFBQUEsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQixDQUF0QjtBQUNBL0MsUUFBQUEsTUFBTSxDQUFDZ0QsVUFBUCxHQUFvQixDQUFwQjtBQUNBaEQsUUFBQUEsTUFBTSxDQUFDaUQsVUFBUCxHQUFvQixDQUFwQjs7QUFDQSxZQUFJekYsS0FBSyxDQUFDcUUsSUFBVixFQUFnQjtBQUNaLGNBQUlXLE1BQUksR0FBRyxJQUFJaEYsS0FBSyxDQUFDcUUsSUFBVixDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsSUFBckIsQ0FBWDs7QUFDQTdCLFVBQUFBLE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ1QyxNQUFJLENBQUNFLFFBQUwsRUFBM0IsR0FBNkN2QyxPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQk0sTUFBSSxDQUFDRCxRQUFMLEVBQTNCLEdBQTZDQyxNQUFqSDtBQUNILFNBSEQsTUFJSXhDLE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkIsR0FBM0IsR0FBaUMsQ0FBeEQ7QUFDUDs7QUFDRCxVQUFJdEIsT0FBTyxDQUFDd0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnhFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDbUQsVUFBUCxHQUFvQnhFLE9BQU8sQ0FBQ3dFLFVBQTVCO0FBQ0osVUFBSXhFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NuRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzhDLFlBQVAsR0FBc0IzQyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ21FLFlBQVQsQ0FBekIsR0FBa0Q3QyxNQUFNLENBQUN0QixPQUFPLENBQUNtRSxZQUFULENBQXhELEdBQWlGbkUsT0FBTyxDQUFDbUUsWUFBL0c7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQjVDLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDb0UsWUFBVCxDQUF6QixHQUFrRDlDLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ29FLFlBQVQsQ0FBeEQsR0FBaUZwRSxPQUFPLENBQUNvRSxZQUEvRztBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCckUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNnRCxVQUFQLEdBQW9CN0MsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUNxRSxVQUFULENBQXpCLEdBQWdEL0MsTUFBTSxDQUFDdEIsT0FBTyxDQUFDcUUsVUFBVCxDQUF0RCxHQUE2RXJFLE9BQU8sQ0FBQ3FFLFVBQXpHO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lELFVBQVAsR0FBb0I5QyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ3NFLFVBQVQsQ0FBekIsR0FBZ0RoRCxNQUFNLENBQUN0QixPQUFPLENBQUNzRSxVQUFULENBQXRELEdBQTZFdEUsT0FBTyxDQUFDc0UsVUFBekc7QUFDSixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3pFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixlQUF2QixDQUFyQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDeUUsYUFBZixLQUFpQyxRQUFyQyxFQUNJcEQsTUFBTSxDQUFDb0QsYUFBUCxHQUF1QmpELE9BQU8sQ0FBQ3NDLEtBQVIsS0FBa0J4QyxNQUFsQixHQUEyQkEsTUFBTSxDQUFDdEIsT0FBTyxDQUFDeUUsYUFBVCxDQUFqQyxHQUEyRHpFLE9BQU8sQ0FBQ3lFLGFBQTFGLENBREosS0FHSXBELE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ6QyxLQUFLLENBQUNxRSxJQUFOLENBQVd0RCxTQUFYLENBQXFCbUUsUUFBckIsQ0FBOEI1RCxJQUE5QixDQUFtQ0gsT0FBTyxDQUFDeUUsYUFBM0MsQ0FBM0IsR0FBdUZqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQixJQUFJMUUsS0FBSyxDQUFDOEUsUUFBVixDQUFtQjNELE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JwQixHQUF0QixLQUE4QixDQUFqRCxFQUFvRHJELE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JuQixJQUF0QixLQUErQixDQUFuRixFQUFzRk0sUUFBdEYsQ0FBK0YsSUFBL0YsQ0FBM0IsR0FBa0k1RCxPQUFPLENBQUN5RSxhQUF4UDtBQUNSLGFBQU9wRCxNQUFQO0FBQ0gsS0FoQ0Q7QUFrQ0E7Ozs7Ozs7OztBQU9Ba0QsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjhCLE1BQTNCLEdBQW9DLFNBQVNBLE1BQVQsR0FBa0I7QUFDbEQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBTzJDLGdCQUFQO0FBQ0gsR0F0VHNCLEVBQXZCOztBQXdUQXRGLEVBQUFBLEdBQUcsQ0FBQ3lGLGNBQUosR0FBc0IsWUFBVztBQUU3Qjs7Ozs7OztBQU9BOzs7Ozs7OztBQVFBLGFBQVNBLGNBQVQsQ0FBd0JsRixVQUF4QixFQUFvQztBQUNoQyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFnRixJQUFBQSxjQUFjLENBQUM5RSxTQUFmLENBQXlCK0UsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7Ozs7O0FBUUFELElBQUFBLGNBQWMsQ0FBQ3BGLE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDaEQsYUFBTyxJQUFJa0YsY0FBSixDQUFtQmxGLFVBQW5CLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FrRixJQUFBQSxjQUFjLENBQUMzRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNyRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCdEYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUMyRSxVQUF2RDtBQUNKLGFBQU8xRSxNQUFQO0FBQ0gsS0FORDtBQVFBOzs7Ozs7Ozs7OztBQVNBeUUsSUFBQUEsY0FBYyxDQUFDcEUsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDdkUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0FtRSxJQUFBQSxjQUFjLENBQUNsRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNwRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFkLEVBQTdFOztBQUNBLGFBQU9qRSxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQzJFLFVBQVIsR0FBcUJsRSxNQUFNLENBQUNMLE1BQVAsRUFBckI7QUFDQTs7QUFDSjtBQUNJSyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBTko7QUFRSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7Ozs7OztBQVVBMEUsSUFBQUEsY0FBYyxDQUFDMUQsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM5RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUFzRSxJQUFBQSxjQUFjLENBQUN6RCxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM3QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCM0UsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQzJFLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FQRDtBQVNBOzs7Ozs7Ozs7O0FBUUFELElBQUFBLGNBQWMsQ0FBQ3RELFVBQWYsR0FBNEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDcEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFoQyxFQUNJLE9BQU9yRCxNQUFQO0FBQ0osVUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFkLEVBQWQ7QUFDQSxVQUFJckQsTUFBTSxDQUFDc0QsVUFBUCxJQUFxQixJQUF6QixFQUNJM0UsT0FBTyxDQUFDMkUsVUFBUixHQUFxQnRELE1BQU0sQ0FBQ3NELFVBQVAsS0FBc0IsQ0FBM0M7QUFDSixhQUFPM0UsT0FBUDtBQUNILEtBUEQ7QUFTQTs7Ozs7Ozs7Ozs7QUFTQTBFLElBQUFBLGNBQWMsQ0FBQ25ELFFBQWYsR0FBMEIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDMUQsVUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osVUFBSUgsTUFBTSxHQUFHLEVBQWI7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFDSUosTUFBTSxDQUFDc0QsVUFBUCxHQUFvQixDQUFwQjtBQUNKLFVBQUkzRSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCM0UsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNzRCxVQUFQLEdBQW9CM0UsT0FBTyxDQUFDMkUsVUFBNUI7QUFDSixhQUFPdEQsTUFBUDtBQUNILEtBVEQ7QUFXQTs7Ozs7Ozs7O0FBT0FxRCxJQUFBQSxjQUFjLENBQUM5RSxTQUFmLENBQXlCOEIsTUFBekIsR0FBa0MsU0FBU0EsTUFBVCxHQUFrQjtBQUNoRCxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPOEMsY0FBUDtBQUNILEdBekxvQixFQUFyQjs7QUEyTEF6RixFQUFBQSxHQUFHLENBQUMyRixXQUFKLEdBQW1CLFlBQVc7QUFFMUI7Ozs7OztBQU1BOzs7Ozs7OztBQVFBLGFBQVNBLFdBQVQsQ0FBcUJwRixVQUFyQixFQUFpQztBQUM3QixVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7Ozs7QUFRQWtGLElBQUFBLFdBQVcsQ0FBQ3RGLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDN0MsYUFBTyxJQUFJb0YsV0FBSixDQUFnQnBGLFVBQWhCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FvRixJQUFBQSxXQUFXLENBQUM3RSxNQUFaLEdBQXFCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNsRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixhQUFPVyxNQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBMkUsSUFBQUEsV0FBVyxDQUFDdEUsZUFBWixHQUE4QixTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDcEUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0FxRSxJQUFBQSxXQUFXLENBQUNwRSxNQUFaLEdBQXFCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNqRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVUyRixXQUFkLEVBQTdFOztBQUNBLGFBQU9uRSxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0E7QUFDSUwsWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQUhKO0FBS0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBYkQ7QUFlQTs7Ozs7Ozs7Ozs7O0FBVUE0RSxJQUFBQSxXQUFXLENBQUM1RCxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzNELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQXdFLElBQUFBLFdBQVcsQ0FBQzNELE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzFDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLGFBQU8sSUFBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBNEUsSUFBQUEsV0FBVyxDQUFDeEQsVUFBWixHQUF5QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNqRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTJGLFdBQWhDLEVBQ0ksT0FBT3ZELE1BQVA7QUFDSixhQUFPLElBQUl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTJGLFdBQWQsRUFBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7Ozs7QUFTQUEsSUFBQUEsV0FBVyxDQUFDckQsUUFBWixHQUF1QixTQUFTQSxRQUFULEdBQW9CO0FBQ3ZDLGFBQU8sRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7O0FBT0FxRCxJQUFBQSxXQUFXLENBQUNoRixTQUFaLENBQXNCOEIsTUFBdEIsR0FBK0IsU0FBU0EsTUFBVCxHQUFrQjtBQUM3QyxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPZ0QsV0FBUDtBQUNILEdBOUppQixFQUFsQjs7QUFnS0EzRixFQUFBQSxHQUFHLENBQUM0RixjQUFKLEdBQXNCLFlBQVc7QUFFN0I7Ozs7Ozs7OztBQVNBOzs7Ozs7OztBQVFBLGFBQVNBLGNBQVQsQ0FBd0JyRixVQUF4QixFQUFvQztBQUNoQyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFtRixJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCa0YsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7OztBQU1BRCxJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCbUYsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7OztBQU1BRixJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCb0YsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7Ozs7O0FBUUFILElBQUFBLGNBQWMsQ0FBQ3ZGLE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDaEQsYUFBTyxJQUFJcUYsY0FBSixDQUFtQnJGLFVBQW5CLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FxRixJQUFBQSxjQUFjLENBQUM5RSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNyRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUM4RSxVQUFSLElBQXNCLElBQXRCLElBQThCekYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUM4RSxVQUF2RDtBQUNKLFVBQUk5RSxPQUFPLENBQUMrRSxVQUFSLElBQXNCLElBQXRCLElBQThCMUYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQytFLFVBQXZEO0FBQ0osVUFBSS9FLE9BQU8sQ0FBQ2dGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEIzRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDZ0YsVUFBdkQ7QUFDSixhQUFPL0UsTUFBUDtBQUNILEtBVkQ7QUFZQTs7Ozs7Ozs7Ozs7QUFTQTRFLElBQUFBLGNBQWMsQ0FBQ3ZFLGVBQWYsR0FBaUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3ZFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBc0UsSUFBQUEsY0FBYyxDQUFDckUsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDcEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVNEYsY0FBZCxFQUE3RTs7QUFDQSxhQUFPcEUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUM4RSxVQUFSLEdBQXFCckUsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQytFLFVBQVIsR0FBcUJ0RSxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDZ0YsVUFBUixHQUFxQnZFLE1BQU0sU0FBTixFQUFyQjtBQUNBOztBQUNKO0FBQ0lBLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFaSjtBQWNIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQXRCRDtBQXdCQTs7Ozs7Ozs7Ozs7O0FBVUE2RSxJQUFBQSxjQUFjLENBQUM3RCxlQUFmLEdBQWlDLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzlELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQXlFLElBQUFBLGNBQWMsQ0FBQzVELE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzdDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQzhFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEI5RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDOEUsVUFBeEIsQ0FBTCxFQUNJLE9BQU8sOEJBQVA7QUFDUixVQUFJOUUsT0FBTyxDQUFDK0UsVUFBUixJQUFzQixJQUF0QixJQUE4Qi9FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDK0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJL0UsT0FBTyxDQUFDZ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmhGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDZ0YsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7QUFRQUgsSUFBQUEsY0FBYyxDQUFDekQsVUFBZixHQUE0QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNwRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTRGLGNBQWhDLEVBQ0ksT0FBT3hELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVTRGLGNBQWQsRUFBZDtBQUNBLFVBQUl4RCxNQUFNLENBQUN5RCxVQUFQLElBQXFCLElBQXpCLEVBQ0k5RSxPQUFPLENBQUM4RSxVQUFSLEdBQXFCekQsTUFBTSxDQUFDeUQsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUl6RCxNQUFNLENBQUMwRCxVQUFQLElBQXFCLElBQXpCLEVBQ0kvRSxPQUFPLENBQUMrRSxVQUFSLEdBQXFCeEIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDMEQsVUFBUixDQUEzQjtBQUNKLFVBQUkxRCxNQUFNLENBQUMyRCxVQUFQLElBQXFCLElBQXpCLEVBQ0loRixPQUFPLENBQUNnRixVQUFSLEdBQXFCekIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDMkQsVUFBUixDQUEzQjtBQUNKLGFBQU9oRixPQUFQO0FBQ0gsS0FYRDtBQWFBOzs7Ozs7Ozs7OztBQVNBNkUsSUFBQUEsY0FBYyxDQUFDdEQsUUFBZixHQUEwQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMxRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3lELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQXpELFFBQUFBLE1BQU0sQ0FBQzBELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQTFELFFBQUFBLE1BQU0sQ0FBQzJELFVBQVAsR0FBb0IsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJaEYsT0FBTyxDQUFDOEUsVUFBUixJQUFzQixJQUF0QixJQUE4QjlFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDeUQsVUFBUCxHQUFvQjlFLE9BQU8sQ0FBQzhFLFVBQTVCO0FBQ0osVUFBSTlFLE9BQU8sQ0FBQytFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEIvRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQzBELFVBQVAsR0FBb0J2RCxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQytFLFVBQVQsQ0FBekIsR0FBZ0R6RCxNQUFNLENBQUN0QixPQUFPLENBQUMrRSxVQUFULENBQXRELEdBQTZFL0UsT0FBTyxDQUFDK0UsVUFBekc7QUFDSixVQUFJL0UsT0FBTyxDQUFDZ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmhGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDMkQsVUFBUCxHQUFvQnhELE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDZ0YsVUFBVCxDQUF6QixHQUFnRDFELE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ2dGLFVBQVQsQ0FBdEQsR0FBNkVoRixPQUFPLENBQUNnRixVQUF6RztBQUNKLGFBQU8zRCxNQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7OztBQU9Bd0QsSUFBQUEsY0FBYyxDQUFDakYsU0FBZixDQUF5QjhCLE1BQXpCLEdBQWtDLFNBQVNBLE1BQVQsR0FBa0I7QUFDaEQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBT2lELGNBQVA7QUFDSCxHQXRPb0IsRUFBckI7O0FBd09BNUYsRUFBQUEsR0FBRyxDQUFDZ0csV0FBSixHQUFtQixZQUFXO0FBRTFCOzs7Ozs7O0FBT0E7Ozs7Ozs7O0FBUUEsYUFBU0EsV0FBVCxDQUFxQnpGLFVBQXJCLEVBQWlDO0FBQzdCLFVBQUlBLFVBQUosRUFDSSxLQUFLLElBQUlDLElBQUksR0FBR0osTUFBTSxDQUFDSSxJQUFQLENBQVlELFVBQVosQ0FBWCxFQUFvQ0UsQ0FBQyxHQUFHLENBQTdDLEVBQWdEQSxDQUFDLEdBQUdELElBQUksQ0FBQ0UsTUFBekQsRUFBaUUsRUFBRUQsQ0FBbkU7QUFDSSxZQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7QUFNQXVGLElBQUFBLFdBQVcsQ0FBQ3JGLFNBQVosQ0FBc0JzRixZQUF0QixHQUFxQyxDQUFyQztBQUVBOzs7Ozs7Ozs7QUFRQUQsSUFBQUEsV0FBVyxDQUFDM0YsTUFBWixHQUFxQixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUM3QyxhQUFPLElBQUl5RixXQUFKLENBQWdCekYsVUFBaEIsQ0FBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQXlGLElBQUFBLFdBQVcsQ0FBQ2xGLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ2xELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0M3RixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxjQUFwQyxDQUFwQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixPQUFyQyxFQUF3Q0EsTUFBeEMsQ0FBK0NKLE9BQU8sQ0FBQ2tGLFlBQXZEO0FBQ0osYUFBT2pGLE1BQVA7QUFDSCxLQU5EO0FBUUE7Ozs7Ozs7Ozs7O0FBU0FnRixJQUFBQSxXQUFXLENBQUMzRSxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUNwRSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQTBFLElBQUFBLFdBQVcsQ0FBQ3pFLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ2pELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWQsRUFBN0U7O0FBQ0EsYUFBT3hFLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDa0YsWUFBUixHQUF1QnpFLE1BQU0sQ0FBQ0wsTUFBUCxFQUF2QjtBQUNBOztBQUNKO0FBQ0lLLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFOSjtBQVFIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWhCRDtBQWtCQTs7Ozs7Ozs7Ozs7O0FBVUFpRixJQUFBQSxXQUFXLENBQUNqRSxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzNELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQTZFLElBQUFBLFdBQVcsQ0FBQ2hFLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzFDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDa0YsWUFBeEIsQ0FBTCxFQUNJLE9BQU8sZ0NBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7QUFRQUQsSUFBQUEsV0FBVyxDQUFDN0QsVUFBWixHQUF5QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNqRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWhDLEVBQ0ksT0FBTzVELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWQsRUFBZDtBQUNBLFVBQUk1RCxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLGFBQU9sRixPQUFQO0FBQ0gsS0FQRDtBQVNBOzs7Ozs7Ozs7OztBQVNBaUYsSUFBQUEsV0FBVyxDQUFDMUQsUUFBWixHQUF1QixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUN2RCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjtBQUNBLFVBQUlHLE9BQU8sQ0FBQ0MsUUFBWixFQUNJSixNQUFNLENBQUM2RCxZQUFQLEdBQXNCLENBQXRCO0FBQ0osVUFBSWxGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0JsRixPQUFPLENBQUNrRixZQUE5QjtBQUNKLGFBQU83RCxNQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7QUFPQTRELElBQUFBLFdBQVcsQ0FBQ3JGLFNBQVosQ0FBc0I4QixNQUF0QixHQUErQixTQUFTQSxNQUFULEdBQWtCO0FBQzdDLGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU9xRCxXQUFQO0FBQ0gsR0F6TGlCLEVBQWxCOztBQTJMQWhHLEVBQUFBLEdBQUcsQ0FBQ2tHLGNBQUosR0FBc0IsWUFBVztBQUU3Qjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxjQUFULENBQXdCM0YsVUFBeEIsRUFBb0M7QUFDaEMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BeUYsSUFBQUEsY0FBYyxDQUFDdkYsU0FBZixDQUF5QndGLFVBQXpCLEdBQXNDLENBQXRDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsY0FBYyxDQUFDdkYsU0FBZixDQUF5QnNGLFlBQXpCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7OztBQVFBQyxJQUFBQSxjQUFjLENBQUM3RixNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2hELGFBQU8sSUFBSTJGLGNBQUosQ0FBbUIzRixVQUFuQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBMkYsSUFBQUEsY0FBYyxDQUFDcEYsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDckQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDb0YsVUFBUixJQUFzQixJQUF0QixJQUE4Qi9GLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDb0YsVUFBdkQ7QUFDSixVQUFJcEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDQSxNQUF6QyxDQUFnREosT0FBTyxDQUFDa0YsWUFBeEQ7QUFDSixhQUFPakYsTUFBUDtBQUNILEtBUkQ7QUFVQTs7Ozs7Ozs7Ozs7QUFTQWtGLElBQUFBLGNBQWMsQ0FBQzdFLGVBQWYsR0FBaUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3ZFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBNEUsSUFBQUEsY0FBYyxDQUFDM0UsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDcEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVa0csY0FBZCxFQUE3RTs7QUFDQSxhQUFPMUUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUNvRixVQUFSLEdBQXFCM0UsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQ2tGLFlBQVIsR0FBdUJ6RSxNQUFNLENBQUNMLE1BQVAsRUFBdkI7QUFDQTs7QUFDSjtBQUNJSyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBVEo7QUFXSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FuQkQ7QUFxQkE7Ozs7Ozs7Ozs7OztBQVVBbUYsSUFBQUEsY0FBYyxDQUFDbkUsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM5RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUErRSxJQUFBQSxjQUFjLENBQUNsRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM3QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUNvRixVQUFSLElBQXNCLElBQXRCLElBQThCcEYsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ29GLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsVUFBSXBGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDa0YsWUFBeEIsQ0FBTCxFQUNJLE9BQU8sZ0NBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVZEO0FBWUE7Ozs7Ozs7Ozs7QUFRQUMsSUFBQUEsY0FBYyxDQUFDL0QsVUFBZixHQUE0QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNwRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVWtHLGNBQWhDLEVBQ0ksT0FBTzlELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWtHLGNBQWQsRUFBZDtBQUNBLFVBQUk5RCxNQUFNLENBQUMrRCxVQUFQLElBQXFCLElBQXpCLEVBQ0lwRixPQUFPLENBQUNvRixVQUFSLEdBQXFCL0QsTUFBTSxDQUFDK0QsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUkvRCxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLGFBQU9sRixPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBbUYsSUFBQUEsY0FBYyxDQUFDNUQsUUFBZixHQUEwQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMxRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQytELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQS9ELFFBQUFBLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDSDs7QUFDRCxVQUFJbEYsT0FBTyxDQUFDb0YsVUFBUixJQUFzQixJQUF0QixJQUE4QnBGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDK0QsVUFBUCxHQUFvQnBGLE9BQU8sQ0FBQ29GLFVBQTVCO0FBQ0osVUFBSXBGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0JsRixPQUFPLENBQUNrRixZQUE5QjtBQUNKLGFBQU83RCxNQUFQO0FBQ0gsS0FiRDtBQWVBOzs7Ozs7Ozs7QUFPQThELElBQUFBLGNBQWMsQ0FBQ3ZGLFNBQWYsQ0FBeUI4QixNQUF6QixHQUFrQyxTQUFTQSxNQUFULEdBQWtCO0FBQ2hELGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU91RCxjQUFQO0FBQ0gsR0FoTm9CLEVBQXJCOztBQWtOQWxHLEVBQUFBLEdBQUcsQ0FBQ29HLG9CQUFKLEdBQTRCLFlBQVc7QUFFbkM7Ozs7Ozs7O0FBUUE7Ozs7Ozs7O0FBUUEsYUFBU0Esb0JBQVQsQ0FBOEI3RixVQUE5QixFQUEwQztBQUN0QyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUEyRixJQUFBQSxvQkFBb0IsQ0FBQ3pGLFNBQXJCLENBQStCc0YsWUFBL0IsR0FBOEMsQ0FBOUM7QUFFQTs7Ozs7OztBQU1BRyxJQUFBQSxvQkFBb0IsQ0FBQ3pGLFNBQXJCLENBQStCMEYsVUFBL0IsR0FBNEMsQ0FBNUM7QUFFQTs7Ozs7Ozs7O0FBUUFELElBQUFBLG9CQUFvQixDQUFDL0YsTUFBckIsR0FBOEIsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDdEQsYUFBTyxJQUFJNkYsb0JBQUosQ0FBeUI3RixVQUF6QixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBNkYsSUFBQUEsb0JBQW9CLENBQUN0RixNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDM0QsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDa0YsWUFBdkQ7QUFDSixVQUFJbEYsT0FBTyxDQUFDc0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmpHLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDQSxNQUF6QyxDQUFnREosT0FBTyxDQUFDc0YsVUFBeEQ7QUFDSixhQUFPckYsTUFBUDtBQUNILEtBUkQ7QUFVQTs7Ozs7Ozs7Ozs7QUFTQW9GLElBQUFBLG9CQUFvQixDQUFDL0UsZUFBckIsR0FBdUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQzdFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBOEUsSUFBQUEsb0JBQW9CLENBQUM3RSxNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDMUQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVb0csb0JBQWQsRUFBN0U7O0FBQ0EsYUFBTzVFLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDa0YsWUFBUixHQUF1QnpFLE1BQU0sQ0FBQ0wsTUFBUCxFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJSixZQUFBQSxPQUFPLENBQUNzRixVQUFSLEdBQXFCN0UsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0o7QUFDSUssWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQVRKO0FBV0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7Ozs7QUFVQXFGLElBQUFBLG9CQUFvQixDQUFDckUsZUFBckIsR0FBdUMsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDcEUsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBaUYsSUFBQUEsb0JBQW9CLENBQUNwRSxNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDbkQsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNrRixZQUF4QixDQUFMLEVBQ0ksT0FBTyxnQ0FBUDtBQUNSLFVBQUlsRixPQUFPLENBQUNzRixVQUFSLElBQXNCLElBQXRCLElBQThCdEYsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ3NGLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FWRDtBQVlBOzs7Ozs7Ozs7O0FBUUFELElBQUFBLG9CQUFvQixDQUFDakUsVUFBckIsR0FBa0MsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDMUQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVVvRyxvQkFBaEMsRUFDSSxPQUFPaEUsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVb0csb0JBQWQsRUFBZDtBQUNBLFVBQUloRSxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLFVBQUk3RCxNQUFNLENBQUNpRSxVQUFQLElBQXFCLElBQXpCLEVBQ0l0RixPQUFPLENBQUNzRixVQUFSLEdBQXFCakUsTUFBTSxDQUFDaUUsVUFBUCxLQUFzQixDQUEzQztBQUNKLGFBQU90RixPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBcUYsSUFBQUEsb0JBQW9CLENBQUM5RCxRQUFyQixHQUFnQyxTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUNoRSxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDQTdELFFBQUFBLE1BQU0sQ0FBQ2lFLFVBQVAsR0FBb0IsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJdEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDNkQsWUFBUCxHQUFzQmxGLE9BQU8sQ0FBQ2tGLFlBQTlCO0FBQ0osVUFBSWxGLE9BQU8sQ0FBQ3NGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lFLFVBQVAsR0FBb0J0RixPQUFPLENBQUNzRixVQUE1QjtBQUNKLGFBQU9qRSxNQUFQO0FBQ0gsS0FiRDtBQWVBOzs7Ozs7Ozs7QUFPQWdFLElBQUFBLG9CQUFvQixDQUFDekYsU0FBckIsQ0FBK0I4QixNQUEvQixHQUF3QyxTQUFTQSxNQUFULEdBQWtCO0FBQ3RELGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU95RCxvQkFBUDtBQUNILEdBaE4wQixFQUEzQjs7QUFrTkFwRyxFQUFBQSxHQUFHLENBQUNzRyxhQUFKLEdBQXFCLFlBQVc7QUFFNUI7Ozs7Ozs7QUFPQTs7Ozs7Ozs7QUFRQSxhQUFTQSxhQUFULENBQXVCL0YsVUFBdkIsRUFBbUM7QUFDL0IsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BNkYsSUFBQUEsYUFBYSxDQUFDM0YsU0FBZCxDQUF3QnNGLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7OztBQVFBSyxJQUFBQSxhQUFhLENBQUNqRyxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQy9DLGFBQU8sSUFBSStGLGFBQUosQ0FBa0IvRixVQUFsQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBK0YsSUFBQUEsYUFBYSxDQUFDeEYsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDcEQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDa0YsWUFBdkQ7QUFDSixhQUFPakYsTUFBUDtBQUNILEtBTkQ7QUFRQTs7Ozs7Ozs7Ozs7QUFTQXNGLElBQUFBLGFBQWEsQ0FBQ2pGLGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3RFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBZ0YsSUFBQUEsYUFBYSxDQUFDL0UsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDbkQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBZCxFQUE3RTs7QUFDQSxhQUFPOUUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUNrRixZQUFSLEdBQXVCekUsTUFBTSxDQUFDTCxNQUFQLEVBQXZCO0FBQ0E7O0FBQ0o7QUFDSUssWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQU5KO0FBUUg7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBaEJEO0FBa0JBOzs7Ozs7Ozs7Ozs7QUFVQXVGLElBQUFBLGFBQWEsQ0FBQ3ZFLGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDN0QsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBbUYsSUFBQUEsYUFBYSxDQUFDdEUsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDNUMsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNrRixZQUF4QixDQUFMLEVBQ0ksT0FBTyxnQ0FBUDtBQUNSLGFBQU8sSUFBUDtBQUNILEtBUEQ7QUFTQTs7Ozs7Ozs7OztBQVFBSyxJQUFBQSxhQUFhLENBQUNuRSxVQUFkLEdBQTJCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ25ELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBaEMsRUFDSSxPQUFPbEUsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBZCxFQUFkO0FBQ0EsVUFBSWxFLE1BQU0sQ0FBQzZELFlBQVAsSUFBdUIsSUFBM0IsRUFDSWxGLE9BQU8sQ0FBQ2tGLFlBQVIsR0FBdUI3RCxNQUFNLENBQUM2RCxZQUFQLEtBQXdCLENBQS9DO0FBQ0osYUFBT2xGLE9BQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7O0FBU0F1RixJQUFBQSxhQUFhLENBQUNoRSxRQUFkLEdBQXlCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQ3pELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiO0FBQ0EsVUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQ0lKLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDSixVQUFJbEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDNkQsWUFBUCxHQUFzQmxGLE9BQU8sQ0FBQ2tGLFlBQTlCO0FBQ0osYUFBTzdELE1BQVA7QUFDSCxLQVREO0FBV0E7Ozs7Ozs7OztBQU9Ba0UsSUFBQUEsYUFBYSxDQUFDM0YsU0FBZCxDQUF3QjhCLE1BQXhCLEdBQWlDLFNBQVNBLE1BQVQsR0FBa0I7QUFDL0MsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBTzJELGFBQVA7QUFDSCxHQXpMbUIsRUFBcEI7O0FBMkxBLFNBQU90RyxHQUFQO0FBQ0gsQ0FwdUc4QixFQUF4Qjs7O0FBc3VHUHVHLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQjFHLEtBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKmVzbGludC1kaXNhYmxlIGJsb2NrLXNjb3BlZC12YXIsIGlkLWxlbmd0aCwgbm8tY29udHJvbC1yZWdleCwgbm8tbWFnaWMtbnVtYmVycywgbm8tcHJvdG90eXBlLWJ1aWx0aW5zLCBuby1yZWRlY2xhcmUsIG5vLXNoYWRvdywgbm8tdmFyLCBzb3J0LXZhcnMqL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciAkcHJvdG9idWYgPSByZXF1aXJlKFwiLi9wcm90b2J1ZlwiKTtcblxuLy8gQ29tbW9uIGFsaWFzZXNcbmNvbnN0ICRSZWFkZXIgPSAkcHJvdG9idWYuUmVhZGVyLCAkV3JpdGVyID0gJHByb3RvYnVmLldyaXRlciwgJHV0aWwgPSAkcHJvdG9idWYudXRpbDtcblxuLy8gRXhwb3J0ZWQgcm9vdCBuYW1lc3BhY2VcbmNvbnN0ICRyb290ID0gJHByb3RvYnVmLnJvb3RzW1wiZGVmYXVsdFwiXSB8fCAoJHByb3RvYnVmLnJvb3RzW1wiZGVmYXVsdFwiXSA9IHt9KTtcblxuZXhwb3J0IGNvbnN0IG1zZyA9ICRyb290Lm1zZyA9ICgoKSA9PiB7XG5cbiAgICAvKipcbiAgICAgKiBOYW1lc3BhY2UgbXNnLlxuICAgICAqIEBleHBvcnRzIG1zZ1xuICAgICAqIEBuYW1lc3BhY2VcbiAgICAgKi9cbiAgICBjb25zdCBtc2cgPSB7fTtcblxuICAgIC8qKlxuICAgICAqIE1zZ0NvZGUgZW51bS5cbiAgICAgKiBAbmFtZSBtc2cuTXNnQ29kZVxuICAgICAqIEBlbnVtIHtudW1iZXJ9XG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfRU5UUllfQ01EPTAgVVNFUl9FTlRSWV9DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9FTlRSWV9SRVNVTFQ9MSBVU0VSX0VOVFJZX1JFU1VMVCB2YWx1ZVxuICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBXSE9fRUxTRV9JU19IRVJFX0NNRD0yIFdIT19FTFNFX0lTX0hFUkVfQ01EIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFdIT19FTFNFX0lTX0hFUkVfUkVTVUxUPTMgV0hPX0VMU0VfSVNfSEVSRV9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9NT1ZFX1RPX0NNRD00IFVTRVJfTU9WRV9UT19DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9NT1ZFX1RPX1JFU1VMVD01IFVTRVJfTU9WRV9UT19SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9RVUlUX1JFU1VMVD02IFVTRVJfUVVJVF9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9TVE9QX0NNRD03IFVTRVJfU1RPUF9DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9TVE9QX1JFU1VMVD04IFVTRVJfU1RPUF9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9BVFRLX0NNRD05IFVTRVJfQVRUS19DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9BVFRLX1JFU1VMVD0xMCBVU0VSX0FUVEtfUkVTVUxUIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfU1VCVFJBQ1RfSFBfUkVTVUxUPTExIFVTRVJfU1VCVFJBQ1RfSFBfUkVTVUxUIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfRElFX1JFU1VMVD0xMiBVU0VSX0RJRV9SRVNVTFQgdmFsdWVcbiAgICAgKi9cbiAgICBtc2cuTXNnQ29kZSA9IChmdW5jdGlvbigpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzQnlJZCA9IHt9LCB2YWx1ZXMgPSBPYmplY3QuY3JlYXRlKHZhbHVlc0J5SWQpO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFswXSA9IFwiVVNFUl9FTlRSWV9DTURcIl0gPSAwO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxXSA9IFwiVVNFUl9FTlRSWV9SRVNVTFRcIl0gPSAxO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsyXSA9IFwiV0hPX0VMU0VfSVNfSEVSRV9DTURcIl0gPSAyO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFszXSA9IFwiV0hPX0VMU0VfSVNfSEVSRV9SRVNVTFRcIl0gPSAzO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFs0XSA9IFwiVVNFUl9NT1ZFX1RPX0NNRFwiXSA9IDQ7XG4gICAgICAgIHZhbHVlc1t2YWx1ZXNCeUlkWzVdID0gXCJVU0VSX01PVkVfVE9fUkVTVUxUXCJdID0gNTtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbNl0gPSBcIlVTRVJfUVVJVF9SRVNVTFRcIl0gPSA2O1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFs3XSA9IFwiVVNFUl9TVE9QX0NNRFwiXSA9IDc7XG4gICAgICAgIHZhbHVlc1t2YWx1ZXNCeUlkWzhdID0gXCJVU0VSX1NUT1BfUkVTVUxUXCJdID0gODtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbOV0gPSBcIlVTRVJfQVRUS19DTURcIl0gPSA5O1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxMF0gPSBcIlVTRVJfQVRUS19SRVNVTFRcIl0gPSAxMDtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbMTFdID0gXCJVU0VSX1NVQlRSQUNUX0hQX1JFU1VMVFwiXSA9IDExO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxMl0gPSBcIlVTRVJfRElFX1JFU1VMVFwiXSA9IDEyO1xuICAgICAgICByZXR1cm4gdmFsdWVzO1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlckVudHJ5Q21kID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckVudHJ5Q21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdXNlcklkXSBVc2VyRW50cnlDbWQgdXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7c3RyaW5nfG51bGx9IFtoZXJvQXZhdGFyXSBVc2VyRW50cnlDbWQgaGVyb0F2YXRhclxuICAgICAgICAgKi9cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29uc3RydWN0cyBhIG5ldyBVc2VyRW50cnlDbWQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlckVudHJ5Q21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBjb25zdHJ1Y3RvclxuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5Q21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyRW50cnlDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRW50cnlDbWQgdXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5wcm90b3R5cGUudXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlckVudHJ5Q21kIGhlcm9BdmF0YXIuXG4gICAgICAgICAqIEBtZW1iZXIge3N0cmluZ30gaGVyb0F2YXRhclxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5wcm90b3R5cGUuaGVyb0F2YXRhciA9IFwiXCI7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlckVudHJ5Q21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyRW50cnlDbWQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJFbnRyeUNtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJFbnRyeUNtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlckVudHJ5Q21kLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeUNtZH0gbWVzc2FnZSBVc2VyRW50cnlDbWQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS51c2VySWQpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDIgPSovMTgpLnN0cmluZyhtZXNzYWdlLmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJFbnRyeUNtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlckVudHJ5Q21kLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeUNtZH0gbWVzc2FnZSBVc2VyRW50cnlDbWQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeUNtZH0gVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyRW50cnlDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5oZXJvQXZhdGFyID0gcmVhZGVyLnN0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlckVudHJ5Q21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS51c2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ1c2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzU3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcikpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcImhlcm9BdmF0YXI6IHN0cmluZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyRW50cnlDbWQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyRW50cnlDbWQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSBvYmplY3QudXNlcklkID4+PiAwO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5oZXJvQXZhdGFyICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5oZXJvQXZhdGFyID0gU3RyaW5nKG9iamVjdC5oZXJvQXZhdGFyKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyRW50cnlDbWQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyRW50cnlDbWR9IG1lc3NhZ2UgVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnVzZXJJZCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lmhlcm9BdmF0YXIgPSBcIlwiO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gbWVzc2FnZS51c2VySWQ7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lmhlcm9BdmF0YXIgPSBtZXNzYWdlLmhlcm9BdmF0YXI7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJFbnRyeUNtZCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyRW50cnlDbWQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyRW50cnlSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyRW50cnlSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFt1c2VySWRdIFVzZXJFbnRyeVJlc3VsdCB1c2VySWRcbiAgICAgICAgICogQHByb3BlcnR5IHtzdHJpbmd8bnVsbH0gW2hlcm9BdmF0YXJdIFVzZXJFbnRyeVJlc3VsdCBoZXJvQXZhdGFyXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJFbnRyeVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyRW50cnlSZXN1bHQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyRW50cnlSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJFbnRyeVJlc3VsdChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJFbnRyeVJlc3VsdCB1c2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdXNlcklkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LnByb3RvdHlwZS51c2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRW50cnlSZXN1bHQgaGVyb0F2YXRhci5cbiAgICAgICAgICogQG1lbWJlciB7c3RyaW5nfSBoZXJvQXZhdGFyXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LnByb3RvdHlwZS5oZXJvQXZhdGFyID0gXCJcIjtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VyRW50cnlSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeVJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuY3JlYXRlID0gZnVuY3Rpb24gY3JlYXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVXNlckVudHJ5UmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckVudHJ5UmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyRW50cnlSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5UmVzdWx0fSBtZXNzYWdlIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnVzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMiA9Ki8xOCkuc3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcik7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckVudHJ5UmVzdWx0IG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyRW50cnlSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5UmVzdWx0fSBtZXNzYWdlIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckVudHJ5UmVzdWx0fSBVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSByZWFkZXIuc3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRW50cnlSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNTdHJpbmcobWVzc2FnZS5oZXJvQXZhdGFyKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiaGVyb0F2YXRhcjogc3RyaW5nIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC51c2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IG9iamVjdC51c2VySWQgPj4+IDA7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lmhlcm9BdmF0YXIgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSBTdHJpbmcob2JqZWN0Lmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gbWVzc2FnZSBVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpIHtcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IFwiXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC51c2VySWQgPSBtZXNzYWdlLnVzZXJJZDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IG1lc3NhZ2UuaGVyb0F2YXRhcjtcbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgVXNlckVudHJ5UmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIFVzZXJFbnRyeVJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLldob0Vsc2VJc0hlcmVDbWQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBXaG9FbHNlSXNIZXJlQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVdob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgV2hvRWxzZUlzSGVyZUNtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBXaG9FbHNlSXNIZXJlQ21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVDbWQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFdob0Vsc2VJc0hlcmVDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFdob0Vsc2VJc0hlcmVDbWQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklXaG9FbHNlSXNIZXJlQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBXaG9FbHNlSXNIZXJlQ21kKHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZUNtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZUNtZH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFdob0Vsc2VJc0hlcmVDbWQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLldob0Vsc2VJc0hlcmVDbWQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVDbWR9IG1lc3NhZ2UgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFdob0Vsc2VJc0hlcmVDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZUNtZClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgcmV0dXJuIG5ldyAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZUNtZCgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVDbWR9IG1lc3NhZ2UgV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdCgpIHtcbiAgICAgICAgICAgIHJldHVybiB7fTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBXaG9FbHNlSXNIZXJlQ21kIHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBXaG9FbHNlSXNIZXJlQ21kLnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gV2hvRWxzZUlzSGVyZUNtZDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBXaG9FbHNlSXNIZXJlUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtBcnJheS48bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPnxudWxsfSBbdXNlckluZm9dIFdob0Vsc2VJc0hlcmVSZXN1bHQgdXNlckluZm9cbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgV2hvRWxzZUlzSGVyZVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBXaG9FbHNlSXNIZXJlUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFdob0Vsc2VJc0hlcmVSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgdGhpcy51c2VySW5mbyA9IFtdO1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXaG9FbHNlSXNIZXJlUmVzdWx0IHVzZXJJbmZvLlxuICAgICAgICAgKiBAbWVtYmVyIHtBcnJheS48bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPn0gdXNlckluZm9cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5wcm90b3R5cGUudXNlckluZm8gPSAkdXRpbC5lbXB0eUFycmF5O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFdob0Vsc2VJc0hlcmVSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklXaG9FbHNlSXNIZXJlUmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdH0gV2hvRWxzZUlzSGVyZVJlc3VsdCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBXaG9FbHNlSXNIZXJlUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlckluZm8gIT0gbnVsbCAmJiBtZXNzYWdlLnVzZXJJbmZvLmxlbmd0aClcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLmVuY29kZShtZXNzYWdlLnVzZXJJbmZvW2ldLCB3cml0ZXIudWludDMyKC8qIGlkIDEsIHdpcmVUeXBlIDIgPSovMTApLmZvcmsoKSkubGRlbGltKCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0fSBXaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIShtZXNzYWdlLnVzZXJJbmZvICYmIG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudXNlckluZm8gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySW5mby5wdXNoKCRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSkpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHR9IFdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBXaG9FbHNlSXNIZXJlUmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlckluZm8gIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlckluZm9cIikpIHtcbiAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkobWVzc2FnZS51c2VySW5mbykpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJbmZvOiBhcnJheSBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWVzc2FnZS51c2VySW5mby5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby52ZXJpZnkobWVzc2FnZS51c2VySW5mb1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJbmZvLlwiICsgZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHR9IFdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVSZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnVzZXJJbmZvKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KG9iamVjdC51c2VySW5mbykpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IFR5cGVFcnJvcihcIi5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC51c2VySW5mbzogYXJyYXkgZXhwZWN0ZWRcIik7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySW5mbyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqZWN0LnVzZXJJbmZvLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqZWN0LnVzZXJJbmZvW2ldICE9PSBcIm9iamVjdFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKFwiLm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LnVzZXJJbmZvOiBvYmplY3QgZXhwZWN0ZWRcIik7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudXNlckluZm9baV0gPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5mcm9tT2JqZWN0KG9iamVjdC51c2VySW5mb1tpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5hcnJheXMgfHwgb3B0aW9ucy5kZWZhdWx0cylcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlckluZm8gPSBbXTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJbmZvICYmIG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnVzZXJJbmZvID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBtZXNzYWdlLnVzZXJJbmZvLmxlbmd0aDsgKytqKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QudXNlckluZm9bal0gPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby50b09iamVjdChtZXNzYWdlLnVzZXJJbmZvW2pdLCBvcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgV2hvRWxzZUlzSGVyZVJlc3VsdCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mbyA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckluZm8uXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdXNlcklkXSBVc2VySW5mbyB1c2VySWRcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7c3RyaW5nfG51bGx9IFtoZXJvQXZhdGFyXSBVc2VySW5mbyBoZXJvQXZhdGFyXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV8bnVsbH0gW21vdmVTdGF0ZV0gVXNlckluZm8gbW92ZVN0YXRlXG4gICAgICAgICAgICAgKi9cblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJJbmZvLlxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VySW5mby5cbiAgICAgICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VySW5mb1xuICAgICAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LklVc2VySW5mbz19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBmdW5jdGlvbiBVc2VySW5mbyhwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGtleXMgPSBPYmplY3Qua2V5cyhwcm9wZXJ0aWVzKSwgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgKytpKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBVc2VySW5mbyB1c2VySWQuXG4gICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHVzZXJJZFxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLnVzZXJJZCA9IDA7XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogVXNlckluZm8gaGVyb0F2YXRhci5cbiAgICAgICAgICAgICAqIEBtZW1iZXIge3N0cmluZ30gaGVyb0F2YXRhclxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLmhlcm9BdmF0YXIgPSBcIlwiO1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIFVzZXJJbmZvIG1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAqIEBtZW1iZXIge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV8bnVsbHx1bmRlZmluZWR9IG1vdmVTdGF0ZVxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLm1vdmVTdGF0ZSA9IG51bGw7XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VySW5mbyBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm99IFVzZXJJbmZvIGluc3RhbmNlXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIFVzZXJJbmZvLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VySW5mbyhwcm9wZXJ0aWVzKTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJJbmZvIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LklVc2VySW5mb30gbWVzc2FnZSBVc2VySW5mbyBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS51c2VySWQpO1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMiA9Ki8xOCkuc3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcik7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXRlICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlU3RhdGVcIikpXG4gICAgICAgICAgICAgICAgICAgICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS5lbmNvZGUobWVzc2FnZS5tb3ZlU3RhdGUsIHdyaXRlci51aW50MzIoLyogaWQgMywgd2lyZVR5cGUgMiA9Ki8yNikuZm9yaygpKS5sZGVsaW0oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckluZm8gbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8udmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvfSBtZXNzYWdlIFVzZXJJbmZvIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIFVzZXJJbmZvLmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogRGVjb2RlcyBhIFVzZXJJbmZvIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8oKTtcbiAgICAgICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSByZWFkZXIuc3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhdGUgPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGUuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIERlY29kZXMgYSBVc2VySW5mbyBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIFZlcmlmaWVzIGEgVXNlckluZm8gbWVzc2FnZS5cbiAgICAgICAgICAgICAqIEBmdW5jdGlvbiB2ZXJpZnlcbiAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb1xuICAgICAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ1c2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNTdHJpbmcobWVzc2FnZS5oZXJvQXZhdGFyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcImhlcm9BdmF0YXI6IHN0cmluZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVTdGF0ZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlU3RhdGVcIikpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVycm9yID0gJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlLnZlcmlmeShtZXNzYWdlLm1vdmVTdGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVTdGF0ZS5cIiArIGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJJbmZvIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvKCk7XG4gICAgICAgICAgICAgICAgaWYgKG9iamVjdC51c2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSBvYmplY3QudXNlcklkID4+PiAwO1xuICAgICAgICAgICAgICAgIGlmIChvYmplY3QuaGVyb0F2YXRhciAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSBTdHJpbmcob2JqZWN0Lmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgICAgIGlmIChvYmplY3QubW92ZVN0YXRlICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXRlICE9PSBcIm9iamVjdFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKFwiLm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLm1vdmVTdGF0ZTogb2JqZWN0IGV4cGVjdGVkXCIpO1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVTdGF0ZSA9ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS5mcm9tT2JqZWN0KG9iamVjdC5tb3ZlU3RhdGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlckluZm8gbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm99IG1lc3NhZ2UgVXNlckluZm9cbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8udG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgIG9iamVjdC51c2VySWQgPSAwO1xuICAgICAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlU3RhdGUgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gbWVzc2FnZS51c2VySWQ7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IG1lc3NhZ2UuaGVyb0F2YXRhcjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlU3RhdGUgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVN0YXRlXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXRlID0gJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlLnRvT2JqZWN0KG1lc3NhZ2UubW92ZVN0YXRlLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJJbmZvIHRvIEpTT04uXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgVXNlckluZm8uTW92ZVN0YXRlID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogUHJvcGVydGllcyBvZiBhIE1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAgICAgKiBAaW50ZXJmYWNlIElNb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbZnJvbVBvc1hdIE1vdmVTdGF0ZSBmcm9tUG9zWFxuICAgICAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtmcm9tUG9zWV0gTW92ZVN0YXRlIGZyb21Qb3NZXG4gICAgICAgICAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RvUG9zWF0gTW92ZVN0YXRlIHRvUG9zWFxuICAgICAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFt0b1Bvc1ldIE1vdmVTdGF0ZSB0b1Bvc1lcbiAgICAgICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxMb25nfG51bGx9IFtzdGFydFRpbWVdIE1vdmVTdGF0ZSBzdGFydFRpbWVcbiAgICAgICAgICAgICAgICAgKi9cblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgTW92ZVN0YXRlLlxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb1xuICAgICAgICAgICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIE1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAgICAgKiBAaW1wbGVtZW50cyBJTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5JTW92ZVN0YXRlPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gTW92ZVN0YXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvcGVydGllc1trZXlzW2ldXSAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBNb3ZlU3RhdGUgZnJvbVBvc1guXG4gICAgICAgICAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBmcm9tUG9zWFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLmZyb21Qb3NYID0gMDtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIE1vdmVTdGF0ZSBmcm9tUG9zWS5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IGZyb21Qb3NZXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5wcm90b3R5cGUuZnJvbVBvc1kgPSAwO1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogTW92ZVN0YXRlIHRvUG9zWC5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHRvUG9zWFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnRvUG9zWCA9IDA7XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBNb3ZlU3RhdGUgdG9Qb3NZLlxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdG9Qb3NZXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5wcm90b3R5cGUudG9Qb3NZID0gMDtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIE1vdmVTdGF0ZSBzdGFydFRpbWUuXG4gICAgICAgICAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfExvbmd9IHN0YXJ0VGltZVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnN0YXJ0VGltZSA9ICR1dGlsLkxvbmcgPyAkdXRpbC5Mb25nLmZyb21CaXRzKDAsMCx0cnVlKSA6IDA7XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IE1vdmVTdGF0ZSBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5JTW92ZVN0YXRlPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlIGluc3RhbmNlXG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgTW92ZVN0YXRlLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgTW92ZVN0YXRlKHByb3BlcnRpZXMpO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgTW92ZVN0YXRlIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV9IG1lc3NhZ2UgTW92ZVN0YXRlIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJmcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgNSA9Ki8xMykuZmxvYXQobWVzc2FnZS5mcm9tUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJmcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgNSA9Ki8yMSkuZmxvYXQobWVzc2FnZS5mcm9tUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLnRvUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA0LCB3aXJlVHlwZSA1ID0qLzM3KS5mbG9hdChtZXNzYWdlLnRvUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwic3RhcnRUaW1lXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA1LCB3aXJlVHlwZSAwID0qLzQwKS51aW50NjQobWVzc2FnZS5zdGFydFRpbWUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgTW92ZVN0YXRlIG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV9IG1lc3NhZ2UgTW92ZVN0YXRlIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogRGVjb2RlcyBhIE1vdmVTdGF0ZSBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmZyb21Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5mcm9tUG9zWSA9IHJlYWRlci5mbG9hdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudG9Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50b1Bvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IHJlYWRlci51aW50NjQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBEZWNvZGVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIFZlcmlmaWVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UuZnJvbVBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiZnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UuZnJvbVBvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiZnJvbVBvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5mcm9tUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJmcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5mcm9tUG9zWSAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJmcm9tUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UudG9Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInRvUG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UudG9Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInRvUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnN0YXJ0VGltZSkgJiYgIShtZXNzYWdlLnN0YXJ0VGltZSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5zdGFydFRpbWUubG93KSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5zdGFydFRpbWUuaGlnaCkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0YXJ0VGltZTogaW50ZWdlcnxMb25nIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBDcmVhdGVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGV9IE1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JqZWN0LmZyb21Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmZyb21Qb3NYID0gTnVtYmVyKG9iamVjdC5mcm9tUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3QuZnJvbVBvc1kgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuZnJvbVBvc1kgPSBOdW1iZXIob2JqZWN0LmZyb21Qb3NZKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iamVjdC50b1Bvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudG9Qb3NYID0gTnVtYmVyKG9iamVjdC50b1Bvc1gpO1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JqZWN0LnRvUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50b1Bvc1kgPSBOdW1iZXIob2JqZWN0LnRvUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3Quc3RhcnRUaW1lICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAobWVzc2FnZS5zdGFydFRpbWUgPSAkdXRpbC5Mb25nLmZyb21WYWx1ZShvYmplY3Quc3RhcnRUaW1lKSkudW5zaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIG9iamVjdC5zdGFydFRpbWUgPT09IFwic3RyaW5nXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5zdGFydFRpbWUgPSBwYXJzZUludChvYmplY3Quc3RhcnRUaW1lLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0VGltZSA9PT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IG9iamVjdC5zdGFydFRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0VGltZSA9PT0gXCJvYmplY3RcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IG5ldyAkdXRpbC5Mb25nQml0cyhvYmplY3Quc3RhcnRUaW1lLmxvdyA+Pj4gMCwgb2JqZWN0LnN0YXJ0VGltZS5oaWdoID4+PiAwKS50b051bWJlcih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIE1vdmVTdGF0ZSBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gbWVzc2FnZSBNb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QuZnJvbVBvc1ggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NZID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdC50b1Bvc1ggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnRvUG9zWSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsb25nID0gbmV3ICR1dGlsLkxvbmcoMCwgMCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IGxvbmcudG9TdHJpbmcoKSA6IG9wdGlvbnMubG9uZ3MgPT09IE51bWJlciA/IGxvbmcudG9OdW1iZXIoKSA6IGxvbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3Quc3RhcnRUaW1lID0gb3B0aW9ucy5sb25ncyA9PT0gU3RyaW5nID8gXCIwXCIgOiAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLmZyb21Qb3NYKSA/IFN0cmluZyhtZXNzYWdlLmZyb21Qb3NYKSA6IG1lc3NhZ2UuZnJvbVBvc1g7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLmZyb21Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLmZyb21Qb3NZKSA6IG1lc3NhZ2UuZnJvbVBvc1k7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QudG9Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnRvUG9zWCkgPyBTdHJpbmcobWVzc2FnZS50b1Bvc1gpIDogbWVzc2FnZS50b1Bvc1g7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QudG9Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnRvUG9zWSkgPyBTdHJpbmcobWVzc2FnZS50b1Bvc1kpIDogbWVzc2FnZS50b1Bvc1k7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2Uuc3RhcnRUaW1lID09PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdC5zdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyBTdHJpbmcobWVzc2FnZS5zdGFydFRpbWUpIDogbWVzc2FnZS5zdGFydFRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/ICR1dGlsLkxvbmcucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobWVzc2FnZS5zdGFydFRpbWUpIDogb3B0aW9ucy5sb25ncyA9PT0gTnVtYmVyID8gbmV3ICR1dGlsLkxvbmdCaXRzKG1lc3NhZ2Uuc3RhcnRUaW1lLmxvdyA+Pj4gMCwgbWVzc2FnZS5zdGFydFRpbWUuaGlnaCA+Pj4gMCkudG9OdW1iZXIodHJ1ZSkgOiBtZXNzYWdlLnN0YXJ0VGltZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQ29udmVydHMgdGhpcyBNb3ZlU3RhdGUgdG8gSlNPTi5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBNb3ZlU3RhdGU7XG4gICAgICAgICAgICB9KSgpO1xuXG4gICAgICAgICAgICByZXR1cm4gVXNlckluZm87XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgcmV0dXJuIFdob0Vsc2VJc0hlcmVSZXN1bHQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyTW92ZVRvQ21kID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlck1vdmVUb0NtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAaW50ZXJmYWNlIElVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1hdIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1ldIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NZXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlVG9Qb3NYXSBVc2VyTW92ZVRvQ21kIG1vdmVUb1Bvc1hcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW21vdmVUb1Bvc1ldIFVzZXJNb3ZlVG9DbWQgbW92ZVRvUG9zWVxuICAgICAgICAgKi9cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29uc3RydWN0cyBhIG5ldyBVc2VyTW92ZVRvQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJNb3ZlVG9DbWQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBjb25zdHJ1Y3RvclxuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlck1vdmVUb0NtZChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NYLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVGcm9tUG9zWFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvQ21kLnByb3RvdHlwZS5tb3ZlRnJvbVBvc1ggPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvQ21kIG1vdmVGcm9tUG9zWS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBtb3ZlRnJvbVBvc1lcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5wcm90b3R5cGUubW92ZUZyb21Qb3NZID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb0NtZCBtb3ZlVG9Qb3NYLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVUb1Bvc1hcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5wcm90b3R5cGUubW92ZVRvUG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9DbWQgbW92ZVRvUG9zWS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBtb3ZlVG9Qb3NZXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQucHJvdG90eXBlLm1vdmVUb1Bvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJNb3ZlVG9DbWQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyTW92ZVRvQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb0NtZH0gVXNlck1vdmVUb0NtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyTW92ZVRvQ21kKHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlck1vdmVUb0NtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlck1vdmVUb0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZH0gbWVzc2FnZSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlRnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSA1ID0qLzEzKS5mbG9hdChtZXNzYWdlLm1vdmVGcm9tUG9zWCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDUgPSovMjEpLmZsb2F0KG1lc3NhZ2UubW92ZUZyb21Qb3NZKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1ggIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLm1vdmVUb1Bvc1gpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDQsIHdpcmVUeXBlIDUgPSovMzcpLmZsb2F0KG1lc3NhZ2UubW92ZVRvUG9zWSk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlck1vdmVUb0NtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlck1vdmVUb0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZH0gbWVzc2FnZSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJNb3ZlVG9DbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvQ21kfSBVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlck1vdmVUb0NtZCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVGcm9tUG9zWCA9IHJlYWRlci5mbG9hdCgpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NZID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgNDpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NZID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb0NtZH0gVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlck1vdmVUb0NtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlRnJvbVBvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVGcm9tUG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVGcm9tUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlLm1vdmVUb1Bvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVUb1Bvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlVG9Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlVG9Qb3NZOiBudW1iZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgVXNlck1vdmVUb0NtZCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvQ21kfSBVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvQ21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyTW92ZVRvQ21kKVxuICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICBsZXQgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlck1vdmVUb0NtZCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlRnJvbVBvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVGcm9tUG9zWCA9IE51bWJlcihvYmplY3QubW92ZUZyb21Qb3NYKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZUZyb21Qb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgPSBOdW1iZXIob2JqZWN0Lm1vdmVGcm9tUG9zWSk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVUb1Bvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1ggPSBOdW1iZXIob2JqZWN0Lm1vdmVUb1Bvc1gpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlVG9Qb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NZID0gTnVtYmVyKG9iamVjdC5tb3ZlVG9Qb3NZKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJNb3ZlVG9DbWR9IG1lc3NhZ2UgVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpIHtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NYID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NZID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVUb1Bvc1kgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVGcm9tUG9zWCkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlRnJvbVBvc1gpIDogbWVzc2FnZS5tb3ZlRnJvbVBvc1g7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1kgPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2UubW92ZUZyb21Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVGcm9tUG9zWSkgOiBtZXNzYWdlLm1vdmVGcm9tUG9zWTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWCA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlVG9Qb3NYKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVUb1Bvc1gpIDogbWVzc2FnZS5tb3ZlVG9Qb3NYO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlVG9Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVUb1Bvc1kpID8gU3RyaW5nKG1lc3NhZ2UubW92ZVRvUG9zWSkgOiBtZXNzYWdlLm1vdmVUb1Bvc1k7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJNb3ZlVG9DbWQgdG8gSlNPTi5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvSlNPTlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyTW92ZVRvQ21kO1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlck1vdmVUb1Jlc3VsdCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJNb3ZlVG9SZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbbW92ZVVzZXJJZF0gVXNlck1vdmVUb1Jlc3VsdCBtb3ZlVXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1hdIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1ldIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NZXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlVG9Qb3NYXSBVc2VyTW92ZVRvUmVzdWx0IG1vdmVUb1Bvc1hcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW21vdmVUb1Bvc1ldIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZVRvUG9zWVxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxMb25nfG51bGx9IFttb3ZlU3RhcnRUaW1lXSBVc2VyTW92ZVRvUmVzdWx0IG1vdmVTdGFydFRpbWVcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlck1vdmVUb1Jlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyTW92ZVRvUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJNb3ZlVG9SZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvUmVzdWx0IG1vdmVVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZVVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb1Jlc3VsdCBtb3ZlRnJvbVBvc1guXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQucHJvdG90eXBlLm1vdmVGcm9tUG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NZLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVGcm9tUG9zWVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlRnJvbVBvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvUmVzdWx0IG1vdmVUb1Bvc1guXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZVRvUG9zWFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlVG9Qb3NYID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb1Jlc3VsdCBtb3ZlVG9Qb3NZLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVUb1Bvc1lcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC5wcm90b3R5cGUubW92ZVRvUG9zWSA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZVN0YXJ0VGltZS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfExvbmd9IG1vdmVTdGFydFRpbWVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC5wcm90b3R5cGUubW92ZVN0YXJ0VGltZSA9ICR1dGlsLkxvbmcgPyAkdXRpbC5Mb25nLmZyb21CaXRzKDAsMCx0cnVlKSA6IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlck1vdmVUb1Jlc3VsdCBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBjcmVhdGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvUmVzdWx0fSBVc2VyTW92ZVRvUmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJNb3ZlVG9SZXN1bHQocHJvcGVydGllcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyTW92ZVRvUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyTW92ZVRvUmVzdWx0fSBtZXNzYWdlIFVzZXJNb3ZlVG9SZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LmVuY29kZSA9IGZ1bmN0aW9uIGVuY29kZShtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIGlmICghd3JpdGVyKVxuICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS5tb3ZlVXNlcklkKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVGcm9tUG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZUZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgNSA9Ki8yMSkuZmxvYXQobWVzc2FnZS5tb3ZlRnJvbVBvc1gpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlRnJvbVBvc1lcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLm1vdmVGcm9tUG9zWSk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlVG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgNCwgd2lyZVR5cGUgNSA9Ki8zNykuZmxvYXQobWVzc2FnZS5tb3ZlVG9Qb3NYKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVUb1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA1LCB3aXJlVHlwZSA1ID0qLzQ1KS5mbG9hdChtZXNzYWdlLm1vdmVUb1Bvc1kpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZVN0YXJ0VGltZVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDYsIHdpcmVUeXBlIDAgPSovNDgpLnVpbnQ2NChtZXNzYWdlLm1vdmVTdGFydFRpbWUpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJNb3ZlVG9SZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJNb3ZlVG9SZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHR9IG1lc3NhZ2UgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb1Jlc3VsdH0gVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJNb3ZlVG9SZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVXNlcklkID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1ggPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA1OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA2OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVTdGFydFRpbWUgPSByZWFkZXIudWludDY0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb1Jlc3VsdH0gVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlVXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwibW92ZVVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlRnJvbVBvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlRnJvbVBvc1k6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlVG9Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlVG9Qb3NYOiBudW1iZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZVRvUG9zWSAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwibW92ZVRvUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlU3RhcnRUaW1lICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVTdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlU3RhcnRUaW1lKSAmJiAhKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmxvdykgJiYgJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UubW92ZVN0YXJ0VGltZS5oaWdoKSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVTdGFydFRpbWU6IGludGVnZXJ8TG9uZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJNb3ZlVG9SZXN1bHR9IFVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJNb3ZlVG9SZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyTW92ZVRvUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVVc2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVVc2VySWQgPSBvYmplY3QubW92ZVVzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZUZyb21Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1ggPSBOdW1iZXIob2JqZWN0Lm1vdmVGcm9tUG9zWCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVGcm9tUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NZID0gTnVtYmVyKG9iamVjdC5tb3ZlRnJvbVBvc1kpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlVG9Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NYID0gTnVtYmVyKG9iamVjdC5tb3ZlVG9Qb3NYKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZVRvUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZVRvUG9zWSA9IE51bWJlcihvYmplY3QubW92ZVRvUG9zWSk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVTdGFydFRpbWUgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZylcbiAgICAgICAgICAgICAgICAgICAgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSA9ICR1dGlsLkxvbmcuZnJvbVZhbHVlKG9iamVjdC5tb3ZlU3RhcnRUaW1lKSkudW5zaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXJ0VGltZSA9PT0gXCJzdHJpbmdcIilcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID0gcGFyc2VJbnQob2JqZWN0Lm1vdmVTdGFydFRpbWUsIDEwKTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0Lm1vdmVTdGFydFRpbWUgPT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZVN0YXJ0VGltZSA9IG9iamVjdC5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXJ0VGltZSA9PT0gXCJvYmplY3RcIilcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID0gbmV3ICR1dGlsLkxvbmdCaXRzKG9iamVjdC5tb3ZlU3RhcnRUaW1lLmxvdyA+Pj4gMCwgb2JqZWN0Lm1vdmVTdGFydFRpbWUuaGlnaCA+Pj4gMCkudG9OdW1iZXIodHJ1ZSk7XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyTW92ZVRvUmVzdWx0fSBtZXNzYWdlIFVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVVc2VySWQgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1ggPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1kgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlVG9Qb3NYID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWSA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKCR1dGlsLkxvbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxvbmcgPSBuZXcgJHV0aWwuTG9uZygwLCAwLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVTdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyBsb25nLnRvU3RyaW5nKCkgOiBvcHRpb25zLmxvbmdzID09PSBOdW1iZXIgPyBsb25nLnRvTnVtYmVyKCkgOiBsb25nO1xuICAgICAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IFwiMFwiIDogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVVzZXJJZCA9IG1lc3NhZ2UubW92ZVVzZXJJZDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVGcm9tUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlRnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVGcm9tUG9zWCA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlRnJvbVBvc1gpID8gU3RyaW5nKG1lc3NhZ2UubW92ZUZyb21Qb3NYKSA6IG1lc3NhZ2UubW92ZUZyb21Qb3NYO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVGcm9tUG9zWSkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlRnJvbVBvc1kpIDogbWVzc2FnZS5tb3ZlRnJvbVBvc1k7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVUb1Bvc1ggPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2UubW92ZVRvUG9zWCkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlVG9Qb3NYKSA6IG1lc3NhZ2UubW92ZVRvUG9zWDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWSA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlVG9Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVUb1Bvc1kpIDogbWVzc2FnZS5tb3ZlVG9Qb3NZO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlU3RhcnRUaW1lXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID09PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IFN0cmluZyhtZXNzYWdlLm1vdmVTdGFydFRpbWUpIDogbWVzc2FnZS5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVTdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyAkdXRpbC5Mb25nLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSkgOiBvcHRpb25zLmxvbmdzID09PSBOdW1iZXIgPyBuZXcgJHV0aWwuTG9uZ0JpdHMobWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmxvdyA+Pj4gMCwgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmhpZ2ggPj4+IDApLnRvTnVtYmVyKHRydWUpIDogbWVzc2FnZS5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyTW92ZVRvUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlck1vdmVUb1Jlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJRdWl0UmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3F1aXRVc2VySWRdIFVzZXJRdWl0UmVzdWx0IHF1aXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyUXVpdFJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyUXVpdFJlc3VsdChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJRdWl0UmVzdWx0IHF1aXRVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gcXVpdFVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQucHJvdG90eXBlLnF1aXRVc2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJRdWl0UmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyUXVpdFJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyUXVpdFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnF1aXRVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInF1aXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnF1aXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyUXVpdFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyUXVpdFJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyUXVpdFJlc3VsdH0gVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlclF1aXRSZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5xdWl0VXNlcklkID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5xdWl0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInF1aXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5xdWl0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwicXVpdFVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyUXVpdFJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlclF1aXRSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyUXVpdFJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5xdWl0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5xdWl0VXNlcklkID0gb2JqZWN0LnF1aXRVc2VySWQgPj4+IDA7XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyUXVpdFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnF1aXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UucXVpdFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJxdWl0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5xdWl0VXNlcklkID0gbWVzc2FnZS5xdWl0VXNlcklkO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyUXVpdFJlc3VsdCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJRdWl0UmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlclF1aXRSZXN1bHQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyU3RvcENtZCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJTdG9wQ21kXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN0b3BDbWRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcENtZD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN0b3BDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJTdG9wQ21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kIGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcENtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyU3RvcENtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJTdG9wQ21kIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyU3RvcENtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wQ21kfSBtZXNzYWdlIFVzZXJTdG9wQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIHJldHVybiB3cml0ZXI7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyU3RvcENtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlclN0b3BDbWQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcENtZH0gbWVzc2FnZSBVc2VyU3RvcENtZCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmVuY29kZShtZXNzYWdlLCB3cml0ZXIpLmxkZWxpbSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdG9wQ21kKCk7XG4gICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgIGxldCB0YWcgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcENtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJTdG9wQ21kIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3RvcENtZH0gVXNlclN0b3BDbWRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyU3RvcENtZClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgcmV0dXJuIG5ldyAkcm9vdC5tc2cuVXNlclN0b3BDbWQoKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlclN0b3BDbWQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJTdG9wQ21kfSBtZXNzYWdlIFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdCgpIHtcbiAgICAgICAgICAgIHJldHVybiB7fTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyU3RvcENtZCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BDbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlclN0b3BDbWQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyU3RvcFJlc3VsdCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wVXNlcklkXSBVc2VyU3RvcFJlc3VsdCBzdG9wVXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wQXRQb3NYXSBVc2VyU3RvcFJlc3VsdCBzdG9wQXRQb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wQXRQb3NZXSBVc2VyU3RvcFJlc3VsdCBzdG9wQXRQb3NZXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcFJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN0b3BSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyU3RvcFJlc3VsdCBzdG9wVXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHN0b3BVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LnByb3RvdHlwZS5zdG9wVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlclN0b3BSZXN1bHQgc3RvcEF0UG9zWC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBzdG9wQXRQb3NYXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5wcm90b3R5cGUuc3RvcEF0UG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJTdG9wUmVzdWx0IHN0b3BBdFBvc1kuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gc3RvcEF0UG9zWVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQucHJvdG90eXBlLnN0b3BBdFBvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJTdG9wUmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wUmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyU3RvcFJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyU3RvcFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wUmVzdWx0fSBtZXNzYWdlIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0b3BVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInN0b3BVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnN0b3BVc2VySWQpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwic3RvcEF0UG9zWFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDUgPSovMjEpLmZsb2F0KG1lc3NhZ2Uuc3RvcEF0UG9zWCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJzdG9wQXRQb3NZXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMywgd2lyZVR5cGUgNSA9Ki8yOSkuZmxvYXQobWVzc2FnZS5zdG9wQXRQb3NZKTtcbiAgICAgICAgICAgIHJldHVybiB3cml0ZXI7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlclN0b3BSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcFJlc3VsdH0gbWVzc2FnZSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmVuY29kZShtZXNzYWdlLCB3cml0ZXIpLmxkZWxpbSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdG9wUmVzdWx0KCk7XG4gICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgIGxldCB0YWcgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3RvcFVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1ggPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJTdG9wUmVzdWx0fSBVc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UuXG4gICAgICAgICAqIEBmdW5jdGlvbiB2ZXJpZnlcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2Uuc3RvcFVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0b3BVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0b3BBdFBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwic3RvcEF0UG9zWFwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwic3RvcEF0UG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN0b3BBdFBvc1lcIikpXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlLnN0b3BBdFBvc1kgIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0b3BBdFBvc1k6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlclN0b3BSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyU3RvcFJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5zdG9wVXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zdG9wVXNlcklkID0gb2JqZWN0LnN0b3BVc2VySWQgPj4+IDA7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnN0b3BBdFBvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1ggPSBOdW1iZXIob2JqZWN0LnN0b3BBdFBvc1gpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5zdG9wQXRQb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zdG9wQXRQb3NZID0gTnVtYmVyKG9iamVjdC5zdG9wQXRQb3NZKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuVXNlclN0b3BSZXN1bHR9IG1lc3NhZ2UgVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5kZWZhdWx0cykge1xuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wVXNlcklkID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3Quc3RvcEF0UG9zWCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnN0b3BBdFBvc1kgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wVXNlcklkID0gbWVzc2FnZS5zdG9wVXNlcklkO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wQXRQb3NYXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wQXRQb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnN0b3BBdFBvc1gpID8gU3RyaW5nKG1lc3NhZ2Uuc3RvcEF0UG9zWCkgOiBtZXNzYWdlLnN0b3BBdFBvc1g7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN0b3BBdFBvc1lcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnN0b3BBdFBvc1kgPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2Uuc3RvcEF0UG9zWSkgPyBTdHJpbmcobWVzc2FnZS5zdG9wQXRQb3NZKSA6IG1lc3NhZ2Uuc3RvcEF0UG9zWTtcbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgVXNlclN0b3BSZXN1bHQgdG8gSlNPTi5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvSlNPTlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIFVzZXJTdG9wUmVzdWx0O1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlckF0dGtDbWQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyQXR0a0NtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAaW50ZXJmYWNlIElVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdGFyZ2V0VXNlcklkXSBVc2VyQXR0a0NtZCB0YXJnZXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlckF0dGtDbWQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlckF0dGtDbWQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyQXR0a0NtZChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJBdHRrQ21kIHRhcmdldFVzZXJJZC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSB0YXJnZXRVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnByb3RvdHlwZS50YXJnZXRVc2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJBdHRrQ21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckF0dGtDbWR9IFVzZXJBdHRrQ21kIGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyQXR0a0NtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJBdHRrQ21kIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyQXR0a0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kfSBtZXNzYWdlIFVzZXJBdHRrQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS50YXJnZXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJBdHRrQ21kIG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyQXR0a0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kfSBtZXNzYWdlIFVzZXJBdHRrQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a0NtZH0gVXNlckF0dGtDbWRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlckF0dGtDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a0NtZH0gVXNlckF0dGtDbWRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS50YXJnZXRVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ0YXJnZXRVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgVXNlckF0dGtDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJBdHRrQ21kfSBVc2VyQXR0a0NtZFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJBdHRrQ21kKVxuICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICBsZXQgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlckF0dGtDbWQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJBdHRrQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyQXR0a0NtZH0gbWVzc2FnZSBVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKVxuICAgICAgICAgICAgICAgIG9iamVjdC50YXJnZXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJBdHRrQ21kIHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyQXR0a0NtZDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJBdHRrUmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckF0dGtSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW2F0dGtVc2VySWRdIFVzZXJBdHRrUmVzdWx0IGF0dGtVc2VySWRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlckF0dGtSZXN1bHQgdGFyZ2V0VXNlcklkXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJBdHRrUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJBdHRrUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyQXR0a1Jlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlckF0dGtSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyQXR0a1Jlc3VsdCBhdHRrVXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IGF0dGtVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnByb3RvdHlwZS5hdHRrVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlckF0dGtSZXN1bHQgdGFyZ2V0VXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHRhcmdldFVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtSZXN1bHQucHJvdG90eXBlLnRhcmdldFVzZXJJZCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlckF0dGtSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJBdHRrUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckF0dGtSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJBdHRrUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHR9IG1lc3NhZ2UgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuYXR0a1VzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwiYXR0a1VzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDEsIHdpcmVUeXBlIDAgPSovOCkudWludDMyKG1lc3NhZ2UuYXR0a1VzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDAgPSovMTYpLnVpbnQzMihtZXNzYWdlLnRhcmdldFVzZXJJZCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJBdHRrUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHR9IG1lc3NhZ2UgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJBdHRrUmVzdWx0fSBVc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyQXR0a1Jlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmF0dGtVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a1Jlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyQXR0a1Jlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmF0dGtVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiYXR0a1VzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLmF0dGtVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJhdHRrVXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UudGFyZ2V0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidGFyZ2V0VXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyQXR0a1Jlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJBdHRrUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LmF0dGtVc2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmF0dGtVc2VySWQgPSBvYmplY3QuYXR0a1VzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyQXR0a1Jlc3VsdH0gbWVzc2FnZSBVc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LmF0dGtVc2VySWQgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC50YXJnZXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuYXR0a1VzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJhdHRrVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5hdHRrVXNlcklkID0gbWVzc2FnZS5hdHRrVXNlcklkO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJBdHRrUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtSZXN1bHQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyQXR0a1Jlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlclN1YnRyYWN0SHBSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlclN1YnRyYWN0SHBSZXN1bHQgdGFyZ2V0VXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdWJ0cmFjdEhwXSBVc2VyU3VidHJhY3RIcFJlc3VsdCBzdWJ0cmFjdEhwXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdWJ0cmFjdEhwUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3VidHJhY3RIcFJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN1YnRyYWN0SHBSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyU3VidHJhY3RIcFJlc3VsdCB0YXJnZXRVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdGFyZ2V0VXNlcklkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5wcm90b3R5cGUudGFyZ2V0VXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlclN1YnRyYWN0SHBSZXN1bHQgc3VidHJhY3RIcC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBzdWJ0cmFjdEhwXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5wcm90b3R5cGUuc3VidHJhY3RIcCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlclN1YnRyYWN0SHBSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJTdWJ0cmFjdEhwUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHR9IG1lc3NhZ2UgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnRhcmdldFVzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdWJ0cmFjdEhwICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJzdWJ0cmFjdEhwXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMCA9Ki8xNikudWludDMyKG1lc3NhZ2Uuc3VidHJhY3RIcCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHR9IG1lc3NhZ2UgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0fSBVc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnRhcmdldFVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN1YnRyYWN0SHAgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyU3VidHJhY3RIcFJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyU3VidHJhY3RIcFJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS50YXJnZXRVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ0YXJnZXRVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN1YnRyYWN0SHAgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwic3VidHJhY3RIcFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnN1YnRyYWN0SHApKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJzdWJ0cmFjdEhwOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnRhcmdldFVzZXJJZCAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UudGFyZ2V0VXNlcklkID0gb2JqZWN0LnRhcmdldFVzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3Quc3VidHJhY3RIcCAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3VidHJhY3RIcCA9IG9iamVjdC5zdWJ0cmFjdEhwID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gbWVzc2FnZSBVc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnRhcmdldFVzZXJJZCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnN1YnRyYWN0SHAgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdWJ0cmFjdEhwICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN1YnRyYWN0SHBcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnN1YnRyYWN0SHAgPSBtZXNzYWdlLnN1YnRyYWN0SHA7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN1YnRyYWN0SHBSZXN1bHQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyU3VidHJhY3RIcFJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJEaWVSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyRGllUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlckRpZVJlc3VsdCB0YXJnZXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlckRpZVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyRGllUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJEaWVSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRGllUmVzdWx0IHRhcmdldFVzZXJJZC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSB0YXJnZXRVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC5wcm90b3R5cGUudGFyZ2V0VXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VyRGllUmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckRpZVJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJEaWVSZXN1bHR9IFVzZXJEaWVSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuY3JlYXRlID0gZnVuY3Rpb24gY3JlYXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVXNlckRpZVJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJEaWVSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJEaWVSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHR9IG1lc3NhZ2UgVXNlckRpZVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS50YXJnZXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJEaWVSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJEaWVSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHR9IG1lc3NhZ2UgVXNlckRpZVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRGllUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJEaWVSZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRGllUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlckRpZVJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UudGFyZ2V0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidGFyZ2V0VXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJEaWVSZXN1bHQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlckRpZVJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJEaWVSZXN1bHQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJEaWVSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuVXNlckRpZVJlc3VsdH0gbWVzc2FnZSBVc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5kZWZhdWx0cylcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gMDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnRhcmdldFVzZXJJZCA9IG1lc3NhZ2UudGFyZ2V0VXNlcklkO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyRGllUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRGllUmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlckRpZVJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgcmV0dXJuIG1zZztcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gJHJvb3Q7XG4iXX0=
//------QC-SOURCE-SPLIT------
