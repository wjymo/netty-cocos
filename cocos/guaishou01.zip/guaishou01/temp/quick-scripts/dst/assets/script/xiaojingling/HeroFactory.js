
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/HeroFactory.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f45fepUk19OLqYbfIDphft/', 'HeroFactory');
// script/xiaojingling/HeroFactory.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Async_1 = require("./Async");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BUNDLE_NAME = "prefab";
var HeroFacyor = /** @class */ (function (_super) {
    __extends(HeroFacyor, _super);
    function HeroFacyor() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // onLoad () {}
    HeroFacyor.prototype.start = function () {
    };
    HeroFacyor.createAsync = function (heroName, funCallback) {
        if (heroName == null) {
            return;
        }
        var loadBundle = cc.assetManager.getBundle(BUNDLE_NAME);
        var loadPrefab = null;
        Async_1.default.seriez(function (funYesContinue) {
            if (loadBundle != null) {
                funYesContinue();
                return;
            }
            cc.assetManager.loadBundle(BUNDLE_NAME, function (error, bundle) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                loadBundle = bundle;
                funYesContinue();
            });
        }, function (funYesContinue) {
            loadPrefab = loadBundle.get(heroName, cc.Prefab);
            if (null != loadPrefab) {
                funYesContinue();
                return;
            }
            loadBundle.load(heroName, cc.Prefab, function (error, prefab) {
                if (error != null) {
                    cc.error("heroName:" + heroName + "\u627E\u4E0D\u5230\u5BF9\u5E94\u9884\u5236\u4F53", error);
                    return;
                }
                loadPrefab = prefab;
                funYesContinue();
            });
        }, function (funYesContinue) {
            var mainBundle = cc.assetManager.getBundle("main");
            mainBundle.preloadDir("spine/xiaojingling/" + heroName, function (error) {
                if (error != null) {
                    cc.error(error);
                    return;
                }
                funYesContinue();
            });
        }, function (funYesContinue) {
            if (loadPrefab == null) {
                cc.error("loadPrefab\u4E3A\u7A7A\uFF0C\u540D\u5B57\uFF1A" + heroName);
                return;
            }
            var heroNode = cc.instantiate(loadPrefab);
            funCallback(heroNode);
        });
        // if(loadBundle==null){
        //     cc.assetManager.loadBundle(BUNDLE_NAME,(error:Error,bundle:cc.AssetManager.Bundle)=>{
        //         if(error!=null){
        //             cc.error(error);
        //             return;
        //         }
        //         let loadPrefab = bundle.get(heroName,cc.Prefab);
        //         if(null==loadPrefab){
        //             bundle.load(heroName,cc.Prefab,(error:Error,prefab:cc.Prefab)=>{
        //                 if(error!=null){
        //                     cc.error(error);
        //                     return;
        //                 }
        //                 let mainBundle = cc.assetManager.getBundle("main");
        //                 mainBundle.preloadDir(`spine/${heroName}`,(error:Error)=>{
        //                     if(error!=null){
        //                         cc.error(error);
        //                         return;
        //                     }
        //                     let heroNode = cc.instantiate(prefab);
        //                     funCallback(heroNode)
        //                 })
        //             });
        //         }
        //     });
        // }
    };
    HeroFacyor = __decorate([
        ccclass
    ], HeroFacyor);
    return HeroFacyor;
}(cc.Component));
exports.default = HeroFacyor;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEhlcm9GYWN0b3J5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRWxGLGlDQUEyQjtBQUVyQixJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUMxQyxJQUFNLFdBQVcsR0FBQyxRQUFRLENBQUM7QUFFM0I7SUFBd0MsOEJBQVk7SUFBcEQ7O0lBcUdBLENBQUM7SUFsR0csZUFBZTtJQUVmLDBCQUFLLEdBQUw7SUFFQSxDQUFDO0lBRU0sc0JBQVcsR0FBbEIsVUFBbUIsUUFBZSxFQUFDLFdBQW9DO1FBQ25FLElBQUksUUFBUSxJQUFJLElBQUksRUFBRTtZQUNsQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFVBQVUsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUN4RCxJQUFJLFVBQVUsR0FBQyxJQUFJLENBQUM7UUFDcEIsZUFBSyxDQUFDLE1BQU0sQ0FDUixVQUFDLGNBQWM7WUFDWCxJQUFHLFVBQVUsSUFBRSxJQUFJLEVBQUM7Z0JBQ2hCLGNBQWMsRUFBRSxDQUFDO2dCQUNqQixPQUFPO2FBQ1Y7WUFDRCxFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUMsVUFBQyxLQUFXLEVBQUMsTUFBNkI7Z0JBQzdFLElBQUcsS0FBSyxJQUFFLElBQUksRUFBQztvQkFDWCxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNoQixPQUFPO2lCQUNWO2dCQUNELFVBQVUsR0FBQyxNQUFNLENBQUM7Z0JBQ2xCLGNBQWMsRUFBRSxDQUFDO1lBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxFQUNELFVBQUMsY0FBYztZQUNYLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDaEQsSUFBRyxJQUFJLElBQUUsVUFBVSxFQUFDO2dCQUNoQixjQUFjLEVBQUUsQ0FBQztnQkFDakIsT0FBTzthQUNWO1lBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUMsRUFBRSxDQUFDLE1BQU0sRUFBQyxVQUFDLEtBQVcsRUFBQyxNQUFnQjtnQkFDNUQsSUFBRyxLQUFLLElBQUUsSUFBSSxFQUFDO29CQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBWSxRQUFRLHFEQUFVLEVBQUMsS0FBSyxDQUFDLENBQUM7b0JBQy9DLE9BQU87aUJBQ1Y7Z0JBQ0QsVUFBVSxHQUFDLE1BQU0sQ0FBQztnQkFDbEIsY0FBYyxFQUFFLENBQUM7WUFDckIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0QsVUFBQyxjQUFjO1lBQ1gsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkQsVUFBVSxDQUFDLFVBQVUsQ0FBQyx3QkFBc0IsUUFBVSxFQUFDLFVBQUMsS0FBVztnQkFDL0QsSUFBRyxLQUFLLElBQUUsSUFBSSxFQUFDO29CQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ2hCLE9BQU87aUJBQ1Y7Z0JBQ0QsY0FBYyxFQUFFLENBQUM7WUFDckIsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLEVBQ0QsVUFBQyxjQUFjO1lBQ1gsSUFBRyxVQUFVLElBQUUsSUFBSSxFQUFDO2dCQUNoQixFQUFFLENBQUMsS0FBSyxDQUFDLG1EQUFtQixRQUFVLENBQUMsQ0FBQTtnQkFDdkMsT0FBTzthQUNWO1lBQ0QsSUFBSSxRQUFRLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUMxQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUNKLENBQUE7UUFRRCx3QkFBd0I7UUFDeEIsNEZBQTRGO1FBQzVGLDJCQUEyQjtRQUMzQiwrQkFBK0I7UUFDL0Isc0JBQXNCO1FBQ3RCLFlBQVk7UUFDWiwyREFBMkQ7UUFDM0QsZ0NBQWdDO1FBQ2hDLCtFQUErRTtRQUMvRSxtQ0FBbUM7UUFDbkMsdUNBQXVDO1FBQ3ZDLDhCQUE4QjtRQUM5QixvQkFBb0I7UUFDcEIsc0VBQXNFO1FBQ3RFLDZFQUE2RTtRQUM3RSx1Q0FBdUM7UUFDdkMsMkNBQTJDO1FBQzNDLGtDQUFrQztRQUNsQyx3QkFBd0I7UUFDeEIsNkRBQTZEO1FBQzdELDRDQUE0QztRQUM1QyxxQkFBcUI7UUFDckIsa0JBQWtCO1FBQ2xCLFlBQVk7UUFDWixVQUFVO1FBQ1YsSUFBSTtJQUNSLENBQUM7SUFsR2dCLFVBQVU7UUFEOUIsT0FBTztPQUNhLFVBQVUsQ0FxRzlCO0lBQUQsaUJBQUM7Q0FyR0QsQUFxR0MsQ0FyR3VDLEVBQUUsQ0FBQyxTQUFTLEdBcUduRDtrQkFyR29CLFVBQVUiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5pbXBvcnQgQXN5bmMgZnJvbSBcIi4vQXN5bmNcIlxyXG5cclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IEJVTkRMRV9OQU1FPVwicHJlZmFiXCI7XHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEhlcm9GYWN5b3IgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge31cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBjcmVhdGVBc3luYyhoZXJvTmFtZTpzdHJpbmcsZnVuQ2FsbGJhY2s6KGhlcm9Ob2RlOmNjLk5vZGUpPT52b2lkKTp2b2lke1xyXG4gICAgICAgIGlmIChoZXJvTmFtZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBsb2FkQnVuZGxlID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShCVU5ETEVfTkFNRSk7XHJcbiAgICAgICAgbGV0IGxvYWRQcmVmYWI9bnVsbDtcclxuICAgICAgICBBc3luYy5zZXJpZXooXHJcbiAgICAgICAgICAgIChmdW5ZZXNDb250aW51ZSk9PntcclxuICAgICAgICAgICAgICAgIGlmKGxvYWRCdW5kbGUhPW51bGwpe1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2MuYXNzZXRNYW5hZ2VyLmxvYWRCdW5kbGUoQlVORExFX05BTUUsKGVycm9yOkVycm9yLGJ1bmRsZTpjYy5Bc3NldE1hbmFnZXIuQnVuZGxlKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVycm9yIT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRCdW5kbGU9YnVuZGxlO1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGZ1blllc0NvbnRpbnVlKT0+e1xyXG4gICAgICAgICAgICAgICAgbG9hZFByZWZhYiA9IGxvYWRCdW5kbGUuZ2V0KGhlcm9OYW1lLGNjLlByZWZhYik7XHJcbiAgICAgICAgICAgICAgICBpZihudWxsIT1sb2FkUHJlZmFiKXtcclxuICAgICAgICAgICAgICAgICAgICBmdW5ZZXNDb250aW51ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGxvYWRCdW5kbGUubG9hZChoZXJvTmFtZSxjYy5QcmVmYWIsKGVycm9yOkVycm9yLHByZWZhYjpjYy5QcmVmYWIpPT57XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoZXJyb3IhPW51bGwpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihgaGVyb05hbWU6JHtoZXJvTmFtZX3mib7kuI3liLDlr7nlupTpooTliLbkvZNgLGVycm9yKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBsb2FkUHJlZmFiPXByZWZhYjtcclxuICAgICAgICAgICAgICAgICAgICBmdW5ZZXNDb250aW51ZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIChmdW5ZZXNDb250aW51ZSk9PntcclxuICAgICAgICAgICAgICAgIGxldCBtYWluQnVuZGxlID0gY2MuYXNzZXRNYW5hZ2VyLmdldEJ1bmRsZShcIm1haW5cIik7XHJcbiAgICAgICAgICAgICAgICBtYWluQnVuZGxlLnByZWxvYWREaXIoYHNwaW5lL3hpYW9qaW5nbGluZy8ke2hlcm9OYW1lfWAsKGVycm9yOkVycm9yKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVycm9yIT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZ1blllc0NvbnRpbnVlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgKGZ1blllc0NvbnRpbnVlKT0+e1xyXG4gICAgICAgICAgICAgICAgaWYobG9hZFByZWZhYj09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICAgICAgY2MuZXJyb3IoYGxvYWRQcmVmYWLkuLrnqbrvvIzlkI3lrZfvvJoke2hlcm9OYW1lfWApXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGV0IGhlcm9Ob2RlID0gY2MuaW5zdGFudGlhdGUobG9hZFByZWZhYik7XHJcbiAgICAgICAgICAgICAgICBmdW5DYWxsYmFjayhoZXJvTm9kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgICAgIC8vIGlmKGxvYWRCdW5kbGU9PW51bGwpe1xyXG4gICAgICAgIC8vICAgICBjYy5hc3NldE1hbmFnZXIubG9hZEJ1bmRsZShCVU5ETEVfTkFNRSwoZXJyb3I6RXJyb3IsYnVuZGxlOmNjLkFzc2V0TWFuYWdlci5CdW5kbGUpPT57XHJcbiAgICAgICAgLy8gICAgICAgICBpZihlcnJvciE9bnVsbCl7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgY2MuZXJyb3IoZXJyb3IpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAvLyAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgIGxldCBsb2FkUHJlZmFiID0gYnVuZGxlLmdldChoZXJvTmFtZSxjYy5QcmVmYWIpO1xyXG4gICAgICAgIC8vICAgICAgICAgaWYobnVsbD09bG9hZFByZWZhYil7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgYnVuZGxlLmxvYWQoaGVyb05hbWUsY2MuUHJlZmFiLChlcnJvcjpFcnJvcixwcmVmYWI6Y2MuUHJlZmFiKT0+e1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICBpZihlcnJvciE9bnVsbCl7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBjYy5lcnJvcihlcnJvcik7XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbGV0IG1haW5CdW5kbGUgPSBjYy5hc3NldE1hbmFnZXIuZ2V0QnVuZGxlKFwibWFpblwiKTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgbWFpbkJ1bmRsZS5wcmVsb2FkRGlyKGBzcGluZS8ke2hlcm9OYW1lfWAsKGVycm9yOkVycm9yKT0+e1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgaWYoZXJyb3IhPW51bGwpe1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgIGNjLmVycm9yKGVycm9yKTtcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICBsZXQgaGVyb05vZGUgPSBjYy5pbnN0YW50aWF0ZShwcmVmYWIpO1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgZnVuQ2FsbGJhY2soaGVyb05vZGUpXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgIH0pO1xyXG4gICAgICAgIC8vIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxyXG59XHJcbiJdfQ==