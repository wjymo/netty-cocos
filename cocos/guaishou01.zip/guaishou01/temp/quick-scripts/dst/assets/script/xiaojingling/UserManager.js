
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/UserManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '08b99EkpNdBM6ZRPy2yEff1', 'UserManager');
// script/xiaojingling/UserManager.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager = /** @class */ (function () {
    function UserManager() {
    }
    UserManager.putMyHeroComp = function (nUserId, oMyHeroComp) {
        UserManager._oMyHeroCompMap[nUserId] = oMyHeroComp;
    };
    UserManager.getMyHeroComp = function (nUserId) {
        return UserManager._oMyHeroCompMap[nUserId];
    };
    UserManager._oMyHeroCompMap = {};
    return UserManager;
}());
exports.default = UserManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXFVzZXJNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7SUFHSTtJQUNBLENBQUM7SUFFTSx5QkFBYSxHQUFwQixVQUFxQixPQUFjLEVBQUMsV0FBa0I7UUFDbEQsV0FBVyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBQyxXQUFXLENBQUM7SUFDckQsQ0FBQztJQUVNLHlCQUFhLEdBQXBCLFVBQXFCLE9BQWM7UUFDL0IsT0FBTyxXQUFXLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFYdUIsMkJBQWUsR0FBMkIsRUFBRSxDQUFDO0lBWXpFLGtCQUFDO0NBYkQsQUFhQyxJQUFBO2tCQWJxQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IENvbW1vbiBmcm9tIFwiLi9Db21tb25cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0ICBjbGFzcyBVc2VyTWFuYWdlciB7XHJcbiAgICBwcml2YXRlIHN0YXRpYyByZWFkb25seSBfb015SGVyb0NvbXBNYXA6e1tuVXNlcklkOm51bWJlcl06Q29tbW9ufT17fTtcclxuXHJcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXRpYyBwdXRNeUhlcm9Db21wKG5Vc2VySWQ6bnVtYmVyLG9NeUhlcm9Db21wOkNvbW1vbik6dm9pZHtcclxuICAgICAgICBVc2VyTWFuYWdlci5fb015SGVyb0NvbXBNYXBbblVzZXJJZF09b015SGVyb0NvbXA7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhdGljIGdldE15SGVyb0NvbXAoblVzZXJJZDpudW1iZXIpOkNvbW1vbntcclxuICAgICAgICByZXR1cm4gVXNlck1hbmFnZXIuX29NeUhlcm9Db21wTWFwW25Vc2VySWRdO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==