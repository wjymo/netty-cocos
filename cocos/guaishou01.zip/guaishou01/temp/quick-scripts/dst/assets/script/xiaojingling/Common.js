
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Common.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8cc52LoIFNAy65yLLiKdbrw', 'Common');
// script/xiaojingling/Common.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var speed = 120;
var customScaleX = 0.7;
var Common = /** @class */ (function (_super) {
    __extends(Common, _super);
    function Common() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.rangeAttack = null;
        /**
         * 是否在移动
         */
        _this._bIsMoving = false;
        /**
         * 移动方向
         */
        _this._oMoveDirection = null;
        /**
         * 目标位置
         */
        _this._oMoveTo = null;
        /**
         *可以攻击的目标集合
         */
        _this._oAttkableObjSet = null;
        /**
         * 当前血量
         */
        _this._nCurrHp = 0;
        /**
         * 是否正在攻击
         */
        _this._bIsAttacking = false;
        return _this;
    }
    Common_1 = Common;
    // onLoad () {}
    Common.prototype.start = function () {
        this._nCurrHp = 100;
        // let oCurrHero = this.node;
        // let skeleton=oCurrHero.getComponent(sp.Skeleton);
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
        // oCurrHero.anchorY=100;
        // console.log('oCurrHero.anchorY', oCurrHero.anchorY);
    };
    Common.prototype.onCollisionEnter = function (oAnotherBox, self) {
        cc.log("\u81EA\u5DF1\u7684\u540D\u5B57\uFF1A" + self.node["_name"] + ",\u5F53\u524Dnode\u540D\u5B57\uFF1A" + this.node.name + ",\u78B0\u5230\u5176\u5B83\u7269\u4F53,name=" + oAnotherBox.node.name);
        if (null != oAnotherBox) {
            var oAnotherBoxName = oAnotherBox.node.name;
            if (oAnotherBoxName.indexOf("_") != -1) {
                console.log("被碰撞的是攻击盒子");
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子
                var strings = oAnotherBoxName.split("_");
                // console.log(`oAnotherBoxName的前缀：${strings[0]}`);
                var heroName = strings[0];
                if (heroName === self.node["_name"]) {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）等于当前节点的名称，说明这个攻击盒子属于当前节点，不做操作
                    return;
                }
                else {
                    //如果被碰撞的盒子所属节点的名称前缀（一个攻击盒子）不等于当前节点的名称，说明这个攻击盒子不属于当前节点
                    //那么要找到这个攻击盒子的父节点a，将当前节点加入a的碰撞set中
                    var parent = oAnotherBox.node.parent;
                    console.log("\u653B\u51FB\u76D2\u5B50\u7684\u7236\u8282\u70B9\u7684\u7EC4\u4EF6:", parent.getComponent(Common_1));
                    var fuCommon = parent.getComponent(Common_1);
                    fuCommon._oAttkableObjSet = fuCommon._oAttkableObjSet || new Set();
                    fuCommon._oAttkableObjSet.add(self.node);
                    console.log('component._oAttkableObjSet', fuCommon._oAttkableObjSet);
                    return;
                }
            }
            else {
                console.log("被碰撞的是人物");
                this._oAttkableObjSet = this._oAttkableObjSet || new Set();
                this._oAttkableObjSet.add(oAnotherBox.node);
            }
        }
        // 碰撞系统会计算出碰撞组件在世界坐标系下的相关的值，并放到 world 这个属性里面
        // var world = self.world;
        // let points = self.points;
        // console.log(`${this.node.name},points`,points);
        // for (let i = 0; i < points.length; i++) {
        //     let point = points[i];
        //     console.log(`${this.node.name},point`,point);
        // }
        // // 碰撞组件的 aabb 碰撞框
        // var aabb = world.aabb;
        // console.log('aabb',aabb);
        //
        // // 上一次计算的碰撞组件的 aabb 碰撞框
        // var preAabb = world.preAabb;
        //
        // // 碰撞框的世界矩阵
        // var t = world.transform;
        //
        // // 以下属性为圆形碰撞组件特有属性
        // var r = world.radius;
        // var p = world.position;
        //
        // // 以下属性为 矩形 和 多边形 碰撞组件特有属性
        // var ps = world.points;
    };
    Common.prototype.onCollisionExit = function (oAnotherBox, self) {
        var oAnotherBoxName = oAnotherBox.node.name;
        cc.log("\u79BB\u5F00\u5176\u5B83\u7269\u4F53,name=" + oAnotherBoxName);
        if (null != oAnotherBox) {
            if (oAnotherBoxName.indexOf("_") != -1) {
                //当被碰撞的盒子的名称包含下划线，说明是攻击盒子，那么要找到他的父节点，从父节点中移除self的节点
                console.log("被离开碰撞的是攻击盒子");
                var parent = oAnotherBox.node.parent;
                var fuCommon = parent.getComponent(Common_1);
                console.log('【离开】攻击盒子的父节点的Common', fuCommon);
                if (fuCommon._oAttkableObjSet != null) {
                    fuCommon._oAttkableObjSet.delete(self.node);
                }
            }
            else {
                console.log("被离开碰撞的是英雄的盒子");
                if (null != this._oAttkableObjSet) {
                    this._oAttkableObjSet.delete(oAnotherBox.node);
                }
            }
        }
    };
    /**
     * 节点销毁时，清空集合，避免内存谢落
     */
    Common.prototype.onDestroy = function () {
        if (null != this._oAttkableObjSet) {
            this._oAttkableObjSet.clear();
        }
    };
    Common.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
        // console.log(this.node,"oCurrHero",oCurrHero.zIndex);
    };
    Common.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        //正在攻击的话，不让他移动，避免R闪
        if (this._bIsAttacking) {
            return;
        }
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    Common.prototype.attk = function (nPosX, nPosY) {
        var _this = this;
        if (this._bIsAttacking) {
            return;
        }
        this._bIsAttacking = true;
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        var self = this;
        var components = self.node['_components'];
        console.log('components', components);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
            self._bIsAttacking = false;
        });
        if (this._oAttkableObjSet == null || this._oAttkableObjSet.size <= 0) {
            return;
        }
        this._oAttkableObjSet.forEach(function (oAttkableObj) {
            if (oAttkableObj == null) {
                return;
            }
            var name = oAttkableObj.name;
            var suffix = name.split("_")[1];
            //如果要攻击的物体为被攻击方的碰撞盒子，直接return
            if (suffix === 'RangeAttack') {
                return;
            }
            //上下位置差太多，打不到对方
            if (Math.abs(_this.node.zIndex - oAttkableObj.zIndex) > 64) {
                return;
            }
            //双方左右位置相反，并有一段距离，打不到对方
            if (((oAttkableObj.x - _this.node.x) <= -64 && _this.node.scale > 0) ||
                ((oAttkableObj.x - _this.node.x) >= 64 && _this.node.scale < 0)) {
                return;
            }
            oAttkableObj.getComponent(Common_1).subtractHp(40);
        });
    };
    /**
     * 被打减血时
     * @param nVal
     */
    Common.prototype.subtractHp = function (nVal) {
        if (nVal < 0) {
            return;
        }
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        //减血效果要延时一下，因为每个小精灵的攻击都需要1秒以上
        var self = this;
        this.schedule(function () {
            //减血时开启被打的动画
            skeleton.setAnimation(1, 'hurt', false);
            self._nCurrHp = Math.max(self._nCurrHp - nVal, 0);
            var oSubBlood = cc.find("SubBlood", self.node);
            oSubBlood = cc.instantiate(oSubBlood);
            oSubBlood.getComponent(cc.Label).string = nVal.toString();
            oSubBlood.active = true;
            // console.log("当前node的名字",self.node.name)
            self.node.addChild(oSubBlood);
            cc.tween(oSubBlood)
                .to(0.0, { scale: 3.2 })
                .to(0.2, { scale: 1.0 })
                .by(0.4, { y: 64, opacity: -128 })
                .start();
            self.schedule(function () {
                oSubBlood.destroy();
            }, 0.6);
            if (self._nCurrHp <= 0) {
                self.die();
            }
        }, 1.2, 0, 0);
    };
    Common.prototype.die = function () {
        var oCurrHero = this.node;
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        skeleton.schedule(function () {
            // 这里的 this 指向 component
            skeleton.setAnimation(1, 'dead', false);
        }, 1, 0, 0);
    };
    var Common_1;
    __decorate([
        property(cc.Prefab)
    ], Common.prototype, "rangeAttack", void 0);
    Common = Common_1 = __decorate([
        ccclass
    ], Common);
    return Common;
}(cc.Component));
exports.default = Common;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXENvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUU1RSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUMxQyxJQUFNLEtBQUssR0FBQyxHQUFHLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUMsR0FBRyxDQUFDO0FBRXZCO0lBQW9DLDBCQUFZO0lBQWhEO1FBQUEscUVBdVNDO1FBcFNHLGlCQUFXLEdBQWMsSUFBSSxDQUFDO1FBQzlCOztXQUVHO1FBQ0gsZ0JBQVUsR0FBUyxLQUFLLENBQUM7UUFFekI7O1dBRUc7UUFDSCxxQkFBZSxHQUF5QixJQUFJLENBQUM7UUFFN0M7O1dBRUc7UUFDSCxjQUFRLEdBQXlCLElBQUksQ0FBQztRQUV0Qzs7V0FFRztRQUNILHNCQUFnQixHQUFjLElBQUksQ0FBQztRQUVuQzs7V0FFRztRQUNILGNBQVEsR0FBUSxDQUFDLENBQUM7UUFFbEI7O1dBRUc7UUFDSCxtQkFBYSxHQUFTLEtBQUssQ0FBQzs7SUF1UWhDLENBQUM7ZUF2U29CLE1BQU07SUFrQ3ZCLGVBQWU7SUFFZixzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBQyxHQUFHLENBQUM7UUFDbEIsNkJBQTZCO1FBQzdCLG9EQUFvRDtRQUNwRCx1REFBdUQ7UUFDdkQseUJBQXlCO1FBQ3pCLHVEQUF1RDtJQUMzRCxDQUFDO0lBRUQsaUNBQWdCLEdBQWhCLFVBQWlCLFdBQTBCLEVBQUMsSUFBSTtRQUM1QyxFQUFFLENBQUMsR0FBRyxDQUFDLHlDQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJDQUFhLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxtREFBZ0IsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFNLENBQUMsQ0FBQTtRQUNyRyxJQUFHLElBQUksSUFBRSxXQUFXLEVBQUM7WUFDakIsSUFBSSxlQUFlLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDNUMsSUFBRyxlQUFlLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFFLENBQUMsQ0FBQyxFQUFDO2dCQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUN6Qix5QkFBeUI7Z0JBQ3pCLElBQUksT0FBTyxHQUFHLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3pDLG1EQUFtRDtnQkFDbkQsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUMxQixJQUFHLFFBQVEsS0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFDO29CQUM3Qix3REFBd0Q7b0JBQ3hELE9BQU87aUJBQ1Y7cUJBQUs7b0JBQ0YscURBQXFEO29CQUNyRCxrQ0FBa0M7b0JBQ2xDLElBQUksTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFFQUFjLEVBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxRQUFNLENBQUMsQ0FBQyxDQUFBO29CQUN2RCxJQUFJLFFBQVEsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLFFBQU0sQ0FBQyxDQUFDO29CQUMzQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUMsUUFBUSxDQUFDLGdCQUFnQixJQUFJLElBQUksR0FBRyxFQUFXLENBQUM7b0JBQzFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO29CQUNuRSxPQUFPO2lCQUNWO2FBQ0o7aUJBQUs7Z0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLGdCQUFnQixHQUFDLElBQUksQ0FBQyxnQkFBZ0IsSUFBRSxJQUFJLEdBQUcsRUFBVyxDQUFDO2dCQUNoRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUMvQztTQUNKO1FBRUQsNENBQTRDO1FBQzVDLDBCQUEwQjtRQUMxQiw0QkFBNEI7UUFDNUIsa0RBQWtEO1FBQ2xELDRDQUE0QztRQUM1Qyw2QkFBNkI7UUFDN0Isb0RBQW9EO1FBQ3BELElBQUk7UUFDSixvQkFBb0I7UUFDcEIseUJBQXlCO1FBQ3pCLDRCQUE0QjtRQUM1QixFQUFFO1FBQ0YsMEJBQTBCO1FBQzFCLCtCQUErQjtRQUMvQixFQUFFO1FBQ0YsY0FBYztRQUNkLDJCQUEyQjtRQUMzQixFQUFFO1FBQ0YscUJBQXFCO1FBQ3JCLHdCQUF3QjtRQUN4QiwwQkFBMEI7UUFDMUIsRUFBRTtRQUNGLDZCQUE2QjtRQUM3Qix5QkFBeUI7SUFDN0IsQ0FBQztJQUNELGdDQUFlLEdBQWYsVUFBZ0IsV0FBMEIsRUFBQyxJQUFJO1FBQzNDLElBQUksZUFBZSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzVDLEVBQUUsQ0FBQyxHQUFHLENBQUMsK0NBQWUsZUFBaUIsQ0FBQyxDQUFBO1FBQ3hDLElBQUcsSUFBSSxJQUFFLFdBQVcsRUFBQztZQUNqQixJQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUUsQ0FBQyxDQUFDLEVBQUM7Z0JBQ2hDLG1EQUFtRDtnQkFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDM0IsSUFBSSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQ3JDLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBTSxDQUFDLENBQUM7Z0JBQzNDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUMsUUFBUSxDQUFDLENBQUE7Z0JBQzNDLElBQUcsUUFBUSxDQUFDLGdCQUFnQixJQUFFLElBQUksRUFBQztvQkFDL0IsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQy9DO2FBQ0o7aUJBQUs7Z0JBQ0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDNUIsSUFBRyxJQUFJLElBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFDO29CQUMzQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDbEQ7YUFDSjtTQUNKO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsMEJBQVMsR0FBVDtRQUNJLElBQUcsSUFBSSxJQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBQztZQUMzQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLENBQUM7U0FDakM7SUFDTCxDQUFDO0lBRUQsdUJBQU0sR0FBTixVQUFRLEVBQUU7UUFDTixJQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztZQUNoQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHNDQUFzQztRQUN0QywyREFBMkQ7UUFDM0QsSUFBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQztZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzdELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQTtTQUM3QjtRQUNELElBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFFLENBQUMsRUFBQztZQUN4RCxJQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN0QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLEtBQUssR0FBQyxFQUFFLENBQUM7UUFDL0MsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDO1FBRS9DLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzlCLHVEQUF1RDtJQUMzRCxDQUFDO0lBRUQsdUJBQU0sR0FBTixVQUFPLEtBQVksRUFBQyxLQUFZO1FBQzVCLG1DQUFtQztRQUNuQyxzQ0FBc0M7UUFDdEMsMENBQTBDO1FBQzFDLG1CQUFtQjtRQUNuQixJQUFHLElBQUksQ0FBQyxhQUFhLEVBQUM7WUFDbEIsT0FBTztTQUNWO1FBQ0QsSUFBSSxDQUFDLGVBQWUsR0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQ25DLEVBQUU7UUFDRixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRTFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekQsRUFBRTtRQUVGLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUM7WUFDVixHQUFHLEVBQUMsS0FBSztZQUNULEdBQUcsRUFBQyxLQUFLO1NBQ1osQ0FBQztRQUNGLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCxxQkFBSSxHQUFKLFVBQUssS0FBWSxFQUFDLEtBQVk7UUFBOUIsaUJBb0RDO1FBbkRHLElBQUcsSUFBSSxDQUFDLGFBQWEsRUFBQztZQUNsQixPQUFPO1NBQ1Y7UUFHRCxJQUFJLENBQUMsYUFBYSxHQUFDLElBQUksQ0FBQztRQUN4QixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHlCQUF5QjtRQUN6Qiw0Q0FBNEM7UUFDNUMsSUFBSTtRQUVKLElBQUksUUFBUSxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pELElBQUksVUFBVSxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBQyxLQUFLLENBQUMsQ0FBQztRQUMxRCxJQUFJLElBQUksR0FBQyxJQUFJLENBQUM7UUFFZCxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFDLFVBQVUsQ0FBQyxDQUFDO1FBSXJDLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVLEVBQUM7WUFDekMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2QixJQUFJLENBQUMsYUFBYSxHQUFDLEtBQUssQ0FBQztRQUU3QixDQUFDLENBQUMsQ0FBQztRQUNILElBQUcsSUFBSSxDQUFDLGdCQUFnQixJQUFFLElBQUksSUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxJQUFFLENBQUMsRUFBQztZQUMxRCxPQUFPO1NBQ1Y7UUFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFVBQUMsWUFBWTtZQUN4QyxJQUFHLFlBQVksSUFBRSxJQUFJLEVBQUM7Z0JBQ2xCLE9BQU87YUFDVjtZQUNELElBQUksSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7WUFDN0IsSUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyw2QkFBNkI7WUFDN0IsSUFBRyxNQUFNLEtBQUcsYUFBYSxFQUFDO2dCQUNyQixPQUFPO2FBQ1g7WUFDRCxlQUFlO1lBQ2YsSUFBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBQyxFQUFFLEVBQUM7Z0JBQ2pELE9BQU87YUFDVjtZQUNELHVCQUF1QjtZQUN2QixJQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUUsQ0FBQyxFQUFFLElBQUUsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUMsQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBQyxLQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFFLEVBQUUsSUFBRSxLQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxDQUFDLENBQUMsRUFBQztnQkFDdEQsT0FBTzthQUNWO1lBQ0QsWUFBWSxDQUFDLFlBQVksQ0FBQyxRQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUM7SUFHUCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsMkJBQVUsR0FBVixVQUFXLElBQVc7UUFDbEIsSUFBRyxJQUFJLEdBQUMsQ0FBQyxFQUFDO1lBQ04sT0FBTztTQUNWO1FBQ0QsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVqRCw2QkFBNkI7UUFDN0IsSUFBSSxJQUFJLEdBQUMsSUFBSSxDQUFDO1FBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNWLFlBQVk7WUFDWixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxNQUFNLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFFdEMsSUFBSSxDQUFDLFFBQVEsR0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzdDLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM5QyxTQUFTLEdBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNwQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hELFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDO1lBQ3RCLDBDQUEwQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUM5QixFQUFFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztpQkFDZCxFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxDQUFDO2lCQUNuQixFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsS0FBSyxFQUFDLEdBQUcsRUFBQyxDQUFDO2lCQUNuQixFQUFFLENBQUMsR0FBRyxFQUFDLEVBQUMsQ0FBQyxFQUFDLEVBQUUsRUFBQyxPQUFPLEVBQUMsQ0FBQyxHQUFHLEVBQUMsQ0FBQztpQkFDM0IsS0FBSyxFQUFFLENBQUM7WUFFYixJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNWLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN4QixDQUFDLEVBQUMsR0FBRyxDQUFDLENBQUM7WUFHUCxJQUFHLElBQUksQ0FBQyxRQUFRLElBQUUsQ0FBQyxFQUFDO2dCQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDZDtRQUNMLENBQUMsRUFBRSxHQUFHLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hCLENBQUM7SUFDRCxvQkFBRyxHQUFIO1FBQ0ksSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxRQUFRLENBQUMsUUFBUSxDQUFDO1lBQ2Qsd0JBQXdCO1lBQ3hCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxLQUFLLENBQUMsQ0FBQztRQUMxQyxDQUFDLEVBQUUsQ0FBQyxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQztJQUNkLENBQUM7O0lBblNEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7K0NBQ1U7SUFIYixNQUFNO1FBRDFCLE9BQU87T0FDYSxNQUFNLENBdVMxQjtJQUFELGFBQUM7Q0F2U0QsQUF1U0MsQ0F2U21DLEVBQUUsQ0FBQyxTQUFTLEdBdVMvQztrQkF2U29CLE1BQU0iLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBUeXBlU2NyaXB0OlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy90eXBlc2NyaXB0Lmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuY29uc3Qgc3BlZWQ9MTIwO1xyXG5jb25zdCBjdXN0b21TY2FsZVg9MC43O1xyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBDb21tb24gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICByYW5nZUF0dGFjazogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIC8qKlxyXG4gICAgICog5piv5ZCm5Zyo56e75YqoXHJcbiAgICAgKi9cclxuICAgIF9iSXNNb3Zpbmc6Ym9vbGVhbj1mYWxzZTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOenu+WKqOaWueWQkVxyXG4gICAgICovXHJcbiAgICBfb01vdmVEaXJlY3Rpb246e19uWDpudW1iZXIsX25ZOm51bWJlcn09bnVsbDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOebruagh+S9jee9rlxyXG4gICAgICovXHJcbiAgICBfb01vdmVUbzp7X25YOm51bWJlcixfblk6bnVtYmVyfT1udWxsO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICrlj6/ku6XmlLvlh7vnmoTnm67moIfpm4blkIhcclxuICAgICAqL1xyXG4gICAgX29BdHRrYWJsZU9ialNldDpTZXQ8Y2MuTm9kZT49bnVsbDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOW9k+WJjeihgOmHj1xyXG4gICAgICovXHJcbiAgICBfbkN1cnJIcDpudW1iZXI9MDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOaYr+WQpuato+WcqOaUu+WHu1xyXG4gICAgICovXHJcbiAgICBfYklzQXR0YWNraW5nOmJvb2xlYW49ZmFsc2U7XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuX25DdXJySHA9MTAwO1xyXG4gICAgICAgIC8vIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gbGV0IHNrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8uYW5jaG9yWScsIG9DdXJySGVyby5hbmNob3JZKTtcclxuICAgICAgICAvLyBvQ3Vyckhlcm8uYW5jaG9yWT0xMDA7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVyby5hbmNob3JZJywgb0N1cnJIZXJvLmFuY2hvclkpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXIob0Fub3RoZXJCb3g6Y2MuQm94Q29sbGlkZXIsc2VsZik6dm9pZHtcclxuICAgICAgICBjYy5sb2coYOiHquW3seeahOWQjeWtl++8miR7c2VsZi5ub2RlW1wiX25hbWVcIl19LOW9k+WJjW5vZGXlkI3lrZfvvJoke3RoaXMubm9kZS5uYW1lfSznorDliLDlhbblroPniankvZMsbmFtZT0ke29Bbm90aGVyQm94Lm5vZGUubmFtZX1gKVxyXG4gICAgICAgIGlmKG51bGwhPW9Bbm90aGVyQm94KXtcclxuICAgICAgICAgICAgbGV0IG9Bbm90aGVyQm94TmFtZSA9IG9Bbm90aGVyQm94Lm5vZGUubmFtZTtcclxuICAgICAgICAgICAgaWYob0Fub3RoZXJCb3hOYW1lLmluZGV4T2YoXCJfXCIpIT0tMSl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuiiq+eisOaSnueahOaYr+aUu+WHu+ebkuWtkFwiKTtcclxuICAgICAgICAgICAgICAgIC8v5b2T6KKr56Kw5pKe55qE55uS5a2Q55qE5ZCN56ew5YyF5ZCr5LiL5YiS57q/77yM6K+05piO5piv5pS75Ye755uS5a2QXHJcbiAgICAgICAgICAgICAgICBsZXQgc3RyaW5ncyA9IG9Bbm90aGVyQm94TmFtZS5zcGxpdChcIl9cIik7XHJcbiAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhgb0Fub3RoZXJCb3hOYW1l55qE5YmN57yA77yaJHtzdHJpbmdzWzBdfWApO1xyXG4gICAgICAgICAgICAgICAgbGV0IGhlcm9OYW1lID0gc3RyaW5nc1swXTtcclxuICAgICAgICAgICAgICAgIGlmKGhlcm9OYW1lPT09c2VsZi5ub2RlW1wiX25hbWVcIl0pe1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aaC5p6c6KKr56Kw5pKe55qE55uS5a2Q5omA5bGe6IqC54K555qE5ZCN56ew5YmN57yA77yI5LiA5Liq5pS75Ye755uS5a2Q77yJ562J5LqO5b2T5YmN6IqC54K555qE5ZCN56ew77yM6K+05piO6L+Z5Liq5pS75Ye755uS5a2Q5bGe5LqO5b2T5YmN6IqC54K577yM5LiN5YGa5pON5L2cXHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIC8v5aaC5p6c6KKr56Kw5pKe55qE55uS5a2Q5omA5bGe6IqC54K555qE5ZCN56ew5YmN57yA77yI5LiA5Liq5pS75Ye755uS5a2Q77yJ5LiN562J5LqO5b2T5YmN6IqC54K555qE5ZCN56ew77yM6K+05piO6L+Z5Liq5pS75Ye755uS5a2Q5LiN5bGe5LqO5b2T5YmN6IqC54K5XHJcbiAgICAgICAgICAgICAgICAgICAgLy/pgqPkuYjopoHmib7liLDov5nkuKrmlLvlh7vnm5LlrZDnmoTniLboioLngrlh77yM5bCG5b2T5YmN6IqC54K55Yqg5YWlYeeahOeisOaSnnNldOS4rVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBwYXJlbnQgPSBvQW5vdGhlckJveC5ub2RlLnBhcmVudDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhg5pS75Ye755uS5a2Q55qE54i26IqC54K555qE57uE5Lu2OmAscGFyZW50LmdldENvbXBvbmVudChDb21tb24pKVxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBmdUNvbW1vbiA9IHBhcmVudC5nZXRDb21wb25lbnQoQ29tbW9uKTtcclxuICAgICAgICAgICAgICAgICAgICBmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0PWZ1Q29tbW9uLl9vQXR0a2FibGVPYmpTZXQgfHwgbmV3IFNldDxjYy5Ob2RlPigpO1xyXG4gICAgICAgICAgICAgICAgICAgIGZ1Q29tbW9uLl9vQXR0a2FibGVPYmpTZXQuYWRkKHNlbGYubm9kZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2NvbXBvbmVudC5fb0F0dGthYmxlT2JqU2V0JyxmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0KVxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLooqvnorDmkp7nmoTmmK/kurrnialcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQ9dGhpcy5fb0F0dGthYmxlT2JqU2V0fHxuZXcgU2V0PGNjLk5vZGU+KCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQuYWRkKG9Bbm90aGVyQm94Lm5vZGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDnorDmkp7ns7vnu5/kvJrorqHnrpflh7rnorDmkp7nu4Tku7blnKjkuJbnlYzlnZDmoIfns7vkuIvnmoTnm7jlhbPnmoTlgLzvvIzlubbmlL7liLAgd29ybGQg6L+Z5Liq5bGe5oCn6YeM6Z2iXHJcbiAgICAgICAgLy8gdmFyIHdvcmxkID0gc2VsZi53b3JsZDtcclxuICAgICAgICAvLyBsZXQgcG9pbnRzID0gc2VsZi5wb2ludHM7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coYCR7dGhpcy5ub2RlLm5hbWV9LHBvaW50c2AscG9pbnRzKTtcclxuICAgICAgICAvLyBmb3IgKGxldCBpID0gMDsgaSA8IHBvaW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgIC8vICAgICBsZXQgcG9pbnQgPSBwb2ludHNbaV07XHJcbiAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKGAke3RoaXMubm9kZS5uYW1lfSxwb2ludGAscG9pbnQpO1xyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyAvLyDnorDmkp7nu4Tku7bnmoQgYWFiYiDnorDmkp7moYZcclxuICAgICAgICAvLyB2YXIgYWFiYiA9IHdvcmxkLmFhYmI7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ2FhYmInLGFhYmIpO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g5LiK5LiA5qyh6K6h566X55qE56Kw5pKe57uE5Lu255qEIGFhYmIg56Kw5pKe5qGGXHJcbiAgICAgICAgLy8gdmFyIHByZUFhYmIgPSB3b3JsZC5wcmVBYWJiO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g56Kw5pKe5qGG55qE5LiW55WM55+p6Zi1XHJcbiAgICAgICAgLy8gdmFyIHQgPSB3b3JsZC50cmFuc2Zvcm07XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyAvLyDku6XkuIvlsZ7mgKfkuLrlnIblvaLnorDmkp7nu4Tku7bnibnmnInlsZ7mgKdcclxuICAgICAgICAvLyB2YXIgciA9IHdvcmxkLnJhZGl1cztcclxuICAgICAgICAvLyB2YXIgcCA9IHdvcmxkLnBvc2l0aW9uO1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gLy8g5Lul5LiL5bGe5oCn5Li6IOefqeW9oiDlkowg5aSa6L655b2iIOeisOaSnue7hOS7tueJueacieWxnuaAp1xyXG4gICAgICAgIC8vIHZhciBwcyA9IHdvcmxkLnBvaW50cztcclxuICAgIH1cclxuICAgIG9uQ29sbGlzaW9uRXhpdChvQW5vdGhlckJveDpjYy5Cb3hDb2xsaWRlcixzZWxmKTp2b2lke1xyXG4gICAgICAgIGxldCBvQW5vdGhlckJveE5hbWUgPSBvQW5vdGhlckJveC5ub2RlLm5hbWU7XHJcbiAgICAgICAgY2MubG9nKGDnprvlvIDlhbblroPniankvZMsbmFtZT0ke29Bbm90aGVyQm94TmFtZX1gKVxyXG4gICAgICAgIGlmKG51bGwhPW9Bbm90aGVyQm94KXtcclxuICAgICAgICAgICAgaWYob0Fub3RoZXJCb3hOYW1lLmluZGV4T2YoXCJfXCIpIT0tMSl7XHJcbiAgICAgICAgICAgICAgICAvL+W9k+iiq+eisOaSnueahOebkuWtkOeahOWQjeensOWMheWQq+S4i+WIkue6v++8jOivtOaYjuaYr+aUu+WHu+ebkuWtkO+8jOmCo+S5iOimgeaJvuWIsOS7lueahOeItuiKgueCue+8jOS7jueItuiKgueCueS4reenu+mZpHNlbGbnmoToioLngrlcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi6KKr56a75byA56Kw5pKe55qE5piv5pS75Ye755uS5a2QXCIpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHBhcmVudCA9IG9Bbm90aGVyQm94Lm5vZGUucGFyZW50O1xyXG4gICAgICAgICAgICAgICAgbGV0IGZ1Q29tbW9uID0gcGFyZW50LmdldENvbXBvbmVudChDb21tb24pO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ+OAkOemu+W8gOOAkeaUu+WHu+ebkuWtkOeahOeItuiKgueCueeahENvbW1vbicsZnVDb21tb24pXHJcbiAgICAgICAgICAgICAgICBpZihmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0IT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICBmdUNvbW1vbi5fb0F0dGthYmxlT2JqU2V0LmRlbGV0ZShzZWxmLm5vZGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9ZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuiiq+emu+W8gOeisOaSnueahOaYr+iLsembhOeahOebkuWtkFwiKTtcclxuICAgICAgICAgICAgICAgIGlmKG51bGwhPXRoaXMuX29BdHRrYWJsZU9ialNldCl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb0F0dGthYmxlT2JqU2V0LmRlbGV0ZShvQW5vdGhlckJveC5ub2RlKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiKgueCuemUgOavgeaXtu+8jOa4heepuumbhuWQiO+8jOmBv+WFjeWGheWtmOiwouiQvVxyXG4gICAgICovXHJcbiAgICBvbkRlc3Ryb3koKTp2b2lke1xyXG4gICAgICAgIGlmKG51bGwhPXRoaXMuX29BdHRrYWJsZU9ialNldCl7XHJcbiAgICAgICAgICAgIHRoaXMuX29BdHRrYWJsZU9ialNldC5jbGVhcigpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgaWYoIXRoaXMuX2JJc01vdmluZyl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVybycsb0N1cnJIZXJvKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fb01vdmVEaXJlY3Rpb24nLHRoaXMuX29Nb3ZlRGlyZWN0aW9uKVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueDw9dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWDwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueD49dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueTw9dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWTwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueT49dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD09MCYmdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPWZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgc2tlbGV0b24gPSBvQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3N0YW5kJyx0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLngrPXRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWCpzcGVlZCpkdDtcclxuICAgICAgICBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKnNwZWVkKmR0O1xyXG5cclxuICAgICAgICBvQ3Vyckhlcm8uekluZGV4PS1vQ3Vyckhlcm8ueTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLm5vZGUsXCJvQ3Vyckhlcm9cIixvQ3Vyckhlcm8uekluZGV4KTtcclxuICAgIH1cclxuXHJcbiAgICBtb3ZlVG8oblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5Nb3ZlVG9YXCIsbk1vdmVUb1gpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb01vdmVUb1YyLngnLG9Nb3ZlVG9WMi54KTtcclxuICAgICAgICAvL+ato+WcqOaUu+WHu+eahOivne+8jOS4jeiuqeS7luenu+WKqO+8jOmBv+WFjVLpl6pcclxuICAgICAgICBpZih0aGlzLl9iSXNBdHRhY2tpbmcpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uPXtfblg6MCxfblk6MH07XHJcbiAgICAgICAgLy9cclxuICAgICAgICBsZXQgb0N1cnJIZXJvID0gdGhpcy5ub2RlO1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZygnb0N1cnJIZXJvJyxvQ3Vyckhlcm8pO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0ob0N1cnJIZXJvLng8PW5Qb3NYKT8xOi0xO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0ob0N1cnJIZXJvLnk8PW5Qb3NZKT8xOi0xO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCd0aGlzLl9vTW92ZURpcmVjdGlvbicsdGhpcy5fb01vdmVEaXJlY3Rpb24pO1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIG9DdXJySGVyby5zY2FsZVg9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25YKmN1c3RvbVNjYWxlWDtcclxuICAgICAgICB0aGlzLl9vTW92ZVRvPXtcclxuICAgICAgICAgICAgX25YOm5Qb3NYLFxyXG4gICAgICAgICAgICBfblk6blBvc1ksXHJcbiAgICAgICAgfTtcclxuICAgICAgICBpZighdGhpcy5fYklzTW92aW5nKXtcclxuICAgICAgICAgICAgbGV0IG9Ta2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgb1NrZWxldG9uLnNldEFuaW1hdGlvbigxLCd3YWxrJyx0cnVlKTtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPXRydWU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGF0dGsoblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICBpZih0aGlzLl9iSXNBdHRhY2tpbmcpe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgdGhpcy5fYklzQXR0YWNraW5nPXRydWU7XHJcbiAgICAgICAgbGV0IG9DdXJySGVybyA9IHRoaXMubm9kZTtcclxuICAgICAgICAvLyBpZihuUG9zWDxvQ3Vyckhlcm8ueCl7XHJcbiAgICAgICAgLy8gICAgIG9DdXJySGVyby5zY2FsZVg9b0N1cnJIZXJvLnNjYWxlWCotMTtcclxuICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgIGxldCBza2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICBsZXQgdHJhY2VFbnRyeSA9IHNrZWxldG9uLnNldEFuaW1hdGlvbigyLCdza2lsbDAxJyxmYWxzZSk7XHJcbiAgICAgICAgbGV0IHNlbGY9dGhpcztcclxuXHJcbiAgICAgICAgbGV0IGNvbXBvbmVudHMgPSBzZWxmLm5vZGVbJ19jb21wb25lbnRzJ107XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbXBvbmVudHMnLGNvbXBvbmVudHMpO1xyXG5cclxuXHJcblxyXG4gICAgICAgIHNrZWxldG9uLnNldFRyYWNrQ29tcGxldGVMaXN0ZW5lcih0cmFjZUVudHJ5LGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygyKTtcclxuICAgICAgICAgICAgc2VsZi5fYklzQXR0YWNraW5nPWZhbHNlO1xyXG5cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZih0aGlzLl9vQXR0a2FibGVPYmpTZXQ9PW51bGx8fHRoaXMuX29BdHRrYWJsZU9ialNldC5zaXplPD0wKXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLl9vQXR0a2FibGVPYmpTZXQuZm9yRWFjaCgob0F0dGthYmxlT2JqKT0+e1xyXG4gICAgICAgICAgIGlmKG9BdHRrYWJsZU9iaj09bnVsbCl7XHJcbiAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgbGV0IG5hbWUgPSBvQXR0a2FibGVPYmoubmFtZTtcclxuICAgICAgICAgICBsZXQgc3VmZml4ID0gbmFtZS5zcGxpdChcIl9cIilbMV07XHJcbiAgICAgICAgICAgLy/lpoLmnpzopoHmlLvlh7vnmoTniankvZPkuLrooqvmlLvlh7vmlrnnmoTnorDmkp7nm5LlrZDvvIznm7TmjqVyZXR1cm5cclxuICAgICAgICAgICBpZihzdWZmaXg9PT0nUmFuZ2VBdHRhY2snKXtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgICAgLy/kuIrkuIvkvY3nva7lt67lpKrlpJrvvIzmiZPkuI3liLDlr7nmlrlcclxuICAgICAgICAgICBpZihNYXRoLmFicyh0aGlzLm5vZGUuekluZGV4LW9BdHRrYWJsZU9iai56SW5kZXgpPjY0KXtcclxuICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICAvL+WPjOaWueW3puWPs+S9jee9ruebuOWPje+8jOW5tuacieS4gOautei3neemu++8jOaJk+S4jeWIsOWvueaWuVxyXG4gICAgICAgICAgIGlmKCgob0F0dGthYmxlT2JqLngtdGhpcy5ub2RlLngpPD0tNjQmJnRoaXMubm9kZS5zY2FsZT4wKXx8XHJcbiAgICAgICAgICAgICAgICgob0F0dGthYmxlT2JqLngtdGhpcy5ub2RlLngpPj02NCYmdGhpcy5ub2RlLnNjYWxlPDApKXtcclxuICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBvQXR0a2FibGVPYmouZ2V0Q29tcG9uZW50KENvbW1vbikuc3VidHJhY3RIcCg0MCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiiq+aJk+WHj+ihgOaXtlxyXG4gICAgICogQHBhcmFtIG5WYWxcclxuICAgICAqL1xyXG4gICAgc3VidHJhY3RIcChuVmFsOm51bWJlcik6dm9pZHtcclxuICAgICAgICBpZihuVmFsPDApe1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgbGV0IHNrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG5cclxuICAgICAgICAvL+WHj+ihgOaViOaenOimgeW7tuaXtuS4gOS4i++8jOWboOS4uuavj+S4quWwj+eyvueBteeahOaUu+WHu+mDvemcgOimgTHnp5Lku6XkuIpcclxuICAgICAgICBsZXQgc2VsZj10aGlzO1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIC8v5YeP6KGA5pe25byA5ZCv6KKr5omT55qE5Yqo55S7XHJcbiAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCdodXJ0JyxmYWxzZSk7XHJcblxyXG4gICAgICAgICAgICBzZWxmLl9uQ3VyckhwPU1hdGgubWF4KHNlbGYuX25DdXJySHAtblZhbCwwKTtcclxuICAgICAgICAgICAgbGV0IG9TdWJCbG9vZCA9IGNjLmZpbmQoXCJTdWJCbG9vZFwiLHNlbGYubm9kZSk7XHJcbiAgICAgICAgICAgIG9TdWJCbG9vZD1jYy5pbnN0YW50aWF0ZShvU3ViQmxvb2QpO1xyXG4gICAgICAgICAgICBvU3ViQmxvb2QuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9blZhbC50b1N0cmluZygpO1xyXG4gICAgICAgICAgICBvU3ViQmxvb2QuYWN0aXZlPXRydWU7XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwi5b2T5YmNbm9kZeeahOWQjeWtl1wiLHNlbGYubm9kZS5uYW1lKVxyXG4gICAgICAgICAgICBzZWxmLm5vZGUuYWRkQ2hpbGQob1N1YkJsb29kKTtcclxuICAgICAgICAgICAgY2MudHdlZW4ob1N1YkJsb29kKVxyXG4gICAgICAgICAgICAgICAgLnRvKDAuMCx7c2NhbGU6My4yfSlcclxuICAgICAgICAgICAgICAgIC50bygwLjIse3NjYWxlOjEuMH0pXHJcbiAgICAgICAgICAgICAgICAuYnkoMC40LHt5OjY0LG9wYWNpdHk6LTEyOH0pXHJcbiAgICAgICAgICAgICAgICAuc3RhcnQoKTtcclxuXHJcbiAgICAgICAgICAgIHNlbGYuc2NoZWR1bGUoKCk9PntcclxuICAgICAgICAgICAgICAgIG9TdWJCbG9vZC5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH0sMC42KTtcclxuXHJcblxyXG4gICAgICAgICAgICBpZihzZWxmLl9uQ3VyckhwPD0wKXtcclxuICAgICAgICAgICAgICAgIHNlbGYuZGllKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCAxLjIsMCwwKTtcclxuICAgIH1cclxuICAgIGRpZSgpOnZvaWR7XHJcbiAgICAgICAgbGV0IG9DdXJySGVybyA9IHRoaXMubm9kZTtcclxuICAgICAgICBsZXQgc2tlbGV0b249b0N1cnJIZXJvLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgc2tlbGV0b24uc2NoZWR1bGUoZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIC8vIOi/memHjOeahCB0aGlzIOaMh+WQkSBjb21wb25lbnRcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ2RlYWQnLGZhbHNlKTtcclxuICAgICAgICB9LCAxLDAsMCk7XHJcbiAgICB9XHJcbn1cclxuIl19