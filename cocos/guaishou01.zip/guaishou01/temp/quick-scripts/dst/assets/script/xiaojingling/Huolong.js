
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Huolong.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a833cHQ1KFAL5FaYlGkgFoC', 'Huolong');
// script/xiaojingling/Huolong.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var speed = 120;
cc.Class({
  "extends": cc.Component,
  properties: {
    _bIsMoving: false,
    _oMoveDirection: null,
    _oMoveTo: null
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    cc.Canvas.instance.node.on(cc.Node.EventType.TOUCH_END, function (event) {
      var nMoveToX = event['getLocationX']();
      var nMoveToY = event['getLocationY']();
      var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY)); // console.log("nMoveToX",nMoveToX)
      // console.log('oMoveToV2',oMoveToV2);
      // console.log('oMoveToV2.x',oMoveToV2.x);

      this._oMoveDirection = {
        _nX: 0,
        _nY: 0
      }; //

      var oCurrHero = cc.find('Canvas/Huolong');
      console.log('oCurrHero', oCurrHero);
      this._oMoveDirection._nX = oCurrHero.x <= oMoveToV2.x ? 1 : -1;
      this._oMoveDirection._nY = oCurrHero.y <= oMoveToV2.y ? 1 : -1;
      console.log('this._oMoveDirection', this._oMoveDirection); //

      this._oMoveTo = {
        _nX: oMoveToV2.x,
        _nY: oMoveToV2.y
      };
      var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
      oSkeleton.setAnimation(1, 'walk', true); // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
      // let traceEntry = skeleton.setAnimation(1,'skill01',false);
      // skeleton.setTrackCompleteListener(traceEntry,function () {
      //     skeleton.clearTrack(1);
      // })
    });
  },
  update: function update(dt) {
    var oCurrHero = cc.find('Canvas/Huolong'); // console.log('oCurrHero',oCurrHero);
    // console.log('this._oMoveDirection',this._oMoveDirection)
    // if((oCurrHero.x<=this._oMoveTo._nX&&this._oMoveDirection._nX<0)||
    //     (oCurrHero.x>=this._oMoveTo._nX&&this._oMoveDirection._nX>0)){
    //     this._oMoveDirection._nX=0
    // }
    // if((oCurrHero.y<=this._oMoveTo._nY&&this._oMoveDirection._nY<0)||
    //     (oCurrHero.y>=this._oMoveTo._nY&&this._oMoveDirection._nY>0)){
    //     this._oMoveDirection._nY=0
    // }
    // if(this._oMoveDirection._nX==0&&this._oMoveDirection._nY==0){
    //     return;
    // }
    //
    // oCurrHero.x+=this._oMoveDirection._nX*120*dt;
    // oCurrHero.y+=this._oMoveDirection._nY*120*dt;
    //
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEh1b2xvbmcuanMiXSwibmFtZXMiOlsic3BlZWQiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIl9iSXNNb3ZpbmciLCJfb01vdmVEaXJlY3Rpb24iLCJfb01vdmVUbyIsInN0YXJ0IiwiQ2FudmFzIiwiaW5zdGFuY2UiLCJub2RlIiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfRU5EIiwiZXZlbnQiLCJuTW92ZVRvWCIsIm5Nb3ZlVG9ZIiwib01vdmVUb1YyIiwiY29udmVydFRvTm9kZVNwYWNlQVIiLCJ2MiIsIl9uWCIsIl9uWSIsIm9DdXJySGVybyIsImZpbmQiLCJjb25zb2xlIiwibG9nIiwieCIsInkiLCJvU2tlbGV0b24iLCJnZXRDb21wb25lbnQiLCJzcCIsIlNrZWxldG9uIiwic2V0QW5pbWF0aW9uIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUEsS0FBSyxHQUFDLEdBQVo7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBQyxLQURIO0FBRVJDLElBQUFBLGVBQWUsRUFBQyxJQUZSO0FBR1JDLElBQUFBLFFBQVEsRUFBQztBQUhELEdBSFA7QUFTTDtBQUVBO0FBRUFDLEVBQUFBLEtBYkssbUJBYUk7QUFDTFAsSUFBQUEsRUFBRSxDQUFDUSxNQUFILENBQVVDLFFBQVYsQ0FBbUJDLElBQW5CLENBQXdCQyxFQUF4QixDQUEyQlgsRUFBRSxDQUFDWSxJQUFILENBQVFDLFNBQVIsQ0FBa0JDLFNBQTdDLEVBQXVELFVBQVVDLEtBQVYsRUFBaUI7QUFDcEUsVUFBSUMsUUFBUSxHQUFHRCxLQUFLLENBQUMsY0FBRCxDQUFMLEVBQWY7QUFDQSxVQUFJRSxRQUFRLEdBQUdGLEtBQUssQ0FBQyxjQUFELENBQUwsRUFBZjtBQUNBLFVBQUlHLFNBQVMsR0FBQ2xCLEVBQUUsQ0FBQ1EsTUFBSCxDQUFVQyxRQUFWLENBQW1CQyxJQUFuQixDQUF3QlMsb0JBQXhCLENBQTZDbkIsRUFBRSxDQUFDb0IsRUFBSCxDQUFNSixRQUFOLEVBQWVDLFFBQWYsQ0FBN0MsQ0FBZCxDQUhvRSxDQUtwRTtBQUNBO0FBQ0E7O0FBRUEsV0FBS1osZUFBTCxHQUFxQjtBQUFDZ0IsUUFBQUEsR0FBRyxFQUFDLENBQUw7QUFBT0MsUUFBQUEsR0FBRyxFQUFDO0FBQVgsT0FBckIsQ0FUb0UsQ0FVcEU7O0FBQ0EsVUFBSUMsU0FBUyxHQUFHdkIsRUFBRSxDQUFDd0IsSUFBSCxDQUFRLGdCQUFSLENBQWhCO0FBRUFDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBd0JILFNBQXhCO0FBQ0EsV0FBS2xCLGVBQUwsQ0FBcUJnQixHQUFyQixHQUEwQkUsU0FBUyxDQUFDSSxDQUFWLElBQWFULFNBQVMsQ0FBQ1MsQ0FBeEIsR0FBMkIsQ0FBM0IsR0FBNkIsQ0FBQyxDQUF2RDtBQUNBLFdBQUt0QixlQUFMLENBQXFCaUIsR0FBckIsR0FBMEJDLFNBQVMsQ0FBQ0ssQ0FBVixJQUFhVixTQUFTLENBQUNVLENBQXhCLEdBQTJCLENBQTNCLEdBQTZCLENBQUMsQ0FBdkQ7QUFDQUgsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksc0JBQVosRUFBbUMsS0FBS3JCLGVBQXhDLEVBaEJvRSxDQWlCcEU7O0FBQ0EsV0FBS0MsUUFBTCxHQUFjO0FBQ1ZlLFFBQUFBLEdBQUcsRUFBQ0gsU0FBUyxDQUFDUyxDQURKO0FBRVZMLFFBQUFBLEdBQUcsRUFBQ0osU0FBUyxDQUFDVTtBQUZKLE9BQWQ7QUFLQSxVQUFJQyxTQUFTLEdBQUNOLFNBQVMsQ0FBQ08sWUFBVixDQUF1QkMsRUFBRSxDQUFDQyxRQUExQixDQUFkO0FBQ0FILE1BQUFBLFNBQVMsQ0FBQ0ksWUFBVixDQUF1QixDQUF2QixFQUF5QixNQUF6QixFQUFnQyxJQUFoQyxFQXhCb0UsQ0E2QnBFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSCxLQWxDRDtBQW1DSCxHQWpESTtBQW1ETEMsRUFBQUEsTUFuREssa0JBbURHQyxFQW5ESCxFQW1ETztBQUNSLFFBQUlaLFNBQVMsR0FBR3ZCLEVBQUUsQ0FBQ3dCLElBQUgsQ0FBUSxnQkFBUixDQUFoQixDQURRLENBRVI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSjtBQUNDO0FBdEVJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5jb25zdCBzcGVlZD0xMjA7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgX2JJc01vdmluZzpmYWxzZSxcclxuICAgICAgICBfb01vdmVEaXJlY3Rpb246bnVsbCxcclxuICAgICAgICBfb01vdmVUbzpudWxsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uIChldmVudCkge1xyXG4gICAgICAgICAgICBsZXQgbk1vdmVUb1ggPSBldmVudFsnZ2V0TG9jYXRpb25YJ10oKTtcclxuICAgICAgICAgICAgbGV0IG5Nb3ZlVG9ZID0gZXZlbnRbJ2dldExvY2F0aW9uWSddKCk7XHJcbiAgICAgICAgICAgIGxldCBvTW92ZVRvVjI9Y2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIoY2MudjIobk1vdmVUb1gsbk1vdmVUb1kpKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwibk1vdmVUb1hcIixuTW92ZVRvWClcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMi54JyxvTW92ZVRvVjIueCk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbj17X25YOjAsX25ZOjB9O1xyXG4gICAgICAgICAgICAvL1xyXG4gICAgICAgICAgICBsZXQgb0N1cnJIZXJvID0gY2MuZmluZCgnQ2FudmFzL0h1b2xvbmcnKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0ob0N1cnJIZXJvLng8PW9Nb3ZlVG9WMi54KT8xOi0xO1xyXG4gICAgICAgICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk9KG9DdXJySGVyby55PD1vTW92ZVRvVjIueSk/MTotMTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbik7XHJcbiAgICAgICAgICAgIC8vXHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlVG89e1xyXG4gICAgICAgICAgICAgICAgX25YOm9Nb3ZlVG9WMi54LFxyXG4gICAgICAgICAgICAgICAgX25ZOm9Nb3ZlVG9WMi55LFxyXG4gICAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgICAgbGV0IG9Ta2VsZXRvbj1vQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgb1NrZWxldG9uLnNldEFuaW1hdGlvbigxLCd3YWxrJyx0cnVlKTtcclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGxldCBza2VsZXRvbj1jYy5maW5kKCdDYW52YXMvSHVvbG9uZycpLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIC8vIGxldCB0cmFjZUVudHJ5ID0gc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3NraWxsMDEnLGZhbHNlKTtcclxuICAgICAgICAgICAgLy8gc2tlbGV0b24uc2V0VHJhY2tDb21wbGV0ZUxpc3RlbmVyKHRyYWNlRW50cnksZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvLyAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgLy8gfSlcclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlIChkdCkge1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSBjYy5maW5kKCdDYW52YXMvSHVvbG9uZycpO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbilcclxuICAgICAgICAvLyBpZigob0N1cnJIZXJvLng8PXRoaXMuX29Nb3ZlVG8uX25YJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg8MCl8fFxyXG4gICAgICAgIC8vICAgICAob0N1cnJIZXJvLng+PXRoaXMuX29Nb3ZlVG8uX25YJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg+MCkpe1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg9MFxyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyBpZigob0N1cnJIZXJvLnk8PXRoaXMuX29Nb3ZlVG8uX25ZJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk8MCl8fFxyXG4gICAgICAgIC8vICAgICAob0N1cnJIZXJvLnk+PXRoaXMuX29Nb3ZlVG8uX25ZJiZ0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk+MCkpe1xyXG4gICAgICAgIC8vICAgICB0aGlzLl9vTW92ZURpcmVjdGlvbi5fblk9MFxyXG4gICAgICAgIC8vIH1cclxuICAgICAgICAvLyBpZih0aGlzLl9vTW92ZURpcmVjdGlvbi5fblg9PTAmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT09MCl7XHJcbiAgICAgICAgLy8gICAgIHJldHVybjtcclxuICAgICAgICAvLyB9XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBvQ3Vyckhlcm8ueCs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25YKjEyMCpkdDtcclxuICAgICAgICAvLyBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKjEyMCpkdDtcclxuICAgIC8vXHJcbiAgICB9LFxyXG59KTtcclxuIl19