
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/MyHuolong.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ac5eeu2IzNBAr/RIh2OKbLI', 'MyHuolong');
// script/xiaojingling/MyHuolong.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var ccclass = cc._decorator.ccclass;
var speed = 120;
var customScaleX = 0.7;
var MyHuuolong = /** @class */ (function (_super) {
    __extends(MyHuuolong, _super);
    function MyHuuolong() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._bIsMoving = false;
        _this._oMoveDirection = null;
        _this._oMoveTo = null;
        return _this;
    }
    // onLoad () {}
    MyHuuolong.prototype.start = function () {
    };
    MyHuuolong.prototype.update = function (dt) {
        if (!this._bIsMoving) {
            return;
        }
        var oCurrHero = this.node;
        // console.log('oCurrHero',oCurrHero);
        // console.log('this._oMoveDirection',this._oMoveDirection)
        if ((oCurrHero.x <= this._oMoveTo._nX && this._oMoveDirection._nX < 0) ||
            (oCurrHero.x >= this._oMoveTo._nX && this._oMoveDirection._nX > 0)) {
            this._oMoveDirection._nX = 0;
        }
        if ((oCurrHero.y <= this._oMoveTo._nY && this._oMoveDirection._nY < 0) ||
            (oCurrHero.y >= this._oMoveTo._nY && this._oMoveDirection._nY > 0)) {
            this._oMoveDirection._nY = 0;
        }
        if (this._oMoveDirection._nX == 0 && this._oMoveDirection._nY == 0) {
            this._bIsMoving = false;
            var skeleton = oCurrHero.getComponent(sp.Skeleton);
            skeleton.clearTrack(1);
            skeleton.setAnimation(1, 'stand', true);
            return;
        }
        oCurrHero.x += this._oMoveDirection._nX * speed * dt;
        oCurrHero.y += this._oMoveDirection._nY * speed * dt;
        oCurrHero.zIndex = -oCurrHero.y;
    };
    MyHuuolong.prototype.moveTo = function (nPosX, nPosY) {
        // console.log("nMoveToX",nMoveToX)
        // console.log('oMoveToV2',oMoveToV2);
        // console.log('oMoveToV2.x',oMoveToV2.x);
        this._oMoveDirection = { _nX: 0, _nY: 0 };
        //
        var oCurrHero = this.node;
        console.log('oCurrHero', oCurrHero);
        this._oMoveDirection._nX = (oCurrHero.x <= nPosX) ? 1 : -1;
        this._oMoveDirection._nY = (oCurrHero.y <= nPosY) ? 1 : -1;
        console.log('this._oMoveDirection', this._oMoveDirection);
        //
        oCurrHero.scaleX = this._oMoveDirection._nX * customScaleX;
        this._oMoveTo = {
            _nX: nPosX,
            _nY: nPosY,
        };
        if (!this._bIsMoving) {
            var oSkeleton = oCurrHero.getComponent(sp.Skeleton);
            oSkeleton.setAnimation(1, 'walk', true);
            this._bIsMoving = true;
        }
    };
    MyHuuolong.prototype.attk = function (nPosX, nPosY) {
        var oCurrHero = this.node;
        // if(nPosX<oCurrHero.x){
        //     oCurrHero.scaleX=oCurrHero.scaleX*-1;
        // }
        var skeleton = oCurrHero.getComponent(sp.Skeleton);
        var traceEntry = skeleton.setAnimation(2, 'skill01', false);
        skeleton.setTrackCompleteListener(traceEntry, function () {
            skeleton.clearTrack(2);
        });
    };
    MyHuuolong.prototype.die = function () {
    };
    MyHuuolong = __decorate([
        ccclass
    ], MyHuuolong);
    return MyHuuolong;
}(cc.Component));
exports.default = MyHuuolong;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXE15SHVvbG9uZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUUzRSxJQUFBLE9BQU8sR0FBSyxFQUFFLENBQUMsVUFBVSxRQUFsQixDQUFtQjtBQUNqQyxJQUFNLEtBQUssR0FBQyxHQUFHLENBQUM7QUFDaEIsSUFBTSxZQUFZLEdBQUMsR0FBRyxDQUFDO0FBRXZCO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBc0ZDO1FBcEZHLGdCQUFVLEdBQVMsS0FBSyxDQUFDO1FBRXpCLHFCQUFlLEdBQXlCLElBQUksQ0FBQztRQUU3QyxjQUFRLEdBQXlCLElBQUksQ0FBQzs7SUFnRjFDLENBQUM7SUE5RUcsZUFBZTtJQUVmLDBCQUFLLEdBQUw7SUFFQSxDQUFDO0lBRUQsMkJBQU0sR0FBTixVQUFRLEVBQUU7UUFDTixJQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBQztZQUNoQixPQUFPO1NBQ1Y7UUFFRCxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzFCLHNDQUFzQztRQUN0QywyREFBMkQ7UUFDM0QsSUFBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUMsRUFBQztZQUM3RCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLENBQUM7WUFDM0QsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQyxFQUFDO1lBQzdELElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsQ0FBQTtTQUM3QjtRQUNELElBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLElBQUUsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxJQUFFLENBQUMsRUFBQztZQUN4RCxJQUFJLENBQUMsVUFBVSxHQUFDLEtBQUssQ0FBQztZQUN0QixJQUFJLFFBQVEsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNuRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE9BQU8sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxPQUFPO1NBQ1Y7UUFFRCxTQUFTLENBQUMsQ0FBQyxJQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLEtBQUssR0FBQyxFQUFFLENBQUM7UUFDL0MsU0FBUyxDQUFDLENBQUMsSUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxLQUFLLEdBQUMsRUFBRSxDQUFDO1FBRS9DLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sS0FBWSxFQUFDLEtBQVk7UUFDNUIsbUNBQW1DO1FBQ25DLHNDQUFzQztRQUN0QywwQ0FBMEM7UUFFMUMsSUFBSSxDQUFDLGVBQWUsR0FBQyxFQUFDLEdBQUcsRUFBQyxDQUFDLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBQ25DLEVBQUU7UUFDRixJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRTFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxHQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBRSxLQUFLLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsR0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUUsS0FBSyxDQUFDLENBQUEsQ0FBQyxDQUFBLENBQUMsQ0FBQSxDQUFDLENBQUEsQ0FBQyxDQUFDLENBQUM7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDekQsRUFBRTtRQUVGLFNBQVMsQ0FBQyxNQUFNLEdBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxRQUFRLEdBQUM7WUFDVixHQUFHLEVBQUMsS0FBSztZQUNULEdBQUcsRUFBQyxLQUFLO1NBQ1osQ0FBQztRQUNGLElBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFDO1lBQ2hCLElBQUksU0FBUyxHQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQ2xELFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFDLE1BQU0sRUFBQyxJQUFJLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFDLElBQUksQ0FBQztTQUN4QjtJQUNMLENBQUM7SUFFRCx5QkFBSSxHQUFKLFVBQUssS0FBWSxFQUFDLEtBQVk7UUFDMUIsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMxQix5QkFBeUI7UUFDekIsNENBQTRDO1FBQzVDLElBQUk7UUFFSixJQUFJLFFBQVEsR0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNqRCxJQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsRUFBQyxTQUFTLEVBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFVBQVUsRUFBQztZQUN6QyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELHdCQUFHLEdBQUg7SUFFQSxDQUFDO0lBckZnQixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBc0Y5QjtJQUFELGlCQUFDO0NBdEZELEFBc0ZDLENBdEZ1QyxFQUFFLENBQUMsU0FBUyxHQXNGbkQ7a0JBdEZvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY29uc3Qge2NjY2xhc3MsfSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IHNwZWVkPTEyMDtcclxuY29uc3QgY3VzdG9tU2NhbGVYPTAuNztcclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlIdXVvbG9uZyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgX2JJc01vdmluZzpib29sZWFuPWZhbHNlO1xyXG5cclxuICAgIF9vTW92ZURpcmVjdGlvbjp7X25YOm51bWJlcixfblk6bnVtYmVyfT1udWxsO1xyXG5cclxuICAgIF9vTW92ZVRvOntfblg6bnVtYmVyLF9uWTpudW1iZXJ9PW51bGw7XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUgKGR0KSB7XHJcbiAgICAgICAgaWYoIXRoaXMuX2JJc01vdmluZyl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29DdXJySGVybycsb0N1cnJIZXJvKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygndGhpcy5fb01vdmVEaXJlY3Rpb24nLHRoaXMuX29Nb3ZlRGlyZWN0aW9uKVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueDw9dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWDwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueD49dGhpcy5fb01vdmVUby5fblgmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChvQ3Vyckhlcm8ueTw9dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWTwwKXx8XHJcbiAgICAgICAgICAgIChvQ3Vyckhlcm8ueT49dGhpcy5fb01vdmVUby5fblkmJnRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT4wKSl7XHJcbiAgICAgICAgICAgIHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWT0wXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKHRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWD09MCYmdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPT0wKXtcclxuICAgICAgICAgICAgdGhpcy5fYklzTW92aW5nPWZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgc2tlbGV0b24gPSBvQ3Vyckhlcm8uZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3N0YW5kJyx0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLngrPXRoaXMuX29Nb3ZlRGlyZWN0aW9uLl9uWCpzcGVlZCpkdDtcclxuICAgICAgICBvQ3Vyckhlcm8ueSs9dGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZKnNwZWVkKmR0O1xyXG5cclxuICAgICAgICBvQ3Vyckhlcm8uekluZGV4PS1vQ3Vyckhlcm8ueTtcclxuICAgIH1cclxuXHJcbiAgICBtb3ZlVG8oblBvc1g6bnVtYmVyLG5Qb3NZOm51bWJlcik6dm9pZHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5Nb3ZlVG9YXCIsbk1vdmVUb1gpXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ29Nb3ZlVG9WMicsb01vdmVUb1YyKTtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZygnb01vdmVUb1YyLngnLG9Nb3ZlVG9WMi54KTtcclxuXHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb249e19uWDowLF9uWTowfTtcclxuICAgICAgICAvL1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKCdvQ3Vyckhlcm8nLG9DdXJySGVybyk7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25YPShvQ3Vyckhlcm8ueDw9blBvc1gpPzE6LTE7XHJcbiAgICAgICAgdGhpcy5fb01vdmVEaXJlY3Rpb24uX25ZPShvQ3Vyckhlcm8ueTw9blBvc1kpPzE6LTE7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3RoaXMuX29Nb3ZlRGlyZWN0aW9uJyx0aGlzLl9vTW92ZURpcmVjdGlvbik7XHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgb0N1cnJIZXJvLnNjYWxlWD10aGlzLl9vTW92ZURpcmVjdGlvbi5fblgqY3VzdG9tU2NhbGVYO1xyXG4gICAgICAgIHRoaXMuX29Nb3ZlVG89e1xyXG4gICAgICAgICAgICBfblg6blBvc1gsXHJcbiAgICAgICAgICAgIF9uWTpuUG9zWSxcclxuICAgICAgICB9O1xyXG4gICAgICAgIGlmKCF0aGlzLl9iSXNNb3Zpbmcpe1xyXG4gICAgICAgICAgICBsZXQgb1NrZWxldG9uPW9DdXJySGVyby5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgICAgICBvU2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3dhbGsnLHRydWUpO1xyXG4gICAgICAgICAgICB0aGlzLl9iSXNNb3Zpbmc9dHJ1ZTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXR0ayhuUG9zWDpudW1iZXIsblBvc1k6bnVtYmVyKTp2b2lke1xyXG4gICAgICAgIGxldCBvQ3Vyckhlcm8gPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgLy8gaWYoblBvc1g8b0N1cnJIZXJvLngpe1xyXG4gICAgICAgIC8vICAgICBvQ3Vyckhlcm8uc2NhbGVYPW9DdXJySGVyby5zY2FsZVgqLTE7XHJcbiAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICBsZXQgc2tlbGV0b249b0N1cnJIZXJvLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgbGV0IHRyYWNlRW50cnkgPSBza2VsZXRvbi5zZXRBbmltYXRpb24oMiwnc2tpbGwwMScsZmFsc2UpO1xyXG4gICAgICAgIHNrZWxldG9uLnNldFRyYWNrQ29tcGxldGVMaXN0ZW5lcih0cmFjZUVudHJ5LGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygyKTtcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuICAgIGRpZSgpOnZvaWR7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==