
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/FightScene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b959c5jWaxClrV2I6mL83rC', 'FightScene');
// script/xiaojingling/FightScene.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var MsgSender_1 = require("../../msg/MsgSender");
var AllHandler_1 = require("../../resultHandler/AllHandler");
var WebUtil_1 = require("./WebUtil");
var mod_GameMsgProcotol = require("../../msg/GameMsgProtocol");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var heroName = "Huolong";
var FightScene = /** @class */ (function (_super) {
    __extends(FightScene, _super);
    function FightScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._oMyHreo = null;
        return _this;
    }
    // onLoad () {}
    FightScene.prototype.start = function () {
        var _this = this;
        var collisionManager = cc.director.getCollisionManager();
        collisionManager.enabled = true;
        collisionManager.enabledDebugDraw = true;
        collisionManager.enabledDrawBoundingBox = true;
        console.log('collisionManager', collisionManager);
        var colliders = collisionManager['_colliders'];
        console.log('colliders', colliders);
        MsgSender_1.default.getInstance().connect(function () {
            var oAllHandler = new AllHandler_1.default();
            MsgSender_1.default.getInstance().onMsgReceived = function (nMsgCode, oMsgBody) {
                oAllHandler.handle(nMsgCode, oMsgBody);
            };
            var userId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            var heroAvatar = WebUtil_1.default.getQueryParam("heroAvatar");
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_ENTRY_CMD, mod_GameMsgProcotol.msg.UserEntryCmd.create({
                userId: userId,
                heroAvatar: heroAvatar
            }));
            MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.WHO_ELSE_IS_HERE_CMD, mod_GameMsgProcotol.msg.WhoElseIsHereCmd.create({}));
        });
        // HeroFactory.createAsync(heroName, (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     // heroNode.x = 300 * Math.random();
        //     // heroNode.y = 300 * Math.random();
        //     heroNode.x = -200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Xiyi", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 0;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        // HeroFactory.createAsync("Gui", (heroNode) => {
        //     cc.Canvas.instance.node.addChild(heroNode);
        //     heroNode.x = 200;
        //     heroNode.y = 0;
        //     heroNode.active = true;
        //     let skeleton = heroNode.getComponent(sp.Skeleton);
        //     skeleton.setAnimation(1, 'stand', true);
        // });
        cc.Canvas.instance.node.on(cc.Node.EventType.MOUSE_UP, function (event) {
            switch (event['getButton']()) {
                case 0: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    // cc.find('Canvas/Huolong').getComponent(MyHuolong).attk(oMoveToV2.x,oMoveToV2.y);
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).attk(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.attk(oMoveToV2.x, oMoveToV2.y);
                    break;
                }
                case 2: {
                    var nMoveToX = event['getLocationX']();
                    var nMoveToY = event['getLocationY']();
                    var oMoveToV2 = cc.Canvas.instance.node.convertToNodeSpaceAR(cc.v2(nMoveToX, nMoveToY));
                    if (_this._oMyHreo == null) {
                        return;
                    }
                    // cc.find(`Canvas/${heroName}`).getComponent(Common).moveTo(oMoveToV2.x, oMoveToV2.y);
                    _this._oMyHreo.moveTo(oMoveToV2.x, oMoveToV2.y);
                    MsgSender_1.default.getInstance().sendMsg(mod_GameMsgProcotol.msg.MsgCode.USER_MOVE_TO_CMD, mod_GameMsgProcotol.msg.UserMoveToCmd.create({
                        // moveFromPosX:this._oMyHreo.node.x,
                        // moveFromPosY:this._oMyHreo.node.y,
                        moveToPosX: oMoveToV2.x,
                        moveToPosY: oMoveToV2.y,
                    }));
                    break;
                }
            }
            // let skeleton=cc.find('Canvas/Huolong').getComponent(sp.Skeleton);
            // let traceEntry = skeleton.setAnimation(1,'skill01',false);
            // skeleton.setTrackCompleteListener(traceEntry,function () {
            //     skeleton.clearTrack(1);
            // })
        });
    };
    FightScene.prototype.update = function (dt) {
        //
    };
    FightScene = __decorate([
        ccclass
    ], FightScene);
    return FightScene;
}(cc.Component));
exports.default = FightScene;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEZpZ2h0U2NlbmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVUEsaURBQTRDO0FBQzVDLDZEQUF3RDtBQUN4RCxxQ0FBZ0M7QUFDaEMsK0RBQWdFO0FBRzFELElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBQzFDLElBQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUUzQjtJQUF3Qyw4QkFBWTtJQUFwRDtRQUFBLHFFQXNIQztRQXBIRyxjQUFRLEdBQVEsSUFBSSxDQUFDOztJQW9IekIsQ0FBQztJQWpIRyxlQUFlO0lBRWYsMEJBQUssR0FBTDtRQUFBLGlCQXlHQztRQXhHRyxJQUFJLGdCQUFnQixHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUN6RCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUMsSUFBSSxDQUFDO1FBQzlCLGdCQUFnQixDQUFDLGdCQUFnQixHQUFDLElBQUksQ0FBQztRQUN2QyxnQkFBZ0IsQ0FBQyxzQkFBc0IsR0FBRSxJQUFJLENBQUM7UUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2pELElBQUksU0FBUyxHQUFHLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRW5DLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUFDO1lBQzVCLElBQUksV0FBVyxHQUFHLElBQUksb0JBQVUsRUFBRSxDQUFDO1lBQ25DLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsYUFBYSxHQUFDLFVBQUMsUUFBUSxFQUFDLFFBQVE7Z0JBQ3BELFdBQVcsQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzFDLENBQUMsQ0FBQTtZQUVELElBQUksTUFBTSxHQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQU8sQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUM1RCxJQUFJLFVBQVUsR0FBQyxpQkFBTyxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVuRCxtQkFBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FDM0IsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQzlDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDO2dCQUN4QyxNQUFNLEVBQUMsTUFBTTtnQkFDYixVQUFVLEVBQUMsVUFBVTthQUN4QixDQUFDLENBQ0wsQ0FBQztZQUNGLG1CQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsT0FBTyxDQUMzQixtQkFBbUIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLG9CQUFvQixFQUNwRCxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUN0RCxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7UUFHSCxvREFBb0Q7UUFDcEQsa0RBQWtEO1FBQ2xELDJDQUEyQztRQUMzQywyQ0FBMkM7UUFDM0MseUJBQXlCO1FBQ3pCLHNCQUFzQjtRQUN0Qiw4QkFBOEI7UUFDOUIseURBQXlEO1FBQ3pELCtDQUErQztRQUMvQyxNQUFNO1FBQ04sa0RBQWtEO1FBQ2xELGtEQUFrRDtRQUNsRCxzQkFBc0I7UUFDdEIsc0JBQXNCO1FBQ3RCLDhCQUE4QjtRQUM5Qix5REFBeUQ7UUFDekQsK0NBQStDO1FBQy9DLE1BQU07UUFDTixpREFBaUQ7UUFDakQsa0RBQWtEO1FBQ2xELHdCQUF3QjtRQUN4QixzQkFBc0I7UUFDdEIsOEJBQThCO1FBQzlCLHlEQUF5RDtRQUN6RCwrQ0FBK0M7UUFDL0MsTUFBTTtRQUVOLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLFVBQUMsS0FBZTtZQUNuRSxRQUFRLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxFQUFFO2dCQUMxQixLQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNKLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO29CQUN2QyxJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBRXhGLG1GQUFtRjtvQkFDbkYsSUFBRyxLQUFJLENBQUMsUUFBUSxJQUFFLElBQUksRUFBQzt3QkFDbkIsT0FBTztxQkFDVjtvQkFDRCxxRkFBcUY7b0JBQ3JGLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUM3QyxNQUFNO2lCQUNUO2dCQUNELEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ0osSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7b0JBQ3ZDLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO29CQUN2QyxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztvQkFDeEYsSUFBRyxLQUFJLENBQUMsUUFBUSxJQUFFLElBQUksRUFBQzt3QkFDbkIsT0FBTztxQkFDVjtvQkFDRCx1RkFBdUY7b0JBQ3ZGLEtBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUMvQyxtQkFBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FDM0IsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFDaEQsbUJBQW1CLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUM7d0JBQ3pDLHFDQUFxQzt3QkFDckMscUNBQXFDO3dCQUNyQyxVQUFVLEVBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ3RCLFVBQVUsRUFBQyxTQUFTLENBQUMsQ0FBQztxQkFFekIsQ0FBQyxDQUNMLENBQUM7b0JBRUYsTUFBTTtpQkFDVDthQUNKO1lBR0Qsb0VBQW9FO1lBQ3BFLDZEQUE2RDtZQUM3RCw2REFBNkQ7WUFDN0QsOEJBQThCO1lBQzlCLEtBQUs7UUFDVCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sRUFBRTtRQUVMLEVBQUU7SUFDTixDQUFDO0lBckhnQixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBc0g5QjtJQUFELGlCQUFDO0NBdEhELEFBc0hDLENBdEh1QyxFQUFFLENBQUMsU0FBUyxHQXNIbkQ7a0JBdEhvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gVHlwZVNjcmlwdDpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvdHlwZXNjcmlwdC5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5pbXBvcnQgTXlIdW9sb25nIGZyb20gXCIuL015SHVvbG9uZ1wiO1xyXG5pbXBvcnQgRXl1IGZyb20gXCIuL0V5dVwiO1xyXG5pbXBvcnQgQ29tbW9uIGZyb20gXCIuL0NvbW1vblwiO1xyXG5pbXBvcnQgSGVyb0ZhY3RvcnkgZnJvbSBcIi4vSGVyb0ZhY3RvcnlcIjtcclxuaW1wb3J0IE1zZ1NlbmRlciBmcm9tIFwiLi4vLi4vbXNnL01zZ1NlbmRlclwiO1xyXG5pbXBvcnQgQWxsSGFuZGxlciBmcm9tIFwiLi4vLi4vcmVzdWx0SGFuZGxlci9BbGxIYW5kbGVyXCI7XHJcbmltcG9ydCBXZWJVdGlsIGZyb20gXCIuL1dlYlV0aWxcIjtcclxuaW1wb3J0IG1vZF9HYW1lTXNnUHJvY290b2w9cmVxdWlyZShcIi4uLy4uL21zZy9HYW1lTXNnUHJvdG9jb2xcIik7XHJcblxyXG5cclxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcbmNvbnN0IGhlcm9OYW1lID0gXCJIdW9sb25nXCI7XHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEZpZ2h0U2NlbmUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIF9vTXlIcmVvOkNvbW1vbj1udWxsO1xyXG5cclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge31cclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICBsZXQgY29sbGlzaW9uTWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWQ9dHJ1ZTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXc9dHJ1ZTtcclxuICAgICAgICBjb2xsaXNpb25NYW5hZ2VyLmVuYWJsZWREcmF3Qm91bmRpbmdCb3ggPXRydWU7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbGxpc2lvbk1hbmFnZXInLGNvbGxpc2lvbk1hbmFnZXIpO1xyXG4gICAgICAgIGxldCBjb2xsaWRlcnMgPSBjb2xsaXNpb25NYW5hZ2VyWydfY29sbGlkZXJzJ107XHJcbiAgICAgICAgY29uc29sZS5sb2coJ2NvbGxpZGVycycsY29sbGlkZXJzKTtcclxuXHJcbiAgICAgICAgTXNnU2VuZGVyLmdldEluc3RhbmNlKCkuY29ubmVjdCgoKT0+e1xyXG4gICAgICAgICAgICBsZXQgb0FsbEhhbmRsZXIgPSBuZXcgQWxsSGFuZGxlcigpO1xyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5vbk1zZ1JlY2VpdmVkPShuTXNnQ29kZSxvTXNnQm9keSk9PntcclxuICAgICAgICAgICAgICAgIG9BbGxIYW5kbGVyLmhhbmRsZShuTXNnQ29kZSxvTXNnQm9keSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCB1c2VySWQ9TnVtYmVyLnBhcnNlSW50KFdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcInVzZXJJZFwiKSk7XHJcbiAgICAgICAgICAgIGxldCBoZXJvQXZhdGFyPVdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcImhlcm9BdmF0YXJcIik7XHJcblxyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgbW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZS5VU0VSX0VOVFJZX0NNRCxcclxuICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLlVzZXJFbnRyeUNtZC5jcmVhdGUoe1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJJZDp1c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVyb0F2YXRhcjpoZXJvQXZhdGFyXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgbW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZS5XSE9fRUxTRV9JU19IRVJFX0NNRCxcclxuICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLldob0Vsc2VJc0hlcmVDbWQuY3JlYXRlKHt9KVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH0pO1xyXG5cclxuXHJcbiAgICAgICAgLy8gSGVyb0ZhY3RvcnkuY3JlYXRlQXN5bmMoaGVyb05hbWUsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIC8vIGhlcm9Ob2RlLnggPSAzMDAgKiBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgIC8vICAgICAvLyBoZXJvTm9kZS55ID0gMzAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAvLyAgICAgaGVyb05vZGUueCA9IC0yMDA7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnkgPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICBsZXQgc2tlbGV0b24gPSBoZXJvTm9kZS5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vICAgICBza2VsZXRvbi5zZXRBbmltYXRpb24oMSwgJ3N0YW5kJywgdHJ1ZSk7XHJcbiAgICAgICAgLy8gfSk7XHJcbiAgICAgICAgLy8gSGVyb0ZhY3RvcnkuY3JlYXRlQXN5bmMoXCJYaXlpXCIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnggPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS55ID0gMDtcclxuICAgICAgICAvLyAgICAgaGVyb05vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgbGV0IHNrZWxldG9uID0gaGVyb05vZGUuZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAvLyAgICAgc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsICdzdGFuZCcsIHRydWUpO1xyXG4gICAgICAgIC8vIH0pO1xyXG4gICAgICAgIC8vIEhlcm9GYWN0b3J5LmNyZWF0ZUFzeW5jKFwiR3VpXCIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5hZGRDaGlsZChoZXJvTm9kZSk7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnggPSAyMDA7XHJcbiAgICAgICAgLy8gICAgIGhlcm9Ob2RlLnkgPSAwO1xyXG4gICAgICAgIC8vICAgICBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgIC8vICAgICBsZXQgc2tlbGV0b24gPSBoZXJvTm9kZS5nZXRDb21wb25lbnQoc3AuU2tlbGV0b24pO1xyXG4gICAgICAgIC8vICAgICBza2VsZXRvbi5zZXRBbmltYXRpb24oMSwgJ3N0YW5kJywgdHJ1ZSk7XHJcbiAgICAgICAgLy8gfSk7XHJcblxyXG4gICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX1VQLCAoZXZlbnQ6IGNjLkV2ZW50KSA9PiB7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoZXZlbnRbJ2dldEJ1dHRvbiddKCkpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDoge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuTW92ZVRvWCA9IGV2ZW50WydnZXRMb2NhdGlvblgnXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBuTW92ZVRvWSA9IGV2ZW50WydnZXRMb2NhdGlvblknXSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCBvTW92ZVRvVjIgPSBjYy5DYW52YXMuaW5zdGFuY2Uubm9kZS5jb252ZXJ0VG9Ob2RlU3BhY2VBUihjYy52MihuTW92ZVRvWCwgbk1vdmVUb1kpKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2MuZmluZCgnQ2FudmFzL0h1b2xvbmcnKS5nZXRDb21wb25lbnQoTXlIdW9sb25nKS5hdHRrKG9Nb3ZlVG9WMi54LG9Nb3ZlVG9WMi55KTtcclxuICAgICAgICAgICAgICAgICAgICBpZih0aGlzLl9vTXlIcmVvPT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvLyBjYy5maW5kKGBDYW52YXMvJHtoZXJvTmFtZX1gKS5nZXRDb21wb25lbnQoQ29tbW9uKS5hdHRrKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb015SHJlby5hdHRrKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYXNlIDI6IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbk1vdmVUb1ggPSBldmVudFsnZ2V0TG9jYXRpb25YJ10oKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgbk1vdmVUb1kgPSBldmVudFsnZ2V0TG9jYXRpb25ZJ10oKTtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgb01vdmVUb1YyID0gY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIoY2MudjIobk1vdmVUb1gsIG5Nb3ZlVG9ZKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYodGhpcy5fb015SHJlbz09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gY2MuZmluZChgQ2FudmFzLyR7aGVyb05hbWV9YCkuZ2V0Q29tcG9uZW50KENvbW1vbikubW92ZVRvKG9Nb3ZlVG9WMi54LCBvTW92ZVRvVjIueSk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fb015SHJlby5tb3ZlVG8ob01vdmVUb1YyLngsIG9Nb3ZlVG9WMi55KTtcclxuICAgICAgICAgICAgICAgICAgICBNc2dTZW5kZXIuZ2V0SW5zdGFuY2UoKS5zZW5kTXNnKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RfR2FtZU1zZ1Byb2NvdG9sLm1zZy5Nc2dDb2RlLlVTRVJfTU9WRV9UT19DTUQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZF9HYW1lTXNnUHJvY290b2wubXNnLlVzZXJNb3ZlVG9DbWQuY3JlYXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1vdmVGcm9tUG9zWDp0aGlzLl9vTXlIcmVvLm5vZGUueCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1vdmVGcm9tUG9zWTp0aGlzLl9vTXlIcmVvLm5vZGUueSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vdmVUb1Bvc1g6b01vdmVUb1YyLngsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb3ZlVG9Qb3NZOm9Nb3ZlVG9WMi55LFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIC8vIGxldCBza2VsZXRvbj1jYy5maW5kKCdDYW52YXMvSHVvbG9uZycpLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIC8vIGxldCB0cmFjZUVudHJ5ID0gc2tlbGV0b24uc2V0QW5pbWF0aW9uKDEsJ3NraWxsMDEnLGZhbHNlKTtcclxuICAgICAgICAgICAgLy8gc2tlbGV0b24uc2V0VHJhY2tDb21wbGV0ZUxpc3RlbmVyKHRyYWNlRW50cnksZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICAvLyAgICAgc2tlbGV0b24uY2xlYXJUcmFjaygxKTtcclxuICAgICAgICAgICAgLy8gfSlcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICB1cGRhdGUoZHQpOiB2b2lkIHtcclxuXHJcbiAgICAgICAgLy9cclxuICAgIH1cclxufVxyXG4iXX0=