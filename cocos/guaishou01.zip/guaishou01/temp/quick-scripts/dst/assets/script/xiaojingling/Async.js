
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/script/xiaojingling/Async.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '07852WwxSlDuJkdDsDPNxD+', 'Async');
// script/xiaojingling/Async.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Async = /** @class */ (function () {
    function Async() {
    }
    Async.seriez = function () {
        var funArry = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            funArry[_i] = arguments[_i];
        }
        if (null == funArry || funArry.length <= 0) {
            return;
        }
        var funYesContinue = function () {
            if (funArry.length < 0) {
                return;
            }
            var funCurr = funArry.shift();
            if ("function" == typeof (funCurr)) {
                funCurr(funYesContinue);
            }
            else {
                funYesContinue();
            }
        };
        funYesContinue();
    };
    Async = __decorate([
        ccclass
    ], Async);
    return Async;
}());
exports.default = Async;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0XFx4aWFvamluZ2xpbmdcXEFzeW5jLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxvQkFBb0I7QUFDcEIsd0VBQXdFO0FBQ3hFLG1CQUFtQjtBQUNuQixrRkFBa0Y7QUFDbEYsOEJBQThCO0FBQzlCLGtGQUFrRjs7Ozs7Ozs7QUFFNUUsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFPMUM7SUFFRztJQUNBLENBQUM7SUFFTyxZQUFNLEdBQWI7UUFBYyxpQkFBMkI7YUFBM0IsVUFBMkIsRUFBM0IscUJBQTJCLEVBQTNCLElBQTJCO1lBQTNCLDRCQUEyQjs7UUFDdEMsSUFBRyxJQUFJLElBQUUsT0FBTyxJQUFFLE9BQU8sQ0FBQyxNQUFNLElBQUUsQ0FBQyxFQUFDO1lBQ2hDLE9BQU87U0FDVjtRQUVELElBQUssY0FBYyxHQUFDO1lBQ2hCLElBQUcsT0FBTyxDQUFDLE1BQU0sR0FBQyxDQUFDLEVBQUM7Z0JBQ2hCLE9BQU87YUFDVjtZQUNELElBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUM3QixJQUFHLFVBQVUsSUFBRSxPQUFNLENBQUMsT0FBTyxDQUFDLEVBQUM7Z0JBQzNCLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQzthQUMzQjtpQkFBSztnQkFDRixjQUFjLEVBQUUsQ0FBQzthQUNwQjtRQUNOLENBQUMsQ0FBQTtRQUNELGNBQWMsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUF0QmdCLEtBQUs7UUFEekIsT0FBTztPQUNhLEtBQUssQ0F1QnpCO0lBQUQsWUFBQztDQXZCRCxBQXVCQyxJQUFBO2tCQXZCb0IsS0FBSyIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxudHlwZSBZZXNDb250aW51ZSA9KCk9PnZvaWQ7XHJcbnR5cGUgQ3VzdG9tRnVuPShmdW5ZZXNDb250aW51ZTpZZXNDb250aW51ZSk9PnZvaWQ7XHJcblxyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQXN5bmN7XHJcblxyXG4gICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICB9XHJcblxyXG4gICAgc3RhdGljIHNlcmlleiguLi5mdW5BcnJ5OkFycmF5PEN1c3RvbUZ1bj4pOnZvaWR7XHJcbiAgICAgICBpZihudWxsPT1mdW5BcnJ5fHxmdW5BcnJ5Lmxlbmd0aDw9MCl7XHJcbiAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgfVxyXG5cclxuICAgICAgIGxldCAgZnVuWWVzQ29udGludWU9KCk6dm9pZD0+e1xyXG4gICAgICAgICAgIGlmKGZ1bkFycnkubGVuZ3RoPDApe1xyXG4gICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGxldCBmdW5DdXJyID0gZnVuQXJyeS5zaGlmdCgpO1xyXG4gICAgICAgICAgICBpZihcImZ1bmN0aW9uXCI9PXR5cGVvZihmdW5DdXJyKSl7XHJcbiAgICAgICAgICAgICAgICBmdW5DdXJyKGZ1blllc0NvbnRpbnVlKTtcclxuICAgICAgICAgICAgfWVsc2Uge1xyXG4gICAgICAgICAgICAgICAgZnVuWWVzQ29udGludWUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgfVxyXG4gICAgICAgZnVuWWVzQ29udGludWUoKTtcclxuICAgIH1cclxufVxyXG4iXX0=