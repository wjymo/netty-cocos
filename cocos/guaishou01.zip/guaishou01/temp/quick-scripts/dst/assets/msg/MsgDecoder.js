
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgDecoder.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f7611y8rnhIzp1CEXC2Al/u', 'MsgDecoder');
// msg/MsgDecoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProcotol = require("./GameMsgProtocol");
var MsgDecoder = /** @class */ (function () {
    function MsgDecoder() {
    }
    MsgDecoder.prototype.getMsgCode = function (oUint8Array) {
        if (oUint8Array == null || oUint8Array.byteLength < 4) {
            return -1;
        }
        var nMsgCode = 0;
        nMsgCode |= (oUint8Array[2] & 0xFF) << 8;
        nMsgCode |= (oUint8Array[3] & 0xFF);
        return nMsgCode;
    };
    MsgDecoder.prototype.decode = function (nMsgCode, oUint8Array) {
        if (nMsgCode < 0 || null == oUint8Array || oUint8Array.byteLength <= 0) {
            return;
        }
        var strMsgName = mod_GameMsgProcotol.msg.MsgCode[nMsgCode];
        if (strMsgName == null) {
            console.log("nMsgCode:" + nMsgCode + "\u5BF9\u5E94msg\u540D\u79F0\u4E0D\u5B58\u5728");
        }
        var oTempArray = strMsgName.split("_");
        strMsgName = "";
        for (var _i = 0, oTempArray_1 = oTempArray; _i < oTempArray_1.length; _i++) {
            var strTemp = oTempArray_1[_i];
            strMsgName += strTemp.charAt(0) + strTemp.substr(1).toLowerCase();
        }
        var oMsgClazz = mod_GameMsgProcotol.msg[strMsgName];
        if (null == oMsgClazz || typeof (oMsgClazz['decode']) != "function") {
            console.log("strMsgName:" + strMsgName + " \u6CA1\u6709\u627E\u5230\u5BF9\u5E94\u7684\u7C7B");
            return;
        }
        return oMsgClazz.decode(oUint8Array);
    };
    return MsgDecoder;
}());
exports.default = MsgDecoder;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dEZWNvZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsdURBQXdEO0FBR3hEO0lBQUE7SUFpQ0EsQ0FBQztJQWhDRywrQkFBVSxHQUFWLFVBQVcsV0FBc0I7UUFDN0IsSUFBRyxXQUFXLElBQUUsSUFBSSxJQUFFLFdBQVcsQ0FBQyxVQUFVLEdBQUMsQ0FBQyxFQUFDO1lBQzNDLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDYjtRQUVELElBQUksUUFBUSxHQUFDLENBQUMsQ0FBQztRQUNmLFFBQVEsSUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBQyxJQUFJLENBQUMsSUFBRyxDQUFDLENBQUM7UUFDcEMsUUFBUSxJQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFDLElBQUksQ0FBQyxDQUFFO1FBRWpDLE9BQU8sUUFBUSxDQUFDO0lBQ3BCLENBQUM7SUFFRCwyQkFBTSxHQUFOLFVBQU8sUUFBZSxFQUFDLFdBQXNCO1FBQ3pDLElBQUcsUUFBUSxHQUFDLENBQUMsSUFBRSxJQUFJLElBQUUsV0FBVyxJQUFFLFdBQVcsQ0FBQyxVQUFVLElBQUUsQ0FBQyxFQUFDO1lBQ3hELE9BQU87U0FDVjtRQUNELElBQUksVUFBVSxHQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDekQsSUFBSSxVQUFVLElBQUksSUFBSSxFQUFFO1lBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBWSxRQUFRLGtEQUFZLENBQUMsQ0FBQztTQUNqRDtRQUNELElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdkMsVUFBVSxHQUFDLEVBQUUsQ0FBQztRQUNkLEtBQW9CLFVBQVUsRUFBVix5QkFBVSxFQUFWLHdCQUFVLEVBQVYsSUFBVSxFQUFFO1lBQTNCLElBQUksT0FBTyxtQkFBQTtZQUNaLFVBQVUsSUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDakU7UUFDRCxJQUFJLFNBQVMsR0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbEQsSUFBRyxJQUFJLElBQUUsU0FBUyxJQUFFLE9BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBRSxVQUFVLEVBQUU7WUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBYyxVQUFVLHNEQUFXLENBQUMsQ0FBQTtZQUNoRCxPQUFPO1NBQ1Y7UUFDRCxPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUNMLGlCQUFDO0FBQUQsQ0FqQ0EsQUFpQ0MsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb2NvdG9sPXJlcXVpcmUoXCIuL0dhbWVNc2dQcm90b2NvbFwiKTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNc2dEZWNvZGVyICB7XHJcbiAgICBnZXRNc2dDb2RlKG9VaW50OEFycmF5OlVpbnQ4QXJyYXkpOm51bWJlcntcclxuICAgICAgICBpZihvVWludDhBcnJheT09bnVsbHx8b1VpbnQ4QXJyYXkuYnl0ZUxlbmd0aDw0KXtcclxuICAgICAgICAgICAgcmV0dXJuIC0xO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5Nc2dDb2RlPTA7XHJcbiAgICAgICAgbk1zZ0NvZGV8PShvVWludDhBcnJheVsyXSYweEZGKSA8PDg7XHJcbiAgICAgICAgbk1zZ0NvZGV8PShvVWludDhBcnJheVszXSYweEZGKSA7XHJcblxyXG4gICAgICAgIHJldHVybiBuTXNnQ29kZTtcclxuICAgIH1cclxuXHJcbiAgICBkZWNvZGUobk1zZ0NvZGU6bnVtYmVyLG9VaW50OEFycmF5OlVpbnQ4QXJyYXkpOmFueXtcclxuICAgICAgICBpZihuTXNnQ29kZTwwfHxudWxsPT1vVWludDhBcnJheXx8b1VpbnQ4QXJyYXkuYnl0ZUxlbmd0aDw9MCl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHN0ck1zZ05hbWU9bW9kX0dhbWVNc2dQcm9jb3RvbC5tc2cuTXNnQ29kZVtuTXNnQ29kZV07XHJcbiAgICAgICAgaWYgKHN0ck1zZ05hbWUgPT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgbk1zZ0NvZGU6JHtuTXNnQ29kZX3lr7nlupRtc2flkI3np7DkuI3lrZjlnKhgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IG9UZW1wQXJyYXkgPSBzdHJNc2dOYW1lLnNwbGl0KFwiX1wiKTtcclxuICAgICAgICBzdHJNc2dOYW1lPVwiXCI7XHJcbiAgICAgICAgZm9yIChsZXQgc3RyVGVtcCBvZiBvVGVtcEFycmF5KSB7XHJcbiAgICAgICAgICAgIHN0ck1zZ05hbWUrPXN0clRlbXAuY2hhckF0KDApK3N0clRlbXAuc3Vic3RyKDEpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBvTXNnQ2xheno9bW9kX0dhbWVNc2dQcm9jb3RvbC5tc2dbc3RyTXNnTmFtZV07XHJcbiAgICAgICAgaWYobnVsbD09b01zZ0NsYXp6fHx0eXBlb2Yob01zZ0NsYXp6WydkZWNvZGUnXSkhPVwiZnVuY3Rpb25cIiApe1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgc3RyTXNnTmFtZToke3N0ck1zZ05hbWV9IOayoeacieaJvuWIsOWvueW6lOeahOexu2ApXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIG9Nc2dDbGF6ei5kZWNvZGUob1VpbnQ4QXJyYXkpO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==