
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgEncoder.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '173416YXH9KiY/sjR5VNENm', 'MsgEncoder');
// msg/MsgEncoder.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_protobuf = require("./protobuf");
var MsgEncoder = /** @class */ (function () {
    function MsgEncoder() {
    }
    MsgEncoder.prototype.encode = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        var oWriter = mod_protobuf.Writer.create();
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        oWriter.bytes(0);
        var oByteAttay = oMsgBody.constructor.encode(oMsgBody, oWriter).finish();
        var nMsgLen = oByteAttay.byteLength = 2;
        oByteAttay[0] = nMsgLen >> 8 & 0xff;
        oByteAttay[1] = nMsgLen & 0xff;
        oByteAttay[2] = nMsgCode >> 8 & 0xff;
        oByteAttay[3] = nMsgCode & 0xff;
        return oByteAttay;
    };
    return MsgEncoder;
}());
exports.default = MsgEncoder;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dFbmNvZGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUNBQTJDO0FBRzNDO0lBQUE7SUFzQkEsQ0FBQztJQXJCRywyQkFBTSxHQUFOLFVBQU8sUUFBZSxFQUFDLFFBQVk7UUFDL0IsSUFBRyxRQUFRLEdBQUMsQ0FBQyxJQUFFLElBQUksSUFBRSxRQUFRLEVBQUM7WUFDMUIsT0FBTztTQUNWO1FBRUQsSUFBSSxPQUFPLEdBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN6QyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDakIsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNqQixPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWpCLElBQUksVUFBVSxHQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUV0RSxJQUFJLE9BQU8sR0FBQyxVQUFVLENBQUMsVUFBVSxHQUFDLENBQUMsQ0FBQztRQUNwQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUM7UUFDbEMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLE9BQU8sR0FBSSxJQUFJLENBQUM7UUFDOUIsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFDLFFBQVEsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ25DLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBQyxRQUFRLEdBQUksSUFBSSxDQUFDO1FBQy9CLE9BQU8sVUFBVSxDQUFDO0lBQ3RCLENBQUM7SUFFTCxpQkFBQztBQUFELENBdEJBLEFBc0JDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX3Byb3RvYnVmID1yZXF1aXJlKFwiLi9wcm90b2J1ZlwiKTtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNc2dFbmNvZGVyICB7XHJcbiAgICBlbmNvZGUobk1zZ0NvZGU6bnVtYmVyLG9Nc2dCb2R5OmFueSk6VWludDhBcnJheXtcclxuICAgICAgICBpZihuTXNnQ29kZTwwfHxudWxsPT1vTXNnQm9keSl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBvV3JpdGVyPW1vZF9wcm90b2J1Zi5Xcml0ZXIuY3JlYXRlKCk7XHJcbiAgICAgICAgb1dyaXRlci5ieXRlcygwKTtcclxuICAgICAgICBvV3JpdGVyLmJ5dGVzKDApO1xyXG4gICAgICAgIG9Xcml0ZXIuYnl0ZXMoMCk7XHJcbiAgICAgICAgb1dyaXRlci5ieXRlcygwKTtcclxuXHJcbiAgICAgICAgbGV0IG9CeXRlQXR0YXk9b01zZ0JvZHkuY29uc3RydWN0b3IuZW5jb2RlKG9Nc2dCb2R5LG9Xcml0ZXIpLmZpbmlzaCgpO1xyXG5cclxuICAgICAgICBsZXQgbk1zZ0xlbj1vQnl0ZUF0dGF5LmJ5dGVMZW5ndGg9MjtcclxuICAgICAgICBvQnl0ZUF0dGF5WzBdPW5Nc2dMZW4gPj4gOCAmIDB4ZmY7XHJcbiAgICAgICAgb0J5dGVBdHRheVsxXT1uTXNnTGVuICAmIDB4ZmY7XHJcbiAgICAgICAgb0J5dGVBdHRheVsyXT1uTXNnQ29kZSA+PiA4ICYgMHhmZjtcclxuICAgICAgICBvQnl0ZUF0dGF5WzNdPW5Nc2dDb2RlICAmIDB4ZmY7XHJcbiAgICAgICAgcmV0dXJuIG9CeXRlQXR0YXk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==