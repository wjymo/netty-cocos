
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/GameMsgProtocol.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ba045tgZHNPO4OQ1rgbD/8K', 'GameMsgProtocol');
// msg/GameMsgProtocol.js

/*eslint-disable block-scoped-var, id-length, no-control-regex, no-magic-numbers, no-prototype-builtins, no-redeclare, no-shadow, no-var, sort-vars*/
"use strict";

exports.__esModule = true;
exports.msg = void 0;

var $protobuf = require("./protobuf"); // Common aliases


var $Reader = $protobuf.Reader,
    $Writer = $protobuf.Writer,
    $util = $protobuf.util; // Exported root namespace

var $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});

var msg = $root.msg = function () {
  /**
   * Namespace msg.
   * @exports msg
   * @namespace
   */
  var msg = {};
  /**
   * MsgCode enum.
   * @name msg.MsgCode
   * @enum {number}
   * @property {number} USER_ENTRY_CMD=0 USER_ENTRY_CMD value
   * @property {number} USER_ENTRY_RESULT=1 USER_ENTRY_RESULT value
   * @property {number} WHO_ELSE_IS_HERE_CMD=2 WHO_ELSE_IS_HERE_CMD value
   * @property {number} WHO_ELSE_IS_HERE_RESULT=3 WHO_ELSE_IS_HERE_RESULT value
   * @property {number} USER_MOVE_TO_CMD=4 USER_MOVE_TO_CMD value
   * @property {number} USER_MOVE_TO_RESULT=5 USER_MOVE_TO_RESULT value
   * @property {number} USER_QUIT_RESULT=6 USER_QUIT_RESULT value
   * @property {number} USER_STOP_CMD=7 USER_STOP_CMD value
   * @property {number} USER_STOP_RESULT=8 USER_STOP_RESULT value
   * @property {number} USER_ATTK_CMD=9 USER_ATTK_CMD value
   * @property {number} USER_ATTK_RESULT=10 USER_ATTK_RESULT value
   * @property {number} USER_SUBTRACT_HP_RESULT=11 USER_SUBTRACT_HP_RESULT value
   * @property {number} USER_DIE_RESULT=12 USER_DIE_RESULT value
   */

  msg.MsgCode = function () {
    var valuesById = {},
        values = Object.create(valuesById);
    values[valuesById[0] = "USER_ENTRY_CMD"] = 0;
    values[valuesById[1] = "USER_ENTRY_RESULT"] = 1;
    values[valuesById[2] = "WHO_ELSE_IS_HERE_CMD"] = 2;
    values[valuesById[3] = "WHO_ELSE_IS_HERE_RESULT"] = 3;
    values[valuesById[4] = "USER_MOVE_TO_CMD"] = 4;
    values[valuesById[5] = "USER_MOVE_TO_RESULT"] = 5;
    values[valuesById[6] = "USER_QUIT_RESULT"] = 6;
    values[valuesById[7] = "USER_STOP_CMD"] = 7;
    values[valuesById[8] = "USER_STOP_RESULT"] = 8;
    values[valuesById[9] = "USER_ATTK_CMD"] = 9;
    values[valuesById[10] = "USER_ATTK_RESULT"] = 10;
    values[valuesById[11] = "USER_SUBTRACT_HP_RESULT"] = 11;
    values[valuesById[12] = "USER_DIE_RESULT"] = 12;
    return values;
  }();

  msg.UserEntryCmd = function () {
    /**
     * Properties of a UserEntryCmd.
     * @memberof msg
     * @interface IUserEntryCmd
     * @property {number|null} [userId] UserEntryCmd userId
     * @property {string|null} [heroAvatar] UserEntryCmd heroAvatar
     */

    /**
     * Constructs a new UserEntryCmd.
     * @memberof msg
     * @classdesc Represents a UserEntryCmd.
     * @implements IUserEntryCmd
     * @constructor
     * @param {msg.IUserEntryCmd=} [properties] Properties to set
     */
    function UserEntryCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserEntryCmd userId.
     * @member {number} userId
     * @memberof msg.UserEntryCmd
     * @instance
     */


    UserEntryCmd.prototype.userId = 0;
    /**
     * UserEntryCmd heroAvatar.
     * @member {string} heroAvatar
     * @memberof msg.UserEntryCmd
     * @instance
     */

    UserEntryCmd.prototype.heroAvatar = "";
    /**
     * Creates a new UserEntryCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd=} [properties] Properties to set
     * @returns {msg.UserEntryCmd} UserEntryCmd instance
     */

    UserEntryCmd.create = function create(properties) {
      return new UserEntryCmd(properties);
    };
    /**
     * Encodes the specified UserEntryCmd message. Does not implicitly {@link msg.UserEntryCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd} message UserEntryCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.userId);
      if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
      /* id 2, wireType 2 =*/
      18).string(message.heroAvatar);
      return writer;
    };
    /**
     * Encodes the specified UserEntryCmd message, length delimited. Does not implicitly {@link msg.UserEntryCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.IUserEntryCmd} message UserEntryCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserEntryCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserEntryCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserEntryCmd} UserEntryCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserEntryCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.userId = reader.uint32();
            break;

          case 2:
            message.heroAvatar = reader.string();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserEntryCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserEntryCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserEntryCmd} UserEntryCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserEntryCmd message.
     * @function verify
     * @memberof msg.UserEntryCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserEntryCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";
      return null;
    };
    /**
     * Creates a UserEntryCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserEntryCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserEntryCmd} UserEntryCmd
     */


    UserEntryCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserEntryCmd) return object;
      var message = new $root.msg.UserEntryCmd();
      if (object.userId != null) message.userId = object.userId >>> 0;
      if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);
      return message;
    };
    /**
     * Creates a plain object from a UserEntryCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserEntryCmd
     * @static
     * @param {msg.UserEntryCmd} message UserEntryCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserEntryCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.userId = 0;
        object.heroAvatar = "";
      }

      if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
      return object;
    };
    /**
     * Converts this UserEntryCmd to JSON.
     * @function toJSON
     * @memberof msg.UserEntryCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserEntryCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserEntryCmd;
  }();

  msg.UserEntryResult = function () {
    /**
     * Properties of a UserEntryResult.
     * @memberof msg
     * @interface IUserEntryResult
     * @property {number|null} [userId] UserEntryResult userId
     * @property {string|null} [heroAvatar] UserEntryResult heroAvatar
     */

    /**
     * Constructs a new UserEntryResult.
     * @memberof msg
     * @classdesc Represents a UserEntryResult.
     * @implements IUserEntryResult
     * @constructor
     * @param {msg.IUserEntryResult=} [properties] Properties to set
     */
    function UserEntryResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserEntryResult userId.
     * @member {number} userId
     * @memberof msg.UserEntryResult
     * @instance
     */


    UserEntryResult.prototype.userId = 0;
    /**
     * UserEntryResult heroAvatar.
     * @member {string} heroAvatar
     * @memberof msg.UserEntryResult
     * @instance
     */

    UserEntryResult.prototype.heroAvatar = "";
    /**
     * Creates a new UserEntryResult instance using the specified properties.
     * @function create
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult=} [properties] Properties to set
     * @returns {msg.UserEntryResult} UserEntryResult instance
     */

    UserEntryResult.create = function create(properties) {
      return new UserEntryResult(properties);
    };
    /**
     * Encodes the specified UserEntryResult message. Does not implicitly {@link msg.UserEntryResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult} message UserEntryResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.userId);
      if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
      /* id 2, wireType 2 =*/
      18).string(message.heroAvatar);
      return writer;
    };
    /**
     * Encodes the specified UserEntryResult message, length delimited. Does not implicitly {@link msg.UserEntryResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.IUserEntryResult} message UserEntryResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserEntryResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserEntryResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserEntryResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserEntryResult} UserEntryResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserEntryResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.userId = reader.uint32();
            break;

          case 2:
            message.heroAvatar = reader.string();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserEntryResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserEntryResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserEntryResult} UserEntryResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserEntryResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserEntryResult message.
     * @function verify
     * @memberof msg.UserEntryResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserEntryResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";
      return null;
    };
    /**
     * Creates a UserEntryResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserEntryResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserEntryResult} UserEntryResult
     */


    UserEntryResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserEntryResult) return object;
      var message = new $root.msg.UserEntryResult();
      if (object.userId != null) message.userId = object.userId >>> 0;
      if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);
      return message;
    };
    /**
     * Creates a plain object from a UserEntryResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserEntryResult
     * @static
     * @param {msg.UserEntryResult} message UserEntryResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserEntryResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.userId = 0;
        object.heroAvatar = "";
      }

      if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
      if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
      return object;
    };
    /**
     * Converts this UserEntryResult to JSON.
     * @function toJSON
     * @memberof msg.UserEntryResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserEntryResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserEntryResult;
  }();

  msg.WhoElseIsHereCmd = function () {
    /**
     * Properties of a WhoElseIsHereCmd.
     * @memberof msg
     * @interface IWhoElseIsHereCmd
     */

    /**
     * Constructs a new WhoElseIsHereCmd.
     * @memberof msg
     * @classdesc Represents a WhoElseIsHereCmd.
     * @implements IWhoElseIsHereCmd
     * @constructor
     * @param {msg.IWhoElseIsHereCmd=} [properties] Properties to set
     */
    function WhoElseIsHereCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * Creates a new WhoElseIsHereCmd instance using the specified properties.
     * @function create
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd=} [properties] Properties to set
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd instance
     */


    WhoElseIsHereCmd.create = function create(properties) {
      return new WhoElseIsHereCmd(properties);
    };
    /**
     * Encodes the specified WhoElseIsHereCmd message. Does not implicitly {@link msg.WhoElseIsHereCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd} message WhoElseIsHereCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      return writer;
    };
    /**
     * Encodes the specified WhoElseIsHereCmd message, length delimited. Does not implicitly {@link msg.WhoElseIsHereCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.IWhoElseIsHereCmd} message WhoElseIsHereCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a WhoElseIsHereCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.WhoElseIsHereCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a WhoElseIsHereCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a WhoElseIsHereCmd message.
     * @function verify
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    WhoElseIsHereCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      return null;
    };
    /**
     * Creates a WhoElseIsHereCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.WhoElseIsHereCmd} WhoElseIsHereCmd
     */


    WhoElseIsHereCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.WhoElseIsHereCmd) return object;
      return new $root.msg.WhoElseIsHereCmd();
    };
    /**
     * Creates a plain object from a WhoElseIsHereCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.WhoElseIsHereCmd
     * @static
     * @param {msg.WhoElseIsHereCmd} message WhoElseIsHereCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    WhoElseIsHereCmd.toObject = function toObject() {
      return {};
    };
    /**
     * Converts this WhoElseIsHereCmd to JSON.
     * @function toJSON
     * @memberof msg.WhoElseIsHereCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    WhoElseIsHereCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return WhoElseIsHereCmd;
  }();

  msg.WhoElseIsHereResult = function () {
    /**
     * Properties of a WhoElseIsHereResult.
     * @memberof msg
     * @interface IWhoElseIsHereResult
     * @property {Array.<msg.WhoElseIsHereResult.IUserInfo>|null} [userInfo] WhoElseIsHereResult userInfo
     */

    /**
     * Constructs a new WhoElseIsHereResult.
     * @memberof msg
     * @classdesc Represents a WhoElseIsHereResult.
     * @implements IWhoElseIsHereResult
     * @constructor
     * @param {msg.IWhoElseIsHereResult=} [properties] Properties to set
     */
    function WhoElseIsHereResult(properties) {
      this.userInfo = [];
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * WhoElseIsHereResult userInfo.
     * @member {Array.<msg.WhoElseIsHereResult.IUserInfo>} userInfo
     * @memberof msg.WhoElseIsHereResult
     * @instance
     */


    WhoElseIsHereResult.prototype.userInfo = $util.emptyArray;
    /**
     * Creates a new WhoElseIsHereResult instance using the specified properties.
     * @function create
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult=} [properties] Properties to set
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult instance
     */

    WhoElseIsHereResult.create = function create(properties) {
      return new WhoElseIsHereResult(properties);
    };
    /**
     * Encodes the specified WhoElseIsHereResult message. Does not implicitly {@link msg.WhoElseIsHereResult.verify|verify} messages.
     * @function encode
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult} message WhoElseIsHereResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.userInfo != null && message.userInfo.length) for (var i = 0; i < message.userInfo.length; ++i) {
        $root.msg.WhoElseIsHereResult.UserInfo.encode(message.userInfo[i], writer.uint32(
        /* id 1, wireType 2 =*/
        10).fork()).ldelim();
      }
      return writer;
    };
    /**
     * Encodes the specified WhoElseIsHereResult message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.IWhoElseIsHereResult} message WhoElseIsHereResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    WhoElseIsHereResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a WhoElseIsHereResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.WhoElseIsHereResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            if (!(message.userInfo && message.userInfo.length)) message.userInfo = [];
            message.userInfo.push($root.msg.WhoElseIsHereResult.UserInfo.decode(reader, reader.uint32()));
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a WhoElseIsHereResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    WhoElseIsHereResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a WhoElseIsHereResult message.
     * @function verify
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    WhoElseIsHereResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";

      if (message.userInfo != null && message.hasOwnProperty("userInfo")) {
        if (!Array.isArray(message.userInfo)) return "userInfo: array expected";

        for (var i = 0; i < message.userInfo.length; ++i) {
          var error = $root.msg.WhoElseIsHereResult.UserInfo.verify(message.userInfo[i]);
          if (error) return "userInfo." + error;
        }
      }

      return null;
    };
    /**
     * Creates a WhoElseIsHereResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.WhoElseIsHereResult} WhoElseIsHereResult
     */


    WhoElseIsHereResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.WhoElseIsHereResult) return object;
      var message = new $root.msg.WhoElseIsHereResult();

      if (object.userInfo) {
        if (!Array.isArray(object.userInfo)) throw TypeError(".msg.WhoElseIsHereResult.userInfo: array expected");
        message.userInfo = [];

        for (var i = 0; i < object.userInfo.length; ++i) {
          if (typeof object.userInfo[i] !== "object") throw TypeError(".msg.WhoElseIsHereResult.userInfo: object expected");
          message.userInfo[i] = $root.msg.WhoElseIsHereResult.UserInfo.fromObject(object.userInfo[i]);
        }
      }

      return message;
    };
    /**
     * Creates a plain object from a WhoElseIsHereResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.WhoElseIsHereResult
     * @static
     * @param {msg.WhoElseIsHereResult} message WhoElseIsHereResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    WhoElseIsHereResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.arrays || options.defaults) object.userInfo = [];

      if (message.userInfo && message.userInfo.length) {
        object.userInfo = [];

        for (var j = 0; j < message.userInfo.length; ++j) {
          object.userInfo[j] = $root.msg.WhoElseIsHereResult.UserInfo.toObject(message.userInfo[j], options);
        }
      }

      return object;
    };
    /**
     * Converts this WhoElseIsHereResult to JSON.
     * @function toJSON
     * @memberof msg.WhoElseIsHereResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    WhoElseIsHereResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    WhoElseIsHereResult.UserInfo = function () {
      /**
       * Properties of a UserInfo.
       * @memberof msg.WhoElseIsHereResult
       * @interface IUserInfo
       * @property {number|null} [userId] UserInfo userId
       * @property {string|null} [heroAvatar] UserInfo heroAvatar
       * @property {msg.WhoElseIsHereResult.UserInfo.IMoveState|null} [moveState] UserInfo moveState
       */

      /**
       * Constructs a new UserInfo.
       * @memberof msg.WhoElseIsHereResult
       * @classdesc Represents a UserInfo.
       * @implements IUserInfo
       * @constructor
       * @param {msg.WhoElseIsHereResult.IUserInfo=} [properties] Properties to set
       */
      function UserInfo(properties) {
        if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
          if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
        }
      }
      /**
       * UserInfo userId.
       * @member {number} userId
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */


      UserInfo.prototype.userId = 0;
      /**
       * UserInfo heroAvatar.
       * @member {string} heroAvatar
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */

      UserInfo.prototype.heroAvatar = "";
      /**
       * UserInfo moveState.
       * @member {msg.WhoElseIsHereResult.UserInfo.IMoveState|null|undefined} moveState
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       */

      UserInfo.prototype.moveState = null;
      /**
       * Creates a new UserInfo instance using the specified properties.
       * @function create
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo=} [properties] Properties to set
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo instance
       */

      UserInfo.create = function create(properties) {
        return new UserInfo(properties);
      };
      /**
       * Encodes the specified UserInfo message. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.verify|verify} messages.
       * @function encode
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo} message UserInfo message or plain object to encode
       * @param {$protobuf.Writer} [writer] Writer to encode to
       * @returns {$protobuf.Writer} Writer
       */


      UserInfo.encode = function encode(message, writer) {
        if (!writer) writer = $Writer.create();
        if (message.userId != null && Object.hasOwnProperty.call(message, "userId")) writer.uint32(
        /* id 1, wireType 0 =*/
        8).uint32(message.userId);
        if (message.heroAvatar != null && Object.hasOwnProperty.call(message, "heroAvatar")) writer.uint32(
        /* id 2, wireType 2 =*/
        18).string(message.heroAvatar);
        if (message.moveState != null && Object.hasOwnProperty.call(message, "moveState")) $root.msg.WhoElseIsHereResult.UserInfo.MoveState.encode(message.moveState, writer.uint32(
        /* id 3, wireType 2 =*/
        26).fork()).ldelim();
        return writer;
      };
      /**
       * Encodes the specified UserInfo message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.verify|verify} messages.
       * @function encodeDelimited
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.IUserInfo} message UserInfo message or plain object to encode
       * @param {$protobuf.Writer} [writer] Writer to encode to
       * @returns {$protobuf.Writer} Writer
       */


      UserInfo.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      /**
       * Decodes a UserInfo message from the specified reader or buffer.
       * @function decode
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
       * @param {number} [length] Message length if known beforehand
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       * @throws {Error} If the payload is not a reader or valid buffer
       * @throws {$protobuf.util.ProtocolError} If required fields are missing
       */


      UserInfo.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
        var end = length === undefined ? reader.len : reader.pos + length,
            message = new $root.msg.WhoElseIsHereResult.UserInfo();

        while (reader.pos < end) {
          var tag = reader.uint32();

          switch (tag >>> 3) {
            case 1:
              message.userId = reader.uint32();
              break;

            case 2:
              message.heroAvatar = reader.string();
              break;

            case 3:
              message.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.decode(reader, reader.uint32());
              break;

            default:
              reader.skipType(tag & 7);
              break;
          }
        }

        return message;
      };
      /**
       * Decodes a UserInfo message from the specified reader or buffer, length delimited.
       * @function decodeDelimited
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       * @throws {Error} If the payload is not a reader or valid buffer
       * @throws {$protobuf.util.ProtocolError} If required fields are missing
       */


      UserInfo.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader)) reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      /**
       * Verifies a UserInfo message.
       * @function verify
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {Object.<string,*>} message Plain object to verify
       * @returns {string|null} `null` if valid, otherwise the reason why it is not
       */


      UserInfo.verify = function verify(message) {
        if (typeof message !== "object" || message === null) return "object expected";
        if (message.userId != null && message.hasOwnProperty("userId")) if (!$util.isInteger(message.userId)) return "userId: integer expected";
        if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) if (!$util.isString(message.heroAvatar)) return "heroAvatar: string expected";

        if (message.moveState != null && message.hasOwnProperty("moveState")) {
          var error = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.verify(message.moveState);
          if (error) return "moveState." + error;
        }

        return null;
      };
      /**
       * Creates a UserInfo message from a plain object. Also converts values to their respective internal types.
       * @function fromObject
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {Object.<string,*>} object Plain object
       * @returns {msg.WhoElseIsHereResult.UserInfo} UserInfo
       */


      UserInfo.fromObject = function fromObject(object) {
        if (object instanceof $root.msg.WhoElseIsHereResult.UserInfo) return object;
        var message = new $root.msg.WhoElseIsHereResult.UserInfo();
        if (object.userId != null) message.userId = object.userId >>> 0;
        if (object.heroAvatar != null) message.heroAvatar = String(object.heroAvatar);

        if (object.moveState != null) {
          if (typeof object.moveState !== "object") throw TypeError(".msg.WhoElseIsHereResult.UserInfo.moveState: object expected");
          message.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.fromObject(object.moveState);
        }

        return message;
      };
      /**
       * Creates a plain object from a UserInfo message. Also converts values to other types if specified.
       * @function toObject
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @static
       * @param {msg.WhoElseIsHereResult.UserInfo} message UserInfo
       * @param {$protobuf.IConversionOptions} [options] Conversion options
       * @returns {Object.<string,*>} Plain object
       */


      UserInfo.toObject = function toObject(message, options) {
        if (!options) options = {};
        var object = {};

        if (options.defaults) {
          object.userId = 0;
          object.heroAvatar = "";
          object.moveState = null;
        }

        if (message.userId != null && message.hasOwnProperty("userId")) object.userId = message.userId;
        if (message.heroAvatar != null && message.hasOwnProperty("heroAvatar")) object.heroAvatar = message.heroAvatar;
        if (message.moveState != null && message.hasOwnProperty("moveState")) object.moveState = $root.msg.WhoElseIsHereResult.UserInfo.MoveState.toObject(message.moveState, options);
        return object;
      };
      /**
       * Converts this UserInfo to JSON.
       * @function toJSON
       * @memberof msg.WhoElseIsHereResult.UserInfo
       * @instance
       * @returns {Object.<string,*>} JSON object
       */


      UserInfo.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };

      UserInfo.MoveState = function () {
        /**
         * Properties of a MoveState.
         * @memberof msg.WhoElseIsHereResult.UserInfo
         * @interface IMoveState
         * @property {number|null} [fromPosX] MoveState fromPosX
         * @property {number|null} [fromPosY] MoveState fromPosY
         * @property {number|null} [toPosX] MoveState toPosX
         * @property {number|null} [toPosY] MoveState toPosY
         * @property {number|Long|null} [startTime] MoveState startTime
         */

        /**
         * Constructs a new MoveState.
         * @memberof msg.WhoElseIsHereResult.UserInfo
         * @classdesc Represents a MoveState.
         * @implements IMoveState
         * @constructor
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState=} [properties] Properties to set
         */
        function MoveState(properties) {
          if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
            if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
          }
        }
        /**
         * MoveState fromPosX.
         * @member {number} fromPosX
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */


        MoveState.prototype.fromPosX = 0;
        /**
         * MoveState fromPosY.
         * @member {number} fromPosY
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.fromPosY = 0;
        /**
         * MoveState toPosX.
         * @member {number} toPosX
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.toPosX = 0;
        /**
         * MoveState toPosY.
         * @member {number} toPosY
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.toPosY = 0;
        /**
         * MoveState startTime.
         * @member {number|Long} startTime
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         */

        MoveState.prototype.startTime = $util.Long ? $util.Long.fromBits(0, 0, true) : 0;
        /**
         * Creates a new MoveState instance using the specified properties.
         * @function create
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState=} [properties] Properties to set
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState instance
         */

        MoveState.create = function create(properties) {
          return new MoveState(properties);
        };
        /**
         * Encodes the specified MoveState message. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.MoveState.verify|verify} messages.
         * @function encode
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState} message MoveState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */


        MoveState.encode = function encode(message, writer) {
          if (!writer) writer = $Writer.create();
          if (message.fromPosX != null && Object.hasOwnProperty.call(message, "fromPosX")) writer.uint32(
          /* id 1, wireType 5 =*/
          13)["float"](message.fromPosX);
          if (message.fromPosY != null && Object.hasOwnProperty.call(message, "fromPosY")) writer.uint32(
          /* id 2, wireType 5 =*/
          21)["float"](message.fromPosY);
          if (message.toPosX != null && Object.hasOwnProperty.call(message, "toPosX")) writer.uint32(
          /* id 3, wireType 5 =*/
          29)["float"](message.toPosX);
          if (message.toPosY != null && Object.hasOwnProperty.call(message, "toPosY")) writer.uint32(
          /* id 4, wireType 5 =*/
          37)["float"](message.toPosY);
          if (message.startTime != null && Object.hasOwnProperty.call(message, "startTime")) writer.uint32(
          /* id 5, wireType 0 =*/
          40).uint64(message.startTime);
          return writer;
        };
        /**
         * Encodes the specified MoveState message, length delimited. Does not implicitly {@link msg.WhoElseIsHereResult.UserInfo.MoveState.verify|verify} messages.
         * @function encodeDelimited
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.IMoveState} message MoveState message or plain object to encode
         * @param {$protobuf.Writer} [writer] Writer to encode to
         * @returns {$protobuf.Writer} Writer
         */


        MoveState.encodeDelimited = function encodeDelimited(message, writer) {
          return this.encode(message, writer).ldelim();
        };
        /**
         * Decodes a MoveState message from the specified reader or buffer.
         * @function decode
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @param {number} [length] Message length if known beforehand
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */


        MoveState.decode = function decode(reader, length) {
          if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
          var end = length === undefined ? reader.len : reader.pos + length,
              message = new $root.msg.WhoElseIsHereResult.UserInfo.MoveState();

          while (reader.pos < end) {
            var tag = reader.uint32();

            switch (tag >>> 3) {
              case 1:
                message.fromPosX = reader["float"]();
                break;

              case 2:
                message.fromPosY = reader["float"]();
                break;

              case 3:
                message.toPosX = reader["float"]();
                break;

              case 4:
                message.toPosY = reader["float"]();
                break;

              case 5:
                message.startTime = reader.uint64();
                break;

              default:
                reader.skipType(tag & 7);
                break;
            }
          }

          return message;
        };
        /**
         * Decodes a MoveState message from the specified reader or buffer, length delimited.
         * @function decodeDelimited
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */


        MoveState.decodeDelimited = function decodeDelimited(reader) {
          if (!(reader instanceof $Reader)) reader = new $Reader(reader);
          return this.decode(reader, reader.uint32());
        };
        /**
         * Verifies a MoveState message.
         * @function verify
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {Object.<string,*>} message Plain object to verify
         * @returns {string|null} `null` if valid, otherwise the reason why it is not
         */


        MoveState.verify = function verify(message) {
          if (typeof message !== "object" || message === null) return "object expected";
          if (message.fromPosX != null && message.hasOwnProperty("fromPosX")) if (typeof message.fromPosX !== "number") return "fromPosX: number expected";
          if (message.fromPosY != null && message.hasOwnProperty("fromPosY")) if (typeof message.fromPosY !== "number") return "fromPosY: number expected";
          if (message.toPosX != null && message.hasOwnProperty("toPosX")) if (typeof message.toPosX !== "number") return "toPosX: number expected";
          if (message.toPosY != null && message.hasOwnProperty("toPosY")) if (typeof message.toPosY !== "number") return "toPosY: number expected";
          if (message.startTime != null && message.hasOwnProperty("startTime")) if (!$util.isInteger(message.startTime) && !(message.startTime && $util.isInteger(message.startTime.low) && $util.isInteger(message.startTime.high))) return "startTime: integer|Long expected";
          return null;
        };
        /**
         * Creates a MoveState message from a plain object. Also converts values to their respective internal types.
         * @function fromObject
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {Object.<string,*>} object Plain object
         * @returns {msg.WhoElseIsHereResult.UserInfo.MoveState} MoveState
         */


        MoveState.fromObject = function fromObject(object) {
          if (object instanceof $root.msg.WhoElseIsHereResult.UserInfo.MoveState) return object;
          var message = new $root.msg.WhoElseIsHereResult.UserInfo.MoveState();
          if (object.fromPosX != null) message.fromPosX = Number(object.fromPosX);
          if (object.fromPosY != null) message.fromPosY = Number(object.fromPosY);
          if (object.toPosX != null) message.toPosX = Number(object.toPosX);
          if (object.toPosY != null) message.toPosY = Number(object.toPosY);
          if (object.startTime != null) if ($util.Long) (message.startTime = $util.Long.fromValue(object.startTime)).unsigned = true;else if (typeof object.startTime === "string") message.startTime = parseInt(object.startTime, 10);else if (typeof object.startTime === "number") message.startTime = object.startTime;else if (typeof object.startTime === "object") message.startTime = new $util.LongBits(object.startTime.low >>> 0, object.startTime.high >>> 0).toNumber(true);
          return message;
        };
        /**
         * Creates a plain object from a MoveState message. Also converts values to other types if specified.
         * @function toObject
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @static
         * @param {msg.WhoElseIsHereResult.UserInfo.MoveState} message MoveState
         * @param {$protobuf.IConversionOptions} [options] Conversion options
         * @returns {Object.<string,*>} Plain object
         */


        MoveState.toObject = function toObject(message, options) {
          if (!options) options = {};
          var object = {};

          if (options.defaults) {
            object.fromPosX = 0;
            object.fromPosY = 0;
            object.toPosX = 0;
            object.toPosY = 0;

            if ($util.Long) {
              var _long = new $util.Long(0, 0, true);

              object.startTime = options.longs === String ? _long.toString() : options.longs === Number ? _long.toNumber() : _long;
            } else object.startTime = options.longs === String ? "0" : 0;
          }

          if (message.fromPosX != null && message.hasOwnProperty("fromPosX")) object.fromPosX = options.json && !isFinite(message.fromPosX) ? String(message.fromPosX) : message.fromPosX;
          if (message.fromPosY != null && message.hasOwnProperty("fromPosY")) object.fromPosY = options.json && !isFinite(message.fromPosY) ? String(message.fromPosY) : message.fromPosY;
          if (message.toPosX != null && message.hasOwnProperty("toPosX")) object.toPosX = options.json && !isFinite(message.toPosX) ? String(message.toPosX) : message.toPosX;
          if (message.toPosY != null && message.hasOwnProperty("toPosY")) object.toPosY = options.json && !isFinite(message.toPosY) ? String(message.toPosY) : message.toPosY;
          if (message.startTime != null && message.hasOwnProperty("startTime")) if (typeof message.startTime === "number") object.startTime = options.longs === String ? String(message.startTime) : message.startTime;else object.startTime = options.longs === String ? $util.Long.prototype.toString.call(message.startTime) : options.longs === Number ? new $util.LongBits(message.startTime.low >>> 0, message.startTime.high >>> 0).toNumber(true) : message.startTime;
          return object;
        };
        /**
         * Converts this MoveState to JSON.
         * @function toJSON
         * @memberof msg.WhoElseIsHereResult.UserInfo.MoveState
         * @instance
         * @returns {Object.<string,*>} JSON object
         */


        MoveState.prototype.toJSON = function toJSON() {
          return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
        };

        return MoveState;
      }();

      return UserInfo;
    }();

    return WhoElseIsHereResult;
  }();

  msg.UserMoveToCmd = function () {
    /**
     * Properties of a UserMoveToCmd.
     * @memberof msg
     * @interface IUserMoveToCmd
     * @property {number|null} [moveFromPosX] UserMoveToCmd moveFromPosX
     * @property {number|null} [moveFromPosY] UserMoveToCmd moveFromPosY
     * @property {number|null} [moveToPosX] UserMoveToCmd moveToPosX
     * @property {number|null} [moveToPosY] UserMoveToCmd moveToPosY
     */

    /**
     * Constructs a new UserMoveToCmd.
     * @memberof msg
     * @classdesc Represents a UserMoveToCmd.
     * @implements IUserMoveToCmd
     * @constructor
     * @param {msg.IUserMoveToCmd=} [properties] Properties to set
     */
    function UserMoveToCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserMoveToCmd moveFromPosX.
     * @member {number} moveFromPosX
     * @memberof msg.UserMoveToCmd
     * @instance
     */


    UserMoveToCmd.prototype.moveFromPosX = 0;
    /**
     * UserMoveToCmd moveFromPosY.
     * @member {number} moveFromPosY
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveFromPosY = 0;
    /**
     * UserMoveToCmd moveToPosX.
     * @member {number} moveToPosX
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveToPosX = 0;
    /**
     * UserMoveToCmd moveToPosY.
     * @member {number} moveToPosY
     * @memberof msg.UserMoveToCmd
     * @instance
     */

    UserMoveToCmd.prototype.moveToPosY = 0;
    /**
     * Creates a new UserMoveToCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd=} [properties] Properties to set
     * @returns {msg.UserMoveToCmd} UserMoveToCmd instance
     */

    UserMoveToCmd.create = function create(properties) {
      return new UserMoveToCmd(properties);
    };
    /**
     * Encodes the specified UserMoveToCmd message. Does not implicitly {@link msg.UserMoveToCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd} message UserMoveToCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.moveFromPosX != null && Object.hasOwnProperty.call(message, "moveFromPosX")) writer.uint32(
      /* id 1, wireType 5 =*/
      13)["float"](message.moveFromPosX);
      if (message.moveFromPosY != null && Object.hasOwnProperty.call(message, "moveFromPosY")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.moveFromPosY);
      if (message.moveToPosX != null && Object.hasOwnProperty.call(message, "moveToPosX")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.moveToPosX);
      if (message.moveToPosY != null && Object.hasOwnProperty.call(message, "moveToPosY")) writer.uint32(
      /* id 4, wireType 5 =*/
      37)["float"](message.moveToPosY);
      return writer;
    };
    /**
     * Encodes the specified UserMoveToCmd message, length delimited. Does not implicitly {@link msg.UserMoveToCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.IUserMoveToCmd} message UserMoveToCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserMoveToCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserMoveToCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.moveFromPosX = reader["float"]();
            break;

          case 2:
            message.moveFromPosY = reader["float"]();
            break;

          case 3:
            message.moveToPosX = reader["float"]();
            break;

          case 4:
            message.moveToPosY = reader["float"]();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserMoveToCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserMoveToCmd message.
     * @function verify
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserMoveToCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) if (typeof message.moveFromPosX !== "number") return "moveFromPosX: number expected";
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) if (typeof message.moveFromPosY !== "number") return "moveFromPosY: number expected";
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) if (typeof message.moveToPosX !== "number") return "moveToPosX: number expected";
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) if (typeof message.moveToPosY !== "number") return "moveToPosY: number expected";
      return null;
    };
    /**
     * Creates a UserMoveToCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserMoveToCmd} UserMoveToCmd
     */


    UserMoveToCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserMoveToCmd) return object;
      var message = new $root.msg.UserMoveToCmd();
      if (object.moveFromPosX != null) message.moveFromPosX = Number(object.moveFromPosX);
      if (object.moveFromPosY != null) message.moveFromPosY = Number(object.moveFromPosY);
      if (object.moveToPosX != null) message.moveToPosX = Number(object.moveToPosX);
      if (object.moveToPosY != null) message.moveToPosY = Number(object.moveToPosY);
      return message;
    };
    /**
     * Creates a plain object from a UserMoveToCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserMoveToCmd
     * @static
     * @param {msg.UserMoveToCmd} message UserMoveToCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserMoveToCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.moveFromPosX = 0;
        object.moveFromPosY = 0;
        object.moveToPosX = 0;
        object.moveToPosY = 0;
      }

      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) object.moveFromPosX = options.json && !isFinite(message.moveFromPosX) ? String(message.moveFromPosX) : message.moveFromPosX;
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) object.moveFromPosY = options.json && !isFinite(message.moveFromPosY) ? String(message.moveFromPosY) : message.moveFromPosY;
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) object.moveToPosX = options.json && !isFinite(message.moveToPosX) ? String(message.moveToPosX) : message.moveToPosX;
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) object.moveToPosY = options.json && !isFinite(message.moveToPosY) ? String(message.moveToPosY) : message.moveToPosY;
      return object;
    };
    /**
     * Converts this UserMoveToCmd to JSON.
     * @function toJSON
     * @memberof msg.UserMoveToCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserMoveToCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserMoveToCmd;
  }();

  msg.UserMoveToResult = function () {
    /**
     * Properties of a UserMoveToResult.
     * @memberof msg
     * @interface IUserMoveToResult
     * @property {number|null} [moveUserId] UserMoveToResult moveUserId
     * @property {number|null} [moveFromPosX] UserMoveToResult moveFromPosX
     * @property {number|null} [moveFromPosY] UserMoveToResult moveFromPosY
     * @property {number|null} [moveToPosX] UserMoveToResult moveToPosX
     * @property {number|null} [moveToPosY] UserMoveToResult moveToPosY
     * @property {number|Long|null} [moveStartTime] UserMoveToResult moveStartTime
     */

    /**
     * Constructs a new UserMoveToResult.
     * @memberof msg
     * @classdesc Represents a UserMoveToResult.
     * @implements IUserMoveToResult
     * @constructor
     * @param {msg.IUserMoveToResult=} [properties] Properties to set
     */
    function UserMoveToResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserMoveToResult moveUserId.
     * @member {number} moveUserId
     * @memberof msg.UserMoveToResult
     * @instance
     */


    UserMoveToResult.prototype.moveUserId = 0;
    /**
     * UserMoveToResult moveFromPosX.
     * @member {number} moveFromPosX
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveFromPosX = 0;
    /**
     * UserMoveToResult moveFromPosY.
     * @member {number} moveFromPosY
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveFromPosY = 0;
    /**
     * UserMoveToResult moveToPosX.
     * @member {number} moveToPosX
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveToPosX = 0;
    /**
     * UserMoveToResult moveToPosY.
     * @member {number} moveToPosY
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveToPosY = 0;
    /**
     * UserMoveToResult moveStartTime.
     * @member {number|Long} moveStartTime
     * @memberof msg.UserMoveToResult
     * @instance
     */

    UserMoveToResult.prototype.moveStartTime = $util.Long ? $util.Long.fromBits(0, 0, true) : 0;
    /**
     * Creates a new UserMoveToResult instance using the specified properties.
     * @function create
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult=} [properties] Properties to set
     * @returns {msg.UserMoveToResult} UserMoveToResult instance
     */

    UserMoveToResult.create = function create(properties) {
      return new UserMoveToResult(properties);
    };
    /**
     * Encodes the specified UserMoveToResult message. Does not implicitly {@link msg.UserMoveToResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult} message UserMoveToResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.moveUserId != null && Object.hasOwnProperty.call(message, "moveUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.moveUserId);
      if (message.moveFromPosX != null && Object.hasOwnProperty.call(message, "moveFromPosX")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.moveFromPosX);
      if (message.moveFromPosY != null && Object.hasOwnProperty.call(message, "moveFromPosY")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.moveFromPosY);
      if (message.moveToPosX != null && Object.hasOwnProperty.call(message, "moveToPosX")) writer.uint32(
      /* id 4, wireType 5 =*/
      37)["float"](message.moveToPosX);
      if (message.moveToPosY != null && Object.hasOwnProperty.call(message, "moveToPosY")) writer.uint32(
      /* id 5, wireType 5 =*/
      45)["float"](message.moveToPosY);
      if (message.moveStartTime != null && Object.hasOwnProperty.call(message, "moveStartTime")) writer.uint32(
      /* id 6, wireType 0 =*/
      48).uint64(message.moveStartTime);
      return writer;
    };
    /**
     * Encodes the specified UserMoveToResult message, length delimited. Does not implicitly {@link msg.UserMoveToResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.IUserMoveToResult} message UserMoveToResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserMoveToResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserMoveToResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserMoveToResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserMoveToResult} UserMoveToResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserMoveToResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.moveUserId = reader.uint32();
            break;

          case 2:
            message.moveFromPosX = reader["float"]();
            break;

          case 3:
            message.moveFromPosY = reader["float"]();
            break;

          case 4:
            message.moveToPosX = reader["float"]();
            break;

          case 5:
            message.moveToPosY = reader["float"]();
            break;

          case 6:
            message.moveStartTime = reader.uint64();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserMoveToResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserMoveToResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserMoveToResult} UserMoveToResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserMoveToResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserMoveToResult message.
     * @function verify
     * @memberof msg.UserMoveToResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserMoveToResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.moveUserId != null && message.hasOwnProperty("moveUserId")) if (!$util.isInteger(message.moveUserId)) return "moveUserId: integer expected";
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) if (typeof message.moveFromPosX !== "number") return "moveFromPosX: number expected";
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) if (typeof message.moveFromPosY !== "number") return "moveFromPosY: number expected";
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) if (typeof message.moveToPosX !== "number") return "moveToPosX: number expected";
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) if (typeof message.moveToPosY !== "number") return "moveToPosY: number expected";
      if (message.moveStartTime != null && message.hasOwnProperty("moveStartTime")) if (!$util.isInteger(message.moveStartTime) && !(message.moveStartTime && $util.isInteger(message.moveStartTime.low) && $util.isInteger(message.moveStartTime.high))) return "moveStartTime: integer|Long expected";
      return null;
    };
    /**
     * Creates a UserMoveToResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserMoveToResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserMoveToResult} UserMoveToResult
     */


    UserMoveToResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserMoveToResult) return object;
      var message = new $root.msg.UserMoveToResult();
      if (object.moveUserId != null) message.moveUserId = object.moveUserId >>> 0;
      if (object.moveFromPosX != null) message.moveFromPosX = Number(object.moveFromPosX);
      if (object.moveFromPosY != null) message.moveFromPosY = Number(object.moveFromPosY);
      if (object.moveToPosX != null) message.moveToPosX = Number(object.moveToPosX);
      if (object.moveToPosY != null) message.moveToPosY = Number(object.moveToPosY);
      if (object.moveStartTime != null) if ($util.Long) (message.moveStartTime = $util.Long.fromValue(object.moveStartTime)).unsigned = true;else if (typeof object.moveStartTime === "string") message.moveStartTime = parseInt(object.moveStartTime, 10);else if (typeof object.moveStartTime === "number") message.moveStartTime = object.moveStartTime;else if (typeof object.moveStartTime === "object") message.moveStartTime = new $util.LongBits(object.moveStartTime.low >>> 0, object.moveStartTime.high >>> 0).toNumber(true);
      return message;
    };
    /**
     * Creates a plain object from a UserMoveToResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserMoveToResult
     * @static
     * @param {msg.UserMoveToResult} message UserMoveToResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserMoveToResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.moveUserId = 0;
        object.moveFromPosX = 0;
        object.moveFromPosY = 0;
        object.moveToPosX = 0;
        object.moveToPosY = 0;

        if ($util.Long) {
          var _long2 = new $util.Long(0, 0, true);

          object.moveStartTime = options.longs === String ? _long2.toString() : options.longs === Number ? _long2.toNumber() : _long2;
        } else object.moveStartTime = options.longs === String ? "0" : 0;
      }

      if (message.moveUserId != null && message.hasOwnProperty("moveUserId")) object.moveUserId = message.moveUserId;
      if (message.moveFromPosX != null && message.hasOwnProperty("moveFromPosX")) object.moveFromPosX = options.json && !isFinite(message.moveFromPosX) ? String(message.moveFromPosX) : message.moveFromPosX;
      if (message.moveFromPosY != null && message.hasOwnProperty("moveFromPosY")) object.moveFromPosY = options.json && !isFinite(message.moveFromPosY) ? String(message.moveFromPosY) : message.moveFromPosY;
      if (message.moveToPosX != null && message.hasOwnProperty("moveToPosX")) object.moveToPosX = options.json && !isFinite(message.moveToPosX) ? String(message.moveToPosX) : message.moveToPosX;
      if (message.moveToPosY != null && message.hasOwnProperty("moveToPosY")) object.moveToPosY = options.json && !isFinite(message.moveToPosY) ? String(message.moveToPosY) : message.moveToPosY;
      if (message.moveStartTime != null && message.hasOwnProperty("moveStartTime")) if (typeof message.moveStartTime === "number") object.moveStartTime = options.longs === String ? String(message.moveStartTime) : message.moveStartTime;else object.moveStartTime = options.longs === String ? $util.Long.prototype.toString.call(message.moveStartTime) : options.longs === Number ? new $util.LongBits(message.moveStartTime.low >>> 0, message.moveStartTime.high >>> 0).toNumber(true) : message.moveStartTime;
      return object;
    };
    /**
     * Converts this UserMoveToResult to JSON.
     * @function toJSON
     * @memberof msg.UserMoveToResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserMoveToResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserMoveToResult;
  }();

  msg.UserQuitResult = function () {
    /**
     * Properties of a UserQuitResult.
     * @memberof msg
     * @interface IUserQuitResult
     * @property {number|null} [quitUserId] UserQuitResult quitUserId
     */

    /**
     * Constructs a new UserQuitResult.
     * @memberof msg
     * @classdesc Represents a UserQuitResult.
     * @implements IUserQuitResult
     * @constructor
     * @param {msg.IUserQuitResult=} [properties] Properties to set
     */
    function UserQuitResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserQuitResult quitUserId.
     * @member {number} quitUserId
     * @memberof msg.UserQuitResult
     * @instance
     */


    UserQuitResult.prototype.quitUserId = 0;
    /**
     * Creates a new UserQuitResult instance using the specified properties.
     * @function create
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult=} [properties] Properties to set
     * @returns {msg.UserQuitResult} UserQuitResult instance
     */

    UserQuitResult.create = function create(properties) {
      return new UserQuitResult(properties);
    };
    /**
     * Encodes the specified UserQuitResult message. Does not implicitly {@link msg.UserQuitResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult} message UserQuitResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserQuitResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.quitUserId != null && Object.hasOwnProperty.call(message, "quitUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.quitUserId);
      return writer;
    };
    /**
     * Encodes the specified UserQuitResult message, length delimited. Does not implicitly {@link msg.UserQuitResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.IUserQuitResult} message UserQuitResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserQuitResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserQuitResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserQuitResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserQuitResult} UserQuitResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserQuitResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserQuitResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.quitUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserQuitResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserQuitResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserQuitResult} UserQuitResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserQuitResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserQuitResult message.
     * @function verify
     * @memberof msg.UserQuitResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserQuitResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.quitUserId != null && message.hasOwnProperty("quitUserId")) if (!$util.isInteger(message.quitUserId)) return "quitUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserQuitResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserQuitResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserQuitResult} UserQuitResult
     */


    UserQuitResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserQuitResult) return object;
      var message = new $root.msg.UserQuitResult();
      if (object.quitUserId != null) message.quitUserId = object.quitUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserQuitResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserQuitResult
     * @static
     * @param {msg.UserQuitResult} message UserQuitResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserQuitResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.quitUserId = 0;
      if (message.quitUserId != null && message.hasOwnProperty("quitUserId")) object.quitUserId = message.quitUserId;
      return object;
    };
    /**
     * Converts this UserQuitResult to JSON.
     * @function toJSON
     * @memberof msg.UserQuitResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserQuitResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserQuitResult;
  }();

  msg.UserStopCmd = function () {
    /**
     * Properties of a UserStopCmd.
     * @memberof msg
     * @interface IUserStopCmd
     */

    /**
     * Constructs a new UserStopCmd.
     * @memberof msg
     * @classdesc Represents a UserStopCmd.
     * @implements IUserStopCmd
     * @constructor
     * @param {msg.IUserStopCmd=} [properties] Properties to set
     */
    function UserStopCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * Creates a new UserStopCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd=} [properties] Properties to set
     * @returns {msg.UserStopCmd} UserStopCmd instance
     */


    UserStopCmd.create = function create(properties) {
      return new UserStopCmd(properties);
    };
    /**
     * Encodes the specified UserStopCmd message. Does not implicitly {@link msg.UserStopCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd} message UserStopCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      return writer;
    };
    /**
     * Encodes the specified UserStopCmd message, length delimited. Does not implicitly {@link msg.UserStopCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.IUserStopCmd} message UserStopCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserStopCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserStopCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserStopCmd} UserStopCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserStopCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserStopCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserStopCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserStopCmd} UserStopCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserStopCmd message.
     * @function verify
     * @memberof msg.UserStopCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserStopCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      return null;
    };
    /**
     * Creates a UserStopCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserStopCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserStopCmd} UserStopCmd
     */


    UserStopCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserStopCmd) return object;
      return new $root.msg.UserStopCmd();
    };
    /**
     * Creates a plain object from a UserStopCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserStopCmd
     * @static
     * @param {msg.UserStopCmd} message UserStopCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserStopCmd.toObject = function toObject() {
      return {};
    };
    /**
     * Converts this UserStopCmd to JSON.
     * @function toJSON
     * @memberof msg.UserStopCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserStopCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserStopCmd;
  }();

  msg.UserStopResult = function () {
    /**
     * Properties of a UserStopResult.
     * @memberof msg
     * @interface IUserStopResult
     * @property {number|null} [stopUserId] UserStopResult stopUserId
     * @property {number|null} [stopAtPosX] UserStopResult stopAtPosX
     * @property {number|null} [stopAtPosY] UserStopResult stopAtPosY
     */

    /**
     * Constructs a new UserStopResult.
     * @memberof msg
     * @classdesc Represents a UserStopResult.
     * @implements IUserStopResult
     * @constructor
     * @param {msg.IUserStopResult=} [properties] Properties to set
     */
    function UserStopResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserStopResult stopUserId.
     * @member {number} stopUserId
     * @memberof msg.UserStopResult
     * @instance
     */


    UserStopResult.prototype.stopUserId = 0;
    /**
     * UserStopResult stopAtPosX.
     * @member {number} stopAtPosX
     * @memberof msg.UserStopResult
     * @instance
     */

    UserStopResult.prototype.stopAtPosX = 0;
    /**
     * UserStopResult stopAtPosY.
     * @member {number} stopAtPosY
     * @memberof msg.UserStopResult
     * @instance
     */

    UserStopResult.prototype.stopAtPosY = 0;
    /**
     * Creates a new UserStopResult instance using the specified properties.
     * @function create
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult=} [properties] Properties to set
     * @returns {msg.UserStopResult} UserStopResult instance
     */

    UserStopResult.create = function create(properties) {
      return new UserStopResult(properties);
    };
    /**
     * Encodes the specified UserStopResult message. Does not implicitly {@link msg.UserStopResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult} message UserStopResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.stopUserId != null && Object.hasOwnProperty.call(message, "stopUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.stopUserId);
      if (message.stopAtPosX != null && Object.hasOwnProperty.call(message, "stopAtPosX")) writer.uint32(
      /* id 2, wireType 5 =*/
      21)["float"](message.stopAtPosX);
      if (message.stopAtPosY != null && Object.hasOwnProperty.call(message, "stopAtPosY")) writer.uint32(
      /* id 3, wireType 5 =*/
      29)["float"](message.stopAtPosY);
      return writer;
    };
    /**
     * Encodes the specified UserStopResult message, length delimited. Does not implicitly {@link msg.UserStopResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.IUserStopResult} message UserStopResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserStopResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserStopResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserStopResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserStopResult} UserStopResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserStopResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.stopUserId = reader.uint32();
            break;

          case 2:
            message.stopAtPosX = reader["float"]();
            break;

          case 3:
            message.stopAtPosY = reader["float"]();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserStopResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserStopResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserStopResult} UserStopResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserStopResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserStopResult message.
     * @function verify
     * @memberof msg.UserStopResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserStopResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.stopUserId != null && message.hasOwnProperty("stopUserId")) if (!$util.isInteger(message.stopUserId)) return "stopUserId: integer expected";
      if (message.stopAtPosX != null && message.hasOwnProperty("stopAtPosX")) if (typeof message.stopAtPosX !== "number") return "stopAtPosX: number expected";
      if (message.stopAtPosY != null && message.hasOwnProperty("stopAtPosY")) if (typeof message.stopAtPosY !== "number") return "stopAtPosY: number expected";
      return null;
    };
    /**
     * Creates a UserStopResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserStopResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserStopResult} UserStopResult
     */


    UserStopResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserStopResult) return object;
      var message = new $root.msg.UserStopResult();
      if (object.stopUserId != null) message.stopUserId = object.stopUserId >>> 0;
      if (object.stopAtPosX != null) message.stopAtPosX = Number(object.stopAtPosX);
      if (object.stopAtPosY != null) message.stopAtPosY = Number(object.stopAtPosY);
      return message;
    };
    /**
     * Creates a plain object from a UserStopResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserStopResult
     * @static
     * @param {msg.UserStopResult} message UserStopResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserStopResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.stopUserId = 0;
        object.stopAtPosX = 0;
        object.stopAtPosY = 0;
      }

      if (message.stopUserId != null && message.hasOwnProperty("stopUserId")) object.stopUserId = message.stopUserId;
      if (message.stopAtPosX != null && message.hasOwnProperty("stopAtPosX")) object.stopAtPosX = options.json && !isFinite(message.stopAtPosX) ? String(message.stopAtPosX) : message.stopAtPosX;
      if (message.stopAtPosY != null && message.hasOwnProperty("stopAtPosY")) object.stopAtPosY = options.json && !isFinite(message.stopAtPosY) ? String(message.stopAtPosY) : message.stopAtPosY;
      return object;
    };
    /**
     * Converts this UserStopResult to JSON.
     * @function toJSON
     * @memberof msg.UserStopResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserStopResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserStopResult;
  }();

  msg.UserAttkCmd = function () {
    /**
     * Properties of a UserAttkCmd.
     * @memberof msg
     * @interface IUserAttkCmd
     * @property {number|null} [targetUserId] UserAttkCmd targetUserId
     */

    /**
     * Constructs a new UserAttkCmd.
     * @memberof msg
     * @classdesc Represents a UserAttkCmd.
     * @implements IUserAttkCmd
     * @constructor
     * @param {msg.IUserAttkCmd=} [properties] Properties to set
     */
    function UserAttkCmd(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserAttkCmd targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserAttkCmd
     * @instance
     */


    UserAttkCmd.prototype.targetUserId = 0;
    /**
     * Creates a new UserAttkCmd instance using the specified properties.
     * @function create
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd=} [properties] Properties to set
     * @returns {msg.UserAttkCmd} UserAttkCmd instance
     */

    UserAttkCmd.create = function create(properties) {
      return new UserAttkCmd(properties);
    };
    /**
     * Encodes the specified UserAttkCmd message. Does not implicitly {@link msg.UserAttkCmd.verify|verify} messages.
     * @function encode
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd} message UserAttkCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkCmd.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserAttkCmd message, length delimited. Does not implicitly {@link msg.UserAttkCmd.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.IUserAttkCmd} message UserAttkCmd message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkCmd.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserAttkCmd message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserAttkCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserAttkCmd} UserAttkCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkCmd.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserAttkCmd();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserAttkCmd message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserAttkCmd
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserAttkCmd} UserAttkCmd
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkCmd.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserAttkCmd message.
     * @function verify
     * @memberof msg.UserAttkCmd
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserAttkCmd.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserAttkCmd message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserAttkCmd
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserAttkCmd} UserAttkCmd
     */


    UserAttkCmd.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserAttkCmd) return object;
      var message = new $root.msg.UserAttkCmd();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserAttkCmd message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserAttkCmd
     * @static
     * @param {msg.UserAttkCmd} message UserAttkCmd
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserAttkCmd.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.targetUserId = 0;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserAttkCmd to JSON.
     * @function toJSON
     * @memberof msg.UserAttkCmd
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserAttkCmd.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserAttkCmd;
  }();

  msg.UserAttkResult = function () {
    /**
     * Properties of a UserAttkResult.
     * @memberof msg
     * @interface IUserAttkResult
     * @property {number|null} [attkUserId] UserAttkResult attkUserId
     * @property {number|null} [targetUserId] UserAttkResult targetUserId
     */

    /**
     * Constructs a new UserAttkResult.
     * @memberof msg
     * @classdesc Represents a UserAttkResult.
     * @implements IUserAttkResult
     * @constructor
     * @param {msg.IUserAttkResult=} [properties] Properties to set
     */
    function UserAttkResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserAttkResult attkUserId.
     * @member {number} attkUserId
     * @memberof msg.UserAttkResult
     * @instance
     */


    UserAttkResult.prototype.attkUserId = 0;
    /**
     * UserAttkResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserAttkResult
     * @instance
     */

    UserAttkResult.prototype.targetUserId = 0;
    /**
     * Creates a new UserAttkResult instance using the specified properties.
     * @function create
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult=} [properties] Properties to set
     * @returns {msg.UserAttkResult} UserAttkResult instance
     */

    UserAttkResult.create = function create(properties) {
      return new UserAttkResult(properties);
    };
    /**
     * Encodes the specified UserAttkResult message. Does not implicitly {@link msg.UserAttkResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult} message UserAttkResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.attkUserId != null && Object.hasOwnProperty.call(message, "attkUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.attkUserId);
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 2, wireType 0 =*/
      16).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserAttkResult message, length delimited. Does not implicitly {@link msg.UserAttkResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.IUserAttkResult} message UserAttkResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserAttkResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserAttkResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserAttkResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserAttkResult} UserAttkResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserAttkResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.attkUserId = reader.uint32();
            break;

          case 2:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserAttkResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserAttkResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserAttkResult} UserAttkResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserAttkResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserAttkResult message.
     * @function verify
     * @memberof msg.UserAttkResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserAttkResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.attkUserId != null && message.hasOwnProperty("attkUserId")) if (!$util.isInteger(message.attkUserId)) return "attkUserId: integer expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserAttkResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserAttkResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserAttkResult} UserAttkResult
     */


    UserAttkResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserAttkResult) return object;
      var message = new $root.msg.UserAttkResult();
      if (object.attkUserId != null) message.attkUserId = object.attkUserId >>> 0;
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserAttkResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserAttkResult
     * @static
     * @param {msg.UserAttkResult} message UserAttkResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserAttkResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.attkUserId = 0;
        object.targetUserId = 0;
      }

      if (message.attkUserId != null && message.hasOwnProperty("attkUserId")) object.attkUserId = message.attkUserId;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserAttkResult to JSON.
     * @function toJSON
     * @memberof msg.UserAttkResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserAttkResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserAttkResult;
  }();

  msg.UserSubtractHpResult = function () {
    /**
     * Properties of a UserSubtractHpResult.
     * @memberof msg
     * @interface IUserSubtractHpResult
     * @property {number|null} [targetUserId] UserSubtractHpResult targetUserId
     * @property {number|null} [subtractHp] UserSubtractHpResult subtractHp
     */

    /**
     * Constructs a new UserSubtractHpResult.
     * @memberof msg
     * @classdesc Represents a UserSubtractHpResult.
     * @implements IUserSubtractHpResult
     * @constructor
     * @param {msg.IUserSubtractHpResult=} [properties] Properties to set
     */
    function UserSubtractHpResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserSubtractHpResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserSubtractHpResult
     * @instance
     */


    UserSubtractHpResult.prototype.targetUserId = 0;
    /**
     * UserSubtractHpResult subtractHp.
     * @member {number} subtractHp
     * @memberof msg.UserSubtractHpResult
     * @instance
     */

    UserSubtractHpResult.prototype.subtractHp = 0;
    /**
     * Creates a new UserSubtractHpResult instance using the specified properties.
     * @function create
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult=} [properties] Properties to set
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult instance
     */

    UserSubtractHpResult.create = function create(properties) {
      return new UserSubtractHpResult(properties);
    };
    /**
     * Encodes the specified UserSubtractHpResult message. Does not implicitly {@link msg.UserSubtractHpResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult} message UserSubtractHpResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserSubtractHpResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      if (message.subtractHp != null && Object.hasOwnProperty.call(message, "subtractHp")) writer.uint32(
      /* id 2, wireType 0 =*/
      16).uint32(message.subtractHp);
      return writer;
    };
    /**
     * Encodes the specified UserSubtractHpResult message, length delimited. Does not implicitly {@link msg.UserSubtractHpResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.IUserSubtractHpResult} message UserSubtractHpResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserSubtractHpResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserSubtractHpResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserSubtractHpResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserSubtractHpResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          case 2:
            message.subtractHp = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserSubtractHpResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserSubtractHpResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserSubtractHpResult message.
     * @function verify
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserSubtractHpResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      if (message.subtractHp != null && message.hasOwnProperty("subtractHp")) if (!$util.isInteger(message.subtractHp)) return "subtractHp: integer expected";
      return null;
    };
    /**
     * Creates a UserSubtractHpResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserSubtractHpResult} UserSubtractHpResult
     */


    UserSubtractHpResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserSubtractHpResult) return object;
      var message = new $root.msg.UserSubtractHpResult();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      if (object.subtractHp != null) message.subtractHp = object.subtractHp >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserSubtractHpResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserSubtractHpResult
     * @static
     * @param {msg.UserSubtractHpResult} message UserSubtractHpResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserSubtractHpResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};

      if (options.defaults) {
        object.targetUserId = 0;
        object.subtractHp = 0;
      }

      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      if (message.subtractHp != null && message.hasOwnProperty("subtractHp")) object.subtractHp = message.subtractHp;
      return object;
    };
    /**
     * Converts this UserSubtractHpResult to JSON.
     * @function toJSON
     * @memberof msg.UserSubtractHpResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserSubtractHpResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserSubtractHpResult;
  }();

  msg.UserDieResult = function () {
    /**
     * Properties of a UserDieResult.
     * @memberof msg
     * @interface IUserDieResult
     * @property {number|null} [targetUserId] UserDieResult targetUserId
     */

    /**
     * Constructs a new UserDieResult.
     * @memberof msg
     * @classdesc Represents a UserDieResult.
     * @implements IUserDieResult
     * @constructor
     * @param {msg.IUserDieResult=} [properties] Properties to set
     */
    function UserDieResult(properties) {
      if (properties) for (var keys = Object.keys(properties), i = 0; i < keys.length; ++i) {
        if (properties[keys[i]] != null) this[keys[i]] = properties[keys[i]];
      }
    }
    /**
     * UserDieResult targetUserId.
     * @member {number} targetUserId
     * @memberof msg.UserDieResult
     * @instance
     */


    UserDieResult.prototype.targetUserId = 0;
    /**
     * Creates a new UserDieResult instance using the specified properties.
     * @function create
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult=} [properties] Properties to set
     * @returns {msg.UserDieResult} UserDieResult instance
     */

    UserDieResult.create = function create(properties) {
      return new UserDieResult(properties);
    };
    /**
     * Encodes the specified UserDieResult message. Does not implicitly {@link msg.UserDieResult.verify|verify} messages.
     * @function encode
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult} message UserDieResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserDieResult.encode = function encode(message, writer) {
      if (!writer) writer = $Writer.create();
      if (message.targetUserId != null && Object.hasOwnProperty.call(message, "targetUserId")) writer.uint32(
      /* id 1, wireType 0 =*/
      8).uint32(message.targetUserId);
      return writer;
    };
    /**
     * Encodes the specified UserDieResult message, length delimited. Does not implicitly {@link msg.UserDieResult.verify|verify} messages.
     * @function encodeDelimited
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.IUserDieResult} message UserDieResult message or plain object to encode
     * @param {$protobuf.Writer} [writer] Writer to encode to
     * @returns {$protobuf.Writer} Writer
     */


    UserDieResult.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    /**
     * Decodes a UserDieResult message from the specified reader or buffer.
     * @function decode
     * @memberof msg.UserDieResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @param {number} [length] Message length if known beforehand
     * @returns {msg.UserDieResult} UserDieResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserDieResult.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader)) reader = $Reader.create(reader);
      var end = length === undefined ? reader.len : reader.pos + length,
          message = new $root.msg.UserDieResult();

      while (reader.pos < end) {
        var tag = reader.uint32();

        switch (tag >>> 3) {
          case 1:
            message.targetUserId = reader.uint32();
            break;

          default:
            reader.skipType(tag & 7);
            break;
        }
      }

      return message;
    };
    /**
     * Decodes a UserDieResult message from the specified reader or buffer, length delimited.
     * @function decodeDelimited
     * @memberof msg.UserDieResult
     * @static
     * @param {$protobuf.Reader|Uint8Array} reader Reader or buffer to decode from
     * @returns {msg.UserDieResult} UserDieResult
     * @throws {Error} If the payload is not a reader or valid buffer
     * @throws {$protobuf.util.ProtocolError} If required fields are missing
     */


    UserDieResult.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader)) reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    /**
     * Verifies a UserDieResult message.
     * @function verify
     * @memberof msg.UserDieResult
     * @static
     * @param {Object.<string,*>} message Plain object to verify
     * @returns {string|null} `null` if valid, otherwise the reason why it is not
     */


    UserDieResult.verify = function verify(message) {
      if (typeof message !== "object" || message === null) return "object expected";
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) if (!$util.isInteger(message.targetUserId)) return "targetUserId: integer expected";
      return null;
    };
    /**
     * Creates a UserDieResult message from a plain object. Also converts values to their respective internal types.
     * @function fromObject
     * @memberof msg.UserDieResult
     * @static
     * @param {Object.<string,*>} object Plain object
     * @returns {msg.UserDieResult} UserDieResult
     */


    UserDieResult.fromObject = function fromObject(object) {
      if (object instanceof $root.msg.UserDieResult) return object;
      var message = new $root.msg.UserDieResult();
      if (object.targetUserId != null) message.targetUserId = object.targetUserId >>> 0;
      return message;
    };
    /**
     * Creates a plain object from a UserDieResult message. Also converts values to other types if specified.
     * @function toObject
     * @memberof msg.UserDieResult
     * @static
     * @param {msg.UserDieResult} message UserDieResult
     * @param {$protobuf.IConversionOptions} [options] Conversion options
     * @returns {Object.<string,*>} Plain object
     */


    UserDieResult.toObject = function toObject(message, options) {
      if (!options) options = {};
      var object = {};
      if (options.defaults) object.targetUserId = 0;
      if (message.targetUserId != null && message.hasOwnProperty("targetUserId")) object.targetUserId = message.targetUserId;
      return object;
    };
    /**
     * Converts this UserDieResult to JSON.
     * @function toJSON
     * @memberof msg.UserDieResult
     * @instance
     * @returns {Object.<string,*>} JSON object
     */


    UserDieResult.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };

    return UserDieResult;
  }();

  return msg;
}();

exports.msg = msg;
module.exports = $root;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxHYW1lTXNnUHJvdG9jb2wuanMiXSwibmFtZXMiOlsiJHByb3RvYnVmIiwicmVxdWlyZSIsIiRSZWFkZXIiLCJSZWFkZXIiLCIkV3JpdGVyIiwiV3JpdGVyIiwiJHV0aWwiLCJ1dGlsIiwiJHJvb3QiLCJyb290cyIsIm1zZyIsIk1zZ0NvZGUiLCJ2YWx1ZXNCeUlkIiwidmFsdWVzIiwiT2JqZWN0IiwiY3JlYXRlIiwiVXNlckVudHJ5Q21kIiwicHJvcGVydGllcyIsImtleXMiLCJpIiwibGVuZ3RoIiwicHJvdG90eXBlIiwidXNlcklkIiwiaGVyb0F2YXRhciIsImVuY29kZSIsIm1lc3NhZ2UiLCJ3cml0ZXIiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJ1aW50MzIiLCJzdHJpbmciLCJlbmNvZGVEZWxpbWl0ZWQiLCJsZGVsaW0iLCJkZWNvZGUiLCJyZWFkZXIiLCJlbmQiLCJ1bmRlZmluZWQiLCJsZW4iLCJwb3MiLCJ0YWciLCJza2lwVHlwZSIsImRlY29kZURlbGltaXRlZCIsInZlcmlmeSIsImlzSW50ZWdlciIsImlzU3RyaW5nIiwiZnJvbU9iamVjdCIsIm9iamVjdCIsIlN0cmluZyIsInRvT2JqZWN0Iiwib3B0aW9ucyIsImRlZmF1bHRzIiwidG9KU09OIiwiY29uc3RydWN0b3IiLCJ0b0pTT05PcHRpb25zIiwiVXNlckVudHJ5UmVzdWx0IiwiV2hvRWxzZUlzSGVyZUNtZCIsIldob0Vsc2VJc0hlcmVSZXN1bHQiLCJ1c2VySW5mbyIsImVtcHR5QXJyYXkiLCJVc2VySW5mbyIsImZvcmsiLCJwdXNoIiwiQXJyYXkiLCJpc0FycmF5IiwiZXJyb3IiLCJUeXBlRXJyb3IiLCJhcnJheXMiLCJqIiwibW92ZVN0YXRlIiwiTW92ZVN0YXRlIiwiZnJvbVBvc1giLCJmcm9tUG9zWSIsInRvUG9zWCIsInRvUG9zWSIsInN0YXJ0VGltZSIsIkxvbmciLCJmcm9tQml0cyIsInVpbnQ2NCIsImxvdyIsImhpZ2giLCJOdW1iZXIiLCJmcm9tVmFsdWUiLCJ1bnNpZ25lZCIsInBhcnNlSW50IiwiTG9uZ0JpdHMiLCJ0b051bWJlciIsImxvbmciLCJsb25ncyIsInRvU3RyaW5nIiwianNvbiIsImlzRmluaXRlIiwiVXNlck1vdmVUb0NtZCIsIm1vdmVGcm9tUG9zWCIsIm1vdmVGcm9tUG9zWSIsIm1vdmVUb1Bvc1giLCJtb3ZlVG9Qb3NZIiwiVXNlck1vdmVUb1Jlc3VsdCIsIm1vdmVVc2VySWQiLCJtb3ZlU3RhcnRUaW1lIiwiVXNlclF1aXRSZXN1bHQiLCJxdWl0VXNlcklkIiwiVXNlclN0b3BDbWQiLCJVc2VyU3RvcFJlc3VsdCIsInN0b3BVc2VySWQiLCJzdG9wQXRQb3NYIiwic3RvcEF0UG9zWSIsIlVzZXJBdHRrQ21kIiwidGFyZ2V0VXNlcklkIiwiVXNlckF0dGtSZXN1bHQiLCJhdHRrVXNlcklkIiwiVXNlclN1YnRyYWN0SHBSZXN1bHQiLCJzdWJ0cmFjdEhwIiwiVXNlckRpZVJlc3VsdCIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7Ozs7O0FBRUEsSUFBSUEsU0FBUyxHQUFHQyxPQUFPLENBQUMsWUFBRCxDQUF2QixFQUVBOzs7QUFDQSxJQUFNQyxPQUFPLEdBQUdGLFNBQVMsQ0FBQ0csTUFBMUI7QUFBQSxJQUFrQ0MsT0FBTyxHQUFHSixTQUFTLENBQUNLLE1BQXREO0FBQUEsSUFBOERDLEtBQUssR0FBR04sU0FBUyxDQUFDTyxJQUFoRixFQUVBOztBQUNBLElBQU1DLEtBQUssR0FBR1IsU0FBUyxDQUFDUyxLQUFWLENBQWdCLFNBQWhCLE1BQStCVCxTQUFTLENBQUNTLEtBQVYsQ0FBZ0IsU0FBaEIsSUFBNkIsRUFBNUQsQ0FBZDs7QUFFTyxJQUFNQyxHQUFHLEdBQUdGLEtBQUssQ0FBQ0UsR0FBTixHQUFhLFlBQU07QUFFbEM7Ozs7O0FBS0EsTUFBTUEsR0FBRyxHQUFHLEVBQVo7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQUEsRUFBQUEsR0FBRyxDQUFDQyxPQUFKLEdBQWUsWUFBVztBQUN0QixRQUFNQyxVQUFVLEdBQUcsRUFBbkI7QUFBQSxRQUF1QkMsTUFBTSxHQUFHQyxNQUFNLENBQUNDLE1BQVAsQ0FBY0gsVUFBZCxDQUFoQztBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0IsZ0JBQWpCLENBQU4sR0FBMkMsQ0FBM0M7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLG1CQUFqQixDQUFOLEdBQThDLENBQTlDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixzQkFBakIsQ0FBTixHQUFpRCxDQUFqRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0IseUJBQWpCLENBQU4sR0FBb0QsQ0FBcEQ7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGtCQUFqQixDQUFOLEdBQTZDLENBQTdDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixxQkFBakIsQ0FBTixHQUFnRCxDQUFoRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxDQUFELENBQVYsR0FBZ0Isa0JBQWpCLENBQU4sR0FBNkMsQ0FBN0M7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGVBQWpCLENBQU4sR0FBMEMsQ0FBMUM7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsQ0FBRCxDQUFWLEdBQWdCLGtCQUFqQixDQUFOLEdBQTZDLENBQTdDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLENBQUQsQ0FBVixHQUFnQixlQUFqQixDQUFOLEdBQTBDLENBQTFDO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0QsVUFBVSxDQUFDLEVBQUQsQ0FBVixHQUFpQixrQkFBbEIsQ0FBTixHQUE4QyxFQUE5QztBQUNBQyxJQUFBQSxNQUFNLENBQUNELFVBQVUsQ0FBQyxFQUFELENBQVYsR0FBaUIseUJBQWxCLENBQU4sR0FBcUQsRUFBckQ7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxVQUFVLENBQUMsRUFBRCxDQUFWLEdBQWlCLGlCQUFsQixDQUFOLEdBQTZDLEVBQTdDO0FBQ0EsV0FBT0MsTUFBUDtBQUNILEdBaEJhLEVBQWQ7O0FBa0JBSCxFQUFBQSxHQUFHLENBQUNNLFlBQUosR0FBb0IsWUFBVztBQUUzQjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxZQUFULENBQXNCQyxVQUF0QixFQUFrQztBQUM5QixVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFILElBQUFBLFlBQVksQ0FBQ0ssU0FBYixDQUF1QkMsTUFBdkIsR0FBZ0MsQ0FBaEM7QUFFQTs7Ozs7OztBQU1BTixJQUFBQSxZQUFZLENBQUNLLFNBQWIsQ0FBdUJFLFVBQXZCLEdBQW9DLEVBQXBDO0FBRUE7Ozs7Ozs7OztBQVFBUCxJQUFBQSxZQUFZLENBQUNELE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDOUMsYUFBTyxJQUFJRCxZQUFKLENBQWlCQyxVQUFqQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBRCxJQUFBQSxZQUFZLENBQUNRLE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ25ELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixhQUFPRyxNQUFQO0FBQ0gsS0FSRDtBQVVBOzs7Ozs7Ozs7OztBQVNBVixJQUFBQSxZQUFZLENBQUNlLGVBQWIsR0FBK0IsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3JFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBaEIsSUFBQUEsWUFBWSxDQUFDaUIsTUFBYixHQUFzQixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDbEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVTSxZQUFkLEVBQTdFOztBQUNBLGFBQU9rQixNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ0gsTUFBUixHQUFpQlksTUFBTSxDQUFDTCxNQUFQLEVBQWpCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQlcsTUFBTSxDQUFDSixNQUFQLEVBQXJCO0FBQ0E7O0FBQ0o7QUFDSUksWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQVRKO0FBV0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7Ozs7QUFVQVQsSUFBQUEsWUFBWSxDQUFDeUIsZUFBYixHQUErQixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM1RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUFiLElBQUFBLFlBQVksQ0FBQzBCLE1BQWIsR0FBc0IsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzNDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQkcsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ0gsTUFBeEIsQ0FBTCxFQUNJLE9BQU8sMEJBQVA7QUFDUixVQUFJRyxPQUFPLENBQUNGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3NDLFFBQU4sQ0FBZW5CLE9BQU8sQ0FBQ0YsVUFBdkIsQ0FBTCxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVZEO0FBWUE7Ozs7Ozs7Ozs7QUFRQVAsSUFBQUEsWUFBWSxDQUFDNkIsVUFBYixHQUEwQixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNsRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVU0sWUFBaEMsRUFDSSxPQUFPOEIsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVTSxZQUFkLEVBQWQ7QUFDQSxVQUFJOEIsTUFBTSxDQUFDeEIsTUFBUCxJQUFpQixJQUFyQixFQUNJRyxPQUFPLENBQUNILE1BQVIsR0FBaUJ3QixNQUFNLENBQUN4QixNQUFQLEtBQWtCLENBQW5DO0FBQ0osVUFBSXdCLE1BQU0sQ0FBQ3ZCLFVBQVAsSUFBcUIsSUFBekIsRUFDSUUsT0FBTyxDQUFDRixVQUFSLEdBQXFCd0IsTUFBTSxDQUFDRCxNQUFNLENBQUN2QixVQUFSLENBQTNCO0FBQ0osYUFBT0UsT0FBUDtBQUNILEtBVEQ7QUFXQTs7Ozs7Ozs7Ozs7QUFTQVQsSUFBQUEsWUFBWSxDQUFDZ0MsUUFBYixHQUF3QixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUN4RCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3hCLE1BQVAsR0FBZ0IsQ0FBaEI7QUFDQXdCLFFBQUFBLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0IsRUFBcEI7QUFDSDs7QUFDRCxVQUFJRSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJbUIsTUFBTSxDQUFDeEIsTUFBUCxHQUFnQkcsT0FBTyxDQUFDSCxNQUF4QjtBQUNKLFVBQUlHLE9BQU8sQ0FBQ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QkUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUN2QixVQUFQLEdBQW9CRSxPQUFPLENBQUNGLFVBQTVCO0FBQ0osYUFBT3VCLE1BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7OztBQU9BOUIsSUFBQUEsWUFBWSxDQUFDSyxTQUFiLENBQXVCOEIsTUFBdkIsR0FBZ0MsU0FBU0EsTUFBVCxHQUFrQjtBQUM5QyxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPckMsWUFBUDtBQUNILEdBaE5rQixFQUFuQjs7QUFrTkFOLEVBQUFBLEdBQUcsQ0FBQzRDLGVBQUosR0FBdUIsWUFBVztBQUU5Qjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxlQUFULENBQXlCckMsVUFBekIsRUFBcUM7QUFDakMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BbUMsSUFBQUEsZUFBZSxDQUFDakMsU0FBaEIsQ0FBMEJDLE1BQTFCLEdBQW1DLENBQW5DO0FBRUE7Ozs7Ozs7QUFNQWdDLElBQUFBLGVBQWUsQ0FBQ2pDLFNBQWhCLENBQTBCRSxVQUExQixHQUF1QyxFQUF2QztBQUVBOzs7Ozs7Ozs7QUFRQStCLElBQUFBLGVBQWUsQ0FBQ3ZDLE1BQWhCLEdBQXlCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2pELGFBQU8sSUFBSXFDLGVBQUosQ0FBb0JyQyxVQUFwQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBcUMsSUFBQUEsZUFBZSxDQUFDOUIsTUFBaEIsR0FBeUIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ3RELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixhQUFPRyxNQUFQO0FBQ0gsS0FSRDtBQVVBOzs7Ozs7Ozs7OztBQVNBNEIsSUFBQUEsZUFBZSxDQUFDdkIsZUFBaEIsR0FBa0MsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3hFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBc0IsSUFBQUEsZUFBZSxDQUFDckIsTUFBaEIsR0FBeUIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3JELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVTRDLGVBQWQsRUFBN0U7O0FBQ0EsYUFBT3BCLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDSCxNQUFSLEdBQWlCWSxNQUFNLENBQUNMLE1BQVAsRUFBakI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSUosWUFBQUEsT0FBTyxDQUFDRixVQUFSLEdBQXFCVyxNQUFNLENBQUNKLE1BQVAsRUFBckI7QUFDQTs7QUFDSjtBQUNJSSxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBVEo7QUFXSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FuQkQ7QUFxQkE7Ozs7Ozs7Ozs7OztBQVVBNkIsSUFBQUEsZUFBZSxDQUFDYixlQUFoQixHQUFrQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUMvRCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUF5QixJQUFBQSxlQUFlLENBQUNaLE1BQWhCLEdBQXlCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM5QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNILE1BQXhCLENBQUwsRUFDSSxPQUFPLDBCQUFQO0FBQ1IsVUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNzQyxRQUFOLENBQWVuQixPQUFPLENBQUNGLFVBQXZCLENBQUwsRUFDSSxPQUFPLDZCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FWRDtBQVlBOzs7Ozs7Ozs7O0FBUUErQixJQUFBQSxlQUFlLENBQUNULFVBQWhCLEdBQTZCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ3JELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVNEMsZUFBaEMsRUFDSSxPQUFPUixNQUFQO0FBQ0osVUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU0QyxlQUFkLEVBQWQ7QUFDQSxVQUFJUixNQUFNLENBQUN4QixNQUFQLElBQWlCLElBQXJCLEVBQ0lHLE9BQU8sQ0FBQ0gsTUFBUixHQUFpQndCLE1BQU0sQ0FBQ3hCLE1BQVAsS0FBa0IsQ0FBbkM7QUFDSixVQUFJd0IsTUFBTSxDQUFDdkIsVUFBUCxJQUFxQixJQUF6QixFQUNJRSxPQUFPLENBQUNGLFVBQVIsR0FBcUJ3QixNQUFNLENBQUNELE1BQU0sQ0FBQ3ZCLFVBQVIsQ0FBM0I7QUFDSixhQUFPRSxPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBNkIsSUFBQUEsZUFBZSxDQUFDTixRQUFoQixHQUEyQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMzRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3hCLE1BQVAsR0FBZ0IsQ0FBaEI7QUFDQXdCLFFBQUFBLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0IsRUFBcEI7QUFDSDs7QUFDRCxVQUFJRSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJbUIsTUFBTSxDQUFDeEIsTUFBUCxHQUFnQkcsT0FBTyxDQUFDSCxNQUF4QjtBQUNKLFVBQUlHLE9BQU8sQ0FBQ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QkUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUN2QixVQUFQLEdBQW9CRSxPQUFPLENBQUNGLFVBQTVCO0FBQ0osYUFBT3VCLE1BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7OztBQU9BUSxJQUFBQSxlQUFlLENBQUNqQyxTQUFoQixDQUEwQjhCLE1BQTFCLEdBQW1DLFNBQVNBLE1BQVQsR0FBa0I7QUFDakQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBT0MsZUFBUDtBQUNILEdBaE5xQixFQUF0Qjs7QUFrTkE1QyxFQUFBQSxHQUFHLENBQUM2QyxnQkFBSixHQUF3QixZQUFXO0FBRS9COzs7Ozs7QUFNQTs7Ozs7Ozs7QUFRQSxhQUFTQSxnQkFBVCxDQUEwQnRDLFVBQTFCLEVBQXNDO0FBQ2xDLFVBQUlBLFVBQUosRUFDSSxLQUFLLElBQUlDLElBQUksR0FBR0osTUFBTSxDQUFDSSxJQUFQLENBQVlELFVBQVosQ0FBWCxFQUFvQ0UsQ0FBQyxHQUFHLENBQTdDLEVBQWdEQSxDQUFDLEdBQUdELElBQUksQ0FBQ0UsTUFBekQsRUFBaUUsRUFBRUQsQ0FBbkU7QUFDSSxZQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7OztBQVFBb0MsSUFBQUEsZ0JBQWdCLENBQUN4QyxNQUFqQixHQUEwQixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUNsRCxhQUFPLElBQUlzQyxnQkFBSixDQUFxQnRDLFVBQXJCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FzQyxJQUFBQSxnQkFBZ0IsQ0FBQy9CLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUN2RCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixhQUFPVyxNQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBNkIsSUFBQUEsZ0JBQWdCLENBQUN4QixlQUFqQixHQUFtQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDekUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0F1QixJQUFBQSxnQkFBZ0IsQ0FBQ3RCLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUN0RCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBZCxFQUE3RTs7QUFDQSxhQUFPckIsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBO0FBQ0lMLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFISjtBQUtIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7OztBQVVBOEIsSUFBQUEsZ0JBQWdCLENBQUNkLGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQ2hFLFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQTBCLElBQUFBLGdCQUFnQixDQUFDYixNQUFqQixHQUEwQixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDL0MsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osYUFBTyxJQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUE4QixJQUFBQSxnQkFBZ0IsQ0FBQ1YsVUFBakIsR0FBOEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDdEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBaEMsRUFDSSxPQUFPVCxNQUFQO0FBQ0osYUFBTyxJQUFJdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU2QyxnQkFBZCxFQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ1AsUUFBakIsR0FBNEIsU0FBU0EsUUFBVCxHQUFvQjtBQUM1QyxhQUFPLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7OztBQU9BTyxJQUFBQSxnQkFBZ0IsQ0FBQ2xDLFNBQWpCLENBQTJCOEIsTUFBM0IsR0FBb0MsU0FBU0EsTUFBVCxHQUFrQjtBQUNsRCxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPRSxnQkFBUDtBQUNILEdBOUpzQixFQUF2Qjs7QUFnS0E3QyxFQUFBQSxHQUFHLENBQUM4QyxtQkFBSixHQUEyQixZQUFXO0FBRWxDOzs7Ozs7O0FBT0E7Ozs7Ozs7O0FBUUEsYUFBU0EsbUJBQVQsQ0FBNkJ2QyxVQUE3QixFQUF5QztBQUNyQyxXQUFLd0MsUUFBTCxHQUFnQixFQUFoQjtBQUNBLFVBQUl4QyxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFxQyxJQUFBQSxtQkFBbUIsQ0FBQ25DLFNBQXBCLENBQThCb0MsUUFBOUIsR0FBeUNuRCxLQUFLLENBQUNvRCxVQUEvQztBQUVBOzs7Ozs7Ozs7QUFRQUYsSUFBQUEsbUJBQW1CLENBQUN6QyxNQUFwQixHQUE2QixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUNyRCxhQUFPLElBQUl1QyxtQkFBSixDQUF3QnZDLFVBQXhCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0F1QyxJQUFBQSxtQkFBbUIsQ0FBQ2hDLE1BQXBCLEdBQTZCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUMxRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUNnQyxRQUFSLElBQW9CLElBQXBCLElBQTRCaEMsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnJDLE1BQWpELEVBQ0ksS0FBSyxJQUFJRCxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHTSxPQUFPLENBQUNnQyxRQUFSLENBQWlCckMsTUFBckMsRUFBNkMsRUFBRUQsQ0FBL0M7QUFDSVgsUUFBQUEsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNuQyxNQUF2QyxDQUE4Q0MsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnRDLENBQWpCLENBQTlDLEVBQW1FTyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixVQUFyQyxFQUF5QytCLElBQXpDLEVBQW5FLEVBQW9INUIsTUFBcEg7QUFESjtBQUVKLGFBQU9OLE1BQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7O0FBU0E4QixJQUFBQSxtQkFBbUIsQ0FBQ3pCLGVBQXBCLEdBQXNDLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUM1RSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQXdCLElBQUFBLG1CQUFtQixDQUFDdkIsTUFBcEIsR0FBNkIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3pELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFkLEVBQTdFOztBQUNBLGFBQU90QixNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0ksZ0JBQUksRUFBRWQsT0FBTyxDQUFDZ0MsUUFBUixJQUFvQmhDLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUF2QyxDQUFKLEVBQ0lLLE9BQU8sQ0FBQ2dDLFFBQVIsR0FBbUIsRUFBbkI7QUFDSmhDLFlBQUFBLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJJLElBQWpCLENBQXNCckQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUMxQixNQUF2QyxDQUE4Q0MsTUFBOUMsRUFBc0RBLE1BQU0sQ0FBQ0wsTUFBUCxFQUF0RCxDQUF0QjtBQUNBOztBQUNKO0FBQ0lLLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFSSjtBQVVIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWxCRDtBQW9CQTs7Ozs7Ozs7Ozs7O0FBVUErQixJQUFBQSxtQkFBbUIsQ0FBQ2YsZUFBcEIsR0FBc0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDbkUsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBMkIsSUFBQUEsbUJBQW1CLENBQUNkLE1BQXBCLEdBQTZCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUNsRCxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7O0FBQ0osVUFBSUEsT0FBTyxDQUFDZ0MsUUFBUixJQUFvQixJQUFwQixJQUE0QmhDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUFvRTtBQUNoRSxZQUFJLENBQUNtQyxLQUFLLENBQUNDLE9BQU4sQ0FBY3RDLE9BQU8sQ0FBQ2dDLFFBQXRCLENBQUwsRUFDSSxPQUFPLDBCQUFQOztBQUNKLGFBQUssSUFBSXRDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdNLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUFyQyxFQUE2QyxFQUFFRCxDQUEvQyxFQUFrRDtBQUM5QyxjQUFJNkMsS0FBSyxHQUFHeEQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNqQixNQUF2QyxDQUE4Q2pCLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJ0QyxDQUFqQixDQUE5QyxDQUFaO0FBQ0EsY0FBSTZDLEtBQUosRUFDSSxPQUFPLGNBQWNBLEtBQXJCO0FBQ1A7QUFDSjs7QUFDRCxhQUFPLElBQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7QUFRQVIsSUFBQUEsbUJBQW1CLENBQUNYLFVBQXBCLEdBQWlDLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ3pELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQWhDLEVBQ0ksT0FBT1YsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQWQsRUFBZDs7QUFDQSxVQUFJVixNQUFNLENBQUNXLFFBQVgsRUFBcUI7QUFDakIsWUFBSSxDQUFDSyxLQUFLLENBQUNDLE9BQU4sQ0FBY2pCLE1BQU0sQ0FBQ1csUUFBckIsQ0FBTCxFQUNJLE1BQU1RLFNBQVMsQ0FBQyxtREFBRCxDQUFmO0FBQ0p4QyxRQUFBQSxPQUFPLENBQUNnQyxRQUFSLEdBQW1CLEVBQW5COztBQUNBLGFBQUssSUFBSXRDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcyQixNQUFNLENBQUNXLFFBQVAsQ0FBZ0JyQyxNQUFwQyxFQUE0QyxFQUFFRCxDQUE5QyxFQUFpRDtBQUM3QyxjQUFJLE9BQU8yQixNQUFNLENBQUNXLFFBQVAsQ0FBZ0J0QyxDQUFoQixDQUFQLEtBQThCLFFBQWxDLEVBQ0ksTUFBTThDLFNBQVMsQ0FBQyxvREFBRCxDQUFmO0FBQ0p4QyxVQUFBQSxPQUFPLENBQUNnQyxRQUFSLENBQWlCdEMsQ0FBakIsSUFBc0JYLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDZCxVQUF2QyxDQUFrREMsTUFBTSxDQUFDVyxRQUFQLENBQWdCdEMsQ0FBaEIsQ0FBbEQsQ0FBdEI7QUFDSDtBQUNKOztBQUNELGFBQU9NLE9BQVA7QUFDSCxLQWZEO0FBaUJBOzs7Ozs7Ozs7OztBQVNBK0IsSUFBQUEsbUJBQW1CLENBQUNSLFFBQXBCLEdBQStCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQy9ELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiO0FBQ0EsVUFBSUcsT0FBTyxDQUFDaUIsTUFBUixJQUFrQmpCLE9BQU8sQ0FBQ0MsUUFBOUIsRUFDSUosTUFBTSxDQUFDVyxRQUFQLEdBQWtCLEVBQWxCOztBQUNKLFVBQUloQyxPQUFPLENBQUNnQyxRQUFSLElBQW9CaEMsT0FBTyxDQUFDZ0MsUUFBUixDQUFpQnJDLE1BQXpDLEVBQWlEO0FBQzdDMEIsUUFBQUEsTUFBTSxDQUFDVyxRQUFQLEdBQWtCLEVBQWxCOztBQUNBLGFBQUssSUFBSVUsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzFDLE9BQU8sQ0FBQ2dDLFFBQVIsQ0FBaUJyQyxNQUFyQyxFQUE2QyxFQUFFK0MsQ0FBL0M7QUFDSXJCLFVBQUFBLE1BQU0sQ0FBQ1csUUFBUCxDQUFnQlUsQ0FBaEIsSUFBcUIzRCxLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUE5QixDQUF1Q1gsUUFBdkMsQ0FBZ0R2QixPQUFPLENBQUNnQyxRQUFSLENBQWlCVSxDQUFqQixDQUFoRCxFQUFxRWxCLE9BQXJFLENBQXJCO0FBREo7QUFFSDs7QUFDRCxhQUFPSCxNQUFQO0FBQ0gsS0FaRDtBQWNBOzs7Ozs7Ozs7QUFPQVUsSUFBQUEsbUJBQW1CLENBQUNuQyxTQUFwQixDQUE4QjhCLE1BQTlCLEdBQXVDLFNBQVNBLE1BQVQsR0FBa0I7QUFDckQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUFHLElBQUFBLG1CQUFtQixDQUFDRyxRQUFwQixHQUFnQyxZQUFXO0FBRXZDOzs7Ozs7Ozs7QUFTQTs7Ozs7Ozs7QUFRQSxlQUFTQSxRQUFULENBQWtCMUMsVUFBbEIsRUFBOEI7QUFDMUIsWUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLGNBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1Bd0MsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQkMsTUFBbkIsR0FBNEIsQ0FBNUI7QUFFQTs7Ozs7OztBQU1BcUMsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQkUsVUFBbkIsR0FBZ0MsRUFBaEM7QUFFQTs7Ozs7OztBQU1Bb0MsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQitDLFNBQW5CLEdBQStCLElBQS9CO0FBRUE7Ozs7Ozs7OztBQVFBVCxNQUFBQSxRQUFRLENBQUM1QyxNQUFULEdBQWtCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQzFDLGVBQU8sSUFBSTBDLFFBQUosQ0FBYTFDLFVBQWIsQ0FBUDtBQUNILE9BRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQTBDLE1BQUFBLFFBQVEsQ0FBQ25DLE1BQVQsR0FBa0IsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQy9DLFlBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFlBQUlVLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQlIsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsU0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUNILE1BQXZEO0FBQ0osWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCVCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixVQUFyQyxFQUF5Q0MsTUFBekMsQ0FBZ0RMLE9BQU8sQ0FBQ0YsVUFBeEQ7QUFDSixZQUFJRSxPQUFPLENBQUMyQyxTQUFSLElBQXFCLElBQXJCLElBQTZCdEQsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsV0FBcEMsQ0FBakMsRUFDSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUF2QyxDQUFpRDdDLE1BQWpELENBQXdEQyxPQUFPLENBQUMyQyxTQUFoRSxFQUEyRTFDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFVBQXJDLEVBQXlDK0IsSUFBekMsRUFBM0UsRUFBNEg1QixNQUE1SDtBQUNKLGVBQU9OLE1BQVA7QUFDSCxPQVZEO0FBWUE7Ozs7Ozs7Ozs7O0FBU0FpQyxNQUFBQSxRQUFRLENBQUM1QixlQUFULEdBQTJCLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUNqRSxlQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxPQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQTJCLE1BQUFBLFFBQVEsQ0FBQzFCLE1BQVQsR0FBa0IsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQzlDLFlBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixZQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxZQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUFsQyxFQUE3RTs7QUFDQSxlQUFPekIsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLGNBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0Esa0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGlCQUFLLENBQUw7QUFDSWQsY0FBQUEsT0FBTyxDQUFDSCxNQUFSLEdBQWlCWSxNQUFNLENBQUNMLE1BQVAsRUFBakI7QUFDQTs7QUFDSixpQkFBSyxDQUFMO0FBQ0lKLGNBQUFBLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQlcsTUFBTSxDQUFDSixNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJTCxjQUFBQSxPQUFPLENBQUMyQyxTQUFSLEdBQW9CNUQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQXZDLENBQWlEcEMsTUFBakQsQ0FBd0RDLE1BQXhELEVBQWdFQSxNQUFNLENBQUNMLE1BQVAsRUFBaEUsQ0FBcEI7QUFDQTs7QUFDSjtBQUNJSyxjQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBWko7QUFjSDs7QUFDRCxlQUFPZCxPQUFQO0FBQ0gsT0F0QkQ7QUF3QkE7Ozs7Ozs7Ozs7OztBQVVBa0MsTUFBQUEsUUFBUSxDQUFDbEIsZUFBVCxHQUEyQixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUN4RCxZQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osZUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsT0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUE4QixNQUFBQSxRQUFRLENBQUNqQixNQUFULEdBQWtCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUN2QyxZQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixZQUFJQSxPQUFPLENBQUNILE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJHLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNILE1BQXhCLENBQUwsRUFDSSxPQUFPLDBCQUFQO0FBQ1IsWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNzQyxRQUFOLENBQWVuQixPQUFPLENBQUNGLFVBQXZCLENBQUwsRUFDSSxPQUFPLDZCQUFQOztBQUNSLFlBQUlFLE9BQU8sQ0FBQzJDLFNBQVIsSUFBcUIsSUFBckIsSUFBNkIzQyxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsV0FBdkIsQ0FBakMsRUFBc0U7QUFDbEUsY0FBSXFDLEtBQUssR0FBR3hELEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUF2QyxDQUFpRDNCLE1BQWpELENBQXdEakIsT0FBTyxDQUFDMkMsU0FBaEUsQ0FBWjtBQUNBLGNBQUlKLEtBQUosRUFDSSxPQUFPLGVBQWVBLEtBQXRCO0FBQ1A7O0FBQ0QsZUFBTyxJQUFQO0FBQ0gsT0FmRDtBQWlCQTs7Ozs7Ozs7OztBQVFBTCxNQUFBQSxRQUFRLENBQUNkLFVBQVQsR0FBc0IsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDOUMsWUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBcEQsRUFDSSxPQUFPYixNQUFQO0FBQ0osWUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBbEMsRUFBZDtBQUNBLFlBQUliLE1BQU0sQ0FBQ3hCLE1BQVAsSUFBaUIsSUFBckIsRUFDSUcsT0FBTyxDQUFDSCxNQUFSLEdBQWlCd0IsTUFBTSxDQUFDeEIsTUFBUCxLQUFrQixDQUFuQztBQUNKLFlBQUl3QixNQUFNLENBQUN2QixVQUFQLElBQXFCLElBQXpCLEVBQ0lFLE9BQU8sQ0FBQ0YsVUFBUixHQUFxQndCLE1BQU0sQ0FBQ0QsTUFBTSxDQUFDdkIsVUFBUixDQUEzQjs7QUFDSixZQUFJdUIsTUFBTSxDQUFDc0IsU0FBUCxJQUFvQixJQUF4QixFQUE4QjtBQUMxQixjQUFJLE9BQU90QixNQUFNLENBQUNzQixTQUFkLEtBQTRCLFFBQWhDLEVBQ0ksTUFBTUgsU0FBUyxDQUFDLDhEQUFELENBQWY7QUFDSnhDLFVBQUFBLE9BQU8sQ0FBQzJDLFNBQVIsR0FBb0I1RCxLQUFLLENBQUNFLEdBQU4sQ0FBVThDLG1CQUFWLENBQThCRyxRQUE5QixDQUF1Q1UsU0FBdkMsQ0FBaUR4QixVQUFqRCxDQUE0REMsTUFBTSxDQUFDc0IsU0FBbkUsQ0FBcEI7QUFDSDs7QUFDRCxlQUFPM0MsT0FBUDtBQUNILE9BZEQ7QUFnQkE7Ozs7Ozs7Ozs7O0FBU0FrQyxNQUFBQSxRQUFRLENBQUNYLFFBQVQsR0FBb0IsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDcEQsWUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osWUFBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsWUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixVQUFBQSxNQUFNLENBQUN4QixNQUFQLEdBQWdCLENBQWhCO0FBQ0F3QixVQUFBQSxNQUFNLENBQUN2QixVQUFQLEdBQW9CLEVBQXBCO0FBQ0F1QixVQUFBQSxNQUFNLENBQUNzQixTQUFQLEdBQW1CLElBQW5CO0FBQ0g7O0FBQ0QsWUFBSTNDLE9BQU8sQ0FBQ0gsTUFBUixJQUFrQixJQUFsQixJQUEwQkcsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ltQixNQUFNLENBQUN4QixNQUFQLEdBQWdCRyxPQUFPLENBQUNILE1BQXhCO0FBQ0osWUFBSUcsT0FBTyxDQUFDRixVQUFSLElBQXNCLElBQXRCLElBQThCRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ3ZCLFVBQVAsR0FBb0JFLE9BQU8sQ0FBQ0YsVUFBNUI7QUFDSixZQUFJRSxPQUFPLENBQUMyQyxTQUFSLElBQXFCLElBQXJCLElBQTZCM0MsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFdBQXZCLENBQWpDLEVBQ0ltQixNQUFNLENBQUNzQixTQUFQLEdBQW1CNUQsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQXZDLENBQWlEckIsUUFBakQsQ0FBMER2QixPQUFPLENBQUMyQyxTQUFsRSxFQUE2RW5CLE9BQTdFLENBQW5CO0FBQ0osZUFBT0gsTUFBUDtBQUNILE9BaEJEO0FBa0JBOzs7Ozs7Ozs7QUFPQWEsTUFBQUEsUUFBUSxDQUFDdEMsU0FBVCxDQUFtQjhCLE1BQW5CLEdBQTRCLFNBQVNBLE1BQVQsR0FBa0I7QUFDMUMsZUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILE9BRkQ7O0FBSUFNLE1BQUFBLFFBQVEsQ0FBQ1UsU0FBVCxHQUFzQixZQUFXO0FBRTdCOzs7Ozs7Ozs7OztBQVdBOzs7Ozs7OztBQVFBLGlCQUFTQSxTQUFULENBQW1CcEQsVUFBbkIsRUFBK0I7QUFDM0IsY0FBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLGdCQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7QUFNQWtELFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JpRCxRQUFwQixHQUErQixDQUEvQjtBQUVBOzs7Ozs7O0FBTUFELFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JrRCxRQUFwQixHQUErQixDQUEvQjtBQUVBOzs7Ozs7O0FBTUFGLFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JtRCxNQUFwQixHQUE2QixDQUE3QjtBQUVBOzs7Ozs7O0FBTUFILFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JvRCxNQUFwQixHQUE2QixDQUE3QjtBQUVBOzs7Ozs7O0FBTUFKLFFBQUFBLFNBQVMsQ0FBQ2hELFNBQVYsQ0FBb0JxRCxTQUFwQixHQUFnQ3BFLEtBQUssQ0FBQ3FFLElBQU4sR0FBYXJFLEtBQUssQ0FBQ3FFLElBQU4sQ0FBV0MsUUFBWCxDQUFvQixDQUFwQixFQUFzQixDQUF0QixFQUF3QixJQUF4QixDQUFiLEdBQTZDLENBQTdFO0FBRUE7Ozs7Ozs7OztBQVFBUCxRQUFBQSxTQUFTLENBQUN0RCxNQUFWLEdBQW1CLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQzNDLGlCQUFPLElBQUlvRCxTQUFKLENBQWNwRCxVQUFkLENBQVA7QUFDSCxTQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FvRCxRQUFBQSxTQUFTLENBQUM3QyxNQUFWLEdBQW1CLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNoRCxjQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixjQUFJVSxPQUFPLENBQUM2QyxRQUFSLElBQW9CLElBQXBCLElBQTRCeEQsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsVUFBcEMsQ0FBaEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsWUFBckMsV0FBK0NKLE9BQU8sQ0FBQzZDLFFBQXZEO0FBQ0osY0FBSTdDLE9BQU8sQ0FBQzhDLFFBQVIsSUFBb0IsSUFBcEIsSUFBNEJ6RCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxVQUFwQyxDQUFoQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixZQUFyQyxXQUErQ0osT0FBTyxDQUFDOEMsUUFBdkQ7QUFDSixjQUFJOUMsT0FBTyxDQUFDK0MsTUFBUixJQUFrQixJQUFsQixJQUEwQjFELE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFFBQXBDLENBQTlCLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFlBQXJDLFdBQStDSixPQUFPLENBQUMrQyxNQUF2RDtBQUNKLGNBQUkvQyxPQUFPLENBQUNnRCxNQUFSLElBQWtCLElBQWxCLElBQTBCM0QsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsUUFBcEMsQ0FBOUIsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsWUFBckMsV0FBK0NKLE9BQU8sQ0FBQ2dELE1BQXZEO0FBQ0osY0FBSWhELE9BQU8sQ0FBQ2lELFNBQVIsSUFBcUIsSUFBckIsSUFBNkI1RCxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxXQUFwQyxDQUFqQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixZQUFyQyxFQUF5Q2dELE1BQXpDLENBQWdEcEQsT0FBTyxDQUFDaUQsU0FBeEQ7QUFDSixpQkFBT2hELE1BQVA7QUFDSCxTQWREO0FBZ0JBOzs7Ozs7Ozs7OztBQVNBMkMsUUFBQUEsU0FBUyxDQUFDdEMsZUFBVixHQUE0QixTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDbEUsaUJBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILFNBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBcUMsUUFBQUEsU0FBUyxDQUFDcEMsTUFBVixHQUFtQixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDL0MsY0FBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLGNBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLGNBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUEzQyxFQUE3RTs7QUFDQSxpQkFBT25DLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixnQkFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxvQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsbUJBQUssQ0FBTDtBQUNJZCxnQkFBQUEsT0FBTyxDQUFDNkMsUUFBUixHQUFtQnBDLE1BQU0sU0FBTixFQUFuQjtBQUNBOztBQUNKLG1CQUFLLENBQUw7QUFDSVQsZ0JBQUFBLE9BQU8sQ0FBQzhDLFFBQVIsR0FBbUJyQyxNQUFNLFNBQU4sRUFBbkI7QUFDQTs7QUFDSixtQkFBSyxDQUFMO0FBQ0lULGdCQUFBQSxPQUFPLENBQUMrQyxNQUFSLEdBQWlCdEMsTUFBTSxTQUFOLEVBQWpCO0FBQ0E7O0FBQ0osbUJBQUssQ0FBTDtBQUNJVCxnQkFBQUEsT0FBTyxDQUFDZ0QsTUFBUixHQUFpQnZDLE1BQU0sU0FBTixFQUFqQjtBQUNBOztBQUNKLG1CQUFLLENBQUw7QUFDSVQsZ0JBQUFBLE9BQU8sQ0FBQ2lELFNBQVIsR0FBb0J4QyxNQUFNLENBQUMyQyxNQUFQLEVBQXBCO0FBQ0E7O0FBQ0o7QUFDSTNDLGdCQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBbEJKO0FBb0JIOztBQUNELGlCQUFPZCxPQUFQO0FBQ0gsU0E1QkQ7QUE4QkE7Ozs7Ozs7Ozs7OztBQVVBNEMsUUFBQUEsU0FBUyxDQUFDNUIsZUFBVixHQUE0QixTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUN6RCxjQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osaUJBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILFNBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBd0MsUUFBQUEsU0FBUyxDQUFDM0IsTUFBVixHQUFtQixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDeEMsY0FBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osY0FBSUEsT0FBTyxDQUFDNkMsUUFBUixJQUFvQixJQUFwQixJQUE0QjdDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDNkMsUUFBZixLQUE0QixRQUFoQyxFQUNJLE9BQU8sMkJBQVA7QUFDUixjQUFJN0MsT0FBTyxDQUFDOEMsUUFBUixJQUFvQixJQUFwQixJQUE0QjlDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDOEMsUUFBZixLQUE0QixRQUFoQyxFQUNJLE9BQU8sMkJBQVA7QUFDUixjQUFJOUMsT0FBTyxDQUFDK0MsTUFBUixJQUFrQixJQUFsQixJQUEwQi9DLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDK0MsTUFBZixLQUEwQixRQUE5QixFQUNJLE9BQU8seUJBQVA7QUFDUixjQUFJL0MsT0FBTyxDQUFDZ0QsTUFBUixJQUFrQixJQUFsQixJQUEwQmhELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixRQUF2QixDQUE5QixFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDZ0QsTUFBZixLQUEwQixRQUE5QixFQUNJLE9BQU8seUJBQVA7QUFDUixjQUFJaEQsT0FBTyxDQUFDaUQsU0FBUixJQUFxQixJQUFyQixJQUE2QmpELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixXQUF2QixDQUFqQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNpRCxTQUF4QixDQUFELElBQXVDLEVBQUVqRCxPQUFPLENBQUNpRCxTQUFSLElBQXFCcEUsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JJLEdBQWxDLENBQXJCLElBQStEeEUsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JLLElBQWxDLENBQWpFLENBQTNDLEVBQ0ksT0FBTyxrQ0FBUDtBQUNSLGlCQUFPLElBQVA7QUFDSCxTQW5CRDtBQXFCQTs7Ozs7Ozs7OztBQVFBVixRQUFBQSxTQUFTLENBQUN4QixVQUFWLEdBQXVCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQy9DLGNBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVOEMsbUJBQVYsQ0FBOEJHLFFBQTlCLENBQXVDVSxTQUE3RCxFQUNJLE9BQU92QixNQUFQO0FBQ0osY0FBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVU4QyxtQkFBVixDQUE4QkcsUUFBOUIsQ0FBdUNVLFNBQTNDLEVBQWQ7QUFDQSxjQUFJdkIsTUFBTSxDQUFDd0IsUUFBUCxJQUFtQixJQUF2QixFQUNJN0MsT0FBTyxDQUFDNkMsUUFBUixHQUFtQlUsTUFBTSxDQUFDbEMsTUFBTSxDQUFDd0IsUUFBUixDQUF6QjtBQUNKLGNBQUl4QixNQUFNLENBQUN5QixRQUFQLElBQW1CLElBQXZCLEVBQ0k5QyxPQUFPLENBQUM4QyxRQUFSLEdBQW1CUyxNQUFNLENBQUNsQyxNQUFNLENBQUN5QixRQUFSLENBQXpCO0FBQ0osY0FBSXpCLE1BQU0sQ0FBQzBCLE1BQVAsSUFBaUIsSUFBckIsRUFDSS9DLE9BQU8sQ0FBQytDLE1BQVIsR0FBaUJRLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQzBCLE1BQVIsQ0FBdkI7QUFDSixjQUFJMUIsTUFBTSxDQUFDMkIsTUFBUCxJQUFpQixJQUFyQixFQUNJaEQsT0FBTyxDQUFDZ0QsTUFBUixHQUFpQk8sTUFBTSxDQUFDbEMsTUFBTSxDQUFDMkIsTUFBUixDQUF2QjtBQUNKLGNBQUkzQixNQUFNLENBQUM0QixTQUFQLElBQW9CLElBQXhCLEVBQ0ksSUFBSXBFLEtBQUssQ0FBQ3FFLElBQVYsRUFDSSxDQUFDbEQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQnBFLEtBQUssQ0FBQ3FFLElBQU4sQ0FBV00sU0FBWCxDQUFxQm5DLE1BQU0sQ0FBQzRCLFNBQTVCLENBQXJCLEVBQTZEUSxRQUE3RCxHQUF3RSxJQUF4RSxDQURKLEtBRUssSUFBSSxPQUFPcEMsTUFBTSxDQUFDNEIsU0FBZCxLQUE0QixRQUFoQyxFQUNEakQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQlMsUUFBUSxDQUFDckMsTUFBTSxDQUFDNEIsU0FBUixFQUFtQixFQUFuQixDQUE1QixDQURDLEtBRUEsSUFBSSxPQUFPNUIsTUFBTSxDQUFDNEIsU0FBZCxLQUE0QixRQUFoQyxFQUNEakQsT0FBTyxDQUFDaUQsU0FBUixHQUFvQjVCLE1BQU0sQ0FBQzRCLFNBQTNCLENBREMsS0FFQSxJQUFJLE9BQU81QixNQUFNLENBQUM0QixTQUFkLEtBQTRCLFFBQWhDLEVBQ0RqRCxPQUFPLENBQUNpRCxTQUFSLEdBQW9CLElBQUlwRSxLQUFLLENBQUM4RSxRQUFWLENBQW1CdEMsTUFBTSxDQUFDNEIsU0FBUCxDQUFpQkksR0FBakIsS0FBeUIsQ0FBNUMsRUFBK0NoQyxNQUFNLENBQUM0QixTQUFQLENBQWlCSyxJQUFqQixLQUEwQixDQUF6RSxFQUE0RU0sUUFBNUUsQ0FBcUYsSUFBckYsQ0FBcEI7QUFDUixpQkFBTzVELE9BQVA7QUFDSCxTQXRCRDtBQXdCQTs7Ozs7Ozs7Ozs7QUFTQTRDLFFBQUFBLFNBQVMsQ0FBQ3JCLFFBQVYsR0FBcUIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDckQsY0FBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osY0FBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsY0FBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixZQUFBQSxNQUFNLENBQUN3QixRQUFQLEdBQWtCLENBQWxCO0FBQ0F4QixZQUFBQSxNQUFNLENBQUN5QixRQUFQLEdBQWtCLENBQWxCO0FBQ0F6QixZQUFBQSxNQUFNLENBQUMwQixNQUFQLEdBQWdCLENBQWhCO0FBQ0ExQixZQUFBQSxNQUFNLENBQUMyQixNQUFQLEdBQWdCLENBQWhCOztBQUNBLGdCQUFJbkUsS0FBSyxDQUFDcUUsSUFBVixFQUFnQjtBQUNaLGtCQUFJVyxLQUFJLEdBQUcsSUFBSWhGLEtBQUssQ0FBQ3FFLElBQVYsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCLElBQXJCLENBQVg7O0FBQ0E3QixjQUFBQSxNQUFNLENBQUM0QixTQUFQLEdBQW1CekIsT0FBTyxDQUFDc0MsS0FBUixLQUFrQnhDLE1BQWxCLEdBQTJCdUMsS0FBSSxDQUFDRSxRQUFMLEVBQTNCLEdBQTZDdkMsT0FBTyxDQUFDc0MsS0FBUixLQUFrQlAsTUFBbEIsR0FBMkJNLEtBQUksQ0FBQ0QsUUFBTCxFQUEzQixHQUE2Q0MsS0FBN0c7QUFDSCxhQUhELE1BSUl4QyxNQUFNLENBQUM0QixTQUFQLEdBQW1CekIsT0FBTyxDQUFDc0MsS0FBUixLQUFrQnhDLE1BQWxCLEdBQTJCLEdBQTNCLEdBQWlDLENBQXBEO0FBQ1A7O0FBQ0QsY0FBSXRCLE9BQU8sQ0FBQzZDLFFBQVIsSUFBb0IsSUFBcEIsSUFBNEI3QyxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsVUFBdkIsQ0FBaEMsRUFDSW1CLE1BQU0sQ0FBQ3dCLFFBQVAsR0FBa0JyQixPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQzZDLFFBQVQsQ0FBekIsR0FBOEN2QixNQUFNLENBQUN0QixPQUFPLENBQUM2QyxRQUFULENBQXBELEdBQXlFN0MsT0FBTyxDQUFDNkMsUUFBbkc7QUFDSixjQUFJN0MsT0FBTyxDQUFDOEMsUUFBUixJQUFvQixJQUFwQixJQUE0QjlDLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixVQUF2QixDQUFoQyxFQUNJbUIsTUFBTSxDQUFDeUIsUUFBUCxHQUFrQnRCLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDOEMsUUFBVCxDQUF6QixHQUE4Q3hCLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQzhDLFFBQVQsQ0FBcEQsR0FBeUU5QyxPQUFPLENBQUM4QyxRQUFuRztBQUNKLGNBQUk5QyxPQUFPLENBQUMrQyxNQUFSLElBQWtCLElBQWxCLElBQTBCL0MsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFFBQXZCLENBQTlCLEVBQ0ltQixNQUFNLENBQUMwQixNQUFQLEdBQWdCdkIsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUMrQyxNQUFULENBQXpCLEdBQTRDekIsTUFBTSxDQUFDdEIsT0FBTyxDQUFDK0MsTUFBVCxDQUFsRCxHQUFxRS9DLE9BQU8sQ0FBQytDLE1BQTdGO0FBQ0osY0FBSS9DLE9BQU8sQ0FBQ2dELE1BQVIsSUFBa0IsSUFBbEIsSUFBMEJoRCxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsUUFBdkIsQ0FBOUIsRUFDSW1CLE1BQU0sQ0FBQzJCLE1BQVAsR0FBZ0J4QixPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ2dELE1BQVQsQ0FBekIsR0FBNEMxQixNQUFNLENBQUN0QixPQUFPLENBQUNnRCxNQUFULENBQWxELEdBQXFFaEQsT0FBTyxDQUFDZ0QsTUFBN0Y7QUFDSixjQUFJaEQsT0FBTyxDQUFDaUQsU0FBUixJQUFxQixJQUFyQixJQUE2QmpELE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixXQUF2QixDQUFqQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDaUQsU0FBZixLQUE2QixRQUFqQyxFQUNJNUIsTUFBTSxDQUFDNEIsU0FBUCxHQUFtQnpCLE9BQU8sQ0FBQ3NDLEtBQVIsS0FBa0J4QyxNQUFsQixHQUEyQkEsTUFBTSxDQUFDdEIsT0FBTyxDQUFDaUQsU0FBVCxDQUFqQyxHQUF1RGpELE9BQU8sQ0FBQ2lELFNBQWxGLENBREosS0FHSTVCLE1BQU0sQ0FBQzRCLFNBQVAsR0FBbUJ6QixPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ6QyxLQUFLLENBQUNxRSxJQUFOLENBQVd0RCxTQUFYLENBQXFCbUUsUUFBckIsQ0FBOEI1RCxJQUE5QixDQUFtQ0gsT0FBTyxDQUFDaUQsU0FBM0MsQ0FBM0IsR0FBbUZ6QixPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQixJQUFJMUUsS0FBSyxDQUFDOEUsUUFBVixDQUFtQjNELE9BQU8sQ0FBQ2lELFNBQVIsQ0FBa0JJLEdBQWxCLEtBQTBCLENBQTdDLEVBQWdEckQsT0FBTyxDQUFDaUQsU0FBUixDQUFrQkssSUFBbEIsS0FBMkIsQ0FBM0UsRUFBOEVNLFFBQTlFLENBQXVGLElBQXZGLENBQTNCLEdBQTBINUQsT0FBTyxDQUFDaUQsU0FBeE87QUFDUixpQkFBTzVCLE1BQVA7QUFDSCxTQTdCRDtBQStCQTs7Ozs7Ozs7O0FBT0F1QixRQUFBQSxTQUFTLENBQUNoRCxTQUFWLENBQW9COEIsTUFBcEIsR0FBNkIsU0FBU0EsTUFBVCxHQUFrQjtBQUMzQyxpQkFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILFNBRkQ7O0FBSUEsZUFBT2dCLFNBQVA7QUFDSCxPQWhTb0IsRUFBckI7O0FBa1NBLGFBQU9WLFFBQVA7QUFDSCxLQTdnQjhCLEVBQS9COztBQStnQkEsV0FBT0gsbUJBQVA7QUFDSCxHQTd0QnlCLEVBQTFCOztBQSt0QkE5QyxFQUFBQSxHQUFHLENBQUNpRixhQUFKLEdBQXFCLFlBQVc7QUFFNUI7Ozs7Ozs7Ozs7QUFVQTs7Ozs7Ozs7QUFRQSxhQUFTQSxhQUFULENBQXVCMUUsVUFBdkIsRUFBbUM7QUFDL0IsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1Bd0UsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QnVFLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QndFLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7QUFNQUYsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QnlFLFVBQXhCLEdBQXFDLENBQXJDO0FBRUE7Ozs7Ozs7QUFNQUgsSUFBQUEsYUFBYSxDQUFDdEUsU0FBZCxDQUF3QjBFLFVBQXhCLEdBQXFDLENBQXJDO0FBRUE7Ozs7Ozs7OztBQVFBSixJQUFBQSxhQUFhLENBQUM1RSxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQy9DLGFBQU8sSUFBSTBFLGFBQUosQ0FBa0IxRSxVQUFsQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBMEUsSUFBQUEsYUFBYSxDQUFDbkUsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDcEQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQzlFLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNtRSxZQUF2RDtBQUNKLFVBQUluRSxPQUFPLENBQUNvRSxZQUFSLElBQXdCLElBQXhCLElBQWdDL0UsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsY0FBcEMsQ0FBcEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQ29FLFlBQXZEO0FBQ0osVUFBSXBFLE9BQU8sQ0FBQ3FFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJoRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDcUUsVUFBdkQ7QUFDSixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QmpGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNzRSxVQUF2RDtBQUNKLGFBQU9yRSxNQUFQO0FBQ0gsS0FaRDtBQWNBOzs7Ozs7Ozs7OztBQVNBaUUsSUFBQUEsYUFBYSxDQUFDNUQsZUFBZCxHQUFnQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDdEUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0EyRCxJQUFBQSxhQUFhLENBQUMxRCxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNuRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVVpRixhQUFkLEVBQTdFOztBQUNBLGFBQU96RCxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ21FLFlBQVIsR0FBdUIxRCxNQUFNLFNBQU4sRUFBdkI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDb0UsWUFBUixHQUF1QjNELE1BQU0sU0FBTixFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUNxRSxVQUFSLEdBQXFCNUQsTUFBTSxTQUFOLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lULFlBQUFBLE9BQU8sQ0FBQ3NFLFVBQVIsR0FBcUI3RCxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSjtBQUNJQSxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBZko7QUFpQkg7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBekJEO0FBMkJBOzs7Ozs7Ozs7Ozs7QUFVQWtFLElBQUFBLGFBQWEsQ0FBQ2xELGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDN0QsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBOEQsSUFBQUEsYUFBYSxDQUFDakQsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDNUMsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQ25FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDbUUsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDb0UsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJcEUsT0FBTyxDQUFDcUUsVUFBUixJQUFzQixJQUF0QixJQUE4QnJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDcUUsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnRFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDc0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQWhCRDtBQWtCQTs7Ozs7Ozs7OztBQVFBSixJQUFBQSxhQUFhLENBQUM5QyxVQUFkLEdBQTJCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ25ELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVaUYsYUFBaEMsRUFDSSxPQUFPN0MsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVaUYsYUFBZCxFQUFkO0FBQ0EsVUFBSTdDLE1BQU0sQ0FBQzhDLFlBQVAsSUFBdUIsSUFBM0IsRUFDSW5FLE9BQU8sQ0FBQ21FLFlBQVIsR0FBdUJaLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQzhDLFlBQVIsQ0FBN0I7QUFDSixVQUFJOUMsTUFBTSxDQUFDK0MsWUFBUCxJQUF1QixJQUEzQixFQUNJcEUsT0FBTyxDQUFDb0UsWUFBUixHQUF1QmIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDK0MsWUFBUixDQUE3QjtBQUNKLFVBQUkvQyxNQUFNLENBQUNnRCxVQUFQLElBQXFCLElBQXpCLEVBQ0lyRSxPQUFPLENBQUNxRSxVQUFSLEdBQXFCZCxNQUFNLENBQUNsQyxNQUFNLENBQUNnRCxVQUFSLENBQTNCO0FBQ0osVUFBSWhELE1BQU0sQ0FBQ2lELFVBQVAsSUFBcUIsSUFBekIsRUFDSXRFLE9BQU8sQ0FBQ3NFLFVBQVIsR0FBcUJmLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQ2lELFVBQVIsQ0FBM0I7QUFDSixhQUFPdEUsT0FBUDtBQUNILEtBYkQ7QUFlQTs7Ozs7Ozs7Ozs7QUFTQWtFLElBQUFBLGFBQWEsQ0FBQzNDLFFBQWQsR0FBeUIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDekQsVUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osVUFBSUgsTUFBTSxHQUFHLEVBQWI7O0FBQ0EsVUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQXNCO0FBQ2xCSixRQUFBQSxNQUFNLENBQUM4QyxZQUFQLEdBQXNCLENBQXRCO0FBQ0E5QyxRQUFBQSxNQUFNLENBQUMrQyxZQUFQLEdBQXNCLENBQXRCO0FBQ0EvQyxRQUFBQSxNQUFNLENBQUNnRCxVQUFQLEdBQW9CLENBQXBCO0FBQ0FoRCxRQUFBQSxNQUFNLENBQUNpRCxVQUFQLEdBQW9CLENBQXBCO0FBQ0g7O0FBQ0QsVUFBSXRFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NuRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzhDLFlBQVAsR0FBc0IzQyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ21FLFlBQVQsQ0FBekIsR0FBa0Q3QyxNQUFNLENBQUN0QixPQUFPLENBQUNtRSxZQUFULENBQXhELEdBQWlGbkUsT0FBTyxDQUFDbUUsWUFBL0c7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQjVDLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDb0UsWUFBVCxDQUF6QixHQUFrRDlDLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ29FLFlBQVQsQ0FBeEQsR0FBaUZwRSxPQUFPLENBQUNvRSxZQUEvRztBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCckUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNnRCxVQUFQLEdBQW9CN0MsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUNxRSxVQUFULENBQXpCLEdBQWdEL0MsTUFBTSxDQUFDdEIsT0FBTyxDQUFDcUUsVUFBVCxDQUF0RCxHQUE2RXJFLE9BQU8sQ0FBQ3FFLFVBQXpHO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lELFVBQVAsR0FBb0I5QyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ3NFLFVBQVQsQ0FBekIsR0FBZ0RoRCxNQUFNLENBQUN0QixPQUFPLENBQUNzRSxVQUFULENBQXRELEdBQTZFdEUsT0FBTyxDQUFDc0UsVUFBekc7QUFDSixhQUFPakQsTUFBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7QUFPQTZDLElBQUFBLGFBQWEsQ0FBQ3RFLFNBQWQsQ0FBd0I4QixNQUF4QixHQUFpQyxTQUFTQSxNQUFULEdBQWtCO0FBQy9DLGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU9zQyxhQUFQO0FBQ0gsR0E1UG1CLEVBQXBCOztBQThQQWpGLEVBQUFBLEdBQUcsQ0FBQ3NGLGdCQUFKLEdBQXdCLFlBQVc7QUFFL0I7Ozs7Ozs7Ozs7OztBQVlBOzs7Ozs7OztBQVFBLGFBQVNBLGdCQUFULENBQTBCL0UsVUFBMUIsRUFBc0M7QUFDbEMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BNkUsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjRFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQnVFLFlBQTNCLEdBQTBDLENBQTFDO0FBRUE7Ozs7Ozs7QUFNQUksSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQndFLFlBQTNCLEdBQTBDLENBQTFDO0FBRUE7Ozs7Ozs7QUFNQUcsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQnlFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUUsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjBFLFVBQTNCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7QUFNQUMsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjZFLGFBQTNCLEdBQTJDNUYsS0FBSyxDQUFDcUUsSUFBTixHQUFhckUsS0FBSyxDQUFDcUUsSUFBTixDQUFXQyxRQUFYLENBQW9CLENBQXBCLEVBQXNCLENBQXRCLEVBQXdCLElBQXhCLENBQWIsR0FBNkMsQ0FBeEY7QUFFQTs7Ozs7Ozs7O0FBUUFvQixJQUFBQSxnQkFBZ0IsQ0FBQ2pGLE1BQWpCLEdBQTBCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2xELGFBQU8sSUFBSStFLGdCQUFKLENBQXFCL0UsVUFBckIsQ0FBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQStFLElBQUFBLGdCQUFnQixDQUFDeEUsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ3ZELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ3dFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJuRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixPQUFyQyxFQUF3Q0EsTUFBeEMsQ0FBK0NKLE9BQU8sQ0FBQ3dFLFVBQXZEO0FBQ0osVUFBSXhFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0M5RSxNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxjQUFwQyxDQUFwQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDbUUsWUFBdkQ7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQy9FLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLFdBQStDSixPQUFPLENBQUNvRSxZQUF2RDtBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCaEYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQ3FFLFVBQXZEO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJqRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDc0UsVUFBdkQ7QUFDSixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3BGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGVBQXBDLENBQXJDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDZ0QsTUFBekMsQ0FBZ0RwRCxPQUFPLENBQUN5RSxhQUF4RDtBQUNKLGFBQU94RSxNQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7Ozs7O0FBU0FzRSxJQUFBQSxnQkFBZ0IsQ0FBQ2pFLGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUN6RSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQWdFLElBQUFBLGdCQUFnQixDQUFDL0QsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ3RELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVXNGLGdCQUFkLEVBQTdFOztBQUNBLGFBQU85RCxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQ3dFLFVBQVIsR0FBcUIvRCxNQUFNLENBQUNMLE1BQVAsRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSUosWUFBQUEsT0FBTyxDQUFDbUUsWUFBUixHQUF1QjFELE1BQU0sU0FBTixFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUNvRSxZQUFSLEdBQXVCM0QsTUFBTSxTQUFOLEVBQXZCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lULFlBQUFBLE9BQU8sQ0FBQ3FFLFVBQVIsR0FBcUI1RCxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDc0UsVUFBUixHQUFxQjdELE1BQU0sU0FBTixFQUFyQjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJVCxZQUFBQSxPQUFPLENBQUN5RSxhQUFSLEdBQXdCaEUsTUFBTSxDQUFDMkMsTUFBUCxFQUF4QjtBQUNBOztBQUNKO0FBQ0kzQyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBckJKO0FBdUJIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQS9CRDtBQWlDQTs7Ozs7Ozs7Ozs7O0FBVUF1RSxJQUFBQSxnQkFBZ0IsQ0FBQ3ZELGVBQWpCLEdBQW1DLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQ2hFLFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQW1FLElBQUFBLGdCQUFnQixDQUFDdEQsTUFBakIsR0FBMEIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQy9DLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ3dFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ4RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDd0UsVUFBeEIsQ0FBTCxFQUNJLE9BQU8sOEJBQVA7QUFDUixVQUFJeEUsT0FBTyxDQUFDbUUsWUFBUixJQUF3QixJQUF4QixJQUFnQ25FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDbUUsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDb0UsWUFBZixLQUFnQyxRQUFwQyxFQUNJLE9BQU8sK0JBQVA7QUFDUixVQUFJcEUsT0FBTyxDQUFDcUUsVUFBUixJQUFzQixJQUF0QixJQUE4QnJFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDcUUsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJckUsT0FBTyxDQUFDc0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnRFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDc0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3pFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixlQUF2QixDQUFyQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUN5RSxhQUF4QixDQUFELElBQTJDLEVBQUV6RSxPQUFPLENBQUN5RSxhQUFSLElBQXlCNUYsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JwQixHQUF0QyxDQUF6QixJQUF1RXhFLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUN5RSxhQUFSLENBQXNCbkIsSUFBdEMsQ0FBekUsQ0FBL0MsRUFDSSxPQUFPLHNDQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0F0QkQ7QUF3QkE7Ozs7Ozs7Ozs7QUFRQWlCLElBQUFBLGdCQUFnQixDQUFDbkQsVUFBakIsR0FBOEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDdEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVVzRixnQkFBaEMsRUFDSSxPQUFPbEQsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0YsZ0JBQWQsRUFBZDtBQUNBLFVBQUlsRCxNQUFNLENBQUNtRCxVQUFQLElBQXFCLElBQXpCLEVBQ0l4RSxPQUFPLENBQUN3RSxVQUFSLEdBQXFCbkQsTUFBTSxDQUFDbUQsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUluRCxNQUFNLENBQUM4QyxZQUFQLElBQXVCLElBQTNCLEVBQ0luRSxPQUFPLENBQUNtRSxZQUFSLEdBQXVCWixNQUFNLENBQUNsQyxNQUFNLENBQUM4QyxZQUFSLENBQTdCO0FBQ0osVUFBSTlDLE1BQU0sQ0FBQytDLFlBQVAsSUFBdUIsSUFBM0IsRUFDSXBFLE9BQU8sQ0FBQ29FLFlBQVIsR0FBdUJiLE1BQU0sQ0FBQ2xDLE1BQU0sQ0FBQytDLFlBQVIsQ0FBN0I7QUFDSixVQUFJL0MsTUFBTSxDQUFDZ0QsVUFBUCxJQUFxQixJQUF6QixFQUNJckUsT0FBTyxDQUFDcUUsVUFBUixHQUFxQmQsTUFBTSxDQUFDbEMsTUFBTSxDQUFDZ0QsVUFBUixDQUEzQjtBQUNKLFVBQUloRCxNQUFNLENBQUNpRCxVQUFQLElBQXFCLElBQXpCLEVBQ0l0RSxPQUFPLENBQUNzRSxVQUFSLEdBQXFCZixNQUFNLENBQUNsQyxNQUFNLENBQUNpRCxVQUFSLENBQTNCO0FBQ0osVUFBSWpELE1BQU0sQ0FBQ29ELGFBQVAsSUFBd0IsSUFBNUIsRUFDSSxJQUFJNUYsS0FBSyxDQUFDcUUsSUFBVixFQUNJLENBQUNsRCxPQUFPLENBQUN5RSxhQUFSLEdBQXdCNUYsS0FBSyxDQUFDcUUsSUFBTixDQUFXTSxTQUFYLENBQXFCbkMsTUFBTSxDQUFDb0QsYUFBNUIsQ0FBekIsRUFBcUVoQixRQUFyRSxHQUFnRixJQUFoRixDQURKLEtBRUssSUFBSSxPQUFPcEMsTUFBTSxDQUFDb0QsYUFBZCxLQUFnQyxRQUFwQyxFQUNEekUsT0FBTyxDQUFDeUUsYUFBUixHQUF3QmYsUUFBUSxDQUFDckMsTUFBTSxDQUFDb0QsYUFBUixFQUF1QixFQUF2QixDQUFoQyxDQURDLEtBRUEsSUFBSSxPQUFPcEQsTUFBTSxDQUFDb0QsYUFBZCxLQUFnQyxRQUFwQyxFQUNEekUsT0FBTyxDQUFDeUUsYUFBUixHQUF3QnBELE1BQU0sQ0FBQ29ELGFBQS9CLENBREMsS0FFQSxJQUFJLE9BQU9wRCxNQUFNLENBQUNvRCxhQUFkLEtBQWdDLFFBQXBDLEVBQ0R6RSxPQUFPLENBQUN5RSxhQUFSLEdBQXdCLElBQUk1RixLQUFLLENBQUM4RSxRQUFWLENBQW1CdEMsTUFBTSxDQUFDb0QsYUFBUCxDQUFxQnBCLEdBQXJCLEtBQTZCLENBQWhELEVBQW1EaEMsTUFBTSxDQUFDb0QsYUFBUCxDQUFxQm5CLElBQXJCLEtBQThCLENBQWpGLEVBQW9GTSxRQUFwRixDQUE2RixJQUE3RixDQUF4QjtBQUNSLGFBQU81RCxPQUFQO0FBQ0gsS0F4QkQ7QUEwQkE7Ozs7Ozs7Ozs7O0FBU0F1RSxJQUFBQSxnQkFBZ0IsQ0FBQ2hELFFBQWpCLEdBQTRCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQzVELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiOztBQUNBLFVBQUlHLE9BQU8sQ0FBQ0MsUUFBWixFQUFzQjtBQUNsQkosUUFBQUEsTUFBTSxDQUFDbUQsVUFBUCxHQUFvQixDQUFwQjtBQUNBbkQsUUFBQUEsTUFBTSxDQUFDOEMsWUFBUCxHQUFzQixDQUF0QjtBQUNBOUMsUUFBQUEsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQixDQUF0QjtBQUNBL0MsUUFBQUEsTUFBTSxDQUFDZ0QsVUFBUCxHQUFvQixDQUFwQjtBQUNBaEQsUUFBQUEsTUFBTSxDQUFDaUQsVUFBUCxHQUFvQixDQUFwQjs7QUFDQSxZQUFJekYsS0FBSyxDQUFDcUUsSUFBVixFQUFnQjtBQUNaLGNBQUlXLE1BQUksR0FBRyxJQUFJaEYsS0FBSyxDQUFDcUUsSUFBVixDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUIsSUFBckIsQ0FBWDs7QUFDQTdCLFVBQUFBLE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ1QyxNQUFJLENBQUNFLFFBQUwsRUFBM0IsR0FBNkN2QyxPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQk0sTUFBSSxDQUFDRCxRQUFMLEVBQTNCLEdBQTZDQyxNQUFqSDtBQUNILFNBSEQsTUFJSXhDLE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkIsR0FBM0IsR0FBaUMsQ0FBeEQ7QUFDUDs7QUFDRCxVQUFJdEIsT0FBTyxDQUFDd0UsVUFBUixJQUFzQixJQUF0QixJQUE4QnhFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDbUQsVUFBUCxHQUFvQnhFLE9BQU8sQ0FBQ3dFLFVBQTVCO0FBQ0osVUFBSXhFLE9BQU8sQ0FBQ21FLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NuRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzhDLFlBQVAsR0FBc0IzQyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ21FLFlBQVQsQ0FBekIsR0FBa0Q3QyxNQUFNLENBQUN0QixPQUFPLENBQUNtRSxZQUFULENBQXhELEdBQWlGbkUsT0FBTyxDQUFDbUUsWUFBL0c7QUFDSixVQUFJbkUsT0FBTyxDQUFDb0UsWUFBUixJQUF3QixJQUF4QixJQUFnQ3BFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDK0MsWUFBUCxHQUFzQjVDLE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDb0UsWUFBVCxDQUF6QixHQUFrRDlDLE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ29FLFlBQVQsQ0FBeEQsR0FBaUZwRSxPQUFPLENBQUNvRSxZQUEvRztBQUNKLFVBQUlwRSxPQUFPLENBQUNxRSxVQUFSLElBQXNCLElBQXRCLElBQThCckUsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNnRCxVQUFQLEdBQW9CN0MsT0FBTyxDQUFDd0MsSUFBUixJQUFnQixDQUFDQyxRQUFRLENBQUNqRSxPQUFPLENBQUNxRSxVQUFULENBQXpCLEdBQWdEL0MsTUFBTSxDQUFDdEIsT0FBTyxDQUFDcUUsVUFBVCxDQUF0RCxHQUE2RXJFLE9BQU8sQ0FBQ3FFLFVBQXpHO0FBQ0osVUFBSXJFLE9BQU8sQ0FBQ3NFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lELFVBQVAsR0FBb0I5QyxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQ3NFLFVBQVQsQ0FBekIsR0FBZ0RoRCxNQUFNLENBQUN0QixPQUFPLENBQUNzRSxVQUFULENBQXRELEdBQTZFdEUsT0FBTyxDQUFDc0UsVUFBekc7QUFDSixVQUFJdEUsT0FBTyxDQUFDeUUsYUFBUixJQUF5QixJQUF6QixJQUFpQ3pFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixlQUF2QixDQUFyQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDeUUsYUFBZixLQUFpQyxRQUFyQyxFQUNJcEQsTUFBTSxDQUFDb0QsYUFBUCxHQUF1QmpELE9BQU8sQ0FBQ3NDLEtBQVIsS0FBa0J4QyxNQUFsQixHQUEyQkEsTUFBTSxDQUFDdEIsT0FBTyxDQUFDeUUsYUFBVCxDQUFqQyxHQUEyRHpFLE9BQU8sQ0FBQ3lFLGFBQTFGLENBREosS0FHSXBELE1BQU0sQ0FBQ29ELGFBQVAsR0FBdUJqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCeEMsTUFBbEIsR0FBMkJ6QyxLQUFLLENBQUNxRSxJQUFOLENBQVd0RCxTQUFYLENBQXFCbUUsUUFBckIsQ0FBOEI1RCxJQUE5QixDQUFtQ0gsT0FBTyxDQUFDeUUsYUFBM0MsQ0FBM0IsR0FBdUZqRCxPQUFPLENBQUNzQyxLQUFSLEtBQWtCUCxNQUFsQixHQUEyQixJQUFJMUUsS0FBSyxDQUFDOEUsUUFBVixDQUFtQjNELE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JwQixHQUF0QixLQUE4QixDQUFqRCxFQUFvRHJELE9BQU8sQ0FBQ3lFLGFBQVIsQ0FBc0JuQixJQUF0QixLQUErQixDQUFuRixFQUFzRk0sUUFBdEYsQ0FBK0YsSUFBL0YsQ0FBM0IsR0FBa0k1RCxPQUFPLENBQUN5RSxhQUF4UDtBQUNSLGFBQU9wRCxNQUFQO0FBQ0gsS0FoQ0Q7QUFrQ0E7Ozs7Ozs7OztBQU9Ba0QsSUFBQUEsZ0JBQWdCLENBQUMzRSxTQUFqQixDQUEyQjhCLE1BQTNCLEdBQW9DLFNBQVNBLE1BQVQsR0FBa0I7QUFDbEQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBTzJDLGdCQUFQO0FBQ0gsR0F0VHNCLEVBQXZCOztBQXdUQXRGLEVBQUFBLEdBQUcsQ0FBQ3lGLGNBQUosR0FBc0IsWUFBVztBQUU3Qjs7Ozs7OztBQU9BOzs7Ozs7OztBQVFBLGFBQVNBLGNBQVQsQ0FBd0JsRixVQUF4QixFQUFvQztBQUNoQyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFnRixJQUFBQSxjQUFjLENBQUM5RSxTQUFmLENBQXlCK0UsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7Ozs7O0FBUUFELElBQUFBLGNBQWMsQ0FBQ3BGLE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDaEQsYUFBTyxJQUFJa0YsY0FBSixDQUFtQmxGLFVBQW5CLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FrRixJQUFBQSxjQUFjLENBQUMzRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNyRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCdEYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUMyRSxVQUF2RDtBQUNKLGFBQU8xRSxNQUFQO0FBQ0gsS0FORDtBQVFBOzs7Ozs7Ozs7OztBQVNBeUUsSUFBQUEsY0FBYyxDQUFDcEUsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDdkUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0FtRSxJQUFBQSxjQUFjLENBQUNsRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNwRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFkLEVBQTdFOztBQUNBLGFBQU9qRSxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0EsZUFBSyxDQUFMO0FBQ0lkLFlBQUFBLE9BQU8sQ0FBQzJFLFVBQVIsR0FBcUJsRSxNQUFNLENBQUNMLE1BQVAsRUFBckI7QUFDQTs7QUFDSjtBQUNJSyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBTko7QUFRSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7Ozs7OztBQVVBMEUsSUFBQUEsY0FBYyxDQUFDMUQsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM5RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUFzRSxJQUFBQSxjQUFjLENBQUN6RCxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM3QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCM0UsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQzJFLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FQRDtBQVNBOzs7Ozs7Ozs7O0FBUUFELElBQUFBLGNBQWMsQ0FBQ3RELFVBQWYsR0FBNEIsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDcEQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFoQyxFQUNJLE9BQU9yRCxNQUFQO0FBQ0osVUFBSXJCLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVV5RixjQUFkLEVBQWQ7QUFDQSxVQUFJckQsTUFBTSxDQUFDc0QsVUFBUCxJQUFxQixJQUF6QixFQUNJM0UsT0FBTyxDQUFDMkUsVUFBUixHQUFxQnRELE1BQU0sQ0FBQ3NELFVBQVAsS0FBc0IsQ0FBM0M7QUFDSixhQUFPM0UsT0FBUDtBQUNILEtBUEQ7QUFTQTs7Ozs7Ozs7Ozs7QUFTQTBFLElBQUFBLGNBQWMsQ0FBQ25ELFFBQWYsR0FBMEIsU0FBU0EsUUFBVCxDQUFrQnZCLE9BQWxCLEVBQTJCd0IsT0FBM0IsRUFBb0M7QUFDMUQsVUFBSSxDQUFDQSxPQUFMLEVBQ0lBLE9BQU8sR0FBRyxFQUFWO0FBQ0osVUFBSUgsTUFBTSxHQUFHLEVBQWI7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFDSUosTUFBTSxDQUFDc0QsVUFBUCxHQUFvQixDQUFwQjtBQUNKLFVBQUkzRSxPQUFPLENBQUMyRSxVQUFSLElBQXNCLElBQXRCLElBQThCM0UsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ltQixNQUFNLENBQUNzRCxVQUFQLEdBQW9CM0UsT0FBTyxDQUFDMkUsVUFBNUI7QUFDSixhQUFPdEQsTUFBUDtBQUNILEtBVEQ7QUFXQTs7Ozs7Ozs7O0FBT0FxRCxJQUFBQSxjQUFjLENBQUM5RSxTQUFmLENBQXlCOEIsTUFBekIsR0FBa0MsU0FBU0EsTUFBVCxHQUFrQjtBQUNoRCxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPOEMsY0FBUDtBQUNILEdBekxvQixFQUFyQjs7QUEyTEF6RixFQUFBQSxHQUFHLENBQUMyRixXQUFKLEdBQW1CLFlBQVc7QUFFMUI7Ozs7OztBQU1BOzs7Ozs7OztBQVFBLGFBQVNBLFdBQVQsQ0FBcUJwRixVQUFyQixFQUFpQztBQUM3QixVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7Ozs7QUFRQWtGLElBQUFBLFdBQVcsQ0FBQ3RGLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDN0MsYUFBTyxJQUFJb0YsV0FBSixDQUFnQnBGLFVBQWhCLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FvRixJQUFBQSxXQUFXLENBQUM3RSxNQUFaLEdBQXFCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNsRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixhQUFPVyxNQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7OztBQVNBMkUsSUFBQUEsV0FBVyxDQUFDdEUsZUFBWixHQUE4QixTQUFTQSxlQUFULENBQXlCTixPQUF6QixFQUFrQ0MsTUFBbEMsRUFBMEM7QUFDcEUsYUFBTyxLQUFLRixNQUFMLENBQVlDLE9BQVosRUFBcUJDLE1BQXJCLEVBQTZCTSxNQUE3QixFQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7Ozs7O0FBV0FxRSxJQUFBQSxXQUFXLENBQUNwRSxNQUFaLEdBQXFCLFNBQVNBLE1BQVQsQ0FBZ0JDLE1BQWhCLEVBQXdCZCxNQUF4QixFQUFnQztBQUNqRCxVQUFJLEVBQUVjLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBR2hDLE9BQU8sQ0FBQ2EsTUFBUixDQUFlbUIsTUFBZixDQUFUO0FBQ0osVUFBSUMsR0FBRyxHQUFHZixNQUFNLEtBQUtnQixTQUFYLEdBQXVCRixNQUFNLENBQUNHLEdBQTlCLEdBQW9DSCxNQUFNLENBQUNJLEdBQVAsR0FBYWxCLE1BQTNEO0FBQUEsVUFBbUVLLE9BQU8sR0FBRyxJQUFJakIsS0FBSyxDQUFDRSxHQUFOLENBQVUyRixXQUFkLEVBQTdFOztBQUNBLGFBQU9uRSxNQUFNLENBQUNJLEdBQVAsR0FBYUgsR0FBcEIsRUFBeUI7QUFDckIsWUFBSUksR0FBRyxHQUFHTCxNQUFNLENBQUNMLE1BQVAsRUFBVjs7QUFDQSxnQkFBUVUsR0FBRyxLQUFLLENBQWhCO0FBQ0E7QUFDSUwsWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQUhKO0FBS0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBYkQ7QUFlQTs7Ozs7Ozs7Ozs7O0FBVUE0RSxJQUFBQSxXQUFXLENBQUM1RCxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzNELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQXdFLElBQUFBLFdBQVcsQ0FBQzNELE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzFDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLGFBQU8sSUFBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBNEUsSUFBQUEsV0FBVyxDQUFDeEQsVUFBWixHQUF5QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNqRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTJGLFdBQWhDLEVBQ0ksT0FBT3ZELE1BQVA7QUFDSixhQUFPLElBQUl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTJGLFdBQWQsRUFBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7Ozs7QUFTQUEsSUFBQUEsV0FBVyxDQUFDckQsUUFBWixHQUF1QixTQUFTQSxRQUFULEdBQW9CO0FBQ3ZDLGFBQU8sRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7O0FBT0FxRCxJQUFBQSxXQUFXLENBQUNoRixTQUFaLENBQXNCOEIsTUFBdEIsR0FBK0IsU0FBU0EsTUFBVCxHQUFrQjtBQUM3QyxhQUFPLEtBQUtDLFdBQUwsQ0FBaUJKLFFBQWpCLENBQTBCLElBQTFCLEVBQWdDaEQsU0FBUyxDQUFDTyxJQUFWLENBQWU4QyxhQUEvQyxDQUFQO0FBQ0gsS0FGRDs7QUFJQSxXQUFPZ0QsV0FBUDtBQUNILEdBOUppQixFQUFsQjs7QUFnS0EzRixFQUFBQSxHQUFHLENBQUM0RixjQUFKLEdBQXNCLFlBQVc7QUFFN0I7Ozs7Ozs7OztBQVNBOzs7Ozs7OztBQVFBLGFBQVNBLGNBQVQsQ0FBd0JyRixVQUF4QixFQUFvQztBQUNoQyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUFtRixJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCa0YsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7OztBQU1BRCxJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCbUYsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7OztBQU1BRixJQUFBQSxjQUFjLENBQUNqRixTQUFmLENBQXlCb0YsVUFBekIsR0FBc0MsQ0FBdEM7QUFFQTs7Ozs7Ozs7O0FBUUFILElBQUFBLGNBQWMsQ0FBQ3ZGLE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDaEQsYUFBTyxJQUFJcUYsY0FBSixDQUFtQnJGLFVBQW5CLENBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7O0FBU0FxRixJQUFBQSxjQUFjLENBQUM5RSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JDLE9BQWhCLEVBQXlCQyxNQUF6QixFQUFpQztBQUNyRCxVQUFJLENBQUNBLE1BQUwsRUFDSUEsTUFBTSxHQUFHdEIsT0FBTyxDQUFDVyxNQUFSLEVBQVQ7QUFDSixVQUFJVSxPQUFPLENBQUM4RSxVQUFSLElBQXNCLElBQXRCLElBQThCekYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsT0FBckMsRUFBd0NBLE1BQXhDLENBQStDSixPQUFPLENBQUM4RSxVQUF2RDtBQUNKLFVBQUk5RSxPQUFPLENBQUMrRSxVQUFSLElBQXNCLElBQXRCLElBQThCMUYsTUFBTSxDQUFDYSxjQUFQLENBQXNCQyxJQUF0QixDQUEyQkgsT0FBM0IsRUFBb0MsWUFBcEMsQ0FBbEMsRUFDSUMsTUFBTSxDQUFDRyxNQUFQO0FBQWM7QUFBdUIsUUFBckMsV0FBK0NKLE9BQU8sQ0FBQytFLFVBQXZEO0FBQ0osVUFBSS9FLE9BQU8sQ0FBQ2dGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEIzRixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxZQUFwQyxDQUFsQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixRQUFyQyxXQUErQ0osT0FBTyxDQUFDZ0YsVUFBdkQ7QUFDSixhQUFPL0UsTUFBUDtBQUNILEtBVkQ7QUFZQTs7Ozs7Ozs7Ozs7QUFTQTRFLElBQUFBLGNBQWMsQ0FBQ3ZFLGVBQWYsR0FBaUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3ZFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBc0UsSUFBQUEsY0FBYyxDQUFDckUsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDcEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVNEYsY0FBZCxFQUE3RTs7QUFDQSxhQUFPcEUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUM4RSxVQUFSLEdBQXFCckUsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQytFLFVBQVIsR0FBcUJ0RSxNQUFNLFNBQU4sRUFBckI7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSVQsWUFBQUEsT0FBTyxDQUFDZ0YsVUFBUixHQUFxQnZFLE1BQU0sU0FBTixFQUFyQjtBQUNBOztBQUNKO0FBQ0lBLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFaSjtBQWNIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQXRCRDtBQXdCQTs7Ozs7Ozs7Ozs7O0FBVUE2RSxJQUFBQSxjQUFjLENBQUM3RCxlQUFmLEdBQWlDLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzlELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQXlFLElBQUFBLGNBQWMsQ0FBQzVELE1BQWYsR0FBd0IsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzdDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQzhFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEI5RSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDOEUsVUFBeEIsQ0FBTCxFQUNJLE9BQU8sOEJBQVA7QUFDUixVQUFJOUUsT0FBTyxDQUFDK0UsVUFBUixJQUFzQixJQUF0QixJQUE4Qi9FLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDK0UsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixVQUFJL0UsT0FBTyxDQUFDZ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmhGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJLElBQUksT0FBT0YsT0FBTyxDQUFDZ0YsVUFBZixLQUE4QixRQUFsQyxFQUNJLE9BQU8sNkJBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQWJEO0FBZUE7Ozs7Ozs7Ozs7QUFRQUgsSUFBQUEsY0FBYyxDQUFDekQsVUFBZixHQUE0QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNwRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVTRGLGNBQWhDLEVBQ0ksT0FBT3hELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVTRGLGNBQWQsRUFBZDtBQUNBLFVBQUl4RCxNQUFNLENBQUN5RCxVQUFQLElBQXFCLElBQXpCLEVBQ0k5RSxPQUFPLENBQUM4RSxVQUFSLEdBQXFCekQsTUFBTSxDQUFDeUQsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUl6RCxNQUFNLENBQUMwRCxVQUFQLElBQXFCLElBQXpCLEVBQ0kvRSxPQUFPLENBQUMrRSxVQUFSLEdBQXFCeEIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDMEQsVUFBUixDQUEzQjtBQUNKLFVBQUkxRCxNQUFNLENBQUMyRCxVQUFQLElBQXFCLElBQXpCLEVBQ0loRixPQUFPLENBQUNnRixVQUFSLEdBQXFCekIsTUFBTSxDQUFDbEMsTUFBTSxDQUFDMkQsVUFBUixDQUEzQjtBQUNKLGFBQU9oRixPQUFQO0FBQ0gsS0FYRDtBQWFBOzs7Ozs7Ozs7OztBQVNBNkUsSUFBQUEsY0FBYyxDQUFDdEQsUUFBZixHQUEwQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMxRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQ3lELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQXpELFFBQUFBLE1BQU0sQ0FBQzBELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQTFELFFBQUFBLE1BQU0sQ0FBQzJELFVBQVAsR0FBb0IsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJaEYsT0FBTyxDQUFDOEUsVUFBUixJQUFzQixJQUF0QixJQUE4QjlFLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDeUQsVUFBUCxHQUFvQjlFLE9BQU8sQ0FBQzhFLFVBQTVCO0FBQ0osVUFBSTlFLE9BQU8sQ0FBQytFLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEIvRSxPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQzBELFVBQVAsR0FBb0J2RCxPQUFPLENBQUN3QyxJQUFSLElBQWdCLENBQUNDLFFBQVEsQ0FBQ2pFLE9BQU8sQ0FBQytFLFVBQVQsQ0FBekIsR0FBZ0R6RCxNQUFNLENBQUN0QixPQUFPLENBQUMrRSxVQUFULENBQXRELEdBQTZFL0UsT0FBTyxDQUFDK0UsVUFBekc7QUFDSixVQUFJL0UsT0FBTyxDQUFDZ0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmhGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDMkQsVUFBUCxHQUFvQnhELE9BQU8sQ0FBQ3dDLElBQVIsSUFBZ0IsQ0FBQ0MsUUFBUSxDQUFDakUsT0FBTyxDQUFDZ0YsVUFBVCxDQUF6QixHQUFnRDFELE1BQU0sQ0FBQ3RCLE9BQU8sQ0FBQ2dGLFVBQVQsQ0FBdEQsR0FBNkVoRixPQUFPLENBQUNnRixVQUF6RztBQUNKLGFBQU8zRCxNQUFQO0FBQ0gsS0FoQkQ7QUFrQkE7Ozs7Ozs7OztBQU9Bd0QsSUFBQUEsY0FBYyxDQUFDakYsU0FBZixDQUF5QjhCLE1BQXpCLEdBQWtDLFNBQVNBLE1BQVQsR0FBa0I7QUFDaEQsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBT2lELGNBQVA7QUFDSCxHQXRPb0IsRUFBckI7O0FBd09BNUYsRUFBQUEsR0FBRyxDQUFDZ0csV0FBSixHQUFtQixZQUFXO0FBRTFCOzs7Ozs7O0FBT0E7Ozs7Ozs7O0FBUUEsYUFBU0EsV0FBVCxDQUFxQnpGLFVBQXJCLEVBQWlDO0FBQzdCLFVBQUlBLFVBQUosRUFDSSxLQUFLLElBQUlDLElBQUksR0FBR0osTUFBTSxDQUFDSSxJQUFQLENBQVlELFVBQVosQ0FBWCxFQUFvQ0UsQ0FBQyxHQUFHLENBQTdDLEVBQWdEQSxDQUFDLEdBQUdELElBQUksQ0FBQ0UsTUFBekQsRUFBaUUsRUFBRUQsQ0FBbkU7QUFDSSxZQUFJRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQVYsSUFBdUIsSUFBM0IsRUFDSSxLQUFLRCxJQUFJLENBQUNDLENBQUQsQ0FBVCxJQUFnQkYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUExQjtBQUZSO0FBR1A7QUFFRDs7Ozs7Ozs7QUFNQXVGLElBQUFBLFdBQVcsQ0FBQ3JGLFNBQVosQ0FBc0JzRixZQUF0QixHQUFxQyxDQUFyQztBQUVBOzs7Ozs7Ozs7QUFRQUQsSUFBQUEsV0FBVyxDQUFDM0YsTUFBWixHQUFxQixTQUFTQSxNQUFULENBQWdCRSxVQUFoQixFQUE0QjtBQUM3QyxhQUFPLElBQUl5RixXQUFKLENBQWdCekYsVUFBaEIsQ0FBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7QUFTQXlGLElBQUFBLFdBQVcsQ0FBQ2xGLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkMsT0FBaEIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQ2xELFVBQUksQ0FBQ0EsTUFBTCxFQUNJQSxNQUFNLEdBQUd0QixPQUFPLENBQUNXLE1BQVIsRUFBVDtBQUNKLFVBQUlVLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0M3RixNQUFNLENBQUNhLGNBQVAsQ0FBc0JDLElBQXRCLENBQTJCSCxPQUEzQixFQUFvQyxjQUFwQyxDQUFwQyxFQUNJQyxNQUFNLENBQUNHLE1BQVA7QUFBYztBQUF1QixPQUFyQyxFQUF3Q0EsTUFBeEMsQ0FBK0NKLE9BQU8sQ0FBQ2tGLFlBQXZEO0FBQ0osYUFBT2pGLE1BQVA7QUFDSCxLQU5EO0FBUUE7Ozs7Ozs7Ozs7O0FBU0FnRixJQUFBQSxXQUFXLENBQUMzRSxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJOLE9BQXpCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUNwRSxhQUFPLEtBQUtGLE1BQUwsQ0FBWUMsT0FBWixFQUFxQkMsTUFBckIsRUFBNkJNLE1BQTdCLEVBQVA7QUFDSCxLQUZEO0FBSUE7Ozs7Ozs7Ozs7Ozs7QUFXQTBFLElBQUFBLFdBQVcsQ0FBQ3pFLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQkMsTUFBaEIsRUFBd0JkLE1BQXhCLEVBQWdDO0FBQ2pELFVBQUksRUFBRWMsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHaEMsT0FBTyxDQUFDYSxNQUFSLENBQWVtQixNQUFmLENBQVQ7QUFDSixVQUFJQyxHQUFHLEdBQUdmLE1BQU0sS0FBS2dCLFNBQVgsR0FBdUJGLE1BQU0sQ0FBQ0csR0FBOUIsR0FBb0NILE1BQU0sQ0FBQ0ksR0FBUCxHQUFhbEIsTUFBM0Q7QUFBQSxVQUFtRUssT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWQsRUFBN0U7O0FBQ0EsYUFBT3hFLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDa0YsWUFBUixHQUF1QnpFLE1BQU0sQ0FBQ0wsTUFBUCxFQUF2QjtBQUNBOztBQUNKO0FBQ0lLLFlBQUFBLE1BQU0sQ0FBQ00sUUFBUCxDQUFnQkQsR0FBRyxHQUFHLENBQXRCO0FBQ0E7QUFOSjtBQVFIOztBQUNELGFBQU9kLE9BQVA7QUFDSCxLQWhCRDtBQWtCQTs7Ozs7Ozs7Ozs7O0FBVUFpRixJQUFBQSxXQUFXLENBQUNqRSxlQUFaLEdBQThCLFNBQVNBLGVBQVQsQ0FBeUJQLE1BQXpCLEVBQWlDO0FBQzNELFVBQUksRUFBRUEsTUFBTSxZQUFZaEMsT0FBcEIsQ0FBSixFQUNJZ0MsTUFBTSxHQUFHLElBQUloQyxPQUFKLENBQVlnQyxNQUFaLENBQVQ7QUFDSixhQUFPLEtBQUtELE1BQUwsQ0FBWUMsTUFBWixFQUFvQkEsTUFBTSxDQUFDTCxNQUFQLEVBQXBCLENBQVA7QUFDSCxLQUpEO0FBTUE7Ozs7Ozs7Ozs7QUFRQTZFLElBQUFBLFdBQVcsQ0FBQ2hFLE1BQVosR0FBcUIsU0FBU0EsTUFBVCxDQUFnQmpCLE9BQWhCLEVBQXlCO0FBQzFDLFVBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFuQixJQUErQkEsT0FBTyxLQUFLLElBQS9DLEVBQ0ksT0FBTyxpQkFBUDtBQUNKLFVBQUlBLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDa0YsWUFBeEIsQ0FBTCxFQUNJLE9BQU8sZ0NBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7QUFRQUQsSUFBQUEsV0FBVyxDQUFDN0QsVUFBWixHQUF5QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNqRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWhDLEVBQ0ksT0FBTzVELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWdHLFdBQWQsRUFBZDtBQUNBLFVBQUk1RCxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLGFBQU9sRixPQUFQO0FBQ0gsS0FQRDtBQVNBOzs7Ozs7Ozs7OztBQVNBaUYsSUFBQUEsV0FBVyxDQUFDMUQsUUFBWixHQUF1QixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUN2RCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjtBQUNBLFVBQUlHLE9BQU8sQ0FBQ0MsUUFBWixFQUNJSixNQUFNLENBQUM2RCxZQUFQLEdBQXNCLENBQXRCO0FBQ0osVUFBSWxGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0JsRixPQUFPLENBQUNrRixZQUE5QjtBQUNKLGFBQU83RCxNQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7QUFPQTRELElBQUFBLFdBQVcsQ0FBQ3JGLFNBQVosQ0FBc0I4QixNQUF0QixHQUErQixTQUFTQSxNQUFULEdBQWtCO0FBQzdDLGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU9xRCxXQUFQO0FBQ0gsR0F6TGlCLEVBQWxCOztBQTJMQWhHLEVBQUFBLEdBQUcsQ0FBQ2tHLGNBQUosR0FBc0IsWUFBVztBQUU3Qjs7Ozs7Ozs7QUFRQTs7Ozs7Ozs7QUFRQSxhQUFTQSxjQUFULENBQXdCM0YsVUFBeEIsRUFBb0M7QUFDaEMsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BeUYsSUFBQUEsY0FBYyxDQUFDdkYsU0FBZixDQUF5QndGLFVBQXpCLEdBQXNDLENBQXRDO0FBRUE7Ozs7Ozs7QUFNQUQsSUFBQUEsY0FBYyxDQUFDdkYsU0FBZixDQUF5QnNGLFlBQXpCLEdBQXdDLENBQXhDO0FBRUE7Ozs7Ozs7OztBQVFBQyxJQUFBQSxjQUFjLENBQUM3RixNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQ2hELGFBQU8sSUFBSTJGLGNBQUosQ0FBbUIzRixVQUFuQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBMkYsSUFBQUEsY0FBYyxDQUFDcEYsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDckQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDb0YsVUFBUixJQUFzQixJQUF0QixJQUE4Qi9GLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDb0YsVUFBdkQ7QUFDSixVQUFJcEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDQSxNQUF6QyxDQUFnREosT0FBTyxDQUFDa0YsWUFBeEQ7QUFDSixhQUFPakYsTUFBUDtBQUNILEtBUkQ7QUFVQTs7Ozs7Ozs7Ozs7QUFTQWtGLElBQUFBLGNBQWMsQ0FBQzdFLGVBQWYsR0FBaUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3ZFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBNEUsSUFBQUEsY0FBYyxDQUFDM0UsTUFBZixHQUF3QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDcEQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVa0csY0FBZCxFQUE3RTs7QUFDQSxhQUFPMUUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUNvRixVQUFSLEdBQXFCM0UsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0osZUFBSyxDQUFMO0FBQ0lKLFlBQUFBLE9BQU8sQ0FBQ2tGLFlBQVIsR0FBdUJ6RSxNQUFNLENBQUNMLE1BQVAsRUFBdkI7QUFDQTs7QUFDSjtBQUNJSyxZQUFBQSxNQUFNLENBQUNNLFFBQVAsQ0FBZ0JELEdBQUcsR0FBRyxDQUF0QjtBQUNBO0FBVEo7QUFXSDs7QUFDRCxhQUFPZCxPQUFQO0FBQ0gsS0FuQkQ7QUFxQkE7Ozs7Ozs7Ozs7OztBQVVBbUYsSUFBQUEsY0FBYyxDQUFDbkUsZUFBZixHQUFpQyxTQUFTQSxlQUFULENBQXlCUCxNQUF6QixFQUFpQztBQUM5RCxVQUFJLEVBQUVBLE1BQU0sWUFBWWhDLE9BQXBCLENBQUosRUFDSWdDLE1BQU0sR0FBRyxJQUFJaEMsT0FBSixDQUFZZ0MsTUFBWixDQUFUO0FBQ0osYUFBTyxLQUFLRCxNQUFMLENBQVlDLE1BQVosRUFBb0JBLE1BQU0sQ0FBQ0wsTUFBUCxFQUFwQixDQUFQO0FBQ0gsS0FKRDtBQU1BOzs7Ozs7Ozs7O0FBUUErRSxJQUFBQSxjQUFjLENBQUNsRSxNQUFmLEdBQXdCLFNBQVNBLE1BQVQsQ0FBZ0JqQixPQUFoQixFQUF5QjtBQUM3QyxVQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbkIsSUFBK0JBLE9BQU8sS0FBSyxJQUEvQyxFQUNJLE9BQU8saUJBQVA7QUFDSixVQUFJQSxPQUFPLENBQUNvRixVQUFSLElBQXNCLElBQXRCLElBQThCcEYsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ29GLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsVUFBSXBGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSSxJQUFJLENBQUNyQixLQUFLLENBQUNxQyxTQUFOLENBQWdCbEIsT0FBTyxDQUFDa0YsWUFBeEIsQ0FBTCxFQUNJLE9BQU8sZ0NBQVA7QUFDUixhQUFPLElBQVA7QUFDSCxLQVZEO0FBWUE7Ozs7Ozs7Ozs7QUFRQUMsSUFBQUEsY0FBYyxDQUFDL0QsVUFBZixHQUE0QixTQUFTQSxVQUFULENBQW9CQyxNQUFwQixFQUE0QjtBQUNwRCxVQUFJQSxNQUFNLFlBQVl0QyxLQUFLLENBQUNFLEdBQU4sQ0FBVWtHLGNBQWhDLEVBQ0ksT0FBTzlELE1BQVA7QUFDSixVQUFJckIsT0FBTyxHQUFHLElBQUlqQixLQUFLLENBQUNFLEdBQU4sQ0FBVWtHLGNBQWQsRUFBZDtBQUNBLFVBQUk5RCxNQUFNLENBQUMrRCxVQUFQLElBQXFCLElBQXpCLEVBQ0lwRixPQUFPLENBQUNvRixVQUFSLEdBQXFCL0QsTUFBTSxDQUFDK0QsVUFBUCxLQUFzQixDQUEzQztBQUNKLFVBQUkvRCxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLGFBQU9sRixPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBbUYsSUFBQUEsY0FBYyxDQUFDNUQsUUFBZixHQUEwQixTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUMxRCxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQytELFVBQVAsR0FBb0IsQ0FBcEI7QUFDQS9ELFFBQUFBLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDSDs7QUFDRCxVQUFJbEYsT0FBTyxDQUFDb0YsVUFBUixJQUFzQixJQUF0QixJQUE4QnBGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixZQUF2QixDQUFsQyxFQUNJbUIsTUFBTSxDQUFDK0QsVUFBUCxHQUFvQnBGLE9BQU8sQ0FBQ29GLFVBQTVCO0FBQ0osVUFBSXBGLE9BQU8sQ0FBQ2tGLFlBQVIsSUFBd0IsSUFBeEIsSUFBZ0NsRixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsY0FBdkIsQ0FBcEMsRUFDSW1CLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0JsRixPQUFPLENBQUNrRixZQUE5QjtBQUNKLGFBQU83RCxNQUFQO0FBQ0gsS0FiRDtBQWVBOzs7Ozs7Ozs7QUFPQThELElBQUFBLGNBQWMsQ0FBQ3ZGLFNBQWYsQ0FBeUI4QixNQUF6QixHQUFrQyxTQUFTQSxNQUFULEdBQWtCO0FBQ2hELGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU91RCxjQUFQO0FBQ0gsR0FoTm9CLEVBQXJCOztBQWtOQWxHLEVBQUFBLEdBQUcsQ0FBQ29HLG9CQUFKLEdBQTRCLFlBQVc7QUFFbkM7Ozs7Ozs7O0FBUUE7Ozs7Ozs7O0FBUUEsYUFBU0Esb0JBQVQsQ0FBOEI3RixVQUE5QixFQUEwQztBQUN0QyxVQUFJQSxVQUFKLEVBQ0ksS0FBSyxJQUFJQyxJQUFJLEdBQUdKLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZRCxVQUFaLENBQVgsRUFBb0NFLENBQUMsR0FBRyxDQUE3QyxFQUFnREEsQ0FBQyxHQUFHRCxJQUFJLENBQUNFLE1BQXpELEVBQWlFLEVBQUVELENBQW5FO0FBQ0ksWUFBSUYsVUFBVSxDQUFDQyxJQUFJLENBQUNDLENBQUQsQ0FBTCxDQUFWLElBQXVCLElBQTNCLEVBQ0ksS0FBS0QsSUFBSSxDQUFDQyxDQUFELENBQVQsSUFBZ0JGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBMUI7QUFGUjtBQUdQO0FBRUQ7Ozs7Ozs7O0FBTUEyRixJQUFBQSxvQkFBb0IsQ0FBQ3pGLFNBQXJCLENBQStCc0YsWUFBL0IsR0FBOEMsQ0FBOUM7QUFFQTs7Ozs7OztBQU1BRyxJQUFBQSxvQkFBb0IsQ0FBQ3pGLFNBQXJCLENBQStCMEYsVUFBL0IsR0FBNEMsQ0FBNUM7QUFFQTs7Ozs7Ozs7O0FBUUFELElBQUFBLG9CQUFvQixDQUFDL0YsTUFBckIsR0FBOEIsU0FBU0EsTUFBVCxDQUFnQkUsVUFBaEIsRUFBNEI7QUFDdEQsYUFBTyxJQUFJNkYsb0JBQUosQ0FBeUI3RixVQUF6QixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBNkYsSUFBQUEsb0JBQW9CLENBQUN0RixNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDM0QsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDa0YsWUFBdkQ7QUFDSixVQUFJbEYsT0FBTyxDQUFDc0YsVUFBUixJQUFzQixJQUF0QixJQUE4QmpHLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLFlBQXBDLENBQWxDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLFFBQXJDLEVBQXlDQSxNQUF6QyxDQUFnREosT0FBTyxDQUFDc0YsVUFBeEQ7QUFDSixhQUFPckYsTUFBUDtBQUNILEtBUkQ7QUFVQTs7Ozs7Ozs7Ozs7QUFTQW9GLElBQUFBLG9CQUFvQixDQUFDL0UsZUFBckIsR0FBdUMsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQzdFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBOEUsSUFBQUEsb0JBQW9CLENBQUM3RSxNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDMUQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVb0csb0JBQWQsRUFBN0U7O0FBQ0EsYUFBTzVFLE1BQU0sQ0FBQ0ksR0FBUCxHQUFhSCxHQUFwQixFQUF5QjtBQUNyQixZQUFJSSxHQUFHLEdBQUdMLE1BQU0sQ0FBQ0wsTUFBUCxFQUFWOztBQUNBLGdCQUFRVSxHQUFHLEtBQUssQ0FBaEI7QUFDQSxlQUFLLENBQUw7QUFDSWQsWUFBQUEsT0FBTyxDQUFDa0YsWUFBUixHQUF1QnpFLE1BQU0sQ0FBQ0wsTUFBUCxFQUF2QjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJSixZQUFBQSxPQUFPLENBQUNzRixVQUFSLEdBQXFCN0UsTUFBTSxDQUFDTCxNQUFQLEVBQXJCO0FBQ0E7O0FBQ0o7QUFDSUssWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQVRKO0FBV0g7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBbkJEO0FBcUJBOzs7Ozs7Ozs7Ozs7QUFVQXFGLElBQUFBLG9CQUFvQixDQUFDckUsZUFBckIsR0FBdUMsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDcEUsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBaUYsSUFBQUEsb0JBQW9CLENBQUNwRSxNQUFyQixHQUE4QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDbkQsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNrRixZQUF4QixDQUFMLEVBQ0ksT0FBTyxnQ0FBUDtBQUNSLFVBQUlsRixPQUFPLENBQUNzRixVQUFSLElBQXNCLElBQXRCLElBQThCdEYsT0FBTyxDQUFDRSxjQUFSLENBQXVCLFlBQXZCLENBQWxDLEVBQ0ksSUFBSSxDQUFDckIsS0FBSyxDQUFDcUMsU0FBTixDQUFnQmxCLE9BQU8sQ0FBQ3NGLFVBQXhCLENBQUwsRUFDSSxPQUFPLDhCQUFQO0FBQ1IsYUFBTyxJQUFQO0FBQ0gsS0FWRDtBQVlBOzs7Ozs7Ozs7O0FBUUFELElBQUFBLG9CQUFvQixDQUFDakUsVUFBckIsR0FBa0MsU0FBU0EsVUFBVCxDQUFvQkMsTUFBcEIsRUFBNEI7QUFDMUQsVUFBSUEsTUFBTSxZQUFZdEMsS0FBSyxDQUFDRSxHQUFOLENBQVVvRyxvQkFBaEMsRUFDSSxPQUFPaEUsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVb0csb0JBQWQsRUFBZDtBQUNBLFVBQUloRSxNQUFNLENBQUM2RCxZQUFQLElBQXVCLElBQTNCLEVBQ0lsRixPQUFPLENBQUNrRixZQUFSLEdBQXVCN0QsTUFBTSxDQUFDNkQsWUFBUCxLQUF3QixDQUEvQztBQUNKLFVBQUk3RCxNQUFNLENBQUNpRSxVQUFQLElBQXFCLElBQXpCLEVBQ0l0RixPQUFPLENBQUNzRixVQUFSLEdBQXFCakUsTUFBTSxDQUFDaUUsVUFBUCxLQUFzQixDQUEzQztBQUNKLGFBQU90RixPQUFQO0FBQ0gsS0FURDtBQVdBOzs7Ozs7Ozs7OztBQVNBcUYsSUFBQUEsb0JBQW9CLENBQUM5RCxRQUFyQixHQUFnQyxTQUFTQSxRQUFULENBQWtCdkIsT0FBbEIsRUFBMkJ3QixPQUEzQixFQUFvQztBQUNoRSxVQUFJLENBQUNBLE9BQUwsRUFDSUEsT0FBTyxHQUFHLEVBQVY7QUFDSixVQUFJSCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxVQUFJRyxPQUFPLENBQUNDLFFBQVosRUFBc0I7QUFDbEJKLFFBQUFBLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDQTdELFFBQUFBLE1BQU0sQ0FBQ2lFLFVBQVAsR0FBb0IsQ0FBcEI7QUFDSDs7QUFDRCxVQUFJdEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDNkQsWUFBUCxHQUFzQmxGLE9BQU8sQ0FBQ2tGLFlBQTlCO0FBQ0osVUFBSWxGLE9BQU8sQ0FBQ3NGLFVBQVIsSUFBc0IsSUFBdEIsSUFBOEJ0RixPQUFPLENBQUNFLGNBQVIsQ0FBdUIsWUFBdkIsQ0FBbEMsRUFDSW1CLE1BQU0sQ0FBQ2lFLFVBQVAsR0FBb0J0RixPQUFPLENBQUNzRixVQUE1QjtBQUNKLGFBQU9qRSxNQUFQO0FBQ0gsS0FiRDtBQWVBOzs7Ozs7Ozs7QUFPQWdFLElBQUFBLG9CQUFvQixDQUFDekYsU0FBckIsQ0FBK0I4QixNQUEvQixHQUF3QyxTQUFTQSxNQUFULEdBQWtCO0FBQ3RELGFBQU8sS0FBS0MsV0FBTCxDQUFpQkosUUFBakIsQ0FBMEIsSUFBMUIsRUFBZ0NoRCxTQUFTLENBQUNPLElBQVYsQ0FBZThDLGFBQS9DLENBQVA7QUFDSCxLQUZEOztBQUlBLFdBQU95RCxvQkFBUDtBQUNILEdBaE4wQixFQUEzQjs7QUFrTkFwRyxFQUFBQSxHQUFHLENBQUNzRyxhQUFKLEdBQXFCLFlBQVc7QUFFNUI7Ozs7Ozs7QUFPQTs7Ozs7Ozs7QUFRQSxhQUFTQSxhQUFULENBQXVCL0YsVUFBdkIsRUFBbUM7QUFDL0IsVUFBSUEsVUFBSixFQUNJLEtBQUssSUFBSUMsSUFBSSxHQUFHSixNQUFNLENBQUNJLElBQVAsQ0FBWUQsVUFBWixDQUFYLEVBQW9DRSxDQUFDLEdBQUcsQ0FBN0MsRUFBZ0RBLENBQUMsR0FBR0QsSUFBSSxDQUFDRSxNQUF6RCxFQUFpRSxFQUFFRCxDQUFuRTtBQUNJLFlBQUlGLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDQyxDQUFELENBQUwsQ0FBVixJQUF1QixJQUEzQixFQUNJLEtBQUtELElBQUksQ0FBQ0MsQ0FBRCxDQUFULElBQWdCRixVQUFVLENBQUNDLElBQUksQ0FBQ0MsQ0FBRCxDQUFMLENBQTFCO0FBRlI7QUFHUDtBQUVEOzs7Ozs7OztBQU1BNkYsSUFBQUEsYUFBYSxDQUFDM0YsU0FBZCxDQUF3QnNGLFlBQXhCLEdBQXVDLENBQXZDO0FBRUE7Ozs7Ozs7OztBQVFBSyxJQUFBQSxhQUFhLENBQUNqRyxNQUFkLEdBQXVCLFNBQVNBLE1BQVQsQ0FBZ0JFLFVBQWhCLEVBQTRCO0FBQy9DLGFBQU8sSUFBSStGLGFBQUosQ0FBa0IvRixVQUFsQixDQUFQO0FBQ0gsS0FGRDtBQUlBOzs7Ozs7Ozs7OztBQVNBK0YsSUFBQUEsYUFBYSxDQUFDeEYsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxPQUFoQixFQUF5QkMsTUFBekIsRUFBaUM7QUFDcEQsVUFBSSxDQUFDQSxNQUFMLEVBQ0lBLE1BQU0sR0FBR3RCLE9BQU8sQ0FBQ1csTUFBUixFQUFUO0FBQ0osVUFBSVUsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQzdGLE1BQU0sQ0FBQ2EsY0FBUCxDQUFzQkMsSUFBdEIsQ0FBMkJILE9BQTNCLEVBQW9DLGNBQXBDLENBQXBDLEVBQ0lDLE1BQU0sQ0FBQ0csTUFBUDtBQUFjO0FBQXVCLE9BQXJDLEVBQXdDQSxNQUF4QyxDQUErQ0osT0FBTyxDQUFDa0YsWUFBdkQ7QUFDSixhQUFPakYsTUFBUDtBQUNILEtBTkQ7QUFRQTs7Ozs7Ozs7Ozs7QUFTQXNGLElBQUFBLGFBQWEsQ0FBQ2pGLGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5Qk4sT0FBekIsRUFBa0NDLE1BQWxDLEVBQTBDO0FBQ3RFLGFBQU8sS0FBS0YsTUFBTCxDQUFZQyxPQUFaLEVBQXFCQyxNQUFyQixFQUE2Qk0sTUFBN0IsRUFBUDtBQUNILEtBRkQ7QUFJQTs7Ozs7Ozs7Ozs7OztBQVdBZ0YsSUFBQUEsYUFBYSxDQUFDL0UsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCQyxNQUFoQixFQUF3QmQsTUFBeEIsRUFBZ0M7QUFDbkQsVUFBSSxFQUFFYyxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUdoQyxPQUFPLENBQUNhLE1BQVIsQ0FBZW1CLE1BQWYsQ0FBVDtBQUNKLFVBQUlDLEdBQUcsR0FBR2YsTUFBTSxLQUFLZ0IsU0FBWCxHQUF1QkYsTUFBTSxDQUFDRyxHQUE5QixHQUFvQ0gsTUFBTSxDQUFDSSxHQUFQLEdBQWFsQixNQUEzRDtBQUFBLFVBQW1FSyxPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBZCxFQUE3RTs7QUFDQSxhQUFPOUUsTUFBTSxDQUFDSSxHQUFQLEdBQWFILEdBQXBCLEVBQXlCO0FBQ3JCLFlBQUlJLEdBQUcsR0FBR0wsTUFBTSxDQUFDTCxNQUFQLEVBQVY7O0FBQ0EsZ0JBQVFVLEdBQUcsS0FBSyxDQUFoQjtBQUNBLGVBQUssQ0FBTDtBQUNJZCxZQUFBQSxPQUFPLENBQUNrRixZQUFSLEdBQXVCekUsTUFBTSxDQUFDTCxNQUFQLEVBQXZCO0FBQ0E7O0FBQ0o7QUFDSUssWUFBQUEsTUFBTSxDQUFDTSxRQUFQLENBQWdCRCxHQUFHLEdBQUcsQ0FBdEI7QUFDQTtBQU5KO0FBUUg7O0FBQ0QsYUFBT2QsT0FBUDtBQUNILEtBaEJEO0FBa0JBOzs7Ozs7Ozs7Ozs7QUFVQXVGLElBQUFBLGFBQWEsQ0FBQ3ZFLGVBQWQsR0FBZ0MsU0FBU0EsZUFBVCxDQUF5QlAsTUFBekIsRUFBaUM7QUFDN0QsVUFBSSxFQUFFQSxNQUFNLFlBQVloQyxPQUFwQixDQUFKLEVBQ0lnQyxNQUFNLEdBQUcsSUFBSWhDLE9BQUosQ0FBWWdDLE1BQVosQ0FBVDtBQUNKLGFBQU8sS0FBS0QsTUFBTCxDQUFZQyxNQUFaLEVBQW9CQSxNQUFNLENBQUNMLE1BQVAsRUFBcEIsQ0FBUDtBQUNILEtBSkQ7QUFNQTs7Ozs7Ozs7OztBQVFBbUYsSUFBQUEsYUFBYSxDQUFDdEUsTUFBZCxHQUF1QixTQUFTQSxNQUFULENBQWdCakIsT0FBaEIsRUFBeUI7QUFDNUMsVUFBSSxPQUFPQSxPQUFQLEtBQW1CLFFBQW5CLElBQStCQSxPQUFPLEtBQUssSUFBL0MsRUFDSSxPQUFPLGlCQUFQO0FBQ0osVUFBSUEsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJLElBQUksQ0FBQ3JCLEtBQUssQ0FBQ3FDLFNBQU4sQ0FBZ0JsQixPQUFPLENBQUNrRixZQUF4QixDQUFMLEVBQ0ksT0FBTyxnQ0FBUDtBQUNSLGFBQU8sSUFBUDtBQUNILEtBUEQ7QUFTQTs7Ozs7Ozs7OztBQVFBSyxJQUFBQSxhQUFhLENBQUNuRSxVQUFkLEdBQTJCLFNBQVNBLFVBQVQsQ0FBb0JDLE1BQXBCLEVBQTRCO0FBQ25ELFVBQUlBLE1BQU0sWUFBWXRDLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBaEMsRUFDSSxPQUFPbEUsTUFBUDtBQUNKLFVBQUlyQixPQUFPLEdBQUcsSUFBSWpCLEtBQUssQ0FBQ0UsR0FBTixDQUFVc0csYUFBZCxFQUFkO0FBQ0EsVUFBSWxFLE1BQU0sQ0FBQzZELFlBQVAsSUFBdUIsSUFBM0IsRUFDSWxGLE9BQU8sQ0FBQ2tGLFlBQVIsR0FBdUI3RCxNQUFNLENBQUM2RCxZQUFQLEtBQXdCLENBQS9DO0FBQ0osYUFBT2xGLE9BQVA7QUFDSCxLQVBEO0FBU0E7Ozs7Ozs7Ozs7O0FBU0F1RixJQUFBQSxhQUFhLENBQUNoRSxRQUFkLEdBQXlCLFNBQVNBLFFBQVQsQ0FBa0J2QixPQUFsQixFQUEyQndCLE9BQTNCLEVBQW9DO0FBQ3pELFVBQUksQ0FBQ0EsT0FBTCxFQUNJQSxPQUFPLEdBQUcsRUFBVjtBQUNKLFVBQUlILE1BQU0sR0FBRyxFQUFiO0FBQ0EsVUFBSUcsT0FBTyxDQUFDQyxRQUFaLEVBQ0lKLE1BQU0sQ0FBQzZELFlBQVAsR0FBc0IsQ0FBdEI7QUFDSixVQUFJbEYsT0FBTyxDQUFDa0YsWUFBUixJQUF3QixJQUF4QixJQUFnQ2xGLE9BQU8sQ0FBQ0UsY0FBUixDQUF1QixjQUF2QixDQUFwQyxFQUNJbUIsTUFBTSxDQUFDNkQsWUFBUCxHQUFzQmxGLE9BQU8sQ0FBQ2tGLFlBQTlCO0FBQ0osYUFBTzdELE1BQVA7QUFDSCxLQVREO0FBV0E7Ozs7Ozs7OztBQU9Ba0UsSUFBQUEsYUFBYSxDQUFDM0YsU0FBZCxDQUF3QjhCLE1BQXhCLEdBQWlDLFNBQVNBLE1BQVQsR0FBa0I7QUFDL0MsYUFBTyxLQUFLQyxXQUFMLENBQWlCSixRQUFqQixDQUEwQixJQUExQixFQUFnQ2hELFNBQVMsQ0FBQ08sSUFBVixDQUFlOEMsYUFBL0MsQ0FBUDtBQUNILEtBRkQ7O0FBSUEsV0FBTzJELGFBQVA7QUFDSCxHQXpMbUIsRUFBcEI7O0FBMkxBLFNBQU90RyxHQUFQO0FBQ0gsQ0FwdUc4QixFQUF4Qjs7O0FBc3VHUHVHLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQjFHLEtBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKmVzbGludC1kaXNhYmxlIGJsb2NrLXNjb3BlZC12YXIsIGlkLWxlbmd0aCwgbm8tY29udHJvbC1yZWdleCwgbm8tbWFnaWMtbnVtYmVycywgbm8tcHJvdG90eXBlLWJ1aWx0aW5zLCBuby1yZWRlY2xhcmUsIG5vLXNoYWRvdywgbm8tdmFyLCBzb3J0LXZhcnMqL1xuXCJ1c2Ugc3RyaWN0XCI7XG5cbnZhciAkcHJvdG9idWYgPSByZXF1aXJlKFwiLi9wcm90b2J1ZlwiKTtcblxuLy8gQ29tbW9uIGFsaWFzZXNcbmNvbnN0ICRSZWFkZXIgPSAkcHJvdG9idWYuUmVhZGVyLCAkV3JpdGVyID0gJHByb3RvYnVmLldyaXRlciwgJHV0aWwgPSAkcHJvdG9idWYudXRpbDtcblxuLy8gRXhwb3J0ZWQgcm9vdCBuYW1lc3BhY2VcbmNvbnN0ICRyb290ID0gJHByb3RvYnVmLnJvb3RzW1wiZGVmYXVsdFwiXSB8fCAoJHByb3RvYnVmLnJvb3RzW1wiZGVmYXVsdFwiXSA9IHt9KTtcblxuZXhwb3J0IGNvbnN0IG1zZyA9ICRyb290Lm1zZyA9ICgoKSA9PiB7XG5cbiAgICAvKipcbiAgICAgKiBOYW1lc3BhY2UgbXNnLlxuICAgICAqIEBleHBvcnRzIG1zZ1xuICAgICAqIEBuYW1lc3BhY2VcbiAgICAgKi9cbiAgICBjb25zdCBtc2cgPSB7fTtcblxuICAgIC8qKlxuICAgICAqIE1zZ0NvZGUgZW51bS5cbiAgICAgKiBAbmFtZSBtc2cuTXNnQ29kZVxuICAgICAqIEBlbnVtIHtudW1iZXJ9XG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfRU5UUllfQ01EPTAgVVNFUl9FTlRSWV9DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9FTlRSWV9SRVNVTFQ9MSBVU0VSX0VOVFJZX1JFU1VMVCB2YWx1ZVxuICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfSBXSE9fRUxTRV9JU19IRVJFX0NNRD0yIFdIT19FTFNFX0lTX0hFUkVfQ01EIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFdIT19FTFNFX0lTX0hFUkVfUkVTVUxUPTMgV0hPX0VMU0VfSVNfSEVSRV9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9NT1ZFX1RPX0NNRD00IFVTRVJfTU9WRV9UT19DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9NT1ZFX1RPX1JFU1VMVD01IFVTRVJfTU9WRV9UT19SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9RVUlUX1JFU1VMVD02IFVTRVJfUVVJVF9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9TVE9QX0NNRD03IFVTRVJfU1RPUF9DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9TVE9QX1JFU1VMVD04IFVTRVJfU1RPUF9SRVNVTFQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9BVFRLX0NNRD05IFVTRVJfQVRUS19DTUQgdmFsdWVcbiAgICAgKiBAcHJvcGVydHkge251bWJlcn0gVVNFUl9BVFRLX1JFU1VMVD0xMCBVU0VSX0FUVEtfUkVTVUxUIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfU1VCVFJBQ1RfSFBfUkVTVUxUPTExIFVTRVJfU1VCVFJBQ1RfSFBfUkVTVUxUIHZhbHVlXG4gICAgICogQHByb3BlcnR5IHtudW1iZXJ9IFVTRVJfRElFX1JFU1VMVD0xMiBVU0VSX0RJRV9SRVNVTFQgdmFsdWVcbiAgICAgKi9cbiAgICBtc2cuTXNnQ29kZSA9IChmdW5jdGlvbigpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzQnlJZCA9IHt9LCB2YWx1ZXMgPSBPYmplY3QuY3JlYXRlKHZhbHVlc0J5SWQpO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFswXSA9IFwiVVNFUl9FTlRSWV9DTURcIl0gPSAwO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxXSA9IFwiVVNFUl9FTlRSWV9SRVNVTFRcIl0gPSAxO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsyXSA9IFwiV0hPX0VMU0VfSVNfSEVSRV9DTURcIl0gPSAyO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFszXSA9IFwiV0hPX0VMU0VfSVNfSEVSRV9SRVNVTFRcIl0gPSAzO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFs0XSA9IFwiVVNFUl9NT1ZFX1RPX0NNRFwiXSA9IDQ7XG4gICAgICAgIHZhbHVlc1t2YWx1ZXNCeUlkWzVdID0gXCJVU0VSX01PVkVfVE9fUkVTVUxUXCJdID0gNTtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbNl0gPSBcIlVTRVJfUVVJVF9SRVNVTFRcIl0gPSA2O1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFs3XSA9IFwiVVNFUl9TVE9QX0NNRFwiXSA9IDc7XG4gICAgICAgIHZhbHVlc1t2YWx1ZXNCeUlkWzhdID0gXCJVU0VSX1NUT1BfUkVTVUxUXCJdID0gODtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbOV0gPSBcIlVTRVJfQVRUS19DTURcIl0gPSA5O1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxMF0gPSBcIlVTRVJfQVRUS19SRVNVTFRcIl0gPSAxMDtcbiAgICAgICAgdmFsdWVzW3ZhbHVlc0J5SWRbMTFdID0gXCJVU0VSX1NVQlRSQUNUX0hQX1JFU1VMVFwiXSA9IDExO1xuICAgICAgICB2YWx1ZXNbdmFsdWVzQnlJZFsxMl0gPSBcIlVTRVJfRElFX1JFU1VMVFwiXSA9IDEyO1xuICAgICAgICByZXR1cm4gdmFsdWVzO1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlckVudHJ5Q21kID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckVudHJ5Q21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdXNlcklkXSBVc2VyRW50cnlDbWQgdXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7c3RyaW5nfG51bGx9IFtoZXJvQXZhdGFyXSBVc2VyRW50cnlDbWQgaGVyb0F2YXRhclxuICAgICAgICAgKi9cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29uc3RydWN0cyBhIG5ldyBVc2VyRW50cnlDbWQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlckVudHJ5Q21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBjb25zdHJ1Y3RvclxuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5Q21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyRW50cnlDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRW50cnlDbWQgdXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5wcm90b3R5cGUudXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlckVudHJ5Q21kIGhlcm9BdmF0YXIuXG4gICAgICAgICAqIEBtZW1iZXIge3N0cmluZ30gaGVyb0F2YXRhclxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5wcm90b3R5cGUuaGVyb0F2YXRhciA9IFwiXCI7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlckVudHJ5Q21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyRW50cnlDbWQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJFbnRyeUNtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJFbnRyeUNtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlckVudHJ5Q21kLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeUNtZH0gbWVzc2FnZSBVc2VyRW50cnlDbWQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS51c2VySWQpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDIgPSovMTgpLnN0cmluZyhtZXNzYWdlLmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJFbnRyeUNtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlckVudHJ5Q21kLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeUNtZH0gbWVzc2FnZSBVc2VyRW50cnlDbWQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeUNtZH0gVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyRW50cnlDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5oZXJvQXZhdGFyID0gcmVhZGVyLnN0cmluZygpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlckVudHJ5Q21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeUNtZC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS51c2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ1c2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzU3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcikpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcImhlcm9BdmF0YXI6IHN0cmluZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyRW50cnlDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyRW50cnlDbWR9IFVzZXJFbnRyeUNtZFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyRW50cnlDbWQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyRW50cnlDbWQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSBvYmplY3QudXNlcklkID4+PiAwO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5oZXJvQXZhdGFyICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5oZXJvQXZhdGFyID0gU3RyaW5nKG9iamVjdC5oZXJvQXZhdGFyKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyRW50cnlDbWQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyRW50cnlDbWR9IG1lc3NhZ2UgVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5Q21kLnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnVzZXJJZCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lmhlcm9BdmF0YXIgPSBcIlwiO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gbWVzc2FnZS51c2VySWQ7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lmhlcm9BdmF0YXIgPSBtZXNzYWdlLmhlcm9BdmF0YXI7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJFbnRyeUNtZCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5Q21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlDbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyRW50cnlDbWQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyRW50cnlSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyRW50cnlSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFt1c2VySWRdIFVzZXJFbnRyeVJlc3VsdCB1c2VySWRcbiAgICAgICAgICogQHByb3BlcnR5IHtzdHJpbmd8bnVsbH0gW2hlcm9BdmF0YXJdIFVzZXJFbnRyeVJlc3VsdCBoZXJvQXZhdGFyXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJFbnRyeVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyRW50cnlSZXN1bHQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyRW50cnlSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJFbnRyeVJlc3VsdChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJFbnRyeVJlc3VsdCB1c2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdXNlcklkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LnByb3RvdHlwZS51c2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRW50cnlSZXN1bHQgaGVyb0F2YXRhci5cbiAgICAgICAgICogQG1lbWJlciB7c3RyaW5nfSBoZXJvQXZhdGFyXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LnByb3RvdHlwZS5oZXJvQXZhdGFyID0gXCJcIjtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VyRW50cnlSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJFbnRyeVJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuY3JlYXRlID0gZnVuY3Rpb24gY3JlYXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVXNlckVudHJ5UmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckVudHJ5UmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyRW50cnlSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5UmVzdWx0fSBtZXNzYWdlIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnVzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMiA9Ki8xOCkuc3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcik7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckVudHJ5UmVzdWx0IG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyRW50cnlSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckVudHJ5UmVzdWx0fSBtZXNzYWdlIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckVudHJ5UmVzdWx0fSBVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSByZWFkZXIuc3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRW50cnlSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlckVudHJ5UmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNTdHJpbmcobWVzc2FnZS5oZXJvQXZhdGFyKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiaGVyb0F2YXRhcjogc3RyaW5nIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gVXNlckVudHJ5UmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJFbnRyeVJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC51c2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IG9iamVjdC51c2VySWQgPj4+IDA7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lmhlcm9BdmF0YXIgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSBTdHJpbmcob2JqZWN0Lmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJFbnRyeVJlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJFbnRyeVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJFbnRyeVJlc3VsdH0gbWVzc2FnZSBVc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRW50cnlSZXN1bHQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpIHtcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IFwiXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC51c2VySWQgPSBtZXNzYWdlLnVzZXJJZDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiaGVyb0F2YXRhclwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IG1lc3NhZ2UuaGVyb0F2YXRhcjtcbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgVXNlckVudHJ5UmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRW50cnlSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJFbnRyeVJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIFVzZXJFbnRyeVJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLldob0Vsc2VJc0hlcmVDbWQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBXaG9FbHNlSXNIZXJlQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVdob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgV2hvRWxzZUlzSGVyZUNtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBXaG9FbHNlSXNIZXJlQ21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVDbWQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFdob0Vsc2VJc0hlcmVDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFdob0Vsc2VJc0hlcmVDbWQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklXaG9FbHNlSXNIZXJlQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBXaG9FbHNlSXNIZXJlQ21kKHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZUNtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZUNtZH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFdob0Vsc2VJc0hlcmVDbWQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLldob0Vsc2VJc0hlcmVDbWQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVDbWR9IG1lc3NhZ2UgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgV2hvRWxzZUlzSGVyZUNtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFdob0Vsc2VJc0hlcmVDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZUNtZH0gV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZUNtZC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZUNtZClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgcmV0dXJuIG5ldyAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZUNtZCgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBXaG9FbHNlSXNIZXJlQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVDbWR9IG1lc3NhZ2UgV2hvRWxzZUlzSGVyZUNtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVDbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdCgpIHtcbiAgICAgICAgICAgIHJldHVybiB7fTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBXaG9FbHNlSXNIZXJlQ21kIHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBXaG9FbHNlSXNIZXJlQ21kLnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gV2hvRWxzZUlzSGVyZUNtZDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBXaG9FbHNlSXNIZXJlUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtBcnJheS48bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPnxudWxsfSBbdXNlckluZm9dIFdob0Vsc2VJc0hlcmVSZXN1bHQgdXNlckluZm9cbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgV2hvRWxzZUlzSGVyZVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBXaG9FbHNlSXNIZXJlUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVdob0Vsc2VJc0hlcmVSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFdob0Vsc2VJc0hlcmVSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgdGhpcy51c2VySW5mbyA9IFtdO1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXaG9FbHNlSXNIZXJlUmVzdWx0IHVzZXJJbmZvLlxuICAgICAgICAgKiBAbWVtYmVyIHtBcnJheS48bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPn0gdXNlckluZm9cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5wcm90b3R5cGUudXNlckluZm8gPSAkdXRpbC5lbXB0eUFycmF5O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFdob0Vsc2VJc0hlcmVSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklXaG9FbHNlSXNIZXJlUmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdH0gV2hvRWxzZUlzSGVyZVJlc3VsdCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBXaG9FbHNlSXNIZXJlUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlckluZm8gIT0gbnVsbCAmJiBtZXNzYWdlLnVzZXJJbmZvLmxlbmd0aClcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLmVuY29kZShtZXNzYWdlLnVzZXJJbmZvW2ldLCB3cml0ZXIudWludDMyKC8qIGlkIDEsIHdpcmVUeXBlIDIgPSovMTApLmZvcmsoKSkubGRlbGltKCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0fSBXaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBpZiAoIShtZXNzYWdlLnVzZXJJbmZvICYmIG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudXNlckluZm8gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySW5mby5wdXNoKCRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSkpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgV2hvRWxzZUlzSGVyZVJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHR9IFdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBXaG9FbHNlSXNIZXJlUmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlckluZm8gIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlckluZm9cIikpIHtcbiAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkobWVzc2FnZS51c2VySW5mbykpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJbmZvOiBhcnJheSBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWVzc2FnZS51c2VySW5mby5sZW5ndGg7ICsraSkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgZXJyb3IgPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby52ZXJpZnkobWVzc2FnZS51c2VySW5mb1tpXSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInVzZXJJbmZvLlwiICsgZXJyb3I7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBXaG9FbHNlSXNIZXJlUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHR9IFdob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFdob0Vsc2VJc0hlcmVSZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnVzZXJJbmZvKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KG9iamVjdC51c2VySW5mbykpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IFR5cGVFcnJvcihcIi5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC51c2VySW5mbzogYXJyYXkgZXhwZWN0ZWRcIik7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySW5mbyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb2JqZWN0LnVzZXJJbmZvLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqZWN0LnVzZXJJbmZvW2ldICE9PSBcIm9iamVjdFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKFwiLm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LnVzZXJJbmZvOiBvYmplY3QgZXhwZWN0ZWRcIik7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudXNlckluZm9baV0gPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5mcm9tT2JqZWN0KG9iamVjdC51c2VySW5mb1tpXSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFdob0Vsc2VJc0hlcmVSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdH0gbWVzc2FnZSBXaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5hcnJheXMgfHwgb3B0aW9ucy5kZWZhdWx0cylcbiAgICAgICAgICAgICAgICBvYmplY3QudXNlckluZm8gPSBbXTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnVzZXJJbmZvICYmIG1lc3NhZ2UudXNlckluZm8ubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnVzZXJJbmZvID0gW107XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBtZXNzYWdlLnVzZXJJbmZvLmxlbmd0aDsgKytqKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QudXNlckluZm9bal0gPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby50b09iamVjdChtZXNzYWdlLnVzZXJJbmZvW2pdLCBvcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgV2hvRWxzZUlzSGVyZVJlc3VsdCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mbyA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckluZm8uXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHRcbiAgICAgICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdXNlcklkXSBVc2VySW5mbyB1c2VySWRcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7c3RyaW5nfG51bGx9IFtoZXJvQXZhdGFyXSBVc2VySW5mbyBoZXJvQXZhdGFyXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV8bnVsbH0gW21vdmVTdGF0ZV0gVXNlckluZm8gbW92ZVN0YXRlXG4gICAgICAgICAgICAgKi9cblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJJbmZvLlxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0XG4gICAgICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VySW5mby5cbiAgICAgICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VySW5mb1xuICAgICAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LklVc2VySW5mbz19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBmdW5jdGlvbiBVc2VySW5mbyhwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGtleXMgPSBPYmplY3Qua2V5cyhwcm9wZXJ0aWVzKSwgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgKytpKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBVc2VySW5mbyB1c2VySWQuXG4gICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHVzZXJJZFxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLnVzZXJJZCA9IDA7XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogVXNlckluZm8gaGVyb0F2YXRhci5cbiAgICAgICAgICAgICAqIEBtZW1iZXIge3N0cmluZ30gaGVyb0F2YXRhclxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLmhlcm9BdmF0YXIgPSBcIlwiO1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIFVzZXJJbmZvIG1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAqIEBtZW1iZXIge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV8bnVsbHx1bmRlZmluZWR9IG1vdmVTdGF0ZVxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8ucHJvdG90eXBlLm1vdmVTdGF0ZSA9IG51bGw7XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VySW5mbyBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm99IFVzZXJJbmZvIGluc3RhbmNlXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIFVzZXJJbmZvLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VySW5mbyhwcm9wZXJ0aWVzKTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJJbmZvIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LklVc2VySW5mb30gbWVzc2FnZSBVc2VySW5mbyBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UudXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ1c2VySWRcIikpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS51c2VySWQpO1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmhlcm9BdmF0YXIgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMiA9Ki8xOCkuc3RyaW5nKG1lc3NhZ2UuaGVyb0F2YXRhcik7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXRlICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlU3RhdGVcIikpXG4gICAgICAgICAgICAgICAgICAgICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS5lbmNvZGUobWVzc2FnZS5tb3ZlU3RhdGUsIHdyaXRlci51aW50MzIoLyogaWQgMywgd2lyZVR5cGUgMiA9Ki8yNikuZm9yaygpKS5sZGVsaW0oKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckluZm8gbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8udmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuSVVzZXJJbmZvfSBtZXNzYWdlIFVzZXJJbmZvIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIFVzZXJJbmZvLmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogRGVjb2RlcyBhIFVzZXJJbmZvIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8oKTtcbiAgICAgICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSByZWFkZXIuc3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhdGUgPSAkcm9vdC5tc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGUuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIERlY29kZXMgYSBVc2VySW5mbyBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvXG4gICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIFZlcmlmaWVzIGEgVXNlckluZm8gbWVzc2FnZS5cbiAgICAgICAgICAgICAqIEBmdW5jdGlvbiB2ZXJpZnlcbiAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb1xuICAgICAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ1c2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5oZXJvQXZhdGFyICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImhlcm9BdmF0YXJcIikpXG4gICAgICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNTdHJpbmcobWVzc2FnZS5oZXJvQXZhdGFyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcImhlcm9BdmF0YXI6IHN0cmluZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVTdGF0ZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlU3RhdGVcIikpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVycm9yID0gJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlLnZlcmlmeShtZXNzYWdlLm1vdmVTdGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVTdGF0ZS5cIiArIGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJJbmZvIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb30gVXNlckluZm9cbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8uZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvKCk7XG4gICAgICAgICAgICAgICAgaWYgKG9iamVjdC51c2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS51c2VySWQgPSBvYmplY3QudXNlcklkID4+PiAwO1xuICAgICAgICAgICAgICAgIGlmIChvYmplY3QuaGVyb0F2YXRhciAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmhlcm9BdmF0YXIgPSBTdHJpbmcob2JqZWN0Lmhlcm9BdmF0YXIpO1xuICAgICAgICAgICAgICAgIGlmIChvYmplY3QubW92ZVN0YXRlICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXRlICE9PSBcIm9iamVjdFwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKFwiLm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLm1vdmVTdGF0ZTogb2JqZWN0IGV4cGVjdGVkXCIpO1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVTdGF0ZSA9ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS5mcm9tT2JqZWN0KG9iamVjdC5tb3ZlU3RhdGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlckluZm8gbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAqIEBwYXJhbSB7bXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm99IG1lc3NhZ2UgVXNlckluZm9cbiAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgVXNlckluZm8udG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgIG9iamVjdC51c2VySWQgPSAwO1xuICAgICAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IFwiXCI7XG4gICAgICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlU3RhdGUgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS51c2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidXNlcklkXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QudXNlcklkID0gbWVzc2FnZS51c2VySWQ7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UuaGVyb0F2YXRhciAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJoZXJvQXZhdGFyXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QuaGVyb0F2YXRhciA9IG1lc3NhZ2UuaGVyb0F2YXRhcjtcbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlU3RhdGUgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVN0YXRlXCIpKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXRlID0gJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlLnRvT2JqZWN0KG1lc3NhZ2UubW92ZVN0YXRlLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJJbmZvIHRvIEpTT04uXG4gICAgICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBVc2VySW5mby5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgVXNlckluZm8uTW92ZVN0YXRlID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogUHJvcGVydGllcyBvZiBhIE1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm9cbiAgICAgICAgICAgICAgICAgKiBAaW50ZXJmYWNlIElNb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbZnJvbVBvc1hdIE1vdmVTdGF0ZSBmcm9tUG9zWFxuICAgICAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtmcm9tUG9zWV0gTW92ZVN0YXRlIGZyb21Qb3NZXG4gICAgICAgICAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RvUG9zWF0gTW92ZVN0YXRlIHRvUG9zWFxuICAgICAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFt0b1Bvc1ldIE1vdmVTdGF0ZSB0b1Bvc1lcbiAgICAgICAgICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxMb25nfG51bGx9IFtzdGFydFRpbWVdIE1vdmVTdGF0ZSBzdGFydFRpbWVcbiAgICAgICAgICAgICAgICAgKi9cblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgTW92ZVN0YXRlLlxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mb1xuICAgICAgICAgICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIE1vdmVTdGF0ZS5cbiAgICAgICAgICAgICAgICAgKiBAaW1wbGVtZW50cyBJTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5JTW92ZVN0YXRlPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gTW92ZVN0YXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJvcGVydGllc1trZXlzW2ldXSAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBNb3ZlU3RhdGUgZnJvbVBvc1guXG4gICAgICAgICAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBmcm9tUG9zWFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLmZyb21Qb3NYID0gMDtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIE1vdmVTdGF0ZSBmcm9tUG9zWS5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IGZyb21Qb3NZXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5wcm90b3R5cGUuZnJvbVBvc1kgPSAwO1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogTW92ZVN0YXRlIHRvUG9zWC5cbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHRvUG9zWFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnRvUG9zWCA9IDA7XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBNb3ZlU3RhdGUgdG9Qb3NZLlxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdG9Qb3NZXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5wcm90b3R5cGUudG9Qb3NZID0gMDtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIE1vdmVTdGF0ZSBzdGFydFRpbWUuXG4gICAgICAgICAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfExvbmd9IHN0YXJ0VGltZVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnN0YXJ0VGltZSA9ICR1dGlsLkxvbmcgPyAkdXRpbC5Mb25nLmZyb21CaXRzKDAsMCx0cnVlKSA6IDA7XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IE1vdmVTdGF0ZSBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5JTW92ZVN0YXRlPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlIGluc3RhbmNlXG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgTW92ZVN0YXRlLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgTW92ZVN0YXRlKHByb3BlcnRpZXMpO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgTW92ZVN0YXRlIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV9IG1lc3NhZ2UgTW92ZVN0YXRlIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJmcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgNSA9Ki8xMykuZmxvYXQobWVzc2FnZS5mcm9tUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJmcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgNSA9Ki8yMSkuZmxvYXQobWVzc2FnZS5mcm9tUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLnRvUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA0LCB3aXJlVHlwZSA1ID0qLzM3KS5mbG9hdChtZXNzYWdlLnRvUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwic3RhcnRUaW1lXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA1LCB3aXJlVHlwZSAwID0qLzQwKS51aW50NjQobWVzc2FnZS5zdGFydFRpbWUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgTW92ZVN0YXRlIG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZS52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLklNb3ZlU3RhdGV9IG1lc3NhZ2UgTW92ZVN0YXRlIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogRGVjb2RlcyBhIE1vdmVTdGF0ZSBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQuVXNlckluZm8uTW92ZVN0YXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmZyb21Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5mcm9tUG9zWSA9IHJlYWRlci5mbG9hdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudG9Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIDQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50b1Bvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgNTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IHJlYWRlci51aW50NjQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBEZWNvZGVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gTW92ZVN0YXRlXG4gICAgICAgICAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIFZlcmlmaWVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UuZnJvbVBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiZnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UuZnJvbVBvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiZnJvbVBvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZS5mcm9tUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJmcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5mcm9tUG9zWSAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJmcm9tUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UudG9Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInRvUG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UudG9Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInRvUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnN0YXJ0VGltZSkgJiYgIShtZXNzYWdlLnN0YXJ0VGltZSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5zdGFydFRpbWUubG93KSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5zdGFydFRpbWUuaGlnaCkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0YXJ0VGltZTogaW50ZWdlcnxMb25nIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBDcmVhdGVzIGEgTW92ZVN0YXRlIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgICAgICAgICAqIEBtZW1iZXJvZiBtc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHttc2cuV2hvRWxzZUlzSGVyZVJlc3VsdC5Vc2VySW5mby5Nb3ZlU3RhdGV9IE1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JqZWN0LmZyb21Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmZyb21Qb3NYID0gTnVtYmVyKG9iamVjdC5mcm9tUG9zWCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3QuZnJvbVBvc1kgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuZnJvbVBvc1kgPSBOdW1iZXIob2JqZWN0LmZyb21Qb3NZKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9iamVjdC50b1Bvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UudG9Qb3NYID0gTnVtYmVyKG9iamVjdC50b1Bvc1gpO1xuICAgICAgICAgICAgICAgICAgICBpZiAob2JqZWN0LnRvUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50b1Bvc1kgPSBOdW1iZXIob2JqZWN0LnRvUG9zWSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvYmplY3Quc3RhcnRUaW1lICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAobWVzc2FnZS5zdGFydFRpbWUgPSAkdXRpbC5Mb25nLmZyb21WYWx1ZShvYmplY3Quc3RhcnRUaW1lKSkudW5zaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAodHlwZW9mIG9iamVjdC5zdGFydFRpbWUgPT09IFwic3RyaW5nXCIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5zdGFydFRpbWUgPSBwYXJzZUludChvYmplY3Quc3RhcnRUaW1lLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0VGltZSA9PT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IG9iamVjdC5zdGFydFRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0LnN0YXJ0VGltZSA9PT0gXCJvYmplY3RcIilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0YXJ0VGltZSA9IG5ldyAkdXRpbC5Mb25nQml0cyhvYmplY3Quc3RhcnRUaW1lLmxvdyA+Pj4gMCwgb2JqZWN0LnN0YXJ0VGltZS5oaWdoID4+PiAwKS50b051bWJlcih0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIE1vdmVTdGF0ZSBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge21zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZX0gbWVzc2FnZSBNb3ZlU3RhdGVcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIE1vdmVTdGF0ZS50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QuZnJvbVBvc1ggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NZID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdC50b1Bvc1ggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnRvUG9zWSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsb25nID0gbmV3ICR1dGlsLkxvbmcoMCwgMCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IGxvbmcudG9TdHJpbmcoKSA6IG9wdGlvbnMubG9uZ3MgPT09IE51bWJlciA/IGxvbmcudG9OdW1iZXIoKSA6IGxvbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3Quc3RhcnRUaW1lID0gb3B0aW9ucy5sb25ncyA9PT0gU3RyaW5nID8gXCIwXCIgOiAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLmZyb21Qb3NYKSA/IFN0cmluZyhtZXNzYWdlLmZyb21Qb3NYKSA6IG1lc3NhZ2UuZnJvbVBvc1g7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLmZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcImZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LmZyb21Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLmZyb21Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLmZyb21Qb3NZKSA6IG1lc3NhZ2UuZnJvbVBvc1k7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QudG9Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnRvUG9zWCkgPyBTdHJpbmcobWVzc2FnZS50b1Bvc1gpIDogbWVzc2FnZS50b1Bvc1g7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0b1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QudG9Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnRvUG9zWSkgPyBTdHJpbmcobWVzc2FnZS50b1Bvc1kpIDogbWVzc2FnZS50b1Bvc1k7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2Uuc3RhcnRUaW1lID09PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iamVjdC5zdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyBTdHJpbmcobWVzc2FnZS5zdGFydFRpbWUpIDogbWVzc2FnZS5zdGFydFRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqZWN0LnN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/ICR1dGlsLkxvbmcucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobWVzc2FnZS5zdGFydFRpbWUpIDogb3B0aW9ucy5sb25ncyA9PT0gTnVtYmVyID8gbmV3ICR1dGlsLkxvbmdCaXRzKG1lc3NhZ2Uuc3RhcnRUaW1lLmxvdyA+Pj4gMCwgbWVzc2FnZS5zdGFydFRpbWUuaGlnaCA+Pj4gMCkudG9OdW1iZXIodHJ1ZSkgOiBtZXNzYWdlLnN0YXJ0VGltZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQ29udmVydHMgdGhpcyBNb3ZlU3RhdGUgdG8gSlNPTi5cbiAgICAgICAgICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAgICAgICAgICogQG1lbWJlcm9mIG1zZy5XaG9FbHNlSXNIZXJlUmVzdWx0LlVzZXJJbmZvLk1vdmVTdGF0ZVxuICAgICAgICAgICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICBNb3ZlU3RhdGUucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBNb3ZlU3RhdGU7XG4gICAgICAgICAgICB9KSgpO1xuXG4gICAgICAgICAgICByZXR1cm4gVXNlckluZm87XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgcmV0dXJuIFdob0Vsc2VJc0hlcmVSZXN1bHQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyTW92ZVRvQ21kID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlck1vdmVUb0NtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAaW50ZXJmYWNlIElVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1hdIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1ldIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NZXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlVG9Qb3NYXSBVc2VyTW92ZVRvQ21kIG1vdmVUb1Bvc1hcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW21vdmVUb1Bvc1ldIFVzZXJNb3ZlVG9DbWQgbW92ZVRvUG9zWVxuICAgICAgICAgKi9cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29uc3RydWN0cyBhIG5ldyBVc2VyTW92ZVRvQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJNb3ZlVG9DbWQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBjb25zdHJ1Y3RvclxuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlck1vdmVUb0NtZChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9DbWQgbW92ZUZyb21Qb3NYLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVGcm9tUG9zWFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvQ21kLnByb3RvdHlwZS5tb3ZlRnJvbVBvc1ggPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvQ21kIG1vdmVGcm9tUG9zWS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBtb3ZlRnJvbVBvc1lcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5wcm90b3R5cGUubW92ZUZyb21Qb3NZID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb0NtZCBtb3ZlVG9Qb3NYLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVUb1Bvc1hcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5wcm90b3R5cGUubW92ZVRvUG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9DbWQgbW92ZVRvUG9zWS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBtb3ZlVG9Qb3NZXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQucHJvdG90eXBlLm1vdmVUb1Bvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJNb3ZlVG9DbWQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyTW92ZVRvQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb0NtZH0gVXNlck1vdmVUb0NtZCBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyTW92ZVRvQ21kKHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlck1vdmVUb0NtZCBtZXNzYWdlLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlck1vdmVUb0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZH0gbWVzc2FnZSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlRnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSA1ID0qLzEzKS5mbG9hdChtZXNzYWdlLm1vdmVGcm9tUG9zWCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDUgPSovMjEpLmZsb2F0KG1lc3NhZ2UubW92ZUZyb21Qb3NZKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1ggIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLm1vdmVUb1Bvc1gpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDQsIHdpcmVUeXBlIDUgPSovMzcpLmZsb2F0KG1lc3NhZ2UubW92ZVRvUG9zWSk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlck1vdmVUb0NtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlck1vdmVUb0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlck1vdmVUb0NtZH0gbWVzc2FnZSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJNb3ZlVG9DbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvQ21kfSBVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlck1vdmVUb0NtZCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVGcm9tUG9zWCA9IHJlYWRlci5mbG9hdCgpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NZID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgNDpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NZID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb0NtZH0gVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlck1vdmVUb0NtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb0NtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlRnJvbVBvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVGcm9tUG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVGcm9tUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlLm1vdmVUb1Bvc1ggIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVUb1Bvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlVG9Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlVG9Qb3NZOiBudW1iZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgVXNlck1vdmVUb0NtZCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvQ21kfSBVc2VyTW92ZVRvQ21kXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvQ21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyTW92ZVRvQ21kKVxuICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICBsZXQgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlck1vdmVUb0NtZCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlRnJvbVBvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVGcm9tUG9zWCA9IE51bWJlcihvYmplY3QubW92ZUZyb21Qb3NYKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZUZyb21Qb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgPSBOdW1iZXIob2JqZWN0Lm1vdmVGcm9tUG9zWSk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVUb1Bvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1ggPSBOdW1iZXIob2JqZWN0Lm1vdmVUb1Bvc1gpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlVG9Qb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NZID0gTnVtYmVyKG9iamVjdC5tb3ZlVG9Qb3NZKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyTW92ZVRvQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJNb3ZlVG9DbWR9IG1lc3NhZ2UgVXNlck1vdmVUb0NtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpIHtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NYID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NZID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVUb1Bvc1kgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVGcm9tUG9zWCkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlRnJvbVBvc1gpIDogbWVzc2FnZS5tb3ZlRnJvbVBvc1g7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlRnJvbVBvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZUZyb21Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1kgPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2UubW92ZUZyb21Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVGcm9tUG9zWSkgOiBtZXNzYWdlLm1vdmVGcm9tUG9zWTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWCA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlVG9Qb3NYKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVUb1Bvc1gpIDogbWVzc2FnZS5tb3ZlVG9Qb3NYO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NZXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlVG9Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVUb1Bvc1kpID8gU3RyaW5nKG1lc3NhZ2UubW92ZVRvUG9zWSkgOiBtZXNzYWdlLm1vdmVUb1Bvc1k7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJNb3ZlVG9DbWQgdG8gSlNPTi5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvSlNPTlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9DbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9DbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyTW92ZVRvQ21kO1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlck1vdmVUb1Jlc3VsdCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJNb3ZlVG9SZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbbW92ZVVzZXJJZF0gVXNlck1vdmVUb1Jlc3VsdCBtb3ZlVXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1hdIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlRnJvbVBvc1ldIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NZXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFttb3ZlVG9Qb3NYXSBVc2VyTW92ZVRvUmVzdWx0IG1vdmVUb1Bvc1hcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW21vdmVUb1Bvc1ldIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZVRvUG9zWVxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxMb25nfG51bGx9IFttb3ZlU3RhcnRUaW1lXSBVc2VyTW92ZVRvUmVzdWx0IG1vdmVTdGFydFRpbWVcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlck1vdmVUb1Jlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyTW92ZVRvUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJNb3ZlVG9SZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvUmVzdWx0IG1vdmVVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZVVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb1Jlc3VsdCBtb3ZlRnJvbVBvc1guXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZUZyb21Qb3NYXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQucHJvdG90eXBlLm1vdmVGcm9tUG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZUZyb21Qb3NZLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVGcm9tUG9zWVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlRnJvbVBvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyTW92ZVRvUmVzdWx0IG1vdmVUb1Bvc1guXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gbW92ZVRvUG9zWFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS5tb3ZlVG9Qb3NYID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlck1vdmVUb1Jlc3VsdCBtb3ZlVG9Qb3NZLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IG1vdmVUb1Bvc1lcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC5wcm90b3R5cGUubW92ZVRvUG9zWSA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJNb3ZlVG9SZXN1bHQgbW92ZVN0YXJ0VGltZS5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfExvbmd9IG1vdmVTdGFydFRpbWVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC5wcm90b3R5cGUubW92ZVN0YXJ0VGltZSA9ICR1dGlsLkxvbmcgPyAkdXRpbC5Mb25nLmZyb21CaXRzKDAsMCx0cnVlKSA6IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlck1vdmVUb1Jlc3VsdCBpbnN0YW5jZSB1c2luZyB0aGUgc3BlY2lmaWVkIHByb3BlcnRpZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBjcmVhdGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyTW92ZVRvUmVzdWx0fSBVc2VyTW92ZVRvUmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJNb3ZlVG9SZXN1bHQocHJvcGVydGllcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyTW92ZVRvUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyTW92ZVRvUmVzdWx0fSBtZXNzYWdlIFVzZXJNb3ZlVG9SZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LmVuY29kZSA9IGZ1bmN0aW9uIGVuY29kZShtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIGlmICghd3JpdGVyKVxuICAgICAgICAgICAgICAgIHdyaXRlciA9ICRXcml0ZXIuY3JlYXRlKCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS5tb3ZlVXNlcklkKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVGcm9tUG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZUZyb21Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgNSA9Ki8yMSkuZmxvYXQobWVzc2FnZS5tb3ZlRnJvbVBvc1gpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlRnJvbVBvc1lcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAzLCB3aXJlVHlwZSA1ID0qLzI5KS5mbG9hdChtZXNzYWdlLm1vdmVGcm9tUG9zWSk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJtb3ZlVG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgNCwgd2lyZVR5cGUgNSA9Ki8zNykuZmxvYXQobWVzc2FnZS5tb3ZlVG9Qb3NYKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcIm1vdmVUb1Bvc1lcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCA1LCB3aXJlVHlwZSA1ID0qLzQ1KS5mbG9hdChtZXNzYWdlLm1vdmVUb1Bvc1kpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwibW92ZVN0YXJ0VGltZVwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDYsIHdpcmVUeXBlIDAgPSovNDgpLnVpbnQ2NChtZXNzYWdlLm1vdmVTdGFydFRpbWUpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJNb3ZlVG9SZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJNb3ZlVG9SZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJNb3ZlVG9SZXN1bHR9IG1lc3NhZ2UgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb1Jlc3VsdH0gVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJNb3ZlVG9SZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVXNlcklkID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NYID0gcmVhZGVyLmZsb2F0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA0OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1ggPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA1OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVUb1Bvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA2OlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVTdGFydFRpbWUgPSByZWFkZXIudWludDY0KCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlck1vdmVUb1Jlc3VsdH0gVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlck1vdmVUb1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlck1vdmVUb1Jlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlVXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwibW92ZVVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWFwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZUZyb21Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlRnJvbVBvc1g6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlRnJvbVBvc1k6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVRvUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlVG9Qb3NYXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlVG9Qb3NYICE9PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJtb3ZlVG9Qb3NYOiBudW1iZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UubW92ZVRvUG9zWSAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwibW92ZVRvUG9zWTogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlU3RhcnRUaW1lICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVTdGFydFRpbWVcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlU3RhcnRUaW1lKSAmJiAhKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAmJiAkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmxvdykgJiYgJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UubW92ZVN0YXJ0VGltZS5oaWdoKSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIm1vdmVTdGFydFRpbWU6IGludGVnZXJ8TG9uZyBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyTW92ZVRvUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJNb3ZlVG9SZXN1bHR9IFVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJNb3ZlVG9SZXN1bHQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJNb3ZlVG9SZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyTW92ZVRvUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVVc2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLm1vdmVVc2VySWQgPSBvYmplY3QubW92ZVVzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZUZyb21Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlRnJvbVBvc1ggPSBOdW1iZXIob2JqZWN0Lm1vdmVGcm9tUG9zWCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVGcm9tUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZUZyb21Qb3NZID0gTnVtYmVyKG9iamVjdC5tb3ZlRnJvbVBvc1kpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5tb3ZlVG9Qb3NYICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlVG9Qb3NYID0gTnVtYmVyKG9iamVjdC5tb3ZlVG9Qb3NYKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QubW92ZVRvUG9zWSAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZVRvUG9zWSA9IE51bWJlcihvYmplY3QubW92ZVRvUG9zWSk7XG4gICAgICAgICAgICBpZiAob2JqZWN0Lm1vdmVTdGFydFRpbWUgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBpZiAoJHV0aWwuTG9uZylcbiAgICAgICAgICAgICAgICAgICAgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSA9ICR1dGlsLkxvbmcuZnJvbVZhbHVlKG9iamVjdC5tb3ZlU3RhcnRUaW1lKSkudW5zaWduZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXJ0VGltZSA9PT0gXCJzdHJpbmdcIilcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID0gcGFyc2VJbnQob2JqZWN0Lm1vdmVTdGFydFRpbWUsIDEwKTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2Ygb2JqZWN0Lm1vdmVTdGFydFRpbWUgPT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UubW92ZVN0YXJ0VGltZSA9IG9iamVjdC5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHR5cGVvZiBvYmplY3QubW92ZVN0YXJ0VGltZSA9PT0gXCJvYmplY3RcIilcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID0gbmV3ICR1dGlsLkxvbmdCaXRzKG9iamVjdC5tb3ZlU3RhcnRUaW1lLmxvdyA+Pj4gMCwgb2JqZWN0Lm1vdmVTdGFydFRpbWUuaGlnaCA+Pj4gMCkudG9OdW1iZXIodHJ1ZSk7XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlck1vdmVUb1Jlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyTW92ZVRvUmVzdWx0fSBtZXNzYWdlIFVzZXJNb3ZlVG9SZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVVc2VySWQgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1ggPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlRnJvbVBvc1kgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC5tb3ZlVG9Qb3NYID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWSA9IDA7XG4gICAgICAgICAgICAgICAgaWYgKCR1dGlsLkxvbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGxvbmcgPSBuZXcgJHV0aWwuTG9uZygwLCAwLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVTdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyBsb25nLnRvU3RyaW5nKCkgOiBvcHRpb25zLmxvbmdzID09PSBOdW1iZXIgPyBsb25nLnRvTnVtYmVyKCkgOiBsb25nO1xuICAgICAgICAgICAgICAgIH0gZWxzZVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IFwiMFwiIDogMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVVzZXJJZCA9IG1lc3NhZ2UubW92ZVVzZXJJZDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVGcm9tUG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlRnJvbVBvc1hcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVGcm9tUG9zWCA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlRnJvbVBvc1gpID8gU3RyaW5nKG1lc3NhZ2UubW92ZUZyb21Qb3NYKSA6IG1lc3NhZ2UubW92ZUZyb21Qb3NYO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZUZyb21Qb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVGcm9tUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZUZyb21Qb3NZID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLm1vdmVGcm9tUG9zWSkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlRnJvbVBvc1kpIDogbWVzc2FnZS5tb3ZlRnJvbVBvc1k7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5tb3ZlVG9Qb3NYICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcIm1vdmVUb1Bvc1hcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVUb1Bvc1ggPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2UubW92ZVRvUG9zWCkgPyBTdHJpbmcobWVzc2FnZS5tb3ZlVG9Qb3NYKSA6IG1lc3NhZ2UubW92ZVRvUG9zWDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLm1vdmVUb1Bvc1kgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwibW92ZVRvUG9zWVwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QubW92ZVRvUG9zWSA9IG9wdGlvbnMuanNvbiAmJiAhaXNGaW5pdGUobWVzc2FnZS5tb3ZlVG9Qb3NZKSA/IFN0cmluZyhtZXNzYWdlLm1vdmVUb1Bvc1kpIDogbWVzc2FnZS5tb3ZlVG9Qb3NZO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJtb3ZlU3RhcnRUaW1lXCIpKVxuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lID09PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgICAgICAgICBvYmplY3QubW92ZVN0YXJ0VGltZSA9IG9wdGlvbnMubG9uZ3MgPT09IFN0cmluZyA/IFN0cmluZyhtZXNzYWdlLm1vdmVTdGFydFRpbWUpIDogbWVzc2FnZS5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgb2JqZWN0Lm1vdmVTdGFydFRpbWUgPSBvcHRpb25zLmxvbmdzID09PSBTdHJpbmcgPyAkdXRpbC5Mb25nLnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG1lc3NhZ2UubW92ZVN0YXJ0VGltZSkgOiBvcHRpb25zLmxvbmdzID09PSBOdW1iZXIgPyBuZXcgJHV0aWwuTG9uZ0JpdHMobWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmxvdyA+Pj4gMCwgbWVzc2FnZS5tb3ZlU3RhcnRUaW1lLmhpZ2ggPj4+IDApLnRvTnVtYmVyKHRydWUpIDogbWVzc2FnZS5tb3ZlU3RhcnRUaW1lO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyTW92ZVRvUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyTW92ZVRvUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyTW92ZVRvUmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlck1vdmVUb1Jlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJRdWl0UmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3F1aXRVc2VySWRdIFVzZXJRdWl0UmVzdWx0IHF1aXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlclF1aXRSZXN1bHQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyUXVpdFJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyUXVpdFJlc3VsdChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJRdWl0UmVzdWx0IHF1aXRVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gcXVpdFVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQucHJvdG90eXBlLnF1aXRVc2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJRdWl0UmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyUXVpdFJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyUXVpdFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnF1aXRVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInF1aXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnF1aXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyUXVpdFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyUXVpdFJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyUXVpdFJlc3VsdH0gVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlclF1aXRSZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5xdWl0VXNlcklkID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5xdWl0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInF1aXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS5xdWl0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwicXVpdFVzZXJJZDogaW50ZWdlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyUXVpdFJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclF1aXRSZXN1bHR9IFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyUXVpdFJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlclF1aXRSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyUXVpdFJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5xdWl0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5xdWl0VXNlcklkID0gb2JqZWN0LnF1aXRVc2VySWQgPj4+IDA7XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlclF1aXRSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyUXVpdFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJRdWl0UmVzdWx0fSBtZXNzYWdlIFVzZXJRdWl0UmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclF1aXRSZXN1bHQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdChtZXNzYWdlLCBvcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMpXG4gICAgICAgICAgICAgICAgb3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgbGV0IG9iamVjdCA9IHt9O1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuZGVmYXVsdHMpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnF1aXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UucXVpdFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJxdWl0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5xdWl0VXNlcklkID0gbWVzc2FnZS5xdWl0VXNlcklkO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyUXVpdFJlc3VsdCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclF1aXRSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJRdWl0UmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlclF1aXRSZXN1bHQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyU3RvcENtZCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJTdG9wQ21kXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdG9wQ21kLlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN0b3BDbWRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcENtZD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN0b3BDbWQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJTdG9wQ21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kIGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcENtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyU3RvcENtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJTdG9wQ21kIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyU3RvcENtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wQ21kfSBtZXNzYWdlIFVzZXJTdG9wQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIHJldHVybiB3cml0ZXI7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyU3RvcENtZCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlclN0b3BDbWQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcENtZH0gbWVzc2FnZSBVc2VyU3RvcENtZCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmVuY29kZShtZXNzYWdlLCB3cml0ZXIpLmxkZWxpbSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdG9wQ21kKCk7XG4gICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgIGxldCB0YWcgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZWFkZXIuc2tpcFR5cGUodGFnICYgNyk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlciwgbGVuZ3RoIGRlbGltaXRlZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BDbWR9IFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlclN0b3BDbWQgbWVzc2FnZS5cbiAgICAgICAgICogQGZ1bmN0aW9uIHZlcmlmeVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gbWVzc2FnZSBQbGFpbiBvYmplY3QgdG8gdmVyaWZ5XG4gICAgICAgICAqIEByZXR1cm5zIHtzdHJpbmd8bnVsbH0gYG51bGxgIGlmIHZhbGlkLCBvdGhlcndpc2UgdGhlIHJlYXNvbiB3aHkgaXQgaXMgbm90XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcENtZC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJTdG9wQ21kIG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3RvcENtZH0gVXNlclN0b3BDbWRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyU3RvcENtZClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgcmV0dXJuIG5ldyAkcm9vdC5tc2cuVXNlclN0b3BDbWQoKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIHBsYWluIG9iamVjdCBmcm9tIGEgVXNlclN0b3BDbWQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcENtZFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLlVzZXJTdG9wQ21kfSBtZXNzYWdlIFVzZXJTdG9wQ21kXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BDbWQudG9PYmplY3QgPSBmdW5jdGlvbiB0b09iamVjdCgpIHtcbiAgICAgICAgICAgIHJldHVybiB7fTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyU3RvcENtZCB0byBKU09OLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9KU09OXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BDbWRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gSlNPTiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wQ21kLnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlclN0b3BDbWQ7XG4gICAgfSkoKTtcblxuICAgIG1zZy5Vc2VyU3RvcFJlc3VsdCA9IChmdW5jdGlvbigpIHtcblxuICAgICAgICAvKipcbiAgICAgICAgICogUHJvcGVydGllcyBvZiBhIFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wVXNlcklkXSBVc2VyU3RvcFJlc3VsdCBzdG9wVXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wQXRQb3NYXSBVc2VyU3RvcFJlc3VsdCBzdG9wQXRQb3NYXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdG9wQXRQb3NZXSBVc2VyU3RvcFJlc3VsdCBzdG9wQXRQb3NZXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdG9wUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcFJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN0b3BSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyU3RvcFJlc3VsdCBzdG9wVXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHN0b3BVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LnByb3RvdHlwZS5zdG9wVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlclN0b3BSZXN1bHQgc3RvcEF0UG9zWC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBzdG9wQXRQb3NYXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5wcm90b3R5cGUuc3RvcEF0UG9zWCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJTdG9wUmVzdWx0IHN0b3BBdFBvc1kuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gc3RvcEF0UG9zWVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQucHJvdG90eXBlLnN0b3BBdFBvc1kgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJTdG9wUmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wUmVzdWx0PX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0IGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyU3RvcFJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyU3RvcFJlc3VsdC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJTdG9wUmVzdWx0fSBtZXNzYWdlIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0b3BVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInN0b3BVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnN0b3BVc2VySWQpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwic3RvcEF0UG9zWFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDUgPSovMjEpLmZsb2F0KG1lc3NhZ2Uuc3RvcEF0UG9zWCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJzdG9wQXRQb3NZXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMywgd2lyZVR5cGUgNSA9Ki8yOSkuZmxvYXQobWVzc2FnZS5zdG9wQXRQb3NZKTtcbiAgICAgICAgICAgIHJldHVybiB3cml0ZXI7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIEVuY29kZXMgdGhlIHNwZWNpZmllZCBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlLCBsZW5ndGggZGVsaW1pdGVkLiBEb2VzIG5vdCBpbXBsaWNpdGx5IHtAbGluayBtc2cuVXNlclN0b3BSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3RvcFJlc3VsdH0gbWVzc2FnZSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LmVuY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZChtZXNzYWdlLCB3cml0ZXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmVuY29kZShtZXNzYWdlLCB3cml0ZXIpLmxkZWxpbSgpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBEZWNvZGVzIGEgVXNlclN0b3BSZXN1bHQgbWVzc2FnZSBmcm9tIHRoZSBzcGVjaWZpZWQgcmVhZGVyIG9yIGJ1ZmZlci5cbiAgICAgICAgICogQGZ1bmN0aW9uIGRlY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEB0aHJvd3Mge0Vycm9yfSBJZiB0aGUgcGF5bG9hZCBpcyBub3QgYSByZWFkZXIgb3IgdmFsaWQgYnVmZmVyXG4gICAgICAgICAqIEB0aHJvd3MgeyRwcm90b2J1Zi51dGlsLlByb3RvY29sRXJyb3J9IElmIHJlcXVpcmVkIGZpZWxkcyBhcmUgbWlzc2luZ1xuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdG9wUmVzdWx0KCk7XG4gICAgICAgICAgICB3aGlsZSAocmVhZGVyLnBvcyA8IGVuZCkge1xuICAgICAgICAgICAgICAgIGxldCB0YWcgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgc3dpdGNoICh0YWcgPj4+IDMpIHtcbiAgICAgICAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3RvcFVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1ggPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1kgPSByZWFkZXIuZmxvYXQoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgcmVhZGVyLnNraXBUeXBlKHRhZyAmIDcpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbWVzc2FnZTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJTdG9wUmVzdWx0fSBVc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdG9wUmVzdWx0LmRlY29kZURlbGltaXRlZCA9IGZ1bmN0aW9uIGRlY29kZURlbGltaXRlZChyZWFkZXIpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9IG5ldyAkUmVhZGVyKHJlYWRlcik7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5kZWNvZGUocmVhZGVyLCByZWFkZXIudWludDMyKCkpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBWZXJpZmllcyBhIFVzZXJTdG9wUmVzdWx0IG1lc3NhZ2UuXG4gICAgICAgICAqIEBmdW5jdGlvbiB2ZXJpZnlcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3RvcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN0b3BSZXN1bHQudmVyaWZ5ID0gZnVuY3Rpb24gdmVyaWZ5KG1lc3NhZ2UpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgbWVzc2FnZSAhPT0gXCJvYmplY3RcIiB8fCBtZXNzYWdlID09PSBudWxsKVxuICAgICAgICAgICAgICAgIHJldHVybiBcIm9iamVjdCBleHBlY3RlZFwiO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2Uuc3RvcFVzZXJJZCkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0b3BVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN0b3BBdFBvc1ggIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwic3RvcEF0UG9zWFwiKSlcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPT0gXCJudW1iZXJcIilcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwic3RvcEF0UG9zWDogbnVtYmVyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN0b3BBdFBvc1lcIikpXG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlLnN0b3BBdFBvc1kgIT09IFwibnVtYmVyXCIpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInN0b3BBdFBvc1k6IG51bWJlciBleHBlY3RlZFwiO1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlIGZyb20gYSBwbGFpbiBvYmplY3QuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIHRoZWlyIHJlc3BlY3RpdmUgaW50ZXJuYWwgdHlwZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBmcm9tT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlclN0b3BSZXN1bHR9IFVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlclN0b3BSZXN1bHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgICAgIGxldCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyU3RvcFJlc3VsdCgpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5zdG9wVXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zdG9wVXNlcklkID0gb2JqZWN0LnN0b3BVc2VySWQgPj4+IDA7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnN0b3BBdFBvc1ggIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnN0b3BBdFBvc1ggPSBOdW1iZXIob2JqZWN0LnN0b3BBdFBvc1gpO1xuICAgICAgICAgICAgaWYgKG9iamVjdC5zdG9wQXRQb3NZICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zdG9wQXRQb3NZID0gTnVtYmVyKG9iamVjdC5zdG9wQXRQb3NZKTtcbiAgICAgICAgICAgIHJldHVybiBtZXNzYWdlO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgcGxhaW4gb2JqZWN0IGZyb20gYSBVc2VyU3RvcFJlc3VsdCBtZXNzYWdlLiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byBvdGhlciB0eXBlcyBpZiBzcGVjaWZpZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b09iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuVXNlclN0b3BSZXN1bHR9IG1lc3NhZ2UgVXNlclN0b3BSZXN1bHRcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuSUNvbnZlcnNpb25PcHRpb25zfSBbb3B0aW9uc10gQ29udmVyc2lvbiBvcHRpb25zXG4gICAgICAgICAqIEByZXR1cm5zIHtPYmplY3QuPHN0cmluZywqPn0gUGxhaW4gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5kZWZhdWx0cykge1xuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wVXNlcklkID0gMDtcbiAgICAgICAgICAgICAgICBvYmplY3Quc3RvcEF0UG9zWCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnN0b3BBdFBvc1kgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wVXNlcklkID0gbWVzc2FnZS5zdG9wVXNlcklkO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RvcEF0UG9zWCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJzdG9wQXRQb3NYXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5zdG9wQXRQb3NYID0gb3B0aW9ucy5qc29uICYmICFpc0Zpbml0ZShtZXNzYWdlLnN0b3BBdFBvc1gpID8gU3RyaW5nKG1lc3NhZ2Uuc3RvcEF0UG9zWCkgOiBtZXNzYWdlLnN0b3BBdFBvc1g7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdG9wQXRQb3NZICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN0b3BBdFBvc1lcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnN0b3BBdFBvc1kgPSBvcHRpb25zLmpzb24gJiYgIWlzRmluaXRlKG1lc3NhZ2Uuc3RvcEF0UG9zWSkgPyBTdHJpbmcobWVzc2FnZS5zdG9wQXRQb3NZKSA6IG1lc3NhZ2Uuc3RvcEF0UG9zWTtcbiAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnZlcnRzIHRoaXMgVXNlclN0b3BSZXN1bHQgdG8gSlNPTi5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvSlNPTlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJTdG9wUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3RvcFJlc3VsdC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29uc3RydWN0b3IudG9PYmplY3QodGhpcywgJHByb3RvYnVmLnV0aWwudG9KU09OT3B0aW9ucyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIFVzZXJTdG9wUmVzdWx0O1xuICAgIH0pKCk7XG5cbiAgICBtc2cuVXNlckF0dGtDbWQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyQXR0a0NtZC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAaW50ZXJmYWNlIElVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAcHJvcGVydHkge251bWJlcnxudWxsfSBbdGFyZ2V0VXNlcklkXSBVc2VyQXR0a0NtZCB0YXJnZXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlckF0dGtDbWQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGNsYXNzZGVzYyBSZXByZXNlbnRzIGEgVXNlckF0dGtDbWQuXG4gICAgICAgICAqIEBpbXBsZW1lbnRzIElVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBVc2VyQXR0a0NtZChwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICBpZiAocHJvcGVydGllcylcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBrZXlzID0gT2JqZWN0LmtleXMocHJvcGVydGllcyksIGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7ICsraSlcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3BlcnRpZXNba2V5c1tpXV0gIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNba2V5c1tpXV0gPSBwcm9wZXJ0aWVzW2tleXNbaV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVzZXJBdHRrQ21kIHRhcmdldFVzZXJJZC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSB0YXJnZXRVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnByb3RvdHlwZS50YXJnZXRVc2VySWQgPSAwO1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgbmV3IFVzZXJBdHRrQ21kIGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kPX0gW3Byb3BlcnRpZXNdIFByb3BlcnRpZXMgdG8gc2V0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckF0dGtDbWR9IFVzZXJBdHRrQ21kIGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5jcmVhdGUgPSBmdW5jdGlvbiBjcmVhdGUocHJvcGVydGllcykge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVc2VyQXR0a0NtZChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJBdHRrQ21kIG1lc3NhZ2UuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyQXR0a0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kfSBtZXNzYWdlIFVzZXJBdHRrQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS50YXJnZXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJBdHRrQ21kIG1lc3NhZ2UsIGxlbmd0aCBkZWxpbWl0ZWQuIERvZXMgbm90IGltcGxpY2l0bHkge0BsaW5rIG1zZy5Vc2VyQXR0a0NtZC52ZXJpZnl8dmVyaWZ5fSBtZXNzYWdlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGVuY29kZURlbGltaXRlZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJBdHRrQ21kfSBtZXNzYWdlIFVzZXJBdHRrQ21kIG1lc3NhZ2Ugb3IgcGxhaW4gb2JqZWN0IHRvIGVuY29kZVxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5Xcml0ZXJ9IFt3cml0ZXJdIFdyaXRlciB0byBlbmNvZGUgdG9cbiAgICAgICAgICogQHJldHVybnMgeyRwcm90b2J1Zi5Xcml0ZXJ9IFdyaXRlclxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHBhcmFtIHtudW1iZXJ9IFtsZW5ndGhdIE1lc3NhZ2UgbGVuZ3RoIGlmIGtub3duIGJlZm9yZWhhbmRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a0NtZH0gVXNlckF0dGtDbWRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUocmVhZGVyLCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGlmICghKHJlYWRlciBpbnN0YW5jZW9mICRSZWFkZXIpKVxuICAgICAgICAgICAgICAgIHJlYWRlciA9ICRSZWFkZXIuY3JlYXRlKHJlYWRlcik7XG4gICAgICAgICAgICBsZXQgZW5kID0gbGVuZ3RoID09PSB1bmRlZmluZWQgPyByZWFkZXIubGVuIDogcmVhZGVyLnBvcyArIGxlbmd0aCwgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlckF0dGtDbWQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a0NtZH0gVXNlckF0dGtDbWRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a0NtZC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyQXR0a0NtZCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS50YXJnZXRVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ0YXJnZXRVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDcmVhdGVzIGEgVXNlckF0dGtDbWQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrQ21kXG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHtPYmplY3QuPHN0cmluZywqPn0gb2JqZWN0IFBsYWluIG9iamVjdFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJBdHRrQ21kfSBVc2VyQXR0a0NtZFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQuZnJvbU9iamVjdCA9IGZ1bmN0aW9uIGZyb21PYmplY3Qob2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAob2JqZWN0IGluc3RhbmNlb2YgJHJvb3QubXNnLlVzZXJBdHRrQ21kKVxuICAgICAgICAgICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgICAgICAgICBsZXQgbWVzc2FnZSA9IG5ldyAkcm9vdC5tc2cuVXNlckF0dGtDbWQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJBdHRrQ21kIG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtDbWRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyQXR0a0NtZH0gbWVzc2FnZSBVc2VyQXR0a0NtZFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrQ21kLnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKVxuICAgICAgICAgICAgICAgIG9iamVjdC50YXJnZXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJBdHRrQ21kIHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a0NtZFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtDbWQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyQXR0a0NtZDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJBdHRrUmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlckF0dGtSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW2F0dGtVc2VySWRdIFVzZXJBdHRrUmVzdWx0IGF0dGtVc2VySWRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlckF0dGtSZXN1bHQgdGFyZ2V0VXNlcklkXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJBdHRrUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJBdHRrUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyQXR0a1Jlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlckF0dGtSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyQXR0a1Jlc3VsdCBhdHRrVXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IGF0dGtVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnByb3RvdHlwZS5hdHRrVXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlckF0dGtSZXN1bHQgdGFyZ2V0VXNlcklkLlxuICAgICAgICAgKiBAbWVtYmVyIHtudW1iZXJ9IHRhcmdldFVzZXJJZFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJBdHRrUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtSZXN1bHQucHJvdG90eXBlLnRhcmdldFVzZXJJZCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlckF0dGtSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJBdHRrUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckF0dGtSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJBdHRrUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHR9IG1lc3NhZ2UgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuYXR0a1VzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwiYXR0a1VzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDEsIHdpcmVUeXBlIDAgPSovOCkudWludDMyKG1lc3NhZ2UuYXR0a1VzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChtZXNzYWdlLCBcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICB3cml0ZXIudWludDMyKC8qIGlkIDIsIHdpcmVUeXBlIDAgPSovMTYpLnVpbnQzMihtZXNzYWdlLnRhcmdldFVzZXJJZCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJBdHRrUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckF0dGtSZXN1bHR9IG1lc3NhZ2UgVXNlckF0dGtSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJBdHRrUmVzdWx0fSBVc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyQXR0a1Jlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmF0dGtVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyQXR0a1Jlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyQXR0a1Jlc3VsdC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyQXR0a1Jlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLmF0dGtVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwiYXR0a1VzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLmF0dGtVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJhdHRrVXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UudGFyZ2V0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidGFyZ2V0VXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyQXR0a1Jlc3VsdH0gVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyQXR0a1Jlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJBdHRrUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LmF0dGtVc2VySWQgIT0gbnVsbClcbiAgICAgICAgICAgICAgICBtZXNzYWdlLmF0dGtVc2VySWQgPSBvYmplY3QuYXR0a1VzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJBdHRrUmVzdWx0IG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckF0dGtSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyQXR0a1Jlc3VsdH0gbWVzc2FnZSBVc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJBdHRrUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LmF0dGtVc2VySWQgPSAwO1xuICAgICAgICAgICAgICAgIG9iamVjdC50YXJnZXRVc2VySWQgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UuYXR0a1VzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJhdHRrVXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIG9iamVjdC5hdHRrVXNlcklkID0gbWVzc2FnZS5hdHRrVXNlcklkO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJBdHRrUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyQXR0a1Jlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckF0dGtSZXN1bHQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyQXR0a1Jlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0ID0gKGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQcm9wZXJ0aWVzIG9mIGEgVXNlclN1YnRyYWN0SHBSZXN1bHQuXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2dcbiAgICAgICAgICogQGludGVyZmFjZSBJVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlclN1YnRyYWN0SHBSZXN1bHQgdGFyZ2V0VXNlcklkXG4gICAgICAgICAqIEBwcm9wZXJ0eSB7bnVtYmVyfG51bGx9IFtzdWJ0cmFjdEhwXSBVc2VyU3VidHJhY3RIcFJlc3VsdCBzdWJ0cmFjdEhwXG4gICAgICAgICAqL1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb25zdHJ1Y3RzIGEgbmV3IFVzZXJTdWJ0cmFjdEhwUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBjbGFzc2Rlc2MgUmVwcmVzZW50cyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGNvbnN0cnVjdG9yXG4gICAgICAgICAqIEBwYXJhbSB7bXNnLklVc2VyU3VidHJhY3RIcFJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gVXNlclN1YnRyYWN0SHBSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyU3VidHJhY3RIcFJlc3VsdCB0YXJnZXRVc2VySWQuXG4gICAgICAgICAqIEBtZW1iZXIge251bWJlcn0gdGFyZ2V0VXNlcklkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5wcm90b3R5cGUudGFyZ2V0VXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVXNlclN1YnRyYWN0SHBSZXN1bHQgc3VidHJhY3RIcC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSBzdWJ0cmFjdEhwXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQGluc3RhbmNlXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5wcm90b3R5cGUuc3VidHJhY3RIcCA9IDA7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBuZXcgVXNlclN1YnRyYWN0SHBSZXN1bHQgaW5zdGFuY2UgdXNpbmcgdGhlIHNwZWNpZmllZCBwcm9wZXJ0aWVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gY3JlYXRlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShwcm9wZXJ0aWVzKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVzZXJTdWJ0cmFjdEhwUmVzdWx0KHByb3BlcnRpZXMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHR9IG1lc3NhZ2UgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5lbmNvZGUgPSBmdW5jdGlvbiBlbmNvZGUobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICBpZiAoIXdyaXRlcilcbiAgICAgICAgICAgICAgICB3cml0ZXIgPSAkV3JpdGVyLmNyZWF0ZSgpO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgd3JpdGVyLnVpbnQzMigvKiBpZCAxLCB3aXJlVHlwZSAwID0qLzgpLnVpbnQzMihtZXNzYWdlLnRhcmdldFVzZXJJZCk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdWJ0cmFjdEhwICE9IG51bGwgJiYgT2JqZWN0Lmhhc093blByb3BlcnR5LmNhbGwobWVzc2FnZSwgXCJzdWJ0cmFjdEhwXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMiwgd2lyZVR5cGUgMCA9Ki8xNikudWludDMyKG1lc3NhZ2Uuc3VidHJhY3RIcCk7XG4gICAgICAgICAgICByZXR1cm4gd3JpdGVyO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBFbmNvZGVzIHRoZSBzcGVjaWZpZWQgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeXx2ZXJpZnl9IG1lc3NhZ2VzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlclN1YnRyYWN0SHBSZXN1bHR9IG1lc3NhZ2UgVXNlclN1YnRyYWN0SHBSZXN1bHQgbWVzc2FnZSBvciBwbGFpbiBvYmplY3QgdG8gZW5jb2RlXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLldyaXRlcn0gW3dyaXRlcl0gV3JpdGVyIHRvIGVuY29kZSB0b1xuICAgICAgICAgKiBAcmV0dXJucyB7JHByb3RvYnVmLldyaXRlcn0gV3JpdGVyXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5lbmNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWQobWVzc2FnZSwgd3JpdGVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5lbmNvZGUobWVzc2FnZSwgd3JpdGVyKS5sZGVsaW0oKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRGVjb2RlcyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLlJlYWRlcnxVaW50OEFycmF5fSByZWFkZXIgUmVhZGVyIG9yIGJ1ZmZlciB0byBkZWNvZGUgZnJvbVxuICAgICAgICAgKiBAcGFyYW0ge251bWJlcn0gW2xlbmd0aF0gTWVzc2FnZSBsZW5ndGggaWYga25vd24gYmVmb3JlaGFuZFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0fSBVc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmRlY29kZSA9IGZ1bmN0aW9uIGRlY29kZShyZWFkZXIsIGxlbmd0aCkge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gJFJlYWRlci5jcmVhdGUocmVhZGVyKTtcbiAgICAgICAgICAgIGxldCBlbmQgPSBsZW5ndGggPT09IHVuZGVmaW5lZCA/IHJlYWRlci5sZW4gOiByZWFkZXIucG9zICsgbGVuZ3RoLCBtZXNzYWdlID0gbmV3ICRyb290Lm1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdCgpO1xuICAgICAgICAgICAgd2hpbGUgKHJlYWRlci5wb3MgPCBlbmQpIHtcbiAgICAgICAgICAgICAgICBsZXQgdGFnID0gcmVhZGVyLnVpbnQzMigpO1xuICAgICAgICAgICAgICAgIHN3aXRjaCAodGFnID4+PiAzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAxOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnRhcmdldFVzZXJJZCA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAyOlxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN1YnRyYWN0SHAgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyU3VidHJhY3RIcFJlc3VsdCBtZXNzYWdlIGZyb20gdGhlIHNwZWNpZmllZCByZWFkZXIgb3IgYnVmZmVyLCBsZW5ndGggZGVsaW1pdGVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkXG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5SZWFkZXJ8VWludDhBcnJheX0gcmVhZGVyIFJlYWRlciBvciBidWZmZXIgdG8gZGVjb2RlIGZyb21cbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHRocm93cyB7RXJyb3J9IElmIHRoZSBwYXlsb2FkIGlzIG5vdCBhIHJlYWRlciBvciB2YWxpZCBidWZmZXJcbiAgICAgICAgICogQHRocm93cyB7JHByb3RvYnVmLnV0aWwuUHJvdG9jb2xFcnJvcn0gSWYgcmVxdWlyZWQgZmllbGRzIGFyZSBtaXNzaW5nXG4gICAgICAgICAqL1xuICAgICAgICBVc2VyU3VidHJhY3RIcFJlc3VsdC5kZWNvZGVEZWxpbWl0ZWQgPSBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWQocmVhZGVyKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSBuZXcgJFJlYWRlcihyZWFkZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGVjb2RlKHJlYWRlciwgcmVhZGVyLnVpbnQzMigpKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogVmVyaWZpZXMgYSBVc2VyU3VidHJhY3RIcFJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBtZXNzYWdlIFBsYWluIG9iamVjdCB0byB2ZXJpZnlcbiAgICAgICAgICogQHJldHVybnMge3N0cmluZ3xudWxsfSBgbnVsbGAgaWYgdmFsaWQsIG90aGVyd2lzZSB0aGUgcmVhc29uIHdoeSBpdCBpcyBub3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LnZlcmlmeSA9IGZ1bmN0aW9uIHZlcmlmeShtZXNzYWdlKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG1lc3NhZ2UgIT09IFwib2JqZWN0XCIgfHwgbWVzc2FnZSA9PT0gbnVsbClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJvYmplY3QgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgaWYgKCEkdXRpbC5pc0ludGVnZXIobWVzc2FnZS50YXJnZXRVc2VySWQpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJ0YXJnZXRVc2VySWQ6IGludGVnZXIgZXhwZWN0ZWRcIjtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnN1YnRyYWN0SHAgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwic3VidHJhY3RIcFwiKSlcbiAgICAgICAgICAgICAgICBpZiAoISR1dGlsLmlzSW50ZWdlcihtZXNzYWdlLnN1YnRyYWN0SHApKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJzdWJ0cmFjdEhwOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UgZnJvbSBhIHBsYWluIG9iamVjdC4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gdGhlaXIgcmVzcGVjdGl2ZSBpbnRlcm5hbCB0eXBlcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGZyb21PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG9iamVjdCBQbGFpbiBvYmplY3RcbiAgICAgICAgICogQHJldHVybnMge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LmZyb21PYmplY3QgPSBmdW5jdGlvbiBmcm9tT2JqZWN0KG9iamVjdCkge1xuICAgICAgICAgICAgaWYgKG9iamVjdCBpbnN0YW5jZW9mICRyb290Lm1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJTdWJ0cmFjdEhwUmVzdWx0KCk7XG4gICAgICAgICAgICBpZiAob2JqZWN0LnRhcmdldFVzZXJJZCAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2UudGFyZ2V0VXNlcklkID0gb2JqZWN0LnRhcmdldFVzZXJJZCA+Pj4gMDtcbiAgICAgICAgICAgIGlmIChvYmplY3Quc3VidHJhY3RIcCAhPSBudWxsKVxuICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3VidHJhY3RIcCA9IG9iamVjdC5zdWJ0cmFjdEhwID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IG1lc3NhZ2UuIEFsc28gY29udmVydHMgdmFsdWVzIHRvIG90aGVyIHR5cGVzIGlmIHNwZWNpZmllZC5cbiAgICAgICAgICogQGZ1bmN0aW9uIHRvT2JqZWN0XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlclN1YnRyYWN0SHBSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdH0gbWVzc2FnZSBVc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAcGFyYW0geyRwcm90b2J1Zi5JQ29udmVyc2lvbk9wdGlvbnN9IFtvcHRpb25zXSBDb252ZXJzaW9uIG9wdGlvbnNcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBQbGFpbiBvYmplY3RcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJTdWJ0cmFjdEhwUmVzdWx0LnRvT2JqZWN0ID0gZnVuY3Rpb24gdG9PYmplY3QobWVzc2FnZSwgb3B0aW9ucykge1xuICAgICAgICAgICAgaWYgKCFvcHRpb25zKVxuICAgICAgICAgICAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgIGxldCBvYmplY3QgPSB7fTtcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmRlZmF1bHRzKSB7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnRhcmdldFVzZXJJZCA9IDA7XG4gICAgICAgICAgICAgICAgb2JqZWN0LnN1YnRyYWN0SHAgPSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG1lc3NhZ2UudGFyZ2V0VXNlcklkICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInRhcmdldFVzZXJJZFwiKSlcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gbWVzc2FnZS50YXJnZXRVc2VySWQ7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS5zdWJ0cmFjdEhwICE9IG51bGwgJiYgbWVzc2FnZS5oYXNPd25Qcm9wZXJ0eShcInN1YnRyYWN0SHBcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnN1YnRyYWN0SHAgPSBtZXNzYWdlLnN1YnRyYWN0SHA7XG4gICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICB9O1xuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDb252ZXJ0cyB0aGlzIFVzZXJTdWJ0cmFjdEhwUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyU3VidHJhY3RIcFJlc3VsdFxuICAgICAgICAgKiBAaW5zdGFuY2VcbiAgICAgICAgICogQHJldHVybnMge09iamVjdC48c3RyaW5nLCo+fSBKU09OIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlclN1YnRyYWN0SHBSZXN1bHQucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIHRvSlNPTigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLnRvT2JqZWN0KHRoaXMsICRwcm90b2J1Zi51dGlsLnRvSlNPTk9wdGlvbnMpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBVc2VyU3VidHJhY3RIcFJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgbXNnLlVzZXJEaWVSZXN1bHQgPSAoZnVuY3Rpb24oKSB7XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFByb3BlcnRpZXMgb2YgYSBVc2VyRGllUmVzdWx0LlxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnXG4gICAgICAgICAqIEBpbnRlcmZhY2UgSVVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHByb3BlcnR5IHtudW1iZXJ8bnVsbH0gW3RhcmdldFVzZXJJZF0gVXNlckRpZVJlc3VsdCB0YXJnZXRVc2VySWRcbiAgICAgICAgICovXG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENvbnN0cnVjdHMgYSBuZXcgVXNlckRpZVJlc3VsdC5cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZ1xuICAgICAgICAgKiBAY2xhc3NkZXNjIFJlcHJlc2VudHMgYSBVc2VyRGllUmVzdWx0LlxuICAgICAgICAgKiBAaW1wbGVtZW50cyBJVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAY29uc3RydWN0b3JcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHQ9fSBbcHJvcGVydGllc10gUHJvcGVydGllcyB0byBzZXRcbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIFVzZXJEaWVSZXN1bHQocHJvcGVydGllcykge1xuICAgICAgICAgICAgaWYgKHByb3BlcnRpZXMpXG4gICAgICAgICAgICAgICAgZm9yIChsZXQga2V5cyA9IE9iamVjdC5rZXlzKHByb3BlcnRpZXMpLCBpID0gMDsgaSA8IGtleXMubGVuZ3RoOyArK2kpXG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wZXJ0aWVzW2tleXNbaV1dICE9IG51bGwpXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzW2tleXNbaV1dID0gcHJvcGVydGllc1trZXlzW2ldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBVc2VyRGllUmVzdWx0IHRhcmdldFVzZXJJZC5cbiAgICAgICAgICogQG1lbWJlciB7bnVtYmVyfSB0YXJnZXRVc2VySWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC5wcm90b3R5cGUudGFyZ2V0VXNlcklkID0gMDtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIG5ldyBVc2VyRGllUmVzdWx0IGluc3RhbmNlIHVzaW5nIHRoZSBzcGVjaWZpZWQgcHJvcGVydGllcy5cbiAgICAgICAgICogQGZ1bmN0aW9uIGNyZWF0ZVxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge21zZy5JVXNlckRpZVJlc3VsdD19IFtwcm9wZXJ0aWVzXSBQcm9wZXJ0aWVzIHRvIHNldFxuICAgICAgICAgKiBAcmV0dXJucyB7bXNnLlVzZXJEaWVSZXN1bHR9IFVzZXJEaWVSZXN1bHQgaW5zdGFuY2VcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuY3JlYXRlID0gZnVuY3Rpb24gY3JlYXRlKHByb3BlcnRpZXMpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVXNlckRpZVJlc3VsdChwcm9wZXJ0aWVzKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJEaWVSZXN1bHQgbWVzc2FnZS4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJEaWVSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHR9IG1lc3NhZ2UgVXNlckRpZVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZW5jb2RlID0gZnVuY3Rpb24gZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgaWYgKCF3cml0ZXIpXG4gICAgICAgICAgICAgICAgd3JpdGVyID0gJFdyaXRlci5jcmVhdGUoKTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1lc3NhZ2UsIFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIHdyaXRlci51aW50MzIoLyogaWQgMSwgd2lyZVR5cGUgMCA9Ki84KS51aW50MzIobWVzc2FnZS50YXJnZXRVc2VySWQpO1xuICAgICAgICAgICAgcmV0dXJuIHdyaXRlcjtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogRW5jb2RlcyB0aGUgc3BlY2lmaWVkIFVzZXJEaWVSZXN1bHQgbWVzc2FnZSwgbGVuZ3RoIGRlbGltaXRlZC4gRG9lcyBub3QgaW1wbGljaXRseSB7QGxpbmsgbXNnLlVzZXJEaWVSZXN1bHQudmVyaWZ5fHZlcmlmeX0gbWVzc2FnZXMuXG4gICAgICAgICAqIEBmdW5jdGlvbiBlbmNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuSVVzZXJEaWVSZXN1bHR9IG1lc3NhZ2UgVXNlckRpZVJlc3VsdCBtZXNzYWdlIG9yIHBsYWluIG9iamVjdCB0byBlbmNvZGVcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuV3JpdGVyfSBbd3JpdGVyXSBXcml0ZXIgdG8gZW5jb2RlIHRvXG4gICAgICAgICAqIEByZXR1cm5zIHskcHJvdG9idWYuV3JpdGVyfSBXcml0ZXJcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZW5jb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZW5jb2RlRGVsaW1pdGVkKG1lc3NhZ2UsIHdyaXRlcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZW5jb2RlKG1lc3NhZ2UsIHdyaXRlcikubGRlbGltKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRGllUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEBwYXJhbSB7bnVtYmVyfSBbbGVuZ3RoXSBNZXNzYWdlIGxlbmd0aCBpZiBrbm93biBiZWZvcmVoYW5kXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZGVjb2RlID0gZnVuY3Rpb24gZGVjb2RlKHJlYWRlciwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBpZiAoIShyZWFkZXIgaW5zdGFuY2VvZiAkUmVhZGVyKSlcbiAgICAgICAgICAgICAgICByZWFkZXIgPSAkUmVhZGVyLmNyZWF0ZShyZWFkZXIpO1xuICAgICAgICAgICAgbGV0IGVuZCA9IGxlbmd0aCA9PT0gdW5kZWZpbmVkID8gcmVhZGVyLmxlbiA6IHJlYWRlci5wb3MgKyBsZW5ndGgsIG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJEaWVSZXN1bHQoKTtcbiAgICAgICAgICAgIHdoaWxlIChyZWFkZXIucG9zIDwgZW5kKSB7XG4gICAgICAgICAgICAgICAgbGV0IHRhZyA9IHJlYWRlci51aW50MzIoKTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHRhZyA+Pj4gMykge1xuICAgICAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSByZWFkZXIudWludDMyKCk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJlYWRlci5za2lwVHlwZSh0YWcgJiA3KTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlY29kZXMgYSBVc2VyRGllUmVzdWx0IG1lc3NhZ2UgZnJvbSB0aGUgc3BlY2lmaWVkIHJlYWRlciBvciBidWZmZXIsIGxlbmd0aCBkZWxpbWl0ZWQuXG4gICAgICAgICAqIEBmdW5jdGlvbiBkZWNvZGVEZWxpbWl0ZWRcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHskcHJvdG9idWYuUmVhZGVyfFVpbnQ4QXJyYXl9IHJlYWRlciBSZWFkZXIgb3IgYnVmZmVyIHRvIGRlY29kZSBmcm9tXG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAdGhyb3dzIHtFcnJvcn0gSWYgdGhlIHBheWxvYWQgaXMgbm90IGEgcmVhZGVyIG9yIHZhbGlkIGJ1ZmZlclxuICAgICAgICAgKiBAdGhyb3dzIHskcHJvdG9idWYudXRpbC5Qcm90b2NvbEVycm9yfSBJZiByZXF1aXJlZCBmaWVsZHMgYXJlIG1pc3NpbmdcbiAgICAgICAgICovXG4gICAgICAgIFVzZXJEaWVSZXN1bHQuZGVjb2RlRGVsaW1pdGVkID0gZnVuY3Rpb24gZGVjb2RlRGVsaW1pdGVkKHJlYWRlcikge1xuICAgICAgICAgICAgaWYgKCEocmVhZGVyIGluc3RhbmNlb2YgJFJlYWRlcikpXG4gICAgICAgICAgICAgICAgcmVhZGVyID0gbmV3ICRSZWFkZXIocmVhZGVyKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmRlY29kZShyZWFkZXIsIHJlYWRlci51aW50MzIoKSk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIFZlcmlmaWVzIGEgVXNlckRpZVJlc3VsdCBtZXNzYWdlLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdmVyaWZ5XG4gICAgICAgICAqIEBtZW1iZXJvZiBtc2cuVXNlckRpZVJlc3VsdFxuICAgICAgICAgKiBAc3RhdGljXG4gICAgICAgICAqIEBwYXJhbSB7T2JqZWN0LjxzdHJpbmcsKj59IG1lc3NhZ2UgUGxhaW4gb2JqZWN0IHRvIHZlcmlmeVxuICAgICAgICAgKiBAcmV0dXJucyB7c3RyaW5nfG51bGx9IGBudWxsYCBpZiB2YWxpZCwgb3RoZXJ3aXNlIHRoZSByZWFzb24gd2h5IGl0IGlzIG5vdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC52ZXJpZnkgPSBmdW5jdGlvbiB2ZXJpZnkobWVzc2FnZSkge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBtZXNzYWdlICE9PSBcIm9iamVjdFwiIHx8IG1lc3NhZ2UgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0IGV4cGVjdGVkXCI7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50YXJnZXRVc2VySWQgIT0gbnVsbCAmJiBtZXNzYWdlLmhhc093blByb3BlcnR5KFwidGFyZ2V0VXNlcklkXCIpKVxuICAgICAgICAgICAgICAgIGlmICghJHV0aWwuaXNJbnRlZ2VyKG1lc3NhZ2UudGFyZ2V0VXNlcklkKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidGFyZ2V0VXNlcklkOiBpbnRlZ2VyIGV4cGVjdGVkXCI7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ3JlYXRlcyBhIFVzZXJEaWVSZXN1bHQgbWVzc2FnZSBmcm9tIGEgcGxhaW4gb2JqZWN0LiBBbHNvIGNvbnZlcnRzIHZhbHVlcyB0byB0aGVpciByZXNwZWN0aXZlIGludGVybmFsIHR5cGVzLlxuICAgICAgICAgKiBAZnVuY3Rpb24gZnJvbU9iamVjdFxuICAgICAgICAgKiBAbWVtYmVyb2YgbXNnLlVzZXJEaWVSZXN1bHRcbiAgICAgICAgICogQHN0YXRpY1xuICAgICAgICAgKiBAcGFyYW0ge09iamVjdC48c3RyaW5nLCo+fSBvYmplY3QgUGxhaW4gb2JqZWN0XG4gICAgICAgICAqIEByZXR1cm5zIHttc2cuVXNlckRpZVJlc3VsdH0gVXNlckRpZVJlc3VsdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC5mcm9tT2JqZWN0ID0gZnVuY3Rpb24gZnJvbU9iamVjdChvYmplY3QpIHtcbiAgICAgICAgICAgIGlmIChvYmplY3QgaW5zdGFuY2VvZiAkcm9vdC5tc2cuVXNlckRpZVJlc3VsdClcbiAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgICAgICAgICAgbGV0IG1lc3NhZ2UgPSBuZXcgJHJvb3QubXNnLlVzZXJEaWVSZXN1bHQoKTtcbiAgICAgICAgICAgIGlmIChvYmplY3QudGFyZ2V0VXNlcklkICE9IG51bGwpXG4gICAgICAgICAgICAgICAgbWVzc2FnZS50YXJnZXRVc2VySWQgPSBvYmplY3QudGFyZ2V0VXNlcklkID4+PiAwO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH07XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIENyZWF0ZXMgYSBwbGFpbiBvYmplY3QgZnJvbSBhIFVzZXJEaWVSZXN1bHQgbWVzc2FnZS4gQWxzbyBjb252ZXJ0cyB2YWx1ZXMgdG8gb3RoZXIgdHlwZXMgaWYgc3BlY2lmaWVkLlxuICAgICAgICAgKiBAZnVuY3Rpb24gdG9PYmplY3RcbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBzdGF0aWNcbiAgICAgICAgICogQHBhcmFtIHttc2cuVXNlckRpZVJlc3VsdH0gbWVzc2FnZSBVc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBwYXJhbSB7JHByb3RvYnVmLklDb252ZXJzaW9uT3B0aW9uc30gW29wdGlvbnNdIENvbnZlcnNpb24gb3B0aW9uc1xuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IFBsYWluIG9iamVjdFxuICAgICAgICAgKi9cbiAgICAgICAgVXNlckRpZVJlc3VsdC50b09iamVjdCA9IGZ1bmN0aW9uIHRvT2JqZWN0KG1lc3NhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucylcbiAgICAgICAgICAgICAgICBvcHRpb25zID0ge307XG4gICAgICAgICAgICBsZXQgb2JqZWN0ID0ge307XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5kZWZhdWx0cylcbiAgICAgICAgICAgICAgICBvYmplY3QudGFyZ2V0VXNlcklkID0gMDtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlLnRhcmdldFVzZXJJZCAhPSBudWxsICYmIG1lc3NhZ2UuaGFzT3duUHJvcGVydHkoXCJ0YXJnZXRVc2VySWRcIikpXG4gICAgICAgICAgICAgICAgb2JqZWN0LnRhcmdldFVzZXJJZCA9IG1lc3NhZ2UudGFyZ2V0VXNlcklkO1xuICAgICAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICAgICAgfTtcblxuICAgICAgICAvKipcbiAgICAgICAgICogQ29udmVydHMgdGhpcyBVc2VyRGllUmVzdWx0IHRvIEpTT04uXG4gICAgICAgICAqIEBmdW5jdGlvbiB0b0pTT05cbiAgICAgICAgICogQG1lbWJlcm9mIG1zZy5Vc2VyRGllUmVzdWx0XG4gICAgICAgICAqIEBpbnN0YW5jZVxuICAgICAgICAgKiBAcmV0dXJucyB7T2JqZWN0LjxzdHJpbmcsKj59IEpTT04gb2JqZWN0XG4gICAgICAgICAqL1xuICAgICAgICBVc2VyRGllUmVzdWx0LnByb3RvdHlwZS50b0pTT04gPSBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5jb25zdHJ1Y3Rvci50b09iamVjdCh0aGlzLCAkcHJvdG9idWYudXRpbC50b0pTT05PcHRpb25zKTtcbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gVXNlckRpZVJlc3VsdDtcbiAgICB9KSgpO1xuXG4gICAgcmV0dXJuIG1zZztcbn0pKCk7XG5cbm1vZHVsZS5leHBvcnRzID0gJHJvb3Q7XG4iXX0=