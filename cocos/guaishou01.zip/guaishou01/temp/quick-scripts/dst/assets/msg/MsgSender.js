
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/MsgSender.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db8e8qijfhLu5qRq3LZHeRc', 'MsgSender');
// msg/MsgSender.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MsgEncoder_1 = require("./MsgEncoder");
var MsgDecoder_1 = require("./MsgDecoder");
var MsgSender = /** @class */ (function () {
    function MsgSender() {
        this._oWebsocket = null;
        this._oMsgEncoder = new MsgEncoder_1.default();
        this._oMsgDecoder = new MsgDecoder_1.default();
    }
    /**
     * 获取单例对象
     */
    MsgSender.getInstance = function () {
        return MsgSender._oInstance;
    };
    MsgSender.prototype.connect = function (funCallback) {
        var _this = this;
        if (funCallback === void 0) { funCallback = null; }
        var url = 'ws://192.168.1.63:6666/websocket';
        var oWebsocket = new WebSocket(url);
        oWebsocket.binaryType = "arraybuffer";
        oWebsocket.onopen = function () {
            cc.log("\u5DF2\u8FDE\u63A5\u670D\u52A1\u5668\uFF0Curl=" + url);
            _this._oWebsocket = oWebsocket;
            if (null != funCallback) {
                funCallback();
            }
        };
        oWebsocket.onclose = function () {
            cc.log("\u670D\u52A1\u5668\u5173\u95ED\u8FDE\u63A5");
            _this._oWebsocket = null;
        };
        oWebsocket.onmessage = function (oEvent) {
            console.log("onmessage进入");
            if (oEvent == null || null == oEvent.data) {
                return;
            }
            var uint8Array = new Uint8Array(oEvent.data);
            var nMsgCode = _this._oMsgDecoder.getMsgCode(uint8Array);
            var decode = _this._oMsgDecoder.decode(nMsgCode, uint8Array.slice(4));
            console.log("decode", decode);
            if (_this.onMsgReceived != null) {
                _this.onMsgReceived(nMsgCode, decode);
            }
        };
    };
    MsgSender.prototype.sendMsg = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || null == oMsgBody) {
            return;
        }
        if (null == this._oWebsocket) {
            return;
        }
        var uint8Array = this._oMsgEncoder.encode(nMsgCode, oMsgBody);
        if (uint8Array == null) {
            return;
        }
        console.log('发送消息，消息编号：', nMsgCode);
        this._oWebsocket.send(uint8Array);
    };
    MsgSender.prototype.onMsgReceived = function (nMsgCode, oMsgBody) {
    };
    MsgSender._oInstance = new MsgSender();
    return MsgSender;
}());
exports.default = MsgSender;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbXNnXFxNc2dTZW5kZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSwyQ0FBc0M7QUFDdEMsMkNBQXNDO0FBRXRDO0lBUUk7UUFKUSxnQkFBVyxHQUFXLElBQUksQ0FBQztRQUVsQixpQkFBWSxHQUFZLElBQUksb0JBQVUsRUFBRSxDQUFDO1FBQ3pDLGlCQUFZLEdBQVksSUFBSSxvQkFBVSxFQUFFLENBQUM7SUFFMUQsQ0FBQztJQUVEOztPQUVHO0lBQ1cscUJBQVcsR0FBekI7UUFDSSxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQUM7SUFDaEMsQ0FBQztJQUNELDJCQUFPLEdBQVAsVUFBUSxXQUF5QjtRQUFqQyxpQkFpQ0M7UUFqQ08sNEJBQUEsRUFBQSxrQkFBeUI7UUFDN0IsSUFBSSxHQUFHLEdBQUMsa0NBQWtDLENBQUM7UUFDM0MsSUFBSSxVQUFVLEdBQUMsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEMsVUFBVSxDQUFDLFVBQVUsR0FBQyxhQUFhLENBQUM7UUFFcEMsVUFBVSxDQUFDLE1BQU0sR0FBQztZQUNkLEVBQUUsQ0FBQyxHQUFHLENBQUMsbURBQWMsR0FBSyxDQUFDLENBQUE7WUFDM0IsS0FBSSxDQUFDLFdBQVcsR0FBQyxVQUFVLENBQUM7WUFDNUIsSUFBRyxJQUFJLElBQUUsV0FBVyxFQUFDO2dCQUNqQixXQUFXLEVBQUUsQ0FBQzthQUNqQjtRQUNMLENBQUMsQ0FBQTtRQUVELFVBQVUsQ0FBQyxPQUFPLEdBQUM7WUFDZixFQUFFLENBQUMsR0FBRyxDQUFDLDRDQUFTLENBQUMsQ0FBQTtZQUNqQixLQUFJLENBQUMsV0FBVyxHQUFDLElBQUksQ0FBQztRQUMxQixDQUFDLENBQUE7UUFFRCxVQUFVLENBQUMsU0FBUyxHQUFDLFVBQUMsTUFBbUI7WUFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMzQixJQUFHLE1BQU0sSUFBRSxJQUFJLElBQUUsSUFBSSxJQUFFLE1BQU0sQ0FBQyxJQUFJLEVBQUM7Z0JBQy9CLE9BQU87YUFDVjtZQUNELElBQUksVUFBVSxHQUFHLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM3QyxJQUFJLFFBQVEsR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUV4RCxJQUFJLE1BQU0sR0FBRyxLQUFJLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BFLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRTdCLElBQUksS0FBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLEVBQUU7Z0JBQzVCLEtBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQ3ZDO1FBQ0wsQ0FBQyxDQUFBO0lBQ0wsQ0FBQztJQUVELDJCQUFPLEdBQVAsVUFBUSxRQUFlLEVBQUMsUUFBWTtRQUNoQyxJQUFHLFFBQVEsR0FBQyxDQUFDLElBQUUsSUFBSSxJQUFFLFFBQVEsRUFBQztZQUMxQixPQUFPO1NBQ1Y7UUFDRCxJQUFHLElBQUksSUFBRSxJQUFJLENBQUMsV0FBVyxFQUFDO1lBQ3RCLE9BQU87U0FDVjtRQUNELElBQUksVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFFBQVEsRUFBQyxRQUFRLENBQUMsQ0FBQztRQUM3RCxJQUFHLFVBQVUsSUFBRSxJQUFJLEVBQUM7WUFDaEIsT0FBTztTQUNWO1FBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUMsUUFBUSxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQUVELGlDQUFhLEdBQWIsVUFBYyxRQUFlLEVBQUMsUUFBWTtJQUUxQyxDQUFDO0lBbkV1QixvQkFBVSxHQUFZLElBQUksU0FBUyxFQUFFLENBQUM7SUFvRWxFLGdCQUFDO0NBdEVELEFBc0VDLElBQUE7a0JBdEVvQixTQUFTIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE1zZ0VuY29kZXIgZnJvbSAnLi9Nc2dFbmNvZGVyJztcclxuaW1wb3J0IE1zZ0RlY29kZXIgZnJvbSAnLi9Nc2dEZWNvZGVyJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1zZ1NlbmRlciAvKmV4dGVuZHMgY2MuQ29tcG9uZW50Ki8ge1xyXG5cclxuICAgIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IF9vSW5zdGFuY2U6TXNnU2VuZGVyID1uZXcgTXNnU2VuZGVyKCk7XHJcblxyXG4gICAgcHJpdmF0ZSBfb1dlYnNvY2tldDpXZWJTb2NrZXQ9bnVsbDtcclxuXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IF9vTXNnRW5jb2RlcjpNc2dFbmNvZGVyPW5ldyBNc2dFbmNvZGVyKCk7XHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IF9vTXNnRGVjb2RlcjpNc2dEZWNvZGVyPW5ldyBNc2dEZWNvZGVyKCk7XHJcbiAgICBwcml2YXRlIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6I635Y+W5Y2V5L6L5a+56LGhXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBzdGF0aWMgZ2V0SW5zdGFuY2UoKTpNc2dTZW5kZXJ7XHJcbiAgICAgICAgcmV0dXJuIE1zZ1NlbmRlci5fb0luc3RhbmNlO1xyXG4gICAgfVxyXG4gICAgY29ubmVjdChmdW5DYWxsYmFjazooKT0+dm9pZD1udWxsKTp2b2lke1xyXG4gICAgICAgIGxldCB1cmw9J3dzOi8vMTkyLjE2OC4xLjYzOjY2NjYvd2Vic29ja2V0JztcclxuICAgICAgICBsZXQgb1dlYnNvY2tldD1uZXcgV2ViU29ja2V0KHVybCk7XHJcbiAgICAgICAgb1dlYnNvY2tldC5iaW5hcnlUeXBlPVwiYXJyYXlidWZmZXJcIjtcclxuXHJcbiAgICAgICAgb1dlYnNvY2tldC5vbm9wZW49KCk6dm9pZD0+e1xyXG4gICAgICAgICAgICBjYy5sb2coYOW3sui/nuaOpeacjeWKoeWZqO+8jHVybD0ke3VybH1gKVxyXG4gICAgICAgICAgICB0aGlzLl9vV2Vic29ja2V0PW9XZWJzb2NrZXQ7XHJcbiAgICAgICAgICAgIGlmKG51bGwhPWZ1bkNhbGxiYWNrKXtcclxuICAgICAgICAgICAgICAgIGZ1bkNhbGxiYWNrKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIG9XZWJzb2NrZXQub25jbG9zZT0oKTp2b2lkPT57XHJcbiAgICAgICAgICAgIGNjLmxvZyhg5pyN5Yqh5Zmo5YWz6Zet6L+e5o6lYClcclxuICAgICAgICAgICAgdGhpcy5fb1dlYnNvY2tldD1udWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgb1dlYnNvY2tldC5vbm1lc3NhZ2U9KG9FdmVudDpNZXNzYWdlRXZlbnQpOnZvaWQgPT57XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwib25tZXNzYWdl6L+b5YWlXCIpO1xyXG4gICAgICAgICAgICBpZihvRXZlbnQ9PW51bGx8fG51bGw9PW9FdmVudC5kYXRhKXtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgdWludDhBcnJheSA9IG5ldyBVaW50OEFycmF5KG9FdmVudC5kYXRhKTtcclxuICAgICAgICAgICAgbGV0IG5Nc2dDb2RlID0gdGhpcy5fb01zZ0RlY29kZXIuZ2V0TXNnQ29kZSh1aW50OEFycmF5KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBkZWNvZGUgPSB0aGlzLl9vTXNnRGVjb2Rlci5kZWNvZGUobk1zZ0NvZGUsdWludDhBcnJheS5zbGljZSg0KSk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGVjb2RlXCIsZGVjb2RlKTtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLm9uTXNnUmVjZWl2ZWQgIT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5vbk1zZ1JlY2VpdmVkKG5Nc2dDb2RlLGRlY29kZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc2VuZE1zZyhuTXNnQ29kZTpudW1iZXIsb01zZ0JvZHk6YW55KTp2b2lke1xyXG4gICAgICAgIGlmKG5Nc2dDb2RlPDB8fG51bGw9PW9Nc2dCb2R5KXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihudWxsPT10aGlzLl9vV2Vic29ja2V0KXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgdWludDhBcnJheSA9IHRoaXMuX29Nc2dFbmNvZGVyLmVuY29kZShuTXNnQ29kZSxvTXNnQm9keSk7XHJcbiAgICAgICAgaWYodWludDhBcnJheT09bnVsbCl7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coJ+WPkemAgea2iOaBr++8jOa2iOaBr+e8luWPt++8micsbk1zZ0NvZGUpO1xyXG4gICAgICAgIHRoaXMuX29XZWJzb2NrZXQuc2VuZCh1aW50OEFycmF5KTtcclxuICAgIH1cclxuXHJcbiAgICBvbk1zZ1JlY2VpdmVkKG5Nc2dDb2RlOm51bWJlcixvTXNnQm9keTphbnkpOnZvaWR7XHJcblxyXG4gICAgfVxyXG59XHJcbiJdfQ==