
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/msg/protobuf.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}(function (global){
"use strict";
cc._RF.push(module, '535ecX0K+xF9I7ep13vV1i0', 'protobuf');
// msg/protobuf.js

"use strict";

/*!
 * protobuf.js v6.11.0 (c) 2016, daniel wirtz
 * compiled thu, 29 apr 2021 02:20:44 utc
 * licensed under the bsd-3-clause license
 * see: https://github.com/dcodeio/protobuf.js for details
 */
(function (undefined) {
  "use strict";

  (function prelude(modules, cache, entries) {
    // This is the prelude used to bundle protobuf.js for the browser. Wraps up the CommonJS
    // sources through a conflict-free require shim and is again wrapped within an iife that
    // provides a minification-friendly `undefined` var plus a global "use strict" directive
    // so that minification can remove the directives of each module.
    function $require(name) {
      var $module = cache[name];
      if (!$module) modules[name][0].call($module = cache[name] = {
        exports: {}
      }, $require, $module, $module.exports);
      return $module.exports;
    }

    var protobuf = $require(entries[0]); // Expose globally

    protobuf.util.global.protobuf = protobuf; // Be nice to AMD

    if (typeof define === "function" && define.amd) define(["long"], function (Long) {
      if (Long && Long.isLong) {
        protobuf.util.Long = Long;
        protobuf.configure();
      }

      return protobuf;
    }); // Be nice to CommonJS

    if (typeof module === "object" && module && module.exports) module.exports = protobuf;
  })(
  /* end of prelude */
  {
    1: [function (require, module, exports) {
      "use strict";

      module.exports = asPromise;
      /**
       * Callback as used by {@link util.asPromise}.
       * @typedef asPromiseCallback
       * @type {function}
       * @param {Error|null} error Error, if any
       * @param {...*} params Additional arguments
       * @returns {undefined}
       */

      /**
       * Returns a promise from a node-style callback function.
       * @memberof util
       * @param {asPromiseCallback} fn Function to call
       * @param {*} ctx Function context
       * @param {...*} params Function arguments
       * @returns {Promise<*>} Promisified function
       */

      function asPromise(fn, ctx
      /*, varargs */
      ) {
        var params = new Array(arguments.length - 1),
            offset = 0,
            index = 2,
            pending = true;

        while (index < arguments.length) {
          params[offset++] = arguments[index++];
        }

        return new Promise(function executor(resolve, reject) {
          params[offset] = function callback(err
          /*, varargs */
          ) {
            if (pending) {
              pending = false;
              if (err) reject(err);else {
                var params = new Array(arguments.length - 1),
                    offset = 0;

                while (offset < params.length) {
                  params[offset++] = arguments[offset];
                }

                resolve.apply(null, params);
              }
            }
          };

          try {
            fn.apply(ctx || null, params);
          } catch (err) {
            if (pending) {
              pending = false;
              reject(err);
            }
          }
        });
      }
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * A minimal base64 implementation for number arrays.
       * @memberof util
       * @namespace
       */

      var base64 = exports;
      /**
       * Calculates the byte length of a base64 encoded string.
       * @param {string} string Base64 encoded string
       * @returns {number} Byte length
       */

      base64.length = function length(string) {
        var p = string.length;
        if (!p) return 0;
        var n = 0;

        while (--p % 4 > 1 && string.charAt(p) === "=") {
          ++n;
        }

        return Math.ceil(string.length * 3) / 4 - n;
      }; // Base64 encoding table


      var b64 = new Array(64); // Base64 decoding table

      var s64 = new Array(123); // 65..90, 97..122, 48..57, 43, 47

      for (var i = 0; i < 64;) {
        s64[b64[i] = i < 26 ? i + 65 : i < 52 ? i + 71 : i < 62 ? i - 4 : i - 59 | 43] = i++;
      }
      /**
       * Encodes a buffer to a base64 encoded string.
       * @param {Uint8Array} buffer Source buffer
       * @param {number} start Source start
       * @param {number} end Source end
       * @returns {string} Base64 encoded string
       */


      base64.encode = function encode(buffer, start, end) {
        var parts = null,
            chunk = [];
        var i = 0,
            // output index
        j = 0,
            // goto index
        t; // temporary

        while (start < end) {
          var b = buffer[start++];

          switch (j) {
            case 0:
              chunk[i++] = b64[b >> 2];
              t = (b & 3) << 4;
              j = 1;
              break;

            case 1:
              chunk[i++] = b64[t | b >> 4];
              t = (b & 15) << 2;
              j = 2;
              break;

            case 2:
              chunk[i++] = b64[t | b >> 6];
              chunk[i++] = b64[b & 63];
              j = 0;
              break;
          }

          if (i > 8191) {
            (parts || (parts = [])).push(String.fromCharCode.apply(String, chunk));
            i = 0;
          }
        }

        if (j) {
          chunk[i++] = b64[t];
          chunk[i++] = 61;
          if (j === 1) chunk[i++] = 61;
        }

        if (parts) {
          if (i) parts.push(String.fromCharCode.apply(String, chunk.slice(0, i)));
          return parts.join("");
        }

        return String.fromCharCode.apply(String, chunk.slice(0, i));
      };

      var invalidEncoding = "invalid encoding";
      /**
       * Decodes a base64 encoded string to a buffer.
       * @param {string} string Source string
       * @param {Uint8Array} buffer Destination buffer
       * @param {number} offset Destination offset
       * @returns {number} Number of bytes written
       * @throws {Error} If encoding is invalid
       */

      base64.decode = function decode(string, buffer, offset) {
        var start = offset;
        var j = 0,
            // goto index
        t; // temporary

        for (var i = 0; i < string.length;) {
          var c = string.charCodeAt(i++);
          if (c === 61 && j > 1) break;
          if ((c = s64[c]) === undefined) throw Error(invalidEncoding);

          switch (j) {
            case 0:
              t = c;
              j = 1;
              break;

            case 1:
              buffer[offset++] = t << 2 | (c & 48) >> 4;
              t = c;
              j = 2;
              break;

            case 2:
              buffer[offset++] = (t & 15) << 4 | (c & 60) >> 2;
              t = c;
              j = 3;
              break;

            case 3:
              buffer[offset++] = (t & 3) << 6 | c;
              j = 0;
              break;
          }
        }

        if (j === 1) throw Error(invalidEncoding);
        return offset - start;
      };
      /**
       * Tests if the specified string appears to be base64 encoded.
       * @param {string} string String to test
       * @returns {boolean} `true` if probably base64 encoded, otherwise false
       */


      base64.test = function test(string) {
        return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(string);
      };
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      module.exports = EventEmitter;
      /**
       * Constructs a new event emitter instance.
       * @classdesc A minimal event emitter.
       * @memberof util
       * @constructor
       */

      function EventEmitter() {
        /**
         * Registered listeners.
         * @type {Object.<string,*>}
         * @private
         */
        this._listeners = {};
      }
      /**
       * Registers an event listener.
       * @param {string} evt Event name
       * @param {function} fn Listener
       * @param {*} [ctx] Listener context
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.on = function on(evt, fn, ctx) {
        (this._listeners[evt] || (this._listeners[evt] = [])).push({
          fn: fn,
          ctx: ctx || this
        });
        return this;
      };
      /**
       * Removes an event listener or any matching listeners if arguments are omitted.
       * @param {string} [evt] Event name. Removes all listeners if omitted.
       * @param {function} [fn] Listener to remove. Removes all listeners of `evt` if omitted.
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.off = function off(evt, fn) {
        if (evt === undefined) this._listeners = {};else {
          if (fn === undefined) this._listeners[evt] = [];else {
            var listeners = this._listeners[evt];

            for (var i = 0; i < listeners.length;) {
              if (listeners[i].fn === fn) listeners.splice(i, 1);else ++i;
            }
          }
        }
        return this;
      };
      /**
       * Emits an event by calling its listeners with the specified arguments.
       * @param {string} evt Event name
       * @param {...*} args Arguments
       * @returns {util.EventEmitter} `this`
       */


      EventEmitter.prototype.emit = function emit(evt) {
        var listeners = this._listeners[evt];

        if (listeners) {
          var args = [],
              i = 1;

          for (; i < arguments.length;) {
            args.push(arguments[i++]);
          }

          for (i = 0; i < listeners.length;) {
            listeners[i].fn.apply(listeners[i++].ctx, args);
          }
        }

        return this;
      };
    }, {}],
    4: [function (require, module, exports) {
      "use strict";

      module.exports = factory(factory);
      /**
       * Reads / writes floats / doubles from / to buffers.
       * @name util.float
       * @namespace
       */

      /**
       * Writes a 32 bit float to a buffer using little endian byte order.
       * @name util.float.writeFloatLE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Writes a 32 bit float to a buffer using big endian byte order.
       * @name util.float.writeFloatBE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Reads a 32 bit float from a buffer using little endian byte order.
       * @name util.float.readFloatLE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Reads a 32 bit float from a buffer using big endian byte order.
       * @name util.float.readFloatBE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Writes a 64 bit double to a buffer using little endian byte order.
       * @name util.float.writeDoubleLE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Writes a 64 bit double to a buffer using big endian byte order.
       * @name util.float.writeDoubleBE
       * @function
       * @param {number} val Value to write
       * @param {Uint8Array} buf Target buffer
       * @param {number} pos Target buffer offset
       * @returns {undefined}
       */

      /**
       * Reads a 64 bit double from a buffer using little endian byte order.
       * @name util.float.readDoubleLE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */

      /**
       * Reads a 64 bit double from a buffer using big endian byte order.
       * @name util.float.readDoubleBE
       * @function
       * @param {Uint8Array} buf Source buffer
       * @param {number} pos Source buffer offset
       * @returns {number} Value read
       */
      // Factory function for the purpose of node-based testing in modified global environments

      function factory(exports) {
        // float: typed array
        if (typeof Float32Array !== "undefined") (function () {
          var f32 = new Float32Array([-0]),
              f8b = new Uint8Array(f32.buffer),
              le = f8b[3] === 128;

          function writeFloat_f32_cpy(val, buf, pos) {
            f32[0] = val;
            buf[pos] = f8b[0];
            buf[pos + 1] = f8b[1];
            buf[pos + 2] = f8b[2];
            buf[pos + 3] = f8b[3];
          }

          function writeFloat_f32_rev(val, buf, pos) {
            f32[0] = val;
            buf[pos] = f8b[3];
            buf[pos + 1] = f8b[2];
            buf[pos + 2] = f8b[1];
            buf[pos + 3] = f8b[0];
          }
          /* istanbul ignore next */


          exports.writeFloatLE = le ? writeFloat_f32_cpy : writeFloat_f32_rev;
          /* istanbul ignore next */

          exports.writeFloatBE = le ? writeFloat_f32_rev : writeFloat_f32_cpy;

          function readFloat_f32_cpy(buf, pos) {
            f8b[0] = buf[pos];
            f8b[1] = buf[pos + 1];
            f8b[2] = buf[pos + 2];
            f8b[3] = buf[pos + 3];
            return f32[0];
          }

          function readFloat_f32_rev(buf, pos) {
            f8b[3] = buf[pos];
            f8b[2] = buf[pos + 1];
            f8b[1] = buf[pos + 2];
            f8b[0] = buf[pos + 3];
            return f32[0];
          }
          /* istanbul ignore next */


          exports.readFloatLE = le ? readFloat_f32_cpy : readFloat_f32_rev;
          /* istanbul ignore next */

          exports.readFloatBE = le ? readFloat_f32_rev : readFloat_f32_cpy; // float: ieee754
        })();else (function () {
          function writeFloat_ieee754(writeUint, val, buf, pos) {
            var sign = val < 0 ? 1 : 0;
            if (sign) val = -val;
            if (val === 0) writeUint(1 / val > 0 ?
            /* positive */
            0 :
            /* negative 0 */
            2147483648, buf, pos);else if (isNaN(val)) writeUint(2143289344, buf, pos);else if (val > 3.4028234663852886e+38) // +-Infinity
              writeUint((sign << 31 | 2139095040) >>> 0, buf, pos);else if (val < 1.1754943508222875e-38) // denormal
              writeUint((sign << 31 | Math.round(val / 1.401298464324817e-45)) >>> 0, buf, pos);else {
              var exponent = Math.floor(Math.log(val) / Math.LN2),
                  mantissa = Math.round(val * Math.pow(2, -exponent) * 8388608) & 8388607;
              writeUint((sign << 31 | exponent + 127 << 23 | mantissa) >>> 0, buf, pos);
            }
          }

          exports.writeFloatLE = writeFloat_ieee754.bind(null, writeUintLE);
          exports.writeFloatBE = writeFloat_ieee754.bind(null, writeUintBE);

          function readFloat_ieee754(readUint, buf, pos) {
            var uint = readUint(buf, pos),
                sign = (uint >> 31) * 2 + 1,
                exponent = uint >>> 23 & 255,
                mantissa = uint & 8388607;
            return exponent === 255 ? mantissa ? NaN : sign * Infinity : exponent === 0 // denormal
            ? sign * 1.401298464324817e-45 * mantissa : sign * Math.pow(2, exponent - 150) * (mantissa + 8388608);
          }

          exports.readFloatLE = readFloat_ieee754.bind(null, readUintLE);
          exports.readFloatBE = readFloat_ieee754.bind(null, readUintBE);
        })(); // double: typed array

        if (typeof Float64Array !== "undefined") (function () {
          var f64 = new Float64Array([-0]),
              f8b = new Uint8Array(f64.buffer),
              le = f8b[7] === 128;

          function writeDouble_f64_cpy(val, buf, pos) {
            f64[0] = val;
            buf[pos] = f8b[0];
            buf[pos + 1] = f8b[1];
            buf[pos + 2] = f8b[2];
            buf[pos + 3] = f8b[3];
            buf[pos + 4] = f8b[4];
            buf[pos + 5] = f8b[5];
            buf[pos + 6] = f8b[6];
            buf[pos + 7] = f8b[7];
          }

          function writeDouble_f64_rev(val, buf, pos) {
            f64[0] = val;
            buf[pos] = f8b[7];
            buf[pos + 1] = f8b[6];
            buf[pos + 2] = f8b[5];
            buf[pos + 3] = f8b[4];
            buf[pos + 4] = f8b[3];
            buf[pos + 5] = f8b[2];
            buf[pos + 6] = f8b[1];
            buf[pos + 7] = f8b[0];
          }
          /* istanbul ignore next */


          exports.writeDoubleLE = le ? writeDouble_f64_cpy : writeDouble_f64_rev;
          /* istanbul ignore next */

          exports.writeDoubleBE = le ? writeDouble_f64_rev : writeDouble_f64_cpy;

          function readDouble_f64_cpy(buf, pos) {
            f8b[0] = buf[pos];
            f8b[1] = buf[pos + 1];
            f8b[2] = buf[pos + 2];
            f8b[3] = buf[pos + 3];
            f8b[4] = buf[pos + 4];
            f8b[5] = buf[pos + 5];
            f8b[6] = buf[pos + 6];
            f8b[7] = buf[pos + 7];
            return f64[0];
          }

          function readDouble_f64_rev(buf, pos) {
            f8b[7] = buf[pos];
            f8b[6] = buf[pos + 1];
            f8b[5] = buf[pos + 2];
            f8b[4] = buf[pos + 3];
            f8b[3] = buf[pos + 4];
            f8b[2] = buf[pos + 5];
            f8b[1] = buf[pos + 6];
            f8b[0] = buf[pos + 7];
            return f64[0];
          }
          /* istanbul ignore next */


          exports.readDoubleLE = le ? readDouble_f64_cpy : readDouble_f64_rev;
          /* istanbul ignore next */

          exports.readDoubleBE = le ? readDouble_f64_rev : readDouble_f64_cpy; // double: ieee754
        })();else (function () {
          function writeDouble_ieee754(writeUint, off0, off1, val, buf, pos) {
            var sign = val < 0 ? 1 : 0;
            if (sign) val = -val;

            if (val === 0) {
              writeUint(0, buf, pos + off0);
              writeUint(1 / val > 0 ?
              /* positive */
              0 :
              /* negative 0 */
              2147483648, buf, pos + off1);
            } else if (isNaN(val)) {
              writeUint(0, buf, pos + off0);
              writeUint(2146959360, buf, pos + off1);
            } else if (val > 1.7976931348623157e+308) {
              // +-Infinity
              writeUint(0, buf, pos + off0);
              writeUint((sign << 31 | 2146435072) >>> 0, buf, pos + off1);
            } else {
              var mantissa;

              if (val < 2.2250738585072014e-308) {
                // denormal
                mantissa = val / 5e-324;
                writeUint(mantissa >>> 0, buf, pos + off0);
                writeUint((sign << 31 | mantissa / 4294967296) >>> 0, buf, pos + off1);
              } else {
                var exponent = Math.floor(Math.log(val) / Math.LN2);
                if (exponent === 1024) exponent = 1023;
                mantissa = val * Math.pow(2, -exponent);
                writeUint(mantissa * 4503599627370496 >>> 0, buf, pos + off0);
                writeUint((sign << 31 | exponent + 1023 << 20 | mantissa * 1048576 & 1048575) >>> 0, buf, pos + off1);
              }
            }
          }

          exports.writeDoubleLE = writeDouble_ieee754.bind(null, writeUintLE, 0, 4);
          exports.writeDoubleBE = writeDouble_ieee754.bind(null, writeUintBE, 4, 0);

          function readDouble_ieee754(readUint, off0, off1, buf, pos) {
            var lo = readUint(buf, pos + off0),
                hi = readUint(buf, pos + off1);
            var sign = (hi >> 31) * 2 + 1,
                exponent = hi >>> 20 & 2047,
                mantissa = 4294967296 * (hi & 1048575) + lo;
            return exponent === 2047 ? mantissa ? NaN : sign * Infinity : exponent === 0 // denormal
            ? sign * 5e-324 * mantissa : sign * Math.pow(2, exponent - 1075) * (mantissa + 4503599627370496);
          }

          exports.readDoubleLE = readDouble_ieee754.bind(null, readUintLE, 0, 4);
          exports.readDoubleBE = readDouble_ieee754.bind(null, readUintBE, 4, 0);
        })();
        return exports;
      } // uint helpers


      function writeUintLE(val, buf, pos) {
        buf[pos] = val & 255;
        buf[pos + 1] = val >>> 8 & 255;
        buf[pos + 2] = val >>> 16 & 255;
        buf[pos + 3] = val >>> 24;
      }

      function writeUintBE(val, buf, pos) {
        buf[pos] = val >>> 24;
        buf[pos + 1] = val >>> 16 & 255;
        buf[pos + 2] = val >>> 8 & 255;
        buf[pos + 3] = val & 255;
      }

      function readUintLE(buf, pos) {
        return (buf[pos] | buf[pos + 1] << 8 | buf[pos + 2] << 16 | buf[pos + 3] << 24) >>> 0;
      }

      function readUintBE(buf, pos) {
        return (buf[pos] << 24 | buf[pos + 1] << 16 | buf[pos + 2] << 8 | buf[pos + 3]) >>> 0;
      }
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      module.exports = inquire;
      /**
       * Requires a module only if available.
       * @memberof util
       * @param {string} moduleName Module to require
       * @returns {?Object} Required module if available and not empty, otherwise `null`
       */

      function inquire(moduleName) {
        try {
          var mod = eval("quire".replace(/^/, "re"))(moduleName); // eslint-disable-line no-eval

          if (mod && (mod.length || Object.keys(mod).length)) return mod;
        } catch (e) {} // eslint-disable-line no-empty


        return null;
      }
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      module.exports = pool;
      /**
       * An allocator as used by {@link util.pool}.
       * @typedef PoolAllocator
       * @type {function}
       * @param {number} size Buffer size
       * @returns {Uint8Array} Buffer
       */

      /**
       * A slicer as used by {@link util.pool}.
       * @typedef PoolSlicer
       * @type {function}
       * @param {number} start Start offset
       * @param {number} end End offset
       * @returns {Uint8Array} Buffer slice
       * @this {Uint8Array}
       */

      /**
       * A general purpose buffer pool.
       * @memberof util
       * @function
       * @param {PoolAllocator} alloc Allocator
       * @param {PoolSlicer} slice Slicer
       * @param {number} [size=8192] Slab size
       * @returns {PoolAllocator} Pooled allocator
       */

      function pool(alloc, slice, size) {
        var SIZE = size || 8192;
        var MAX = SIZE >>> 1;
        var slab = null;
        var offset = SIZE;
        return function pool_alloc(size) {
          if (size < 1 || size > MAX) return alloc(size);

          if (offset + size > SIZE) {
            slab = alloc(SIZE);
            offset = 0;
          }

          var buf = slice.call(slab, offset, offset += size);
          if (offset & 7) // align to 32 bit
            offset = (offset | 7) + 1;
          return buf;
        };
      }
    }, {}],
    7: [function (require, module, exports) {
      "use strict";
      /**
       * A minimal UTF8 implementation for number arrays.
       * @memberof util
       * @namespace
       */

      var utf8 = exports;
      /**
       * Calculates the UTF8 byte length of a string.
       * @param {string} string String
       * @returns {number} Byte length
       */

      utf8.length = function utf8_length(string) {
        var len = 0,
            c = 0;

        for (var i = 0; i < string.length; ++i) {
          c = string.charCodeAt(i);
          if (c < 128) len += 1;else if (c < 2048) len += 2;else if ((c & 0xFC00) === 0xD800 && (string.charCodeAt(i + 1) & 0xFC00) === 0xDC00) {
            ++i;
            len += 4;
          } else len += 3;
        }

        return len;
      };
      /**
       * Reads UTF8 bytes as a string.
       * @param {Uint8Array} buffer Source buffer
       * @param {number} start Source start
       * @param {number} end Source end
       * @returns {string} String read
       */


      utf8.read = function utf8_read(buffer, start, end) {
        var len = end - start;
        if (len < 1) return "";
        var parts = null,
            chunk = [],
            i = 0,
            // char offset
        t; // temporary

        while (start < end) {
          t = buffer[start++];
          if (t < 128) chunk[i++] = t;else if (t > 191 && t < 224) chunk[i++] = (t & 31) << 6 | buffer[start++] & 63;else if (t > 239 && t < 365) {
            t = ((t & 7) << 18 | (buffer[start++] & 63) << 12 | (buffer[start++] & 63) << 6 | buffer[start++] & 63) - 0x10000;
            chunk[i++] = 0xD800 + (t >> 10);
            chunk[i++] = 0xDC00 + (t & 1023);
          } else chunk[i++] = (t & 15) << 12 | (buffer[start++] & 63) << 6 | buffer[start++] & 63;

          if (i > 8191) {
            (parts || (parts = [])).push(String.fromCharCode.apply(String, chunk));
            i = 0;
          }
        }

        if (parts) {
          if (i) parts.push(String.fromCharCode.apply(String, chunk.slice(0, i)));
          return parts.join("");
        }

        return String.fromCharCode.apply(String, chunk.slice(0, i));
      };
      /**
       * Writes a string as UTF8 bytes.
       * @param {string} string Source string
       * @param {Uint8Array} buffer Destination buffer
       * @param {number} offset Destination offset
       * @returns {number} Bytes written
       */


      utf8.write = function utf8_write(string, buffer, offset) {
        var start = offset,
            c1,
            // character 1
        c2; // character 2

        for (var i = 0; i < string.length; ++i) {
          c1 = string.charCodeAt(i);

          if (c1 < 128) {
            buffer[offset++] = c1;
          } else if (c1 < 2048) {
            buffer[offset++] = c1 >> 6 | 192;
            buffer[offset++] = c1 & 63 | 128;
          } else if ((c1 & 0xFC00) === 0xD800 && ((c2 = string.charCodeAt(i + 1)) & 0xFC00) === 0xDC00) {
            c1 = 0x10000 + ((c1 & 0x03FF) << 10) + (c2 & 0x03FF);
            ++i;
            buffer[offset++] = c1 >> 18 | 240;
            buffer[offset++] = c1 >> 12 & 63 | 128;
            buffer[offset++] = c1 >> 6 & 63 | 128;
            buffer[offset++] = c1 & 63 | 128;
          } else {
            buffer[offset++] = c1 >> 12 | 224;
            buffer[offset++] = c1 >> 6 & 63 | 128;
            buffer[offset++] = c1 & 63 | 128;
          }
        }

        return offset - start;
      };
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      var protobuf = exports;
      /**
       * Build type, one of `"full"`, `"light"` or `"minimal"`.
       * @name build
       * @type {string}
       * @const
       */

      protobuf.build = "minimal"; // Serialization

      protobuf.Writer = require(16);
      protobuf.BufferWriter = require(17);
      protobuf.Reader = require(9);
      protobuf.BufferReader = require(10); // Utility

      protobuf.util = require(15);
      protobuf.rpc = require(12);
      protobuf.roots = require(11);
      protobuf.configure = configure;
      /* istanbul ignore next */

      /**
       * Reconfigures the library according to the environment.
       * @returns {undefined}
       */

      function configure() {
        protobuf.util._configure();

        protobuf.Writer._configure(protobuf.BufferWriter);

        protobuf.Reader._configure(protobuf.BufferReader);
      } // Set up buffer utility according to the environment


      configure();
    }, {
      "10": 10,
      "11": 11,
      "12": 12,
      "15": 15,
      "16": 16,
      "17": 17,
      "9": 9
    }],
    9: [function (require, module, exports) {
      "use strict";

      module.exports = Reader;

      var util = require(15);

      var BufferReader; // cyclic

      var LongBits = util.LongBits,
          utf8 = util.utf8;
      /* istanbul ignore next */

      function indexOutOfRange(reader, writeLength) {
        return RangeError("index out of range: " + reader.pos + " + " + (writeLength || 1) + " > " + reader.len);
      }
      /**
       * Constructs a new reader instance using the specified buffer.
       * @classdesc Wire format reader using `Uint8Array` if available, otherwise `Array`.
       * @constructor
       * @param {Uint8Array} buffer Buffer to read from
       */


      function Reader(buffer) {
        /**
         * Read buffer.
         * @type {Uint8Array}
         */
        this.buf = buffer;
        /**
         * Read buffer position.
         * @type {number}
         */

        this.pos = 0;
        /**
         * Read buffer length.
         * @type {number}
         */

        this.len = buffer.length;
      }

      var create_array = typeof Uint8Array !== "undefined" ? function create_typed_array(buffer) {
        if (buffer instanceof Uint8Array || Array.isArray(buffer)) return new Reader(buffer);
        throw Error("illegal buffer");
      }
      /* istanbul ignore next */
      : function create_array(buffer) {
        if (Array.isArray(buffer)) return new Reader(buffer);
        throw Error("illegal buffer");
      };

      var create = function create() {
        return util.Buffer ? function create_buffer_setup(buffer) {
          return (Reader.create = function create_buffer(buffer) {
            return util.Buffer.isBuffer(buffer) ? new BufferReader(buffer)
            /* istanbul ignore next */
            : create_array(buffer);
          })(buffer);
        }
        /* istanbul ignore next */
        : create_array;
      };
      /**
       * Creates a new reader using the specified buffer.
       * @function
       * @param {Uint8Array|Buffer} buffer Buffer to read from
       * @returns {Reader|BufferReader} A {@link BufferReader} if `buffer` is a Buffer, otherwise a {@link Reader}
       * @throws {Error} If `buffer` is not a valid buffer
       */


      Reader.create = create();
      Reader.prototype._slice = util.Array.prototype.subarray ||
      /* istanbul ignore next */
      util.Array.prototype.slice;
      /**
       * Reads a varint as an unsigned 32 bit value.
       * @function
       * @returns {number} Value read
       */

      Reader.prototype.uint32 = function read_uint32_setup() {
        var value = 4294967295; // optimizer type-hint, tends to deopt otherwise (?!)

        return function read_uint32() {
          value = (this.buf[this.pos] & 127) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 7) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 14) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 127) << 21) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          value = (value | (this.buf[this.pos] & 15) << 28) >>> 0;
          if (this.buf[this.pos++] < 128) return value;
          /* istanbul ignore if */

          if ((this.pos += 5) > this.len) {
            this.pos = this.len;
            throw indexOutOfRange(this, 10);
          }

          return value;
        };
      }();
      /**
       * Reads a varint as a signed 32 bit value.
       * @returns {number} Value read
       */


      Reader.prototype.int32 = function read_int32() {
        return this.uint32() | 0;
      };
      /**
       * Reads a zig-zag encoded varint as a signed 32 bit value.
       * @returns {number} Value read
       */


      Reader.prototype.sint32 = function read_sint32() {
        var value = this.uint32();
        return value >>> 1 ^ -(value & 1) | 0;
      };
      /* eslint-disable no-invalid-this */


      function readLongVarint() {
        // tends to deopt with local vars for octet etc.
        var bits = new LongBits(0, 0);
        var i = 0;

        if (this.len - this.pos > 4) {
          // fast route (lo)
          for (; i < 4; ++i) {
            // 1st..4th
            bits.lo = (bits.lo | (this.buf[this.pos] & 127) << i * 7) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          } // 5th


          bits.lo = (bits.lo | (this.buf[this.pos] & 127) << 28) >>> 0;
          bits.hi = (bits.hi | (this.buf[this.pos] & 127) >> 4) >>> 0;
          if (this.buf[this.pos++] < 128) return bits;
          i = 0;
        } else {
          for (; i < 3; ++i) {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this); // 1st..3th

            bits.lo = (bits.lo | (this.buf[this.pos] & 127) << i * 7) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          } // 4th


          bits.lo = (bits.lo | (this.buf[this.pos++] & 127) << i * 7) >>> 0;
          return bits;
        }

        if (this.len - this.pos > 4) {
          // fast route (hi)
          for (; i < 5; ++i) {
            // 6th..10th
            bits.hi = (bits.hi | (this.buf[this.pos] & 127) << i * 7 + 3) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          }
        } else {
          for (; i < 5; ++i) {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this); // 6th..10th

            bits.hi = (bits.hi | (this.buf[this.pos] & 127) << i * 7 + 3) >>> 0;
            if (this.buf[this.pos++] < 128) return bits;
          }
        }
        /* istanbul ignore next */


        throw Error("invalid varint encoding");
      }
      /* eslint-enable no-invalid-this */

      /**
       * Reads a varint as a signed 64 bit value.
       * @name Reader#int64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a varint as an unsigned 64 bit value.
       * @name Reader#uint64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a zig-zag encoded varint as a signed 64 bit value.
       * @name Reader#sint64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a varint as a boolean.
       * @returns {boolean} Value read
       */


      Reader.prototype.bool = function read_bool() {
        return this.uint32() !== 0;
      };

      function readFixed32_end(buf, end) {
        // note that this uses `end`, not `pos`
        return (buf[end - 4] | buf[end - 3] << 8 | buf[end - 2] << 16 | buf[end - 1] << 24) >>> 0;
      }
      /**
       * Reads fixed 32 bits as an unsigned 32 bit integer.
       * @returns {number} Value read
       */


      Reader.prototype.fixed32 = function read_fixed32() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        return readFixed32_end(this.buf, this.pos += 4);
      };
      /**
       * Reads fixed 32 bits as a signed 32 bit integer.
       * @returns {number} Value read
       */


      Reader.prototype.sfixed32 = function read_sfixed32() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        return readFixed32_end(this.buf, this.pos += 4) | 0;
      };
      /* eslint-disable no-invalid-this */


      function readFixed64()
      /* this: Reader */
      {
        /* istanbul ignore if */
        if (this.pos + 8 > this.len) throw indexOutOfRange(this, 8);
        return new LongBits(readFixed32_end(this.buf, this.pos += 4), readFixed32_end(this.buf, this.pos += 4));
      }
      /* eslint-enable no-invalid-this */

      /**
       * Reads fixed 64 bits.
       * @name Reader#fixed64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads zig-zag encoded fixed 64 bits.
       * @name Reader#sfixed64
       * @function
       * @returns {Long} Value read
       */

      /**
       * Reads a float (32 bit) as a number.
       * @function
       * @returns {number} Value read
       */


      Reader.prototype["float"] = function read_float() {
        /* istanbul ignore if */
        if (this.pos + 4 > this.len) throw indexOutOfRange(this, 4);
        var value = util["float"].readFloatLE(this.buf, this.pos);
        this.pos += 4;
        return value;
      };
      /**
       * Reads a double (64 bit float) as a number.
       * @function
       * @returns {number} Value read
       */


      Reader.prototype["double"] = function read_double() {
        /* istanbul ignore if */
        if (this.pos + 8 > this.len) throw indexOutOfRange(this, 4);
        var value = util["float"].readDoubleLE(this.buf, this.pos);
        this.pos += 8;
        return value;
      };
      /**
       * Reads a sequence of bytes preceeded by its length as a varint.
       * @returns {Uint8Array} Value read
       */


      Reader.prototype.bytes = function read_bytes() {
        var length = this.uint32(),
            start = this.pos,
            end = this.pos + length;
        /* istanbul ignore if */

        if (end > this.len) throw indexOutOfRange(this, length);
        this.pos += length;
        if (Array.isArray(this.buf)) // plain array
          return this.buf.slice(start, end);
        return start === end // fix for IE 10/Win8 and others' subarray returning array of size 1
        ? new this.buf.constructor(0) : this._slice.call(this.buf, start, end);
      };
      /**
       * Reads a string preceeded by its byte length as a varint.
       * @returns {string} Value read
       */


      Reader.prototype.string = function read_string() {
        var bytes = this.bytes();
        return utf8.read(bytes, 0, bytes.length);
      };
      /**
       * Skips the specified number of bytes if specified, otherwise skips a varint.
       * @param {number} [length] Length if known, otherwise a varint is assumed
       * @returns {Reader} `this`
       */


      Reader.prototype.skip = function skip(length) {
        if (typeof length === "number") {
          /* istanbul ignore if */
          if (this.pos + length > this.len) throw indexOutOfRange(this, length);
          this.pos += length;
        } else {
          do {
            /* istanbul ignore if */
            if (this.pos >= this.len) throw indexOutOfRange(this);
          } while (this.buf[this.pos++] & 128);
        }

        return this;
      };
      /**
       * Skips the next element of the specified wire type.
       * @param {number} wireType Wire type received
       * @returns {Reader} `this`
       */


      Reader.prototype.skipType = function (wireType) {
        switch (wireType) {
          case 0:
            this.skip();
            break;

          case 1:
            this.skip(8);
            break;

          case 2:
            this.skip(this.uint32());
            break;

          case 3:
            while ((wireType = this.uint32() & 7) !== 4) {
              this.skipType(wireType);
            }

            break;

          case 5:
            this.skip(4);
            break;

          /* istanbul ignore next */

          default:
            throw Error("invalid wire type " + wireType + " at offset " + this.pos);
        }

        return this;
      };

      Reader._configure = function (BufferReader_) {
        BufferReader = BufferReader_;
        Reader.create = create();

        BufferReader._configure();

        var fn = util.Long ? "toLong" :
        /* istanbul ignore next */
        "toNumber";
        util.merge(Reader.prototype, {
          int64: function read_int64() {
            return readLongVarint.call(this)[fn](false);
          },
          uint64: function read_uint64() {
            return readLongVarint.call(this)[fn](true);
          },
          sint64: function read_sint64() {
            return readLongVarint.call(this).zzDecode()[fn](false);
          },
          fixed64: function read_fixed64() {
            return readFixed64.call(this)[fn](true);
          },
          sfixed64: function read_sfixed64() {
            return readFixed64.call(this)[fn](false);
          }
        });
      };
    }, {
      "15": 15
    }],
    10: [function (require, module, exports) {
      "use strict";

      module.exports = BufferReader; // extends Reader

      var Reader = require(9);

      (BufferReader.prototype = Object.create(Reader.prototype)).constructor = BufferReader;

      var util = require(15);
      /**
       * Constructs a new buffer reader instance.
       * @classdesc Wire format reader using node buffers.
       * @extends Reader
       * @constructor
       * @param {Buffer} buffer Buffer to read from
       */


      function BufferReader(buffer) {
        Reader.call(this, buffer);
        /**
         * Read buffer.
         * @name BufferReader#buf
         * @type {Buffer}
         */
      }

      BufferReader._configure = function () {
        /* istanbul ignore else */
        if (util.Buffer) BufferReader.prototype._slice = util.Buffer.prototype.slice;
      };
      /**
       * @override
       */


      BufferReader.prototype.string = function read_string_buffer() {
        var len = this.uint32(); // modifies pos

        return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + len, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + len, this.len));
      };
      /**
       * Reads a sequence of bytes preceeded by its length as a varint.
       * @name BufferReader#bytes
       * @function
       * @returns {Buffer} Value read
       */


      BufferReader._configure();
    }, {
      "15": 15,
      "9": 9
    }],
    11: [function (require, module, exports) {
      "use strict";

      module.exports = {};
      /**
       * Named roots.
       * This is where pbjs stores generated structures (the option `-r, --root` specifies a name).
       * Can also be used manually to make roots available accross modules.
       * @name roots
       * @type {Object.<string,Root>}
       * @example
       * // pbjs -r myroot -o compiled.js ...
       *
       * // in another module:
       * require("./compiled.js");
       *
       * // in any subsequent module:
       * var root = protobuf.roots["myroot"];
       */
    }, {}],
    12: [function (require, module, exports) {
      "use strict";
      /**
       * Streaming RPC helpers.
       * @namespace
       */

      var rpc = exports;
      /**
       * RPC implementation passed to {@link Service#create} performing a service request on network level, i.e. by utilizing http requests or websockets.
       * @typedef RPCImpl
       * @type {function}
       * @param {Method|rpc.ServiceMethod<Message<{}>,Message<{}>>} method Reflected or static method being called
       * @param {Uint8Array} requestData Request data
       * @param {RPCImplCallback} callback Callback function
       * @returns {undefined}
       * @example
       * function rpcImpl(method, requestData, callback) {
       *     if (protobuf.util.lcFirst(method.name) !== "myMethod") // compatible with static code
       *         throw Error("no such method");
       *     asynchronouslyObtainAResponse(requestData, function(err, responseData) {
       *         callback(err, responseData);
       *     });
       * }
       */

      /**
       * Node-style callback as used by {@link RPCImpl}.
       * @typedef RPCImplCallback
       * @type {function}
       * @param {Error|null} error Error, if any, otherwise `null`
       * @param {Uint8Array|null} [response] Response data or `null` to signal end of stream, if there hasn't been an error
       * @returns {undefined}
       */

      rpc.Service = require(13);
    }, {
      "13": 13
    }],
    13: [function (require, module, exports) {
      "use strict";

      module.exports = Service;

      var util = require(15); // Extends EventEmitter


      (Service.prototype = Object.create(util.EventEmitter.prototype)).constructor = Service;
      /**
       * A service method callback as used by {@link rpc.ServiceMethod|ServiceMethod}.
       *
       * Differs from {@link RPCImplCallback} in that it is an actual callback of a service method which may not return `response = null`.
       * @typedef rpc.ServiceMethodCallback
       * @template TRes extends Message<TRes>
       * @type {function}
       * @param {Error|null} error Error, if any
       * @param {TRes} [response] Response message
       * @returns {undefined}
       */

      /**
       * A service method part of a {@link rpc.Service} as created by {@link Service.create}.
       * @typedef rpc.ServiceMethod
       * @template TReq extends Message<TReq>
       * @template TRes extends Message<TRes>
       * @type {function}
       * @param {TReq|Properties<TReq>} request Request message or plain object
       * @param {rpc.ServiceMethodCallback<TRes>} [callback] Node-style callback called with the error, if any, and the response message
       * @returns {Promise<Message<TRes>>} Promise if `callback` has been omitted, otherwise `undefined`
       */

      /**
       * Constructs a new RPC service instance.
       * @classdesc An RPC service as returned by {@link Service#create}.
       * @exports rpc.Service
       * @extends util.EventEmitter
       * @constructor
       * @param {RPCImpl} rpcImpl RPC implementation
       * @param {boolean} [requestDelimited=false] Whether requests are length-delimited
       * @param {boolean} [responseDelimited=false] Whether responses are length-delimited
       */

      function Service(rpcImpl, requestDelimited, responseDelimited) {
        if (typeof rpcImpl !== "function") throw TypeError("rpcImpl must be a function");
        util.EventEmitter.call(this);
        /**
         * RPC implementation. Becomes `null` once the service is ended.
         * @type {RPCImpl|null}
         */

        this.rpcImpl = rpcImpl;
        /**
         * Whether requests are length-delimited.
         * @type {boolean}
         */

        this.requestDelimited = Boolean(requestDelimited);
        /**
         * Whether responses are length-delimited.
         * @type {boolean}
         */

        this.responseDelimited = Boolean(responseDelimited);
      }
      /**
       * Calls a service method through {@link rpc.Service#rpcImpl|rpcImpl}.
       * @param {Method|rpc.ServiceMethod<TReq,TRes>} method Reflected or static method
       * @param {Constructor<TReq>} requestCtor Request constructor
       * @param {Constructor<TRes>} responseCtor Response constructor
       * @param {TReq|Properties<TReq>} request Request message or plain object
       * @param {rpc.ServiceMethodCallback<TRes>} callback Service callback
       * @returns {undefined}
       * @template TReq extends Message<TReq>
       * @template TRes extends Message<TRes>
       */


      Service.prototype.rpcCall = function rpcCall(method, requestCtor, responseCtor, request, callback) {
        if (!request) throw TypeError("request must be specified");
        var self = this;
        if (!callback) return util.asPromise(rpcCall, self, method, requestCtor, responseCtor, request);

        if (!self.rpcImpl) {
          setTimeout(function () {
            callback(Error("already ended"));
          }, 0);
          return undefined;
        }

        try {
          return self.rpcImpl(method, requestCtor[self.requestDelimited ? "encodeDelimited" : "encode"](request).finish(), function rpcCallback(err, response) {
            if (err) {
              self.emit("error", err, method);
              return callback(err);
            }

            if (response === null) {
              self.end(
              /* endedByRPC */
              true);
              return undefined;
            }

            if (!(response instanceof responseCtor)) {
              try {
                response = responseCtor[self.responseDelimited ? "decodeDelimited" : "decode"](response);
              } catch (err) {
                self.emit("error", err, method);
                return callback(err);
              }
            }

            self.emit("data", response, method);
            return callback(null, response);
          });
        } catch (err) {
          self.emit("error", err, method);
          setTimeout(function () {
            callback(err);
          }, 0);
          return undefined;
        }
      };
      /**
       * Ends this service and emits the `end` event.
       * @param {boolean} [endedByRPC=false] Whether the service has been ended by the RPC implementation.
       * @returns {rpc.Service} `this`
       */


      Service.prototype.end = function end(endedByRPC) {
        if (this.rpcImpl) {
          if (!endedByRPC) // signal end to rpcImpl
            this.rpcImpl(null, null, null);
          this.rpcImpl = null;
          this.emit("end").off();
        }

        return this;
      };
    }, {
      "15": 15
    }],
    14: [function (require, module, exports) {
      "use strict";

      module.exports = LongBits;

      var util = require(15);
      /**
       * Constructs new long bits.
       * @classdesc Helper class for working with the low and high bits of a 64 bit value.
       * @memberof util
       * @constructor
       * @param {number} lo Low 32 bits, unsigned
       * @param {number} hi High 32 bits, unsigned
       */


      function LongBits(lo, hi) {
        // note that the casts below are theoretically unnecessary as of today, but older statically
        // generated converter code might still call the ctor with signed 32bits. kept for compat.

        /**
         * Low bits.
         * @type {number}
         */
        this.lo = lo >>> 0;
        /**
         * High bits.
         * @type {number}
         */

        this.hi = hi >>> 0;
      }
      /**
       * Zero bits.
       * @memberof util.LongBits
       * @type {util.LongBits}
       */


      var zero = LongBits.zero = new LongBits(0, 0);

      zero.toNumber = function () {
        return 0;
      };

      zero.zzEncode = zero.zzDecode = function () {
        return this;
      };

      zero.length = function () {
        return 1;
      };
      /**
       * Zero hash.
       * @memberof util.LongBits
       * @type {string}
       */


      var zeroHash = LongBits.zeroHash = "\0\0\0\0\0\0\0\0";
      /**
       * Constructs new long bits from the specified number.
       * @param {number} value Value
       * @returns {util.LongBits} Instance
       */

      LongBits.fromNumber = function fromNumber(value) {
        if (value === 0) return zero;
        var sign = value < 0;
        if (sign) value = -value;
        var lo = value >>> 0,
            hi = (value - lo) / 4294967296 >>> 0;

        if (sign) {
          hi = ~hi >>> 0;
          lo = ~lo >>> 0;

          if (++lo > 4294967295) {
            lo = 0;
            if (++hi > 4294967295) hi = 0;
          }
        }

        return new LongBits(lo, hi);
      };
      /**
       * Constructs new long bits from a number, long or string.
       * @param {Long|number|string} value Value
       * @returns {util.LongBits} Instance
       */


      LongBits.from = function from(value) {
        if (typeof value === "number") return LongBits.fromNumber(value);

        if (util.isString(value)) {
          /* istanbul ignore else */
          if (util.Long) value = util.Long.fromString(value);else return LongBits.fromNumber(parseInt(value, 10));
        }

        return value.low || value.high ? new LongBits(value.low >>> 0, value.high >>> 0) : zero;
      };
      /**
       * Converts this long bits to a possibly unsafe JavaScript number.
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {number} Possibly unsafe number
       */


      LongBits.prototype.toNumber = function toNumber(unsigned) {
        if (!unsigned && this.hi >>> 31) {
          var lo = ~this.lo + 1 >>> 0,
              hi = ~this.hi >>> 0;
          if (!lo) hi = hi + 1 >>> 0;
          return -(lo + hi * 4294967296);
        }

        return this.lo + this.hi * 4294967296;
      };
      /**
       * Converts this long bits to a long.
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {Long} Long
       */


      LongBits.prototype.toLong = function toLong(unsigned) {
        return util.Long ? new util.Long(this.lo | 0, this.hi | 0, Boolean(unsigned))
        /* istanbul ignore next */
        : {
          low: this.lo | 0,
          high: this.hi | 0,
          unsigned: Boolean(unsigned)
        };
      };

      var charCodeAt = String.prototype.charCodeAt;
      /**
       * Constructs new long bits from the specified 8 characters long hash.
       * @param {string} hash Hash
       * @returns {util.LongBits} Bits
       */

      LongBits.fromHash = function fromHash(hash) {
        if (hash === zeroHash) return zero;
        return new LongBits((charCodeAt.call(hash, 0) | charCodeAt.call(hash, 1) << 8 | charCodeAt.call(hash, 2) << 16 | charCodeAt.call(hash, 3) << 24) >>> 0, (charCodeAt.call(hash, 4) | charCodeAt.call(hash, 5) << 8 | charCodeAt.call(hash, 6) << 16 | charCodeAt.call(hash, 7) << 24) >>> 0);
      };
      /**
       * Converts this long bits to a 8 characters long hash.
       * @returns {string} Hash
       */


      LongBits.prototype.toHash = function toHash() {
        return String.fromCharCode(this.lo & 255, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, this.hi & 255, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
      };
      /**
       * Zig-zag encodes this long bits.
       * @returns {util.LongBits} `this`
       */


      LongBits.prototype.zzEncode = function zzEncode() {
        var mask = this.hi >> 31;
        this.hi = ((this.hi << 1 | this.lo >>> 31) ^ mask) >>> 0;
        this.lo = (this.lo << 1 ^ mask) >>> 0;
        return this;
      };
      /**
       * Zig-zag decodes this long bits.
       * @returns {util.LongBits} `this`
       */


      LongBits.prototype.zzDecode = function zzDecode() {
        var mask = -(this.lo & 1);
        this.lo = ((this.lo >>> 1 | this.hi << 31) ^ mask) >>> 0;
        this.hi = (this.hi >>> 1 ^ mask) >>> 0;
        return this;
      };
      /**
       * Calculates the length of this longbits when encoded as a varint.
       * @returns {number} Length
       */


      LongBits.prototype.length = function length() {
        var part0 = this.lo,
            part1 = (this.lo >>> 28 | this.hi << 4) >>> 0,
            part2 = this.hi >>> 24;
        return part2 === 0 ? part1 === 0 ? part0 < 16384 ? part0 < 128 ? 1 : 2 : part0 < 2097152 ? 3 : 4 : part1 < 16384 ? part1 < 128 ? 5 : 6 : part1 < 2097152 ? 7 : 8 : part2 < 128 ? 9 : 10;
      };
    }, {
      "15": 15
    }],
    15: [function (require, module, exports) {
      "use strict";

      var util = exports; // used to return a Promise where callback is omitted

      util.asPromise = require(1); // converts to / from base64 encoded strings

      util.base64 = require(2); // base class of rpc.Service

      util.EventEmitter = require(3); // float handling accross browsers

      util["float"] = require(4); // requires modules optionally and hides the call from bundlers

      util.inquire = require(5); // converts to / from utf8 encoded strings

      util.utf8 = require(7); // provides a node-like buffer pool in the browser

      util.pool = require(6); // utility to work with the low and high bits of a 64 bit value

      util.LongBits = require(14);
      /**
       * Whether running within node or not.
       * @memberof util
       * @type {boolean}
       */

      util.isNode = Boolean(typeof global !== "undefined" && global && global.process && global.process.versions && global.process.versions.node);
      /**
       * Global object reference.
       * @memberof util
       * @type {Object}
       */

      util.global = util.isNode && global || typeof window !== "undefined" && window || typeof self !== "undefined" && self || this; // eslint-disable-line no-invalid-this

      /**
       * An immuable empty array.
       * @memberof util
       * @type {Array.<*>}
       * @const
       */

      util.emptyArray = Object.freeze ? Object.freeze([]) :
      /* istanbul ignore next */
      []; // used on prototypes

      /**
       * An immutable empty object.
       * @type {Object}
       * @const
       */

      util.emptyObject = Object.freeze ? Object.freeze({}) :
      /* istanbul ignore next */
      {}; // used on prototypes

      /**
       * Tests if the specified value is an integer.
       * @function
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is an integer
       */

      util.isInteger = Number.isInteger ||
      /* istanbul ignore next */
      function isInteger(value) {
        return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
      };
      /**
       * Tests if the specified value is a string.
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is a string
       */


      util.isString = function isString(value) {
        return typeof value === "string" || value instanceof String;
      };
      /**
       * Tests if the specified value is a non-null object.
       * @param {*} value Value to test
       * @returns {boolean} `true` if the value is a non-null object
       */


      util.isObject = function isObject(value) {
        return value && typeof value === "object";
      };
      /**
       * Checks if a property on a message is considered to be present.
       * This is an alias of {@link util.isSet}.
       * @function
       * @param {Object} obj Plain object or message instance
       * @param {string} prop Property name
       * @returns {boolean} `true` if considered to be present, otherwise `false`
       */


      util.isset =
      /**
       * Checks if a property on a message is considered to be present.
       * @param {Object} obj Plain object or message instance
       * @param {string} prop Property name
       * @returns {boolean} `true` if considered to be present, otherwise `false`
       */
      util.isSet = function isSet(obj, prop) {
        var value = obj[prop];
        if (value != null && obj.hasOwnProperty(prop)) // eslint-disable-line eqeqeq, no-prototype-builtins
          return typeof value !== "object" || (Array.isArray(value) ? value.length : Object.keys(value).length) > 0;
        return false;
      };
      /**
       * Any compatible Buffer instance.
       * This is a minimal stand-alone definition of a Buffer instance. The actual type is that exported by node's typings.
       * @interface Buffer
       * @extends Uint8Array
       */

      /**
       * Node's Buffer class if available.
       * @type {Constructor<Buffer>}
       */


      util.Buffer = function () {
        try {
          var Buffer = util.inquire("buffer").Buffer; // refuse to use non-node buffers if not explicitly assigned (perf reasons):

          return Buffer.prototype.utf8Write ? Buffer :
          /* istanbul ignore next */
          null;
        } catch (e) {
          /* istanbul ignore next */
          return null;
        }
      }(); // Internal alias of or polyfull for Buffer.from.


      util._Buffer_from = null; // Internal alias of or polyfill for Buffer.allocUnsafe.

      util._Buffer_allocUnsafe = null;
      /**
       * Creates a new buffer of whatever type supported by the environment.
       * @param {number|number[]} [sizeOrArray=0] Buffer size or number array
       * @returns {Uint8Array|Buffer} Buffer
       */

      util.newBuffer = function newBuffer(sizeOrArray) {
        /* istanbul ignore next */
        return typeof sizeOrArray === "number" ? util.Buffer ? util._Buffer_allocUnsafe(sizeOrArray) : new util.Array(sizeOrArray) : util.Buffer ? util._Buffer_from(sizeOrArray) : typeof Uint8Array === "undefined" ? sizeOrArray : new Uint8Array(sizeOrArray);
      };
      /**
       * Array implementation used in the browser. `Uint8Array` if supported, otherwise `Array`.
       * @type {Constructor<Uint8Array>}
       */


      util.Array = typeof Uint8Array !== "undefined" ? Uint8Array
      /* istanbul ignore next */
      : Array;
      /**
       * Any compatible Long instance.
       * This is a minimal stand-alone definition of a Long instance. The actual type is that exported by long.js.
       * @interface Long
       * @property {number} low Low bits
       * @property {number} high High bits
       * @property {boolean} unsigned Whether unsigned or not
       */

      /**
       * Long.js's Long class if available.
       * @type {Constructor<Long>}
       */

      util.Long =
      /* istanbul ignore next */
      util.global.dcodeIO &&
      /* istanbul ignore next */
      util.global.dcodeIO.Long ||
      /* istanbul ignore next */
      util.global.Long || util.inquire("long");
      /**
       * Regular expression used to verify 2 bit (`bool`) map keys.
       * @type {RegExp}
       * @const
       */

      util.key2Re = /^true|false|0|1$/;
      /**
       * Regular expression used to verify 32 bit (`int32` etc.) map keys.
       * @type {RegExp}
       * @const
       */

      util.key32Re = /^-?(?:0|[1-9][0-9]*)$/;
      /**
       * Regular expression used to verify 64 bit (`int64` etc.) map keys.
       * @type {RegExp}
       * @const
       */

      util.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/;
      /**
       * Converts a number or long to an 8 characters long hash string.
       * @param {Long|number} value Value to convert
       * @returns {string} Hash
       */

      util.longToHash = function longToHash(value) {
        return value ? util.LongBits.from(value).toHash() : util.LongBits.zeroHash;
      };
      /**
       * Converts an 8 characters long hash string to a long or number.
       * @param {string} hash Hash
       * @param {boolean} [unsigned=false] Whether unsigned or not
       * @returns {Long|number} Original value
       */


      util.longFromHash = function longFromHash(hash, unsigned) {
        var bits = util.LongBits.fromHash(hash);
        if (util.Long) return util.Long.fromBits(bits.lo, bits.hi, unsigned);
        return bits.toNumber(Boolean(unsigned));
      };
      /**
       * Merges the properties of the source object into the destination object.
       * @memberof util
       * @param {Object.<string,*>} dst Destination object
       * @param {Object.<string,*>} src Source object
       * @param {boolean} [ifNotSet=false] Merges only if the key is not already set
       * @returns {Object.<string,*>} Destination object
       */


      function merge(dst, src, ifNotSet) {
        // used by converters
        for (var keys = Object.keys(src), i = 0; i < keys.length; ++i) {
          if (dst[keys[i]] === undefined || !ifNotSet) dst[keys[i]] = src[keys[i]];
        }

        return dst;
      }

      util.merge = merge;
      /**
       * Converts the first character of a string to lower case.
       * @param {string} str String to convert
       * @returns {string} Converted string
       */

      util.lcFirst = function lcFirst(str) {
        return str.charAt(0).toLowerCase() + str.substring(1);
      };
      /**
       * Creates a custom error constructor.
       * @memberof util
       * @param {string} name Error name
       * @returns {Constructor<Error>} Custom error constructor
       */


      function newError(name) {
        function CustomError(message, properties) {
          if (!(this instanceof CustomError)) return new CustomError(message, properties); // Error.call(this, message);
          // ^ just returns a new error instance because the ctor can be called as a function

          Object.defineProperty(this, "message", {
            get: function get() {
              return message;
            }
          });
          /* istanbul ignore next */

          if (Error.captureStackTrace) // node
            Error.captureStackTrace(this, CustomError);else Object.defineProperty(this, "stack", {
            value: new Error().stack || ""
          });
          if (properties) merge(this, properties);
        }

        (CustomError.prototype = Object.create(Error.prototype)).constructor = CustomError;
        Object.defineProperty(CustomError.prototype, "name", {
          get: function get() {
            return name;
          }
        });

        CustomError.prototype.toString = function toString() {
          return this.name + ": " + this.message;
        };

        return CustomError;
      }

      util.newError = newError;
      /**
       * Constructs a new protocol error.
       * @classdesc Error subclass indicating a protocol specifc error.
       * @memberof util
       * @extends Error
       * @template T extends Message<T>
       * @constructor
       * @param {string} message Error message
       * @param {Object.<string,*>} [properties] Additional properties
       * @example
       * try {
       *     MyMessage.decode(someBuffer); // throws if required fields are missing
       * } catch (e) {
       *     if (e instanceof ProtocolError && e.instance)
       *         console.log("decoded so far: " + JSON.stringify(e.instance));
       * }
       */

      util.ProtocolError = newError("ProtocolError");
      /**
       * So far decoded message instance.
       * @name util.ProtocolError#instance
       * @type {Message<T>}
       */

      /**
       * A OneOf getter as returned by {@link util.oneOfGetter}.
       * @typedef OneOfGetter
       * @type {function}
       * @returns {string|undefined} Set field name, if any
       */

      /**
       * Builds a getter for a oneof's present field name.
       * @param {string[]} fieldNames Field names
       * @returns {OneOfGetter} Unbound getter
       */

      util.oneOfGetter = function getOneOf(fieldNames) {
        var fieldMap = {};

        for (var i = 0; i < fieldNames.length; ++i) {
          fieldMap[fieldNames[i]] = 1;
        }
        /**
         * @returns {string|undefined} Set field name, if any
         * @this Object
         * @ignore
         */


        return function () {
          // eslint-disable-line consistent-return
          for (var keys = Object.keys(this), i = keys.length - 1; i > -1; --i) {
            if (fieldMap[keys[i]] === 1 && this[keys[i]] !== undefined && this[keys[i]] !== null) return keys[i];
          }
        };
      };
      /**
       * A OneOf setter as returned by {@link util.oneOfSetter}.
       * @typedef OneOfSetter
       * @type {function}
       * @param {string|undefined} value Field name
       * @returns {undefined}
       */

      /**
       * Builds a setter for a oneof's present field name.
       * @param {string[]} fieldNames Field names
       * @returns {OneOfSetter} Unbound setter
       */


      util.oneOfSetter = function setOneOf(fieldNames) {
        /**
         * @param {string} name Field name
         * @returns {undefined}
         * @this Object
         * @ignore
         */
        return function (name) {
          for (var i = 0; i < fieldNames.length; ++i) {
            if (fieldNames[i] !== name) delete this[fieldNames[i]];
          }
        };
      };
      /**
       * Default conversion options used for {@link Message#toJSON} implementations.
       *
       * These options are close to proto3's JSON mapping with the exception that internal types like Any are handled just like messages. More precisely:
       *
       * - Longs become strings
       * - Enums become string keys
       * - Bytes become base64 encoded strings
       * - (Sub-)Messages become plain objects
       * - Maps become plain objects with all string keys
       * - Repeated fields become arrays
       * - NaN and Infinity for float and double fields become strings
       *
       * @type {IConversionOptions}
       * @see https://developers.google.com/protocol-buffers/docs/proto3?hl=en#json
       */


      util.toJSONOptions = {
        longs: String,
        enums: String,
        bytes: String,
        json: true
      }; // Sets up buffer utility according to the environment (called in index-minimal)

      util._configure = function () {
        var Buffer = util.Buffer;
        /* istanbul ignore if */

        if (!Buffer) {
          util._Buffer_from = util._Buffer_allocUnsafe = null;
          return;
        } // because node 4.x buffers are incompatible & immutable
        // see: https://github.com/dcodeIO/protobuf.js/pull/665


        util._Buffer_from = Buffer.from !== Uint8Array.from && Buffer.from ||
        /* istanbul ignore next */
        function Buffer_from(value, encoding) {
          return new Buffer(value, encoding);
        };

        util._Buffer_allocUnsafe = Buffer.allocUnsafe ||
        /* istanbul ignore next */
        function Buffer_allocUnsafe(size) {
          return new Buffer(size);
        };
      };
    }, {
      "1": 1,
      "14": 14,
      "2": 2,
      "3": 3,
      "4": 4,
      "5": 5,
      "6": 6,
      "7": 7
    }],
    16: [function (require, module, exports) {
      "use strict";

      module.exports = Writer;

      var util = require(15);

      var BufferWriter; // cyclic

      var LongBits = util.LongBits,
          base64 = util.base64,
          utf8 = util.utf8;
      /**
       * Constructs a new writer operation instance.
       * @classdesc Scheduled writer operation.
       * @constructor
       * @param {function(*, Uint8Array, number)} fn Function to call
       * @param {number} len Value byte length
       * @param {*} val Value to write
       * @ignore
       */

      function Op(fn, len, val) {
        /**
         * Function to call.
         * @type {function(Uint8Array, number, *)}
         */
        this.fn = fn;
        /**
         * Value byte length.
         * @type {number}
         */

        this.len = len;
        /**
         * Next operation.
         * @type {Writer.Op|undefined}
         */

        this.next = undefined;
        /**
         * Value to write.
         * @type {*}
         */

        this.val = val; // type varies
      }
      /* istanbul ignore next */


      function noop() {} // eslint-disable-line no-empty-function

      /**
       * Constructs a new writer state instance.
       * @classdesc Copied writer state.
       * @memberof Writer
       * @constructor
       * @param {Writer} writer Writer to copy state from
       * @ignore
       */


      function State(writer) {
        /**
         * Current head.
         * @type {Writer.Op}
         */
        this.head = writer.head;
        /**
         * Current tail.
         * @type {Writer.Op}
         */

        this.tail = writer.tail;
        /**
         * Current buffer length.
         * @type {number}
         */

        this.len = writer.len;
        /**
         * Next state.
         * @type {State|null}
         */

        this.next = writer.states;
      }
      /**
       * Constructs a new writer instance.
       * @classdesc Wire format writer using `Uint8Array` if available, otherwise `Array`.
       * @constructor
       */


      function Writer() {
        /**
         * Current length.
         * @type {number}
         */
        this.len = 0;
        /**
         * Operations head.
         * @type {Object}
         */

        this.head = new Op(noop, 0, 0);
        /**
         * Operations tail
         * @type {Object}
         */

        this.tail = this.head;
        /**
         * Linked forked states.
         * @type {Object|null}
         */

        this.states = null; // When a value is written, the writer calculates its byte length and puts it into a linked
        // list of operations to perform when finish() is called. This both allows us to allocate
        // buffers of the exact required size and reduces the amount of work we have to do compared
        // to first calculating over objects and then encoding over objects. In our case, the encoding
        // part is just a linked list walk calling operations with already prepared values.
      }

      var create = function create() {
        return util.Buffer ? function create_buffer_setup() {
          return (Writer.create = function create_buffer() {
            return new BufferWriter();
          })();
        }
        /* istanbul ignore next */
        : function create_array() {
          return new Writer();
        };
      };
      /**
       * Creates a new writer.
       * @function
       * @returns {BufferWriter|Writer} A {@link BufferWriter} when Buffers are supported, otherwise a {@link Writer}
       */


      Writer.create = create();
      /**
       * Allocates a buffer of the specified size.
       * @param {number} size Buffer size
       * @returns {Uint8Array} Buffer
       */

      Writer.alloc = function alloc(size) {
        return new util.Array(size);
      }; // Use Uint8Array buffer pool in the browser, just like node does with buffers

      /* istanbul ignore else */


      if (util.Array !== Array) Writer.alloc = util.pool(Writer.alloc, util.Array.prototype.subarray);
      /**
       * Pushes a new operation to the queue.
       * @param {function(Uint8Array, number, *)} fn Function to call
       * @param {number} len Value byte length
       * @param {number} val Value to write
       * @returns {Writer} `this`
       * @private
       */

      Writer.prototype._push = function push(fn, len, val) {
        this.tail = this.tail.next = new Op(fn, len, val);
        this.len += len;
        return this;
      };

      function writeByte(val, buf, pos) {
        buf[pos] = val & 255;
      }

      function writeVarint32(val, buf, pos) {
        while (val > 127) {
          buf[pos++] = val & 127 | 128;
          val >>>= 7;
        }

        buf[pos] = val;
      }
      /**
       * Constructs a new varint writer operation instance.
       * @classdesc Scheduled varint writer operation.
       * @extends Op
       * @constructor
       * @param {number} len Value byte length
       * @param {number} val Value to write
       * @ignore
       */


      function VarintOp(len, val) {
        this.len = len;
        this.next = undefined;
        this.val = val;
      }

      VarintOp.prototype = Object.create(Op.prototype);
      VarintOp.prototype.fn = writeVarint32;
      /**
       * Writes an unsigned 32 bit value as a varint.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */

      Writer.prototype.uint32 = function write_uint32(value) {
        // here, the call to this.push has been inlined and a varint specific Op subclass is used.
        // uint32 is by far the most frequently used operation and benefits significantly from this.
        this.len += (this.tail = this.tail.next = new VarintOp((value = value >>> 0) < 128 ? 1 : value < 16384 ? 2 : value < 2097152 ? 3 : value < 268435456 ? 4 : 5, value)).len;
        return this;
      };
      /**
       * Writes a signed 32 bit value as a varint.
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.int32 = function write_int32(value) {
        return value < 0 ? this._push(writeVarint64, 10, LongBits.fromNumber(value)) // 10 bytes per spec
        : this.uint32(value);
      };
      /**
       * Writes a 32 bit value as a varint, zig-zag encoded.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.sint32 = function write_sint32(value) {
        return this.uint32((value << 1 ^ value >> 31) >>> 0);
      };

      function writeVarint64(val, buf, pos) {
        while (val.hi) {
          buf[pos++] = val.lo & 127 | 128;
          val.lo = (val.lo >>> 7 | val.hi << 25) >>> 0;
          val.hi >>>= 7;
        }

        while (val.lo > 127) {
          buf[pos++] = val.lo & 127 | 128;
          val.lo = val.lo >>> 7;
        }

        buf[pos++] = val.lo;
      }
      /**
       * Writes an unsigned 64 bit value as a varint.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.uint64 = function write_uint64(value) {
        var bits = LongBits.from(value);
        return this._push(writeVarint64, bits.length(), bits);
      };
      /**
       * Writes a signed 64 bit value as a varint.
       * @function
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.int64 = Writer.prototype.uint64;
      /**
       * Writes a signed 64 bit value as a varint, zig-zag encoded.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */

      Writer.prototype.sint64 = function write_sint64(value) {
        var bits = LongBits.from(value).zzEncode();
        return this._push(writeVarint64, bits.length(), bits);
      };
      /**
       * Writes a boolish value as a varint.
       * @param {boolean} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.bool = function write_bool(value) {
        return this._push(writeByte, 1, value ? 1 : 0);
      };

      function writeFixed32(val, buf, pos) {
        buf[pos] = val & 255;
        buf[pos + 1] = val >>> 8 & 255;
        buf[pos + 2] = val >>> 16 & 255;
        buf[pos + 3] = val >>> 24;
      }
      /**
       * Writes an unsigned 32 bit value as fixed 32 bits.
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.fixed32 = function write_fixed32(value) {
        return this._push(writeFixed32, 4, value >>> 0);
      };
      /**
       * Writes a signed 32 bit value as fixed 32 bits.
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.sfixed32 = Writer.prototype.fixed32;
      /**
       * Writes an unsigned 64 bit value as fixed 64 bits.
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */

      Writer.prototype.fixed64 = function write_fixed64(value) {
        var bits = LongBits.from(value);
        return this._push(writeFixed32, 4, bits.lo)._push(writeFixed32, 4, bits.hi);
      };
      /**
       * Writes a signed 64 bit value as fixed 64 bits.
       * @function
       * @param {Long|number|string} value Value to write
       * @returns {Writer} `this`
       * @throws {TypeError} If `value` is a string and no long library is present.
       */


      Writer.prototype.sfixed64 = Writer.prototype.fixed64;
      /**
       * Writes a float (32 bit).
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */

      Writer.prototype["float"] = function write_float(value) {
        return this._push(util["float"].writeFloatLE, 4, value);
      };
      /**
       * Writes a double (64 bit float).
       * @function
       * @param {number} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype["double"] = function write_double(value) {
        return this._push(util["float"].writeDoubleLE, 8, value);
      };

      var writeBytes = util.Array.prototype.set ? function writeBytes_set(val, buf, pos) {
        buf.set(val, pos); // also works for plain array values
      }
      /* istanbul ignore next */
      : function writeBytes_for(val, buf, pos) {
        for (var i = 0; i < val.length; ++i) {
          buf[pos + i] = val[i];
        }
      };
      /**
       * Writes a sequence of bytes.
       * @param {Uint8Array|string} value Buffer or base64 encoded string to write
       * @returns {Writer} `this`
       */

      Writer.prototype.bytes = function write_bytes(value) {
        var len = value.length >>> 0;
        if (!len) return this._push(writeByte, 1, 0);

        if (util.isString(value)) {
          var buf = Writer.alloc(len = base64.length(value));
          base64.decode(value, buf, 0);
          value = buf;
        }

        return this.uint32(len)._push(writeBytes, len, value);
      };
      /**
       * Writes a string.
       * @param {string} value Value to write
       * @returns {Writer} `this`
       */


      Writer.prototype.string = function write_string(value) {
        var len = utf8.length(value);
        return len ? this.uint32(len)._push(utf8.write, len, value) : this._push(writeByte, 1, 0);
      };
      /**
       * Forks this writer's state by pushing it to a stack.
       * Calling {@link Writer#reset|reset} or {@link Writer#ldelim|ldelim} resets the writer to the previous state.
       * @returns {Writer} `this`
       */


      Writer.prototype.fork = function fork() {
        this.states = new State(this);
        this.head = this.tail = new Op(noop, 0, 0);
        this.len = 0;
        return this;
      };
      /**
       * Resets this instance to the last state.
       * @returns {Writer} `this`
       */


      Writer.prototype.reset = function reset() {
        if (this.states) {
          this.head = this.states.head;
          this.tail = this.states.tail;
          this.len = this.states.len;
          this.states = this.states.next;
        } else {
          this.head = this.tail = new Op(noop, 0, 0);
          this.len = 0;
        }

        return this;
      };
      /**
       * Resets to the last state and appends the fork state's current write length as a varint followed by its operations.
       * @returns {Writer} `this`
       */


      Writer.prototype.ldelim = function ldelim() {
        var head = this.head,
            tail = this.tail,
            len = this.len;
        this.reset().uint32(len);

        if (len) {
          this.tail.next = head.next; // skip noop

          this.tail = tail;
          this.len += len;
        }

        return this;
      };
      /**
       * Finishes the write operation.
       * @returns {Uint8Array} Finished buffer
       */


      Writer.prototype.finish = function finish() {
        var head = this.head.next,
            // skip noop
        buf = this.constructor.alloc(this.len),
            pos = 0;

        while (head) {
          head.fn(head.val, buf, pos);
          pos += head.len;
          head = head.next;
        } // this.head = this.tail = null;


        return buf;
      };

      Writer._configure = function (BufferWriter_) {
        BufferWriter = BufferWriter_;
        Writer.create = create();

        BufferWriter._configure();
      };
    }, {
      "15": 15
    }],
    17: [function (require, module, exports) {
      "use strict";

      module.exports = BufferWriter; // extends Writer

      var Writer = require(16);

      (BufferWriter.prototype = Object.create(Writer.prototype)).constructor = BufferWriter;

      var util = require(15);
      /**
       * Constructs a new buffer writer instance.
       * @classdesc Wire format writer using node buffers.
       * @extends Writer
       * @constructor
       */


      function BufferWriter() {
        Writer.call(this);
      }

      BufferWriter._configure = function () {
        /**
         * Allocates a buffer of the specified size.
         * @function
         * @param {number} size Buffer size
         * @returns {Buffer} Buffer
         */
        BufferWriter.alloc = util._Buffer_allocUnsafe;
        BufferWriter.writeBytesBuffer = util.Buffer && util.Buffer.prototype instanceof Uint8Array && util.Buffer.prototype.set.name === "set" ? function writeBytesBuffer_set(val, buf, pos) {
          buf.set(val, pos); // faster than copy (requires node >= 4 where Buffers extend Uint8Array and set is properly inherited)
          // also works for plain array values
        }
        /* istanbul ignore next */
        : function writeBytesBuffer_copy(val, buf, pos) {
          if (val.copy) // Buffer values
            val.copy(buf, pos, 0, val.length);else for (var i = 0; i < val.length;) {
            // plain array values
            buf[pos++] = val[i++];
          }
        };
      };
      /**
       * @override
       */


      BufferWriter.prototype.bytes = function write_bytes_buffer(value) {
        if (util.isString(value)) value = util._Buffer_from(value, "base64");
        var len = value.length >>> 0;
        this.uint32(len);
        if (len) this._push(BufferWriter.writeBytesBuffer, len, value);
        return this;
      };

      function writeStringBuffer(val, buf, pos) {
        if (val.length < 40) // plain js is faster for short strings (probably due to redundant assertions)
          util.utf8.write(val, buf, pos);else if (buf.utf8Write) buf.utf8Write(val, pos);else buf.write(val, pos);
      }
      /**
       * @override
       */


      BufferWriter.prototype.string = function write_string_buffer(value) {
        var len = util.Buffer.byteLength(value);
        this.uint32(len);
        if (len) this._push(writeStringBuffer, len, value);
        return this;
      };
      /**
       * Finishes the write operation.
       * @name BufferWriter#finish
       * @function
       * @returns {Buffer} Finished buffer
       */


      BufferWriter._configure();
    }, {
      "15": 15,
      "16": 16
    }]
  }, {}, [8]);
})(); 

cc._RF.pop();

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9hc3NldHNcXG1zZ1xccHJvdG9idWYuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7Ozs7OztBQU1BLENBQUMsVUFBUyxTQUFULEVBQW1CO0FBQUM7O0FBQWEsR0FBQyxTQUFTLE9BQVQsQ0FBaUIsT0FBakIsRUFBMEIsS0FBMUIsRUFBaUMsT0FBakMsRUFBMEM7QUFFekU7QUFDQTtBQUNBO0FBQ0E7QUFFQSxhQUFTLFFBQVQsQ0FBa0IsSUFBbEIsRUFBd0I7QUFDcEIsVUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUQsQ0FBbkI7QUFDQSxVQUFJLENBQUMsT0FBTCxFQUNJLE9BQU8sQ0FBQyxJQUFELENBQVAsQ0FBYyxDQUFkLEVBQWlCLElBQWpCLENBQXNCLE9BQU8sR0FBRyxLQUFLLENBQUMsSUFBRCxDQUFMLEdBQWM7QUFBRSxRQUFBLE9BQU8sRUFBRTtBQUFYLE9BQTlDLEVBQStELFFBQS9ELEVBQXlFLE9BQXpFLEVBQWtGLE9BQU8sQ0FBQyxPQUExRjtBQUNKLGFBQU8sT0FBTyxDQUFDLE9BQWY7QUFDSDs7QUFFRCxRQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUQsQ0FBUixDQUF2QixDQWR5RSxDQWdCekU7O0FBQ0EsSUFBQSxRQUFRLENBQUMsSUFBVCxDQUFjLE1BQWQsQ0FBcUIsUUFBckIsR0FBZ0MsUUFBaEMsQ0FqQnlFLENBbUJ6RTs7QUFDQSxRQUFJLE9BQU8sTUFBUCxLQUFrQixVQUFsQixJQUFnQyxNQUFNLENBQUMsR0FBM0MsRUFDSSxNQUFNLENBQUMsQ0FBQyxNQUFELENBQUQsRUFBVyxVQUFTLElBQVQsRUFBZTtBQUM1QixVQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBakIsRUFBeUI7QUFDckIsUUFBQSxRQUFRLENBQUMsSUFBVCxDQUFjLElBQWQsR0FBcUIsSUFBckI7QUFDQSxRQUFBLFFBQVEsQ0FBQyxTQUFUO0FBQ0g7O0FBQ0QsYUFBTyxRQUFQO0FBQ0gsS0FOSyxDQUFOLENBckJxRSxDQTZCekU7O0FBQ0EsUUFBSSxPQUFPLE1BQVAsS0FBa0IsUUFBbEIsSUFBOEIsTUFBOUIsSUFBd0MsTUFBTSxDQUFDLE9BQW5ELEVBQ0ksTUFBTSxDQUFDLE9BQVAsR0FBaUIsUUFBakI7QUFFUCxHQWpDaUM7QUFpQ2hDO0FBQXFCO0FBQUMsT0FBRSxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUMzRDs7QUFDQSxNQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFNBQWpCO0FBRUE7Ozs7Ozs7OztBQVNBOzs7Ozs7Ozs7QUFRQSxlQUFTLFNBQVQsQ0FBbUIsRUFBbkIsRUFBdUI7QUFBRztBQUExQixRQUEwQztBQUN0QyxZQUFJLE1BQU0sR0FBSSxJQUFJLEtBQUosQ0FBVSxTQUFTLENBQUMsTUFBVixHQUFtQixDQUE3QixDQUFkO0FBQUEsWUFDSSxNQUFNLEdBQUksQ0FEZDtBQUFBLFlBRUksS0FBSyxHQUFLLENBRmQ7QUFBQSxZQUdJLE9BQU8sR0FBRyxJQUhkOztBQUlBLGVBQU8sS0FBSyxHQUFHLFNBQVMsQ0FBQyxNQUF6QjtBQUNJLFVBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLFNBQVMsQ0FBQyxLQUFLLEVBQU4sQ0FBNUI7QUFESjs7QUFFQSxlQUFPLElBQUksT0FBSixDQUFZLFNBQVMsUUFBVCxDQUFrQixPQUFsQixFQUEyQixNQUEzQixFQUFtQztBQUNsRCxVQUFBLE1BQU0sQ0FBQyxNQUFELENBQU4sR0FBaUIsU0FBUyxRQUFULENBQWtCO0FBQUc7QUFBckIsWUFBcUM7QUFDbEQsZ0JBQUksT0FBSixFQUFhO0FBQ1QsY0FBQSxPQUFPLEdBQUcsS0FBVjtBQUNBLGtCQUFJLEdBQUosRUFDSSxNQUFNLENBQUMsR0FBRCxDQUFOLENBREosS0FFSztBQUNELG9CQUFJLE1BQU0sR0FBRyxJQUFJLEtBQUosQ0FBVSxTQUFTLENBQUMsTUFBVixHQUFtQixDQUE3QixDQUFiO0FBQUEsb0JBQ0ksTUFBTSxHQUFHLENBRGI7O0FBRUEsdUJBQU8sTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUF2QjtBQUNJLGtCQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixTQUFTLENBQUMsTUFBRCxDQUE1QjtBQURKOztBQUVBLGdCQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsSUFBZCxFQUFvQixNQUFwQjtBQUNIO0FBQ0o7QUFDSixXQWJEOztBQWNBLGNBQUk7QUFDQSxZQUFBLEVBQUUsQ0FBQyxLQUFILENBQVMsR0FBRyxJQUFJLElBQWhCLEVBQXNCLE1BQXRCO0FBQ0gsV0FGRCxDQUVFLE9BQU8sR0FBUCxFQUFZO0FBQ1YsZ0JBQUksT0FBSixFQUFhO0FBQ1QsY0FBQSxPQUFPLEdBQUcsS0FBVjtBQUNBLGNBQUEsTUFBTSxDQUFDLEdBQUQsQ0FBTjtBQUNIO0FBQ0o7QUFDSixTQXZCTSxDQUFQO0FBd0JIO0FBRUEsS0F0RHlCLEVBc0R4QixFQXREd0IsQ0FBSDtBQXNEakIsT0FBRSxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUN6QztBQUVBOzs7Ozs7QUFLQSxVQUFJLE1BQU0sR0FBRyxPQUFiO0FBRUE7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCO0FBQ3BDLFlBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFmO0FBQ0EsWUFBSSxDQUFDLENBQUwsRUFDSSxPQUFPLENBQVA7QUFDSixZQUFJLENBQUMsR0FBRyxDQUFSOztBQUNBLGVBQU8sRUFBRSxDQUFGLEdBQU0sQ0FBTixHQUFVLENBQVYsSUFBZSxNQUFNLENBQUMsTUFBUCxDQUFjLENBQWQsTUFBcUIsR0FBM0M7QUFDSSxZQUFFLENBQUY7QUFESjs7QUFFQSxlQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsQ0FBMUIsSUFBK0IsQ0FBL0IsR0FBbUMsQ0FBMUM7QUFDSCxPQVJELENBZnlDLENBeUJ6Qzs7O0FBQ0EsVUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFKLENBQVUsRUFBVixDQUFWLENBMUJ5QyxDQTRCekM7O0FBQ0EsVUFBSSxHQUFHLEdBQUcsSUFBSSxLQUFKLENBQVUsR0FBVixDQUFWLENBN0J5QyxDQStCekM7O0FBQ0EsV0FBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxFQUFwQjtBQUNJLFFBQUEsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxDQUFDLEdBQUcsRUFBSixHQUFTLENBQUMsR0FBRyxFQUFiLEdBQWtCLENBQUMsR0FBRyxFQUFKLEdBQVMsQ0FBQyxHQUFHLEVBQWIsR0FBa0IsQ0FBQyxHQUFHLEVBQUosR0FBUyxDQUFDLEdBQUcsQ0FBYixHQUFpQixDQUFDLEdBQUcsRUFBSixHQUFTLEVBQXhFLENBQUgsR0FBaUYsQ0FBQyxFQUFsRjtBQURKO0FBR0E7Ozs7Ozs7OztBQU9BLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCLEtBQXhCLEVBQStCLEdBQS9CLEVBQW9DO0FBQ2hELFlBQUksS0FBSyxHQUFHLElBQVo7QUFBQSxZQUNJLEtBQUssR0FBRyxFQURaO0FBRUEsWUFBSSxDQUFDLEdBQUcsQ0FBUjtBQUFBLFlBQVc7QUFDUCxRQUFBLENBQUMsR0FBRyxDQURSO0FBQUEsWUFDVztBQUNQLFFBQUEsQ0FGSixDQUhnRCxDQUtyQzs7QUFDWCxlQUFPLEtBQUssR0FBRyxHQUFmLEVBQW9CO0FBQ2hCLGNBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBZDs7QUFDQSxrQkFBUSxDQUFSO0FBQ0ksaUJBQUssQ0FBTDtBQUNJLGNBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFOLENBQWhCO0FBQ0EsY0FBQSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBTCxLQUFXLENBQWY7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBVixDQUFoQjtBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUFoQjtBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQTs7QUFDSixpQkFBSyxDQUFMO0FBQ0ksY0FBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFWLENBQWhCO0FBQ0EsY0FBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUwsQ0FBaEI7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7QUFmUjs7QUFpQkEsY0FBSSxDQUFDLEdBQUcsSUFBUixFQUFjO0FBQ1YsYUFBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQWIsQ0FBTixFQUF3QixJQUF4QixDQUE2QixNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFsQyxDQUE3QjtBQUNBLFlBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSDtBQUNKOztBQUNELFlBQUksQ0FBSixFQUFPO0FBQ0gsVUFBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxHQUFHLENBQUMsQ0FBRCxDQUFoQjtBQUNBLFVBQUEsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsRUFBYjtBQUNBLGNBQUksQ0FBQyxLQUFLLENBQVYsRUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxFQUFiO0FBQ1A7O0FBQ0QsWUFBSSxLQUFKLEVBQVc7QUFDUCxjQUFJLENBQUosRUFDSSxLQUFLLENBQUMsSUFBTixDQUFXLE1BQU0sQ0FBQyxZQUFQLENBQW9CLEtBQXBCLENBQTBCLE1BQTFCLEVBQWtDLEtBQUssQ0FBQyxLQUFOLENBQVksQ0FBWixFQUFlLENBQWYsQ0FBbEMsQ0FBWDtBQUNKLGlCQUFPLEtBQUssQ0FBQyxJQUFOLENBQVcsRUFBWCxDQUFQO0FBQ0g7O0FBQ0QsZUFBTyxNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFLLENBQUMsS0FBTixDQUFZLENBQVosRUFBZSxDQUFmLENBQWxDLENBQVA7QUFDSCxPQTFDRDs7QUE0Q0EsVUFBSSxlQUFlLEdBQUcsa0JBQXRCO0FBRUE7Ozs7Ozs7OztBQVFBLE1BQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsU0FBUyxNQUFULENBQWdCLE1BQWhCLEVBQXdCLE1BQXhCLEVBQWdDLE1BQWhDLEVBQXdDO0FBQ3BELFlBQUksS0FBSyxHQUFHLE1BQVo7QUFDQSxZQUFJLENBQUMsR0FBRyxDQUFSO0FBQUEsWUFBVztBQUNQLFFBQUEsQ0FESixDQUZvRCxDQUd6Qzs7QUFDWCxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUEzQixHQUFvQztBQUNoQyxjQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsVUFBUCxDQUFrQixDQUFDLEVBQW5CLENBQVI7QUFDQSxjQUFJLENBQUMsS0FBSyxFQUFOLElBQVksQ0FBQyxHQUFHLENBQXBCLEVBQ0k7QUFDSixjQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFELENBQVIsTUFBaUIsU0FBckIsRUFDSSxNQUFNLEtBQUssQ0FBQyxlQUFELENBQVg7O0FBQ0osa0JBQVEsQ0FBUjtBQUNJLGlCQUFLLENBQUw7QUFDSSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0EsY0FBQSxDQUFDLEdBQUcsQ0FBSjtBQUNBOztBQUNKLGlCQUFLLENBQUw7QUFDSSxjQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixDQUFDLElBQUksQ0FBTCxHQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUF4QztBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUFaLEdBQWdCLENBQUMsQ0FBQyxHQUFHLEVBQUwsS0FBWSxDQUEvQztBQUNBLGNBQUEsQ0FBQyxHQUFHLENBQUo7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7O0FBQ0osaUJBQUssQ0FBTDtBQUNJLGNBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLENBQUMsQ0FBQyxHQUFHLENBQUwsS0FBVyxDQUFYLEdBQWUsQ0FBbEM7QUFDQSxjQUFBLENBQUMsR0FBRyxDQUFKO0FBQ0E7QUFsQlI7QUFvQkg7O0FBQ0QsWUFBSSxDQUFDLEtBQUssQ0FBVixFQUNJLE1BQU0sS0FBSyxDQUFDLGVBQUQsQ0FBWDtBQUNKLGVBQU8sTUFBTSxHQUFHLEtBQWhCO0FBQ0gsT0FsQ0Q7QUFvQ0E7Ozs7Ozs7QUFLQSxNQUFBLE1BQU0sQ0FBQyxJQUFQLEdBQWMsU0FBUyxJQUFULENBQWMsTUFBZCxFQUFzQjtBQUNoQyxlQUFPLG1FQUFtRSxJQUFuRSxDQUF3RSxNQUF4RSxDQUFQO0FBQ0gsT0FGRDtBQUlDLEtBN0lPLEVBNklOLEVBN0lNLENBdERlO0FBbU1qQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsWUFBakI7QUFFQTs7Ozs7OztBQU1BLGVBQVMsWUFBVCxHQUF3QjtBQUVwQjs7Ozs7QUFLQSxhQUFLLFVBQUwsR0FBa0IsRUFBbEI7QUFDSDtBQUVEOzs7Ozs7Ozs7QUFPQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLEVBQXZCLEdBQTRCLFNBQVMsRUFBVCxDQUFZLEdBQVosRUFBaUIsRUFBakIsRUFBcUIsR0FBckIsRUFBMEI7QUFDbEQsU0FBQyxLQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsTUFBeUIsS0FBSyxVQUFMLENBQWdCLEdBQWhCLElBQXVCLEVBQWhELENBQUQsRUFBc0QsSUFBdEQsQ0FBMkQ7QUFDdkQsVUFBQSxFQUFFLEVBQUksRUFEaUQ7QUFFdkQsVUFBQSxHQUFHLEVBQUcsR0FBRyxJQUFJO0FBRjBDLFNBQTNEO0FBSUEsZUFBTyxJQUFQO0FBQ0gsT0FORDtBQVFBOzs7Ozs7OztBQU1BLE1BQUEsWUFBWSxDQUFDLFNBQWIsQ0FBdUIsR0FBdkIsR0FBNkIsU0FBUyxHQUFULENBQWEsR0FBYixFQUFrQixFQUFsQixFQUFzQjtBQUMvQyxZQUFJLEdBQUcsS0FBSyxTQUFaLEVBQ0ksS0FBSyxVQUFMLEdBQWtCLEVBQWxCLENBREosS0FFSztBQUNELGNBQUksRUFBRSxLQUFLLFNBQVgsRUFDSSxLQUFLLFVBQUwsQ0FBZ0IsR0FBaEIsSUFBdUIsRUFBdkIsQ0FESixLQUVLO0FBQ0QsZ0JBQUksU0FBUyxHQUFHLEtBQUssVUFBTCxDQUFnQixHQUFoQixDQUFoQjs7QUFDQSxpQkFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBOUI7QUFDSSxrQkFBSSxTQUFTLENBQUMsQ0FBRCxDQUFULENBQWEsRUFBYixLQUFvQixFQUF4QixFQUNJLFNBQVMsQ0FBQyxNQUFWLENBQWlCLENBQWpCLEVBQW9CLENBQXBCLEVBREosS0FHSSxFQUFFLENBQUY7QUFKUjtBQUtIO0FBQ0o7QUFDRCxlQUFPLElBQVA7QUFDSCxPQWhCRDtBQWtCQTs7Ozs7Ozs7QUFNQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLElBQXZCLEdBQThCLFNBQVMsSUFBVCxDQUFjLEdBQWQsRUFBbUI7QUFDN0MsWUFBSSxTQUFTLEdBQUcsS0FBSyxVQUFMLENBQWdCLEdBQWhCLENBQWhCOztBQUNBLFlBQUksU0FBSixFQUFlO0FBQ1gsY0FBSSxJQUFJLEdBQUcsRUFBWDtBQUFBLGNBQ0ksQ0FBQyxHQUFHLENBRFI7O0FBRUEsaUJBQU8sQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFyQjtBQUNJLFlBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFTLENBQUMsQ0FBQyxFQUFGLENBQW5CO0FBREo7O0FBRUEsZUFBSyxDQUFDLEdBQUcsQ0FBVCxFQUFZLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBMUI7QUFDSSxZQUFBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYSxFQUFiLENBQWdCLEtBQWhCLENBQXNCLFNBQVMsQ0FBQyxDQUFDLEVBQUYsQ0FBVCxDQUFlLEdBQXJDLEVBQTBDLElBQTFDO0FBREo7QUFFSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQVhEO0FBYUMsS0E5RU8sRUE4RU4sRUE5RU0sQ0FuTWU7QUFpUmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBRUEsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixPQUFPLENBQUMsT0FBRCxDQUF4QjtBQUVBOzs7Ozs7QUFNQTs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7OztBQVNBOzs7Ozs7Ozs7QUFTQTs7Ozs7Ozs7OztBQVVBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7OztBQVNBOzs7Ozs7OztBQVNBOztBQUNBLGVBQVMsT0FBVCxDQUFpQixPQUFqQixFQUEwQjtBQUV0QjtBQUNBLFlBQUksT0FBTyxZQUFQLEtBQXdCLFdBQTVCLEVBQXlDLENBQUMsWUFBVztBQUVqRCxjQUFJLEdBQUcsR0FBRyxJQUFJLFlBQUosQ0FBaUIsQ0FBRSxDQUFDLENBQUgsQ0FBakIsQ0FBVjtBQUFBLGNBQ0ksR0FBRyxHQUFHLElBQUksVUFBSixDQUFlLEdBQUcsQ0FBQyxNQUFuQixDQURWO0FBQUEsY0FFSSxFQUFFLEdBQUksR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBRnJCOztBQUlBLG1CQUFTLGtCQUFULENBQTRCLEdBQTVCLEVBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLEVBQTJDO0FBQ3ZDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIOztBQUVELG1CQUFTLGtCQUFULENBQTRCLEdBQTVCLEVBQWlDLEdBQWpDLEVBQXNDLEdBQXRDLEVBQTJDO0FBQ3ZDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDs7QUFFQSxtQkFBUyxpQkFBVCxDQUEyQixHQUEzQixFQUFnQyxHQUFoQyxFQUFxQztBQUNqQyxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsbUJBQU8sR0FBRyxDQUFDLENBQUQsQ0FBVjtBQUNIOztBQUVELG1CQUFTLGlCQUFULENBQTJCLEdBQTNCLEVBQWdDLEdBQWhDLEVBQXFDO0FBQ2pDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFELENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxtQkFBTyxHQUFHLENBQUMsQ0FBRCxDQUFWO0FBQ0g7QUFFRDs7O0FBQ0EsVUFBQSxPQUFPLENBQUMsV0FBUixHQUFzQixFQUFFLEdBQUcsaUJBQUgsR0FBdUIsaUJBQS9DO0FBQ0E7O0FBQ0EsVUFBQSxPQUFPLENBQUMsV0FBUixHQUFzQixFQUFFLEdBQUcsaUJBQUgsR0FBdUIsaUJBQS9DLENBOUNpRCxDQWdEckQ7QUFDQyxTQWpEd0MsSUFBekMsS0FpRFcsQ0FBQyxZQUFXO0FBRW5CLG1CQUFTLGtCQUFULENBQTRCLFNBQTVCLEVBQXVDLEdBQXZDLEVBQTRDLEdBQTVDLEVBQWlELEdBQWpELEVBQXNEO0FBQ2xELGdCQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsQ0FBTixHQUFVLENBQVYsR0FBYyxDQUF6QjtBQUNBLGdCQUFJLElBQUosRUFDSSxHQUFHLEdBQUcsQ0FBQyxHQUFQO0FBQ0osZ0JBQUksR0FBRyxLQUFLLENBQVosRUFDSSxTQUFTLENBQUMsSUFBSSxHQUFKLEdBQVUsQ0FBVjtBQUFjO0FBQWUsYUFBN0I7QUFBaUM7QUFBaUIsc0JBQW5ELEVBQStELEdBQS9ELEVBQW9FLEdBQXBFLENBQVQsQ0FESixLQUVLLElBQUksS0FBSyxDQUFDLEdBQUQsQ0FBVCxFQUNELFNBQVMsQ0FBQyxVQUFELEVBQWEsR0FBYixFQUFrQixHQUFsQixDQUFULENBREMsS0FFQSxJQUFJLEdBQUcsR0FBRyxzQkFBVixFQUFrQztBQUNuQyxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsVUFBZCxNQUE4QixDQUEvQixFQUFrQyxHQUFsQyxFQUF1QyxHQUF2QyxDQUFULENBREMsS0FFQSxJQUFJLEdBQUcsR0FBRyxzQkFBVixFQUFrQztBQUNuQyxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsSUFBSSxDQUFDLEtBQUwsQ0FBVyxHQUFHLEdBQUcscUJBQWpCLENBQWQsTUFBMkQsQ0FBNUQsRUFBK0QsR0FBL0QsRUFBb0UsR0FBcEUsQ0FBVCxDQURDLEtBRUE7QUFDRCxrQkFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEdBQVQsSUFBZ0IsSUFBSSxDQUFDLEdBQWhDLENBQWY7QUFBQSxrQkFDSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksQ0FBQyxRQUFiLENBQU4sR0FBK0IsT0FBMUMsSUFBcUQsT0FEcEU7QUFFQSxjQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsUUFBUSxHQUFHLEdBQVgsSUFBa0IsRUFBL0IsR0FBb0MsUUFBckMsTUFBbUQsQ0FBcEQsRUFBdUQsR0FBdkQsRUFBNEQsR0FBNUQsQ0FBVDtBQUNIO0FBQ0o7O0FBRUQsVUFBQSxPQUFPLENBQUMsWUFBUixHQUF1QixrQkFBa0IsQ0FBQyxJQUFuQixDQUF3QixJQUF4QixFQUE4QixXQUE5QixDQUF2QjtBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEIsV0FBOUIsQ0FBdkI7O0FBRUEsbUJBQVMsaUJBQVQsQ0FBMkIsUUFBM0IsRUFBcUMsR0FBckMsRUFBMEMsR0FBMUMsRUFBK0M7QUFDM0MsZ0JBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFELEVBQU0sR0FBTixDQUFuQjtBQUFBLGdCQUNJLElBQUksR0FBRyxDQUFDLElBQUksSUFBSSxFQUFULElBQWUsQ0FBZixHQUFtQixDQUQ5QjtBQUFBLGdCQUVJLFFBQVEsR0FBRyxJQUFJLEtBQUssRUFBVCxHQUFjLEdBRjdCO0FBQUEsZ0JBR0ksUUFBUSxHQUFHLElBQUksR0FBRyxPQUh0QjtBQUlBLG1CQUFPLFFBQVEsS0FBSyxHQUFiLEdBQ0QsUUFBUSxHQUNSLEdBRFEsR0FFUixJQUFJLEdBQUcsUUFITixHQUlELFFBQVEsS0FBSyxDQUFiLENBQWU7QUFBZixjQUNBLElBQUksR0FBRyxxQkFBUCxHQUErQixRQUQvQixHQUVBLElBQUksR0FBRyxJQUFJLENBQUMsR0FBTCxDQUFTLENBQVQsRUFBWSxRQUFRLEdBQUcsR0FBdkIsQ0FBUCxJQUFzQyxRQUFRLEdBQUcsT0FBakQsQ0FOTjtBQU9IOztBQUVELFVBQUEsT0FBTyxDQUFDLFdBQVIsR0FBc0IsaUJBQWlCLENBQUMsSUFBbEIsQ0FBdUIsSUFBdkIsRUFBNkIsVUFBN0IsQ0FBdEI7QUFDQSxVQUFBLE9BQU8sQ0FBQyxXQUFSLEdBQXNCLGlCQUFpQixDQUFDLElBQWxCLENBQXVCLElBQXZCLEVBQTZCLFVBQTdCLENBQXRCO0FBRUgsU0F6Q1UsSUFwRFcsQ0ErRnRCOztBQUNBLFlBQUksT0FBTyxZQUFQLEtBQXdCLFdBQTVCLEVBQXlDLENBQUMsWUFBVztBQUVqRCxjQUFJLEdBQUcsR0FBRyxJQUFJLFlBQUosQ0FBaUIsQ0FBQyxDQUFDLENBQUYsQ0FBakIsQ0FBVjtBQUFBLGNBQ0ksR0FBRyxHQUFHLElBQUksVUFBSixDQUFlLEdBQUcsQ0FBQyxNQUFuQixDQURWO0FBQUEsY0FFSSxFQUFFLEdBQUksR0FBRyxDQUFDLENBQUQsQ0FBSCxLQUFXLEdBRnJCOztBQUlBLG1CQUFTLG1CQUFULENBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDLEdBQXZDLEVBQTRDO0FBQ3hDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIOztBQUVELG1CQUFTLG1CQUFULENBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDLEdBQXZDLEVBQTRDO0FBQ3hDLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQVQ7QUFDQSxZQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNBLFlBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsRUFBRSxHQUFHLG1CQUFILEdBQXlCLG1CQUFuRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsRUFBRSxHQUFHLG1CQUFILEdBQXlCLG1CQUFuRDs7QUFFQSxtQkFBUyxrQkFBVCxDQUE0QixHQUE1QixFQUFpQyxHQUFqQyxFQUFzQztBQUNsQyxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxtQkFBTyxHQUFHLENBQUMsQ0FBRCxDQUFWO0FBQ0g7O0FBRUQsbUJBQVMsa0JBQVQsQ0FBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUQsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsWUFBQSxHQUFHLENBQUMsQ0FBRCxDQUFILEdBQVMsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQVo7QUFDQSxZQUFBLEdBQUcsQ0FBQyxDQUFELENBQUgsR0FBUyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBWjtBQUNBLFlBQUEsR0FBRyxDQUFDLENBQUQsQ0FBSCxHQUFTLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFaO0FBQ0EsbUJBQU8sR0FBRyxDQUFDLENBQUQsQ0FBVjtBQUNIO0FBRUQ7OztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRDtBQUNBOztBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsRUFBRSxHQUFHLGtCQUFILEdBQXdCLGtCQUFqRCxDQTlEaUQsQ0FnRXJEO0FBQ0MsU0FqRXdDLElBQXpDLEtBaUVXLENBQUMsWUFBVztBQUVuQixtQkFBUyxtQkFBVCxDQUE2QixTQUE3QixFQUF3QyxJQUF4QyxFQUE4QyxJQUE5QyxFQUFvRCxHQUFwRCxFQUF5RCxHQUF6RCxFQUE4RCxHQUE5RCxFQUFtRTtBQUMvRCxnQkFBSSxJQUFJLEdBQUcsR0FBRyxHQUFHLENBQU4sR0FBVSxDQUFWLEdBQWMsQ0FBekI7QUFDQSxnQkFBSSxJQUFKLEVBQ0ksR0FBRyxHQUFHLENBQUMsR0FBUDs7QUFDSixnQkFBSSxHQUFHLEtBQUssQ0FBWixFQUFlO0FBQ1gsY0FBQSxTQUFTLENBQUMsQ0FBRCxFQUFJLEdBQUosRUFBUyxHQUFHLEdBQUcsSUFBZixDQUFUO0FBQ0EsY0FBQSxTQUFTLENBQUMsSUFBSSxHQUFKLEdBQVUsQ0FBVjtBQUFjO0FBQWUsZUFBN0I7QUFBaUM7QUFBaUIsd0JBQW5ELEVBQStELEdBQS9ELEVBQW9FLEdBQUcsR0FBRyxJQUExRSxDQUFUO0FBQ0gsYUFIRCxNQUdPLElBQUksS0FBSyxDQUFDLEdBQUQsQ0FBVCxFQUFnQjtBQUNuQixjQUFBLFNBQVMsQ0FBQyxDQUFELEVBQUksR0FBSixFQUFTLEdBQUcsR0FBRyxJQUFmLENBQVQ7QUFDQSxjQUFBLFNBQVMsQ0FBQyxVQUFELEVBQWEsR0FBYixFQUFrQixHQUFHLEdBQUcsSUFBeEIsQ0FBVDtBQUNILGFBSE0sTUFHQSxJQUFJLEdBQUcsR0FBRyx1QkFBVixFQUFtQztBQUFFO0FBQ3hDLGNBQUEsU0FBUyxDQUFDLENBQUQsRUFBSSxHQUFKLEVBQVMsR0FBRyxHQUFHLElBQWYsQ0FBVDtBQUNBLGNBQUEsU0FBUyxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQVIsR0FBYSxVQUFkLE1BQThCLENBQS9CLEVBQWtDLEdBQWxDLEVBQXVDLEdBQUcsR0FBRyxJQUE3QyxDQUFUO0FBQ0gsYUFITSxNQUdBO0FBQ0gsa0JBQUksUUFBSjs7QUFDQSxrQkFBSSxHQUFHLEdBQUcsdUJBQVYsRUFBbUM7QUFBRTtBQUNqQyxnQkFBQSxRQUFRLEdBQUcsR0FBRyxHQUFHLE1BQWpCO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLFFBQVEsS0FBSyxDQUFkLEVBQWlCLEdBQWpCLEVBQXNCLEdBQUcsR0FBRyxJQUE1QixDQUFUO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQVIsR0FBYSxRQUFRLEdBQUcsVUFBekIsTUFBeUMsQ0FBMUMsRUFBNkMsR0FBN0MsRUFBa0QsR0FBRyxHQUFHLElBQXhELENBQVQ7QUFDSCxlQUpELE1BSU87QUFDSCxvQkFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEdBQVQsSUFBZ0IsSUFBSSxDQUFDLEdBQWhDLENBQWY7QUFDQSxvQkFBSSxRQUFRLEtBQUssSUFBakIsRUFDSSxRQUFRLEdBQUcsSUFBWDtBQUNKLGdCQUFBLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksQ0FBQyxRQUFiLENBQWpCO0FBQ0EsZ0JBQUEsU0FBUyxDQUFDLFFBQVEsR0FBRyxnQkFBWCxLQUFnQyxDQUFqQyxFQUFvQyxHQUFwQyxFQUF5QyxHQUFHLEdBQUcsSUFBL0MsQ0FBVDtBQUNBLGdCQUFBLFNBQVMsQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFSLEdBQWEsUUFBUSxHQUFHLElBQVgsSUFBbUIsRUFBaEMsR0FBcUMsUUFBUSxHQUFHLE9BQVgsR0FBcUIsT0FBM0QsTUFBd0UsQ0FBekUsRUFBNEUsR0FBNUUsRUFBaUYsR0FBRyxHQUFHLElBQXZGLENBQVQ7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsVUFBQSxPQUFPLENBQUMsYUFBUixHQUF3QixtQkFBbUIsQ0FBQyxJQUFwQixDQUF5QixJQUF6QixFQUErQixXQUEvQixFQUE0QyxDQUE1QyxFQUErQyxDQUEvQyxDQUF4QjtBQUNBLFVBQUEsT0FBTyxDQUFDLGFBQVIsR0FBd0IsbUJBQW1CLENBQUMsSUFBcEIsQ0FBeUIsSUFBekIsRUFBK0IsV0FBL0IsRUFBNEMsQ0FBNUMsRUFBK0MsQ0FBL0MsQ0FBeEI7O0FBRUEsbUJBQVMsa0JBQVQsQ0FBNEIsUUFBNUIsRUFBc0MsSUFBdEMsRUFBNEMsSUFBNUMsRUFBa0QsR0FBbEQsRUFBdUQsR0FBdkQsRUFBNEQ7QUFDeEQsZ0JBQUksRUFBRSxHQUFHLFFBQVEsQ0FBQyxHQUFELEVBQU0sR0FBRyxHQUFHLElBQVosQ0FBakI7QUFBQSxnQkFDSSxFQUFFLEdBQUcsUUFBUSxDQUFDLEdBQUQsRUFBTSxHQUFHLEdBQUcsSUFBWixDQURqQjtBQUVBLGdCQUFJLElBQUksR0FBRyxDQUFDLEVBQUUsSUFBSSxFQUFQLElBQWEsQ0FBYixHQUFpQixDQUE1QjtBQUFBLGdCQUNJLFFBQVEsR0FBRyxFQUFFLEtBQUssRUFBUCxHQUFZLElBRDNCO0FBQUEsZ0JBRUksUUFBUSxHQUFHLGNBQWMsRUFBRSxHQUFHLE9BQW5CLElBQThCLEVBRjdDO0FBR0EsbUJBQU8sUUFBUSxLQUFLLElBQWIsR0FDRCxRQUFRLEdBQ1IsR0FEUSxHQUVSLElBQUksR0FBRyxRQUhOLEdBSUQsUUFBUSxLQUFLLENBQWIsQ0FBZTtBQUFmLGNBQ0EsSUFBSSxHQUFHLE1BQVAsR0FBZ0IsUUFEaEIsR0FFQSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUwsQ0FBUyxDQUFULEVBQVksUUFBUSxHQUFHLElBQXZCLENBQVAsSUFBdUMsUUFBUSxHQUFHLGdCQUFsRCxDQU5OO0FBT0g7O0FBRUQsVUFBQSxPQUFPLENBQUMsWUFBUixHQUF1QixrQkFBa0IsQ0FBQyxJQUFuQixDQUF3QixJQUF4QixFQUE4QixVQUE5QixFQUEwQyxDQUExQyxFQUE2QyxDQUE3QyxDQUF2QjtBQUNBLFVBQUEsT0FBTyxDQUFDLFlBQVIsR0FBdUIsa0JBQWtCLENBQUMsSUFBbkIsQ0FBd0IsSUFBeEIsRUFBOEIsVUFBOUIsRUFBMEMsQ0FBMUMsRUFBNkMsQ0FBN0MsQ0FBdkI7QUFFSCxTQXJEVTtBQXVEWCxlQUFPLE9BQVA7QUFDSCxPQWpUd0MsQ0FtVHpDOzs7QUFFQSxlQUFTLFdBQVQsQ0FBcUIsR0FBckIsRUFBMEIsR0FBMUIsRUFBK0IsR0FBL0IsRUFBb0M7QUFDaEMsUUFBQSxHQUFHLENBQUMsR0FBRCxDQUFILEdBQWdCLEdBQUcsR0FBVSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLENBQVIsR0FBYSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLEVBQVIsR0FBYSxHQUE3QjtBQUNBLFFBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZ0IsR0FBRyxLQUFLLEVBQXhCO0FBQ0g7O0FBRUQsZUFBUyxXQUFULENBQXFCLEdBQXJCLEVBQTBCLEdBQTFCLEVBQStCLEdBQS9CLEVBQW9DO0FBQ2hDLFFBQUEsR0FBRyxDQUFDLEdBQUQsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBeEI7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsS0FBSyxFQUFSLEdBQWEsR0FBN0I7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsS0FBSyxDQUFSLEdBQWEsR0FBN0I7QUFDQSxRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQWdCLEdBQUcsR0FBVSxHQUE3QjtBQUNIOztBQUVELGVBQVMsVUFBVCxDQUFvQixHQUFwQixFQUF5QixHQUF6QixFQUE4QjtBQUMxQixlQUFPLENBQUMsR0FBRyxDQUFDLEdBQUQsQ0FBSCxHQUNBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLENBRGhCLEdBRUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsRUFGaEIsR0FHQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxJQUFnQixFQUhqQixNQUd5QixDQUhoQztBQUlIOztBQUVELGVBQVMsVUFBVCxDQUFvQixHQUFwQixFQUF5QixHQUF6QixFQUE4QjtBQUMxQixlQUFPLENBQUMsR0FBRyxDQUFDLEdBQUQsQ0FBSCxJQUFnQixFQUFoQixHQUNBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLEVBRGhCLEdBRUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsQ0FGaEIsR0FHQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FISixNQUdtQixDQUgxQjtBQUlIO0FBRUEsS0FqVk8sRUFpVk4sRUFqVk0sQ0FqUmU7QUFrbUJqQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsT0FBakI7QUFFQTs7Ozs7OztBQU1BLGVBQVMsT0FBVCxDQUFpQixVQUFqQixFQUE2QjtBQUN6QixZQUFJO0FBQ0EsY0FBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsT0FBUixDQUFnQixHQUFoQixFQUFvQixJQUFwQixDQUFELENBQUosQ0FBZ0MsVUFBaEMsQ0FBVixDQURBLENBQ3VEOztBQUN2RCxjQUFJLEdBQUcsS0FBSyxHQUFHLENBQUMsTUFBSixJQUFjLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixFQUFpQixNQUFwQyxDQUFQLEVBQ0ksT0FBTyxHQUFQO0FBQ1AsU0FKRCxDQUlFLE9BQU8sQ0FBUCxFQUFVLENBQUUsQ0FMVyxDQUtWOzs7QUFDZixlQUFPLElBQVA7QUFDSDtBQUVBLEtBbkJPLEVBbUJOLEVBbkJNLENBbG1CZTtBQXFuQmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixJQUFqQjtBQUVBOzs7Ozs7OztBQVFBOzs7Ozs7Ozs7O0FBVUE7Ozs7Ozs7Ozs7QUFTQSxlQUFTLElBQVQsQ0FBYyxLQUFkLEVBQXFCLEtBQXJCLEVBQTRCLElBQTVCLEVBQWtDO0FBQzlCLFlBQUksSUFBSSxHQUFLLElBQUksSUFBSSxJQUFyQjtBQUNBLFlBQUksR0FBRyxHQUFNLElBQUksS0FBSyxDQUF0QjtBQUNBLFlBQUksSUFBSSxHQUFLLElBQWI7QUFDQSxZQUFJLE1BQU0sR0FBRyxJQUFiO0FBQ0EsZUFBTyxTQUFTLFVBQVQsQ0FBb0IsSUFBcEIsRUFBMEI7QUFDN0IsY0FBSSxJQUFJLEdBQUcsQ0FBUCxJQUFZLElBQUksR0FBRyxHQUF2QixFQUNJLE9BQU8sS0FBSyxDQUFDLElBQUQsQ0FBWjs7QUFDSixjQUFJLE1BQU0sR0FBRyxJQUFULEdBQWdCLElBQXBCLEVBQTBCO0FBQ3RCLFlBQUEsSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFELENBQVo7QUFDQSxZQUFBLE1BQU0sR0FBRyxDQUFUO0FBQ0g7O0FBQ0QsY0FBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLElBQU4sQ0FBVyxJQUFYLEVBQWlCLE1BQWpCLEVBQXlCLE1BQU0sSUFBSSxJQUFuQyxDQUFWO0FBQ0EsY0FBSSxNQUFNLEdBQUcsQ0FBYixFQUFnQjtBQUNaLFlBQUEsTUFBTSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQVYsSUFBZSxDQUF4QjtBQUNKLGlCQUFPLEdBQVA7QUFDSCxTQVhEO0FBWUg7QUFFQSxLQWxETyxFQWtETixFQWxETSxDQXJuQmU7QUF1cUJqQixPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3pDO0FBRUE7Ozs7OztBQUtBLFVBQUksSUFBSSxHQUFHLE9BQVg7QUFFQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsTUFBTCxHQUFjLFNBQVMsV0FBVCxDQUFxQixNQUFyQixFQUE2QjtBQUN2QyxZQUFJLEdBQUcsR0FBRyxDQUFWO0FBQUEsWUFDSSxDQUFDLEdBQUcsQ0FEUjs7QUFFQSxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUEzQixFQUFtQyxFQUFFLENBQXJDLEVBQXdDO0FBQ3BDLFVBQUEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxVQUFQLENBQWtCLENBQWxCLENBQUo7QUFDQSxjQUFJLENBQUMsR0FBRyxHQUFSLEVBQ0ksR0FBRyxJQUFJLENBQVAsQ0FESixLQUVLLElBQUksQ0FBQyxHQUFHLElBQVIsRUFDRCxHQUFHLElBQUksQ0FBUCxDQURDLEtBRUEsSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFMLE1BQWlCLE1BQWpCLElBQTJCLENBQUMsTUFBTSxDQUFDLFVBQVAsQ0FBa0IsQ0FBQyxHQUFHLENBQXRCLElBQTJCLE1BQTVCLE1BQXdDLE1BQXZFLEVBQStFO0FBQ2hGLGNBQUUsQ0FBRjtBQUNBLFlBQUEsR0FBRyxJQUFJLENBQVA7QUFDSCxXQUhJLE1BSUQsR0FBRyxJQUFJLENBQVA7QUFDUDs7QUFDRCxlQUFPLEdBQVA7QUFDSCxPQWhCRDtBQWtCQTs7Ozs7Ozs7O0FBT0EsTUFBQSxJQUFJLENBQUMsSUFBTCxHQUFZLFNBQVMsU0FBVCxDQUFtQixNQUFuQixFQUEyQixLQUEzQixFQUFrQyxHQUFsQyxFQUF1QztBQUMvQyxZQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBaEI7QUFDQSxZQUFJLEdBQUcsR0FBRyxDQUFWLEVBQ0ksT0FBTyxFQUFQO0FBQ0osWUFBSSxLQUFLLEdBQUcsSUFBWjtBQUFBLFlBQ0ksS0FBSyxHQUFHLEVBRFo7QUFBQSxZQUVJLENBQUMsR0FBRyxDQUZSO0FBQUEsWUFFVztBQUNQLFFBQUEsQ0FISixDQUorQyxDQU9wQzs7QUFDWCxlQUFPLEtBQUssR0FBRyxHQUFmLEVBQW9CO0FBQ2hCLFVBQUEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBVjtBQUNBLGNBQUksQ0FBQyxHQUFHLEdBQVIsRUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxDQUFiLENBREosS0FFSyxJQUFJLENBQUMsR0FBRyxHQUFKLElBQVcsQ0FBQyxHQUFHLEdBQW5CLEVBQ0QsS0FBSyxDQUFDLENBQUMsRUFBRixDQUFMLEdBQWEsQ0FBQyxDQUFDLEdBQUcsRUFBTCxLQUFZLENBQVosR0FBZ0IsTUFBTSxDQUFDLEtBQUssRUFBTixDQUFOLEdBQWtCLEVBQS9DLENBREMsS0FFQSxJQUFJLENBQUMsR0FBRyxHQUFKLElBQVcsQ0FBQyxHQUFHLEdBQW5CLEVBQXdCO0FBQ3pCLFlBQUEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBTCxLQUFXLEVBQVgsR0FBZ0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBbkIsS0FBMEIsRUFBMUMsR0FBK0MsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBbkIsS0FBMEIsQ0FBekUsR0FBNkUsTUFBTSxDQUFDLEtBQUssRUFBTixDQUFOLEdBQWtCLEVBQWhHLElBQXNHLE9BQTFHO0FBQ0EsWUFBQSxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxVQUFVLENBQUMsSUFBSSxFQUFmLENBQWI7QUFDQSxZQUFBLEtBQUssQ0FBQyxDQUFDLEVBQUYsQ0FBTCxHQUFhLFVBQVUsQ0FBQyxHQUFHLElBQWQsQ0FBYjtBQUNILFdBSkksTUFLRCxLQUFLLENBQUMsQ0FBQyxFQUFGLENBQUwsR0FBYSxDQUFDLENBQUMsR0FBRyxFQUFMLEtBQVksRUFBWixHQUFpQixDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQU4sQ0FBTixHQUFrQixFQUFuQixLQUEwQixDQUEzQyxHQUErQyxNQUFNLENBQUMsS0FBSyxFQUFOLENBQU4sR0FBa0IsRUFBOUU7O0FBQ0osY0FBSSxDQUFDLEdBQUcsSUFBUixFQUFjO0FBQ1YsYUFBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQWIsQ0FBTixFQUF3QixJQUF4QixDQUE2QixNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFsQyxDQUE3QjtBQUNBLFlBQUEsQ0FBQyxHQUFHLENBQUo7QUFDSDtBQUNKOztBQUNELFlBQUksS0FBSixFQUFXO0FBQ1AsY0FBSSxDQUFKLEVBQ0ksS0FBSyxDQUFDLElBQU4sQ0FBVyxNQUFNLENBQUMsWUFBUCxDQUFvQixLQUFwQixDQUEwQixNQUExQixFQUFrQyxLQUFLLENBQUMsS0FBTixDQUFZLENBQVosRUFBZSxDQUFmLENBQWxDLENBQVg7QUFDSixpQkFBTyxLQUFLLENBQUMsSUFBTixDQUFXLEVBQVgsQ0FBUDtBQUNIOztBQUNELGVBQU8sTUFBTSxDQUFDLFlBQVAsQ0FBb0IsS0FBcEIsQ0FBMEIsTUFBMUIsRUFBa0MsS0FBSyxDQUFDLEtBQU4sQ0FBWSxDQUFaLEVBQWUsQ0FBZixDQUFsQyxDQUFQO0FBQ0gsT0EvQkQ7QUFpQ0E7Ozs7Ozs7OztBQU9BLE1BQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxTQUFTLFVBQVQsQ0FBb0IsTUFBcEIsRUFBNEIsTUFBNUIsRUFBb0MsTUFBcEMsRUFBNEM7QUFDckQsWUFBSSxLQUFLLEdBQUcsTUFBWjtBQUFBLFlBQ0ksRUFESjtBQUFBLFlBQ1E7QUFDSixRQUFBLEVBRkosQ0FEcUQsQ0FHN0M7O0FBQ1IsYUFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBM0IsRUFBbUMsRUFBRSxDQUFyQyxFQUF3QztBQUNwQyxVQUFBLEVBQUUsR0FBRyxNQUFNLENBQUMsVUFBUCxDQUFrQixDQUFsQixDQUFMOztBQUNBLGNBQUksRUFBRSxHQUFHLEdBQVQsRUFBYztBQUNWLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQW5CO0FBQ0gsV0FGRCxNQUVPLElBQUksRUFBRSxHQUFHLElBQVQsRUFBZTtBQUNsQixZQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixFQUFFLElBQUksQ0FBTixHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsR0FBUyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0gsV0FITSxNQUdBLElBQUksQ0FBQyxFQUFFLEdBQUcsTUFBTixNQUFrQixNQUFsQixJQUE0QixDQUFDLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQyxVQUFQLENBQWtCLENBQUMsR0FBRyxDQUF0QixDQUFOLElBQWtDLE1BQW5DLE1BQStDLE1BQS9FLEVBQXVGO0FBQzFGLFlBQUEsRUFBRSxHQUFHLFdBQVcsQ0FBQyxFQUFFLEdBQUcsTUFBTixLQUFpQixFQUE1QixLQUFtQyxFQUFFLEdBQUcsTUFBeEMsQ0FBTDtBQUNBLGNBQUUsQ0FBRjtBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsSUFBSSxFQUFOLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxJQUFJLEVBQU4sR0FBVyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxJQUFJLENBQU4sR0FBVyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0EsWUFBQSxNQUFNLENBQUMsTUFBTSxFQUFQLENBQU4sR0FBbUIsRUFBRSxHQUFTLEVBQVgsR0FBZ0IsR0FBbkM7QUFDSCxXQVBNLE1BT0E7QUFDSCxZQUFBLE1BQU0sQ0FBQyxNQUFNLEVBQVAsQ0FBTixHQUFtQixFQUFFLElBQUksRUFBTixHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsSUFBSSxDQUFOLEdBQVcsRUFBWCxHQUFnQixHQUFuQztBQUNBLFlBQUEsTUFBTSxDQUFDLE1BQU0sRUFBUCxDQUFOLEdBQW1CLEVBQUUsR0FBUyxFQUFYLEdBQWdCLEdBQW5DO0FBQ0g7QUFDSjs7QUFDRCxlQUFPLE1BQU0sR0FBRyxLQUFoQjtBQUNILE9BekJEO0FBMkJDLEtBM0dPLEVBMkdOLEVBM0dNLENBdnFCZTtBQWt4QmpCLE9BQUUsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDekM7O0FBQ0EsVUFBSSxRQUFRLEdBQUcsT0FBZjtBQUVBOzs7Ozs7O0FBTUEsTUFBQSxRQUFRLENBQUMsS0FBVCxHQUFpQixTQUFqQixDQVZ5QyxDQVl6Qzs7QUFDQSxNQUFBLFFBQVEsQ0FBQyxNQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CO0FBQ0EsTUFBQSxRQUFRLENBQUMsWUFBVCxHQUF3QixPQUFPLENBQUMsRUFBRCxDQUEvQjtBQUNBLE1BQUEsUUFBUSxDQUFDLE1BQVQsR0FBd0IsT0FBTyxDQUFDLENBQUQsQ0FBL0I7QUFDQSxNQUFBLFFBQVEsQ0FBQyxZQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CLENBaEJ5QyxDQWtCekM7O0FBQ0EsTUFBQSxRQUFRLENBQUMsSUFBVCxHQUF3QixPQUFPLENBQUMsRUFBRCxDQUEvQjtBQUNBLE1BQUEsUUFBUSxDQUFDLEdBQVQsR0FBd0IsT0FBTyxDQUFDLEVBQUQsQ0FBL0I7QUFDQSxNQUFBLFFBQVEsQ0FBQyxLQUFULEdBQXdCLE9BQU8sQ0FBQyxFQUFELENBQS9CO0FBQ0EsTUFBQSxRQUFRLENBQUMsU0FBVCxHQUF3QixTQUF4QjtBQUVBOztBQUNBOzs7OztBQUlBLGVBQVMsU0FBVCxHQUFxQjtBQUNqQixRQUFBLFFBQVEsQ0FBQyxJQUFULENBQWMsVUFBZDs7QUFDQSxRQUFBLFFBQVEsQ0FBQyxNQUFULENBQWdCLFVBQWhCLENBQTJCLFFBQVEsQ0FBQyxZQUFwQzs7QUFDQSxRQUFBLFFBQVEsQ0FBQyxNQUFULENBQWdCLFVBQWhCLENBQTJCLFFBQVEsQ0FBQyxZQUFwQztBQUNILE9BakN3QyxDQW1DekM7OztBQUNBLE1BQUEsU0FBUztBQUVSLEtBdENPLEVBc0NOO0FBQUMsWUFBSyxFQUFOO0FBQVMsWUFBSyxFQUFkO0FBQWlCLFlBQUssRUFBdEI7QUFBeUIsWUFBSyxFQUE5QjtBQUFpQyxZQUFLLEVBQXRDO0FBQXlDLFlBQUssRUFBOUM7QUFBaUQsV0FBSTtBQUFyRCxLQXRDTSxDQWx4QmU7QUF3ekJvQyxPQUFFLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQzlGOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsTUFBakI7O0FBRUEsVUFBSSxJQUFJLEdBQVEsT0FBTyxDQUFDLEVBQUQsQ0FBdkI7O0FBRUEsVUFBSSxZQUFKLENBTjhGLENBTTVFOztBQUVsQixVQUFJLFFBQVEsR0FBSSxJQUFJLENBQUMsUUFBckI7QUFBQSxVQUNJLElBQUksR0FBUSxJQUFJLENBQUMsSUFEckI7QUFHQTs7QUFDQSxlQUFTLGVBQVQsQ0FBeUIsTUFBekIsRUFBaUMsV0FBakMsRUFBOEM7QUFDMUMsZUFBTyxVQUFVLENBQUMseUJBQXlCLE1BQU0sQ0FBQyxHQUFoQyxHQUFzQyxLQUF0QyxJQUErQyxXQUFXLElBQUksQ0FBOUQsSUFBbUUsS0FBbkUsR0FBMkUsTUFBTSxDQUFDLEdBQW5GLENBQWpCO0FBQ0g7QUFFRDs7Ozs7Ozs7QUFNQSxlQUFTLE1BQVQsQ0FBZ0IsTUFBaEIsRUFBd0I7QUFFcEI7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxNQUFYO0FBRUE7Ozs7O0FBSUEsYUFBSyxHQUFMLEdBQVcsQ0FBWDtBQUVBOzs7OztBQUlBLGFBQUssR0FBTCxHQUFXLE1BQU0sQ0FBQyxNQUFsQjtBQUNIOztBQUVELFVBQUksWUFBWSxHQUFHLE9BQU8sVUFBUCxLQUFzQixXQUF0QixHQUNiLFNBQVMsa0JBQVQsQ0FBNEIsTUFBNUIsRUFBb0M7QUFDbEMsWUFBSSxNQUFNLFlBQVksVUFBbEIsSUFBZ0MsS0FBSyxDQUFDLE9BQU4sQ0FBYyxNQUFkLENBQXBDLEVBQ0ksT0FBTyxJQUFJLE1BQUosQ0FBVyxNQUFYLENBQVA7QUFDSixjQUFNLEtBQUssQ0FBQyxnQkFBRCxDQUFYO0FBQ0g7QUFDRDtBQU5lLFFBT2IsU0FBUyxZQUFULENBQXNCLE1BQXRCLEVBQThCO0FBQzVCLFlBQUksS0FBSyxDQUFDLE9BQU4sQ0FBYyxNQUFkLENBQUosRUFDSSxPQUFPLElBQUksTUFBSixDQUFXLE1BQVgsQ0FBUDtBQUNKLGNBQU0sS0FBSyxDQUFDLGdCQUFELENBQVg7QUFDSCxPQVhMOztBQWFBLFVBQUksTUFBTSxHQUFHLFNBQVMsTUFBVCxHQUFrQjtBQUMzQixlQUFPLElBQUksQ0FBQyxNQUFMLEdBQ0QsU0FBUyxtQkFBVCxDQUE2QixNQUE3QixFQUFxQztBQUNuQyxpQkFBTyxDQUFDLE1BQU0sQ0FBQyxNQUFQLEdBQWdCLFNBQVMsYUFBVCxDQUF1QixNQUF2QixFQUErQjtBQUNuRCxtQkFBTyxJQUFJLENBQUMsTUFBTCxDQUFZLFFBQVosQ0FBcUIsTUFBckIsSUFDRCxJQUFJLFlBQUosQ0FBaUIsTUFBakI7QUFDRjtBQUZHLGNBR0QsWUFBWSxDQUFDLE1BQUQsQ0FIbEI7QUFJSCxXQUxNLEVBS0osTUFMSSxDQUFQO0FBTUg7QUFDRDtBQVRHLFVBVUQsWUFWTjtBQVdILE9BWkQ7QUFjQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLEVBQXRCO0FBRUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsUUFBckI7QUFBaUM7QUFBMkIsTUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsS0FBM0c7QUFFQTs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEyQixTQUFTLGlCQUFULEdBQTZCO0FBQ3BELFlBQUksS0FBSyxHQUFHLFVBQVosQ0FEb0QsQ0FDNUI7O0FBQ3hCLGVBQU8sU0FBUyxXQUFULEdBQXVCO0FBQzFCLFVBQUEsS0FBSyxHQUFHLENBQVUsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQS9CLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQStCLENBQXhDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBQzFGLFVBQUEsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXNCLEVBQXZCLEtBQThCLEVBQXZDLE1BQStDLENBQXZEO0FBQTBELGNBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFBZ0MsT0FBTyxLQUFQO0FBRTFGOztBQUNBLGNBQUksQ0FBQyxLQUFLLEdBQUwsSUFBWSxDQUFiLElBQWtCLEtBQUssR0FBM0IsRUFBZ0M7QUFDNUIsaUJBQUssR0FBTCxHQUFXLEtBQUssR0FBaEI7QUFDQSxrQkFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLEVBQVAsQ0FBckI7QUFDSDs7QUFDRCxpQkFBTyxLQUFQO0FBQ0gsU0FiRDtBQWNILE9BaEJ5QixFQUExQjtBQWtCQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixTQUFTLFVBQVQsR0FBc0I7QUFDM0MsZUFBTyxLQUFLLE1BQUwsS0FBZ0IsQ0FBdkI7QUFDSCxPQUZEO0FBSUE7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxXQUFULEdBQXVCO0FBQzdDLFlBQUksS0FBSyxHQUFHLEtBQUssTUFBTCxFQUFaO0FBQ0EsZUFBTyxLQUFLLEtBQUssQ0FBVixHQUFjLEVBQUUsS0FBSyxHQUFHLENBQVYsQ0FBZCxHQUE2QixDQUFwQztBQUNILE9BSEQ7QUFLQTs7O0FBRUEsZUFBUyxjQUFULEdBQTBCO0FBQ3RCO0FBQ0EsWUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFKLENBQWEsQ0FBYixFQUFnQixDQUFoQixDQUFYO0FBQ0EsWUFBSSxDQUFDLEdBQUcsQ0FBUjs7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLEtBQUssR0FBaEIsR0FBc0IsQ0FBMUIsRUFBNkI7QUFBRTtBQUMzQixpQkFBTyxDQUFDLEdBQUcsQ0FBWCxFQUFjLEVBQUUsQ0FBaEIsRUFBbUI7QUFDZjtBQUNBLFlBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBOEIsQ0FBQyxHQUFHLENBQTdDLE1BQW9ELENBQTlEO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUCxXQU53QixDQU96Qjs7O0FBQ0EsVUFBQSxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBZCxJQUFxQixHQUF0QixLQUE4QixFQUF6QyxNQUFpRCxDQUEzRDtBQUNBLFVBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBK0IsQ0FBMUMsTUFBaUQsQ0FBM0Q7QUFDQSxjQUFJLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBTCxFQUFULElBQXVCLEdBQTNCLEVBQ0ksT0FBTyxJQUFQO0FBQ0osVUFBQSxDQUFDLEdBQUcsQ0FBSjtBQUNILFNBYkQsTUFhTztBQUNILGlCQUFPLENBQUMsR0FBRyxDQUFYLEVBQWMsRUFBRSxDQUFoQixFQUFtQjtBQUNmO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLElBQVksS0FBSyxHQUFyQixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsQ0FBckIsQ0FIVyxDQUlmOztBQUNBLFlBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQWQsSUFBcUIsR0FBdEIsS0FBOEIsQ0FBQyxHQUFHLENBQTdDLE1BQW9ELENBQTlEO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUCxXQVRFLENBVUg7OztBQUNBLFVBQUEsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQUwsRUFBVCxJQUF1QixHQUF4QixLQUFnQyxDQUFDLEdBQUcsQ0FBL0MsTUFBc0QsQ0FBaEU7QUFDQSxpQkFBTyxJQUFQO0FBQ0g7O0FBQ0QsWUFBSSxLQUFLLEdBQUwsR0FBVyxLQUFLLEdBQWhCLEdBQXNCLENBQTFCLEVBQTZCO0FBQUU7QUFDM0IsaUJBQU8sQ0FBQyxHQUFHLENBQVgsRUFBYyxFQUFFLENBQWhCLEVBQW1CO0FBQ2Y7QUFDQSxZQUFBLElBQUksQ0FBQyxFQUFMLEdBQVUsQ0FBQyxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFkLElBQXFCLEdBQXRCLEtBQThCLENBQUMsR0FBRyxDQUFKLEdBQVEsQ0FBakQsTUFBd0QsQ0FBbEU7QUFDQSxnQkFBSSxLQUFLLEdBQUwsQ0FBUyxLQUFLLEdBQUwsRUFBVCxJQUF1QixHQUEzQixFQUNJLE9BQU8sSUFBUDtBQUNQO0FBQ0osU0FQRCxNQU9PO0FBQ0gsaUJBQU8sQ0FBQyxHQUFHLENBQVgsRUFBYyxFQUFFLENBQWhCLEVBQW1CO0FBQ2Y7QUFDQSxnQkFBSSxLQUFLLEdBQUwsSUFBWSxLQUFLLEdBQXJCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxDQUFyQixDQUhXLENBSWY7O0FBQ0EsWUFBQSxJQUFJLENBQUMsRUFBTCxHQUFVLENBQUMsSUFBSSxDQUFDLEVBQUwsR0FBVSxDQUFDLEtBQUssR0FBTCxDQUFTLEtBQUssR0FBZCxJQUFxQixHQUF0QixLQUE4QixDQUFDLEdBQUcsQ0FBSixHQUFRLENBQWpELE1BQXdELENBQWxFO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FBM0IsRUFDSSxPQUFPLElBQVA7QUFDUDtBQUNKO0FBQ0Q7OztBQUNBLGNBQU0sS0FBSyxDQUFDLHlCQUFELENBQVg7QUFDSDtBQUVEOztBQUVBOzs7Ozs7O0FBT0E7Ozs7Ozs7QUFPQTs7Ozs7OztBQU9BOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLElBQWpCLEdBQXdCLFNBQVMsU0FBVCxHQUFxQjtBQUN6QyxlQUFPLEtBQUssTUFBTCxPQUFrQixDQUF6QjtBQUNILE9BRkQ7O0FBSUEsZUFBUyxlQUFULENBQXlCLEdBQXpCLEVBQThCLEdBQTlCLEVBQW1DO0FBQUU7QUFDakMsZUFBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILEdBQ0EsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsSUFBZ0IsQ0FEaEIsR0FFQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxJQUFnQixFQUZoQixHQUdBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBUCxDQUFILElBQWdCLEVBSGpCLE1BR3lCLENBSGhDO0FBSUg7QUFFRDs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixPQUFqQixHQUEyQixTQUFTLFlBQVQsR0FBd0I7QUFFL0M7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUF0QjtBQUNILE9BUEQ7QUFTQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixTQUFTLGFBQVQsR0FBeUI7QUFFakQ7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUFmLEdBQTJDLENBQWxEO0FBQ0gsT0FQRDtBQVNBOzs7QUFFQSxlQUFTLFdBQVQ7QUFBcUI7QUFBb0I7QUFFckM7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixlQUFPLElBQUksUUFBSixDQUFhLGVBQWUsQ0FBQyxLQUFLLEdBQU4sRUFBVyxLQUFLLEdBQUwsSUFBWSxDQUF2QixDQUE1QixFQUF1RCxlQUFlLENBQUMsS0FBSyxHQUFOLEVBQVcsS0FBSyxHQUFMLElBQVksQ0FBdkIsQ0FBdEUsQ0FBUDtBQUNIO0FBRUQ7O0FBRUE7Ozs7Ozs7QUFPQTs7Ozs7OztBQU9BOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxZQUF5QixTQUFTLFVBQVQsR0FBc0I7QUFFM0M7QUFDQSxZQUFJLEtBQUssR0FBTCxHQUFXLENBQVgsR0FBZSxLQUFLLEdBQXhCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLENBQVAsQ0FBckI7QUFFSixZQUFJLEtBQUssR0FBRyxJQUFJLFNBQUosQ0FBVyxXQUFYLENBQXVCLEtBQUssR0FBNUIsRUFBaUMsS0FBSyxHQUF0QyxDQUFaO0FBQ0EsYUFBSyxHQUFMLElBQVksQ0FBWjtBQUNBLGVBQU8sS0FBUDtBQUNILE9BVEQ7QUFXQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsYUFBMEIsU0FBUyxXQUFULEdBQXVCO0FBRTdDO0FBQ0EsWUFBSSxLQUFLLEdBQUwsR0FBVyxDQUFYLEdBQWUsS0FBSyxHQUF4QixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsRUFBTyxDQUFQLENBQXJCO0FBRUosWUFBSSxLQUFLLEdBQUcsSUFBSSxTQUFKLENBQVcsWUFBWCxDQUF3QixLQUFLLEdBQTdCLEVBQWtDLEtBQUssR0FBdkMsQ0FBWjtBQUNBLGFBQUssR0FBTCxJQUFZLENBQVo7QUFDQSxlQUFPLEtBQVA7QUFDSCxPQVREO0FBV0E7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsS0FBakIsR0FBeUIsU0FBUyxVQUFULEdBQXNCO0FBQzNDLFlBQUksTUFBTSxHQUFHLEtBQUssTUFBTCxFQUFiO0FBQUEsWUFDSSxLQUFLLEdBQUksS0FBSyxHQURsQjtBQUFBLFlBRUksR0FBRyxHQUFNLEtBQUssR0FBTCxHQUFXLE1BRnhCO0FBSUE7O0FBQ0EsWUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFmLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBckI7QUFFSixhQUFLLEdBQUwsSUFBWSxNQUFaO0FBQ0EsWUFBSSxLQUFLLENBQUMsT0FBTixDQUFjLEtBQUssR0FBbkIsQ0FBSixFQUE2QjtBQUN6QixpQkFBTyxLQUFLLEdBQUwsQ0FBUyxLQUFULENBQWUsS0FBZixFQUFzQixHQUF0QixDQUFQO0FBQ0osZUFBTyxLQUFLLEtBQUssR0FBVixDQUFjO0FBQWQsVUFDRCxJQUFJLEtBQUssR0FBTCxDQUFTLFdBQWIsQ0FBeUIsQ0FBekIsQ0FEQyxHQUVELEtBQUssTUFBTCxDQUFZLElBQVosQ0FBaUIsS0FBSyxHQUF0QixFQUEyQixLQUEzQixFQUFrQyxHQUFsQyxDQUZOO0FBR0gsT0FmRDtBQWlCQTs7Ozs7O0FBSUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFdBQVQsR0FBdUI7QUFDN0MsWUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFMLEVBQVo7QUFDQSxlQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsS0FBVixFQUFpQixDQUFqQixFQUFvQixLQUFLLENBQUMsTUFBMUIsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBakIsR0FBd0IsU0FBUyxJQUFULENBQWMsTUFBZCxFQUFzQjtBQUMxQyxZQUFJLE9BQU8sTUFBUCxLQUFrQixRQUF0QixFQUFnQztBQUM1QjtBQUNBLGNBQUksS0FBSyxHQUFMLEdBQVcsTUFBWCxHQUFvQixLQUFLLEdBQTdCLEVBQ0ksTUFBTSxlQUFlLENBQUMsSUFBRCxFQUFPLE1BQVAsQ0FBckI7QUFDSixlQUFLLEdBQUwsSUFBWSxNQUFaO0FBQ0gsU0FMRCxNQUtPO0FBQ0gsYUFBRztBQUNDO0FBQ0EsZ0JBQUksS0FBSyxHQUFMLElBQVksS0FBSyxHQUFyQixFQUNJLE1BQU0sZUFBZSxDQUFDLElBQUQsQ0FBckI7QUFDUCxXQUpELFFBSVMsS0FBSyxHQUFMLENBQVMsS0FBSyxHQUFMLEVBQVQsSUFBdUIsR0FKaEM7QUFLSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQWREO0FBZ0JBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixVQUFTLFFBQVQsRUFBbUI7QUFDM0MsZ0JBQVEsUUFBUjtBQUNJLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUw7QUFDQTs7QUFDSixlQUFLLENBQUw7QUFDSSxpQkFBSyxJQUFMLENBQVUsQ0FBVjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUwsQ0FBVSxLQUFLLE1BQUwsRUFBVjtBQUNBOztBQUNKLGVBQUssQ0FBTDtBQUNJLG1CQUFPLENBQUMsUUFBUSxHQUFHLEtBQUssTUFBTCxLQUFnQixDQUE1QixNQUFtQyxDQUExQyxFQUE2QztBQUN6QyxtQkFBSyxRQUFMLENBQWMsUUFBZDtBQUNIOztBQUNEOztBQUNKLGVBQUssQ0FBTDtBQUNJLGlCQUFLLElBQUwsQ0FBVSxDQUFWO0FBQ0E7O0FBRUo7O0FBQ0E7QUFDSSxrQkFBTSxLQUFLLENBQUMsdUJBQXVCLFFBQXZCLEdBQWtDLGFBQWxDLEdBQWtELEtBQUssR0FBeEQsQ0FBWDtBQXJCUjs7QUF1QkEsZUFBTyxJQUFQO0FBQ0gsT0F6QkQ7O0FBMkJBLE1BQUEsTUFBTSxDQUFDLFVBQVAsR0FBb0IsVUFBUyxhQUFULEVBQXdCO0FBQ3hDLFFBQUEsWUFBWSxHQUFHLGFBQWY7QUFDQSxRQUFBLE1BQU0sQ0FBQyxNQUFQLEdBQWdCLE1BQU0sRUFBdEI7O0FBQ0EsUUFBQSxZQUFZLENBQUMsVUFBYjs7QUFFQSxZQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsSUFBTCxHQUFZLFFBQVo7QUFBdUI7QUFBMkIsa0JBQTNEO0FBQ0EsUUFBQSxJQUFJLENBQUMsS0FBTCxDQUFXLE1BQU0sQ0FBQyxTQUFsQixFQUE2QjtBQUV6QixVQUFBLEtBQUssRUFBRSxTQUFTLFVBQVQsR0FBc0I7QUFDekIsbUJBQU8sY0FBYyxDQUFDLElBQWYsQ0FBb0IsSUFBcEIsRUFBMEIsRUFBMUIsRUFBOEIsS0FBOUIsQ0FBUDtBQUNILFdBSndCO0FBTXpCLFVBQUEsTUFBTSxFQUFFLFNBQVMsV0FBVCxHQUF1QjtBQUMzQixtQkFBTyxjQUFjLENBQUMsSUFBZixDQUFvQixJQUFwQixFQUEwQixFQUExQixFQUE4QixJQUE5QixDQUFQO0FBQ0gsV0FSd0I7QUFVekIsVUFBQSxNQUFNLEVBQUUsU0FBUyxXQUFULEdBQXVCO0FBQzNCLG1CQUFPLGNBQWMsQ0FBQyxJQUFmLENBQW9CLElBQXBCLEVBQTBCLFFBQTFCLEdBQXFDLEVBQXJDLEVBQXlDLEtBQXpDLENBQVA7QUFDSCxXQVp3QjtBQWN6QixVQUFBLE9BQU8sRUFBRSxTQUFTLFlBQVQsR0FBd0I7QUFDN0IsbUJBQU8sV0FBVyxDQUFDLElBQVosQ0FBaUIsSUFBakIsRUFBdUIsRUFBdkIsRUFBMkIsSUFBM0IsQ0FBUDtBQUNILFdBaEJ3QjtBQWtCekIsVUFBQSxRQUFRLEVBQUUsU0FBUyxhQUFULEdBQXlCO0FBQy9CLG1CQUFPLFdBQVcsQ0FBQyxJQUFaLENBQWlCLElBQWpCLEVBQXVCLEVBQXZCLEVBQTJCLEtBQTNCLENBQVA7QUFDSDtBQXBCd0IsU0FBN0I7QUF1QkgsT0E3QkQ7QUErQkMsS0E3WjRELEVBNlozRDtBQUFDLFlBQUs7QUFBTixLQTdaMkQsQ0F4ekJ0QztBQXF0Q1YsUUFBRyxDQUFDLFVBQVMsT0FBVCxFQUFpQixNQUFqQixFQUF3QixPQUF4QixFQUFnQztBQUNqRDs7QUFDQSxNQUFBLE1BQU0sQ0FBQyxPQUFQLEdBQWlCLFlBQWpCLENBRmlELENBSWpEOztBQUNBLFVBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFELENBQXBCOztBQUNBLE9BQUMsWUFBWSxDQUFDLFNBQWIsR0FBeUIsTUFBTSxDQUFDLE1BQVAsQ0FBYyxNQUFNLENBQUMsU0FBckIsQ0FBMUIsRUFBMkQsV0FBM0QsR0FBeUUsWUFBekU7O0FBRUEsVUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEVBQUQsQ0FBbEI7QUFFQTs7Ozs7Ozs7O0FBT0EsZUFBUyxZQUFULENBQXNCLE1BQXRCLEVBQThCO0FBQzFCLFFBQUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaLEVBQWtCLE1BQWxCO0FBRUE7Ozs7O0FBS0g7O0FBRUQsTUFBQSxZQUFZLENBQUMsVUFBYixHQUEwQixZQUFZO0FBQ2xDO0FBQ0EsWUFBSSxJQUFJLENBQUMsTUFBVCxFQUNJLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLElBQUksQ0FBQyxNQUFMLENBQVksU0FBWixDQUFzQixLQUF0RDtBQUNQLE9BSkQ7QUFPQTs7Ozs7QUFHQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLFNBQVMsa0JBQVQsR0FBOEI7QUFDMUQsWUFBSSxHQUFHLEdBQUcsS0FBSyxNQUFMLEVBQVYsQ0FEMEQsQ0FDakM7O0FBQ3pCLGVBQU8sS0FBSyxHQUFMLENBQVMsU0FBVCxHQUNELEtBQUssR0FBTCxDQUFTLFNBQVQsQ0FBbUIsS0FBSyxHQUF4QixFQUE2QixLQUFLLEdBQUwsR0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEtBQUssR0FBTCxHQUFXLEdBQXBCLEVBQXlCLEtBQUssR0FBOUIsQ0FBeEMsQ0FEQyxHQUVELEtBQUssR0FBTCxDQUFTLFFBQVQsQ0FBa0IsT0FBbEIsRUFBMkIsS0FBSyxHQUFoQyxFQUFxQyxLQUFLLEdBQUwsR0FBVyxJQUFJLENBQUMsR0FBTCxDQUFTLEtBQUssR0FBTCxHQUFXLEdBQXBCLEVBQXlCLEtBQUssR0FBOUIsQ0FBaEQsQ0FGTjtBQUdILE9BTEQ7QUFPQTs7Ozs7Ozs7QUFPQSxNQUFBLFlBQVksQ0FBQyxVQUFiO0FBRUMsS0FyRGUsRUFxRGQ7QUFBQyxZQUFLLEVBQU47QUFBUyxXQUFJO0FBQWIsS0FyRGMsQ0FydENPO0FBMHdDSixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ3ZEOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsRUFBakI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JDLEtBcEJxQixFQW9CcEIsRUFwQm9CLENBMXdDQztBQTh4Q2pCLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDMUM7QUFFQTs7Ozs7QUFJQSxVQUFJLEdBQUcsR0FBRyxPQUFWO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQTs7Ozs7Ozs7O0FBU0EsTUFBQSxHQUFHLENBQUMsT0FBSixHQUFjLE9BQU8sQ0FBQyxFQUFELENBQXJCO0FBRUMsS0F0Q1EsRUFzQ1A7QUFBQyxZQUFLO0FBQU4sS0F0Q08sQ0E5eENjO0FBbzBDVixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ2pEOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsT0FBakI7O0FBRUEsVUFBSSxJQUFJLEdBQUcsT0FBTyxDQUFDLEVBQUQsQ0FBbEIsQ0FKaUQsQ0FNakQ7OztBQUNBLE9BQUMsT0FBTyxDQUFDLFNBQVIsR0FBb0IsTUFBTSxDQUFDLE1BQVAsQ0FBYyxJQUFJLENBQUMsWUFBTCxDQUFrQixTQUFoQyxDQUFyQixFQUFpRSxXQUFqRSxHQUErRSxPQUEvRTtBQUVBOzs7Ozs7Ozs7Ozs7QUFZQTs7Ozs7Ozs7Ozs7QUFXQTs7Ozs7Ozs7Ozs7QUFVQSxlQUFTLE9BQVQsQ0FBaUIsT0FBakIsRUFBMEIsZ0JBQTFCLEVBQTRDLGlCQUE1QyxFQUErRDtBQUUzRCxZQUFJLE9BQU8sT0FBUCxLQUFtQixVQUF2QixFQUNJLE1BQU0sU0FBUyxDQUFDLDRCQUFELENBQWY7QUFFSixRQUFBLElBQUksQ0FBQyxZQUFMLENBQWtCLElBQWxCLENBQXVCLElBQXZCO0FBRUE7Ozs7O0FBSUEsYUFBSyxPQUFMLEdBQWUsT0FBZjtBQUVBOzs7OztBQUlBLGFBQUssZ0JBQUwsR0FBd0IsT0FBTyxDQUFDLGdCQUFELENBQS9CO0FBRUE7Ozs7O0FBSUEsYUFBSyxpQkFBTCxHQUF5QixPQUFPLENBQUMsaUJBQUQsQ0FBaEM7QUFDSDtBQUVEOzs7Ozs7Ozs7Ozs7O0FBV0EsTUFBQSxPQUFPLENBQUMsU0FBUixDQUFrQixPQUFsQixHQUE0QixTQUFTLE9BQVQsQ0FBaUIsTUFBakIsRUFBeUIsV0FBekIsRUFBc0MsWUFBdEMsRUFBb0QsT0FBcEQsRUFBNkQsUUFBN0QsRUFBdUU7QUFFL0YsWUFBSSxDQUFDLE9BQUwsRUFDSSxNQUFNLFNBQVMsQ0FBQywyQkFBRCxDQUFmO0FBRUosWUFBSSxJQUFJLEdBQUcsSUFBWDtBQUNBLFlBQUksQ0FBQyxRQUFMLEVBQ0ksT0FBTyxJQUFJLENBQUMsU0FBTCxDQUFlLE9BQWYsRUFBd0IsSUFBeEIsRUFBOEIsTUFBOUIsRUFBc0MsV0FBdEMsRUFBbUQsWUFBbkQsRUFBaUUsT0FBakUsQ0FBUDs7QUFFSixZQUFJLENBQUMsSUFBSSxDQUFDLE9BQVYsRUFBbUI7QUFDZixVQUFBLFVBQVUsQ0FBQyxZQUFXO0FBQUUsWUFBQSxRQUFRLENBQUMsS0FBSyxDQUFDLGVBQUQsQ0FBTixDQUFSO0FBQW1DLFdBQWpELEVBQW1ELENBQW5ELENBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7O0FBRUQsWUFBSTtBQUNBLGlCQUFPLElBQUksQ0FBQyxPQUFMLENBQ0gsTUFERyxFQUVILFdBQVcsQ0FBQyxJQUFJLENBQUMsZ0JBQUwsR0FBd0IsaUJBQXhCLEdBQTRDLFFBQTdDLENBQVgsQ0FBa0UsT0FBbEUsRUFBMkUsTUFBM0UsRUFGRyxFQUdILFNBQVMsV0FBVCxDQUFxQixHQUFyQixFQUEwQixRQUExQixFQUFvQztBQUVoQyxnQkFBSSxHQUFKLEVBQVM7QUFDTCxjQUFBLElBQUksQ0FBQyxJQUFMLENBQVUsT0FBVixFQUFtQixHQUFuQixFQUF3QixNQUF4QjtBQUNBLHFCQUFPLFFBQVEsQ0FBQyxHQUFELENBQWY7QUFDSDs7QUFFRCxnQkFBSSxRQUFRLEtBQUssSUFBakIsRUFBdUI7QUFDbkIsY0FBQSxJQUFJLENBQUMsR0FBTDtBQUFTO0FBQWlCLGtCQUExQjtBQUNBLHFCQUFPLFNBQVA7QUFDSDs7QUFFRCxnQkFBSSxFQUFFLFFBQVEsWUFBWSxZQUF0QixDQUFKLEVBQXlDO0FBQ3JDLGtCQUFJO0FBQ0EsZ0JBQUEsUUFBUSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUMsaUJBQUwsR0FBeUIsaUJBQXpCLEdBQTZDLFFBQTlDLENBQVosQ0FBb0UsUUFBcEUsQ0FBWDtBQUNILGVBRkQsQ0FFRSxPQUFPLEdBQVAsRUFBWTtBQUNWLGdCQUFBLElBQUksQ0FBQyxJQUFMLENBQVUsT0FBVixFQUFtQixHQUFuQixFQUF3QixNQUF4QjtBQUNBLHVCQUFPLFFBQVEsQ0FBQyxHQUFELENBQWY7QUFDSDtBQUNKOztBQUVELFlBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxNQUFWLEVBQWtCLFFBQWxCLEVBQTRCLE1BQTVCO0FBQ0EsbUJBQU8sUUFBUSxDQUFDLElBQUQsRUFBTyxRQUFQLENBQWY7QUFDSCxXQTFCRSxDQUFQO0FBNEJILFNBN0JELENBNkJFLE9BQU8sR0FBUCxFQUFZO0FBQ1YsVUFBQSxJQUFJLENBQUMsSUFBTCxDQUFVLE9BQVYsRUFBbUIsR0FBbkIsRUFBd0IsTUFBeEI7QUFDQSxVQUFBLFVBQVUsQ0FBQyxZQUFXO0FBQUUsWUFBQSxRQUFRLENBQUMsR0FBRCxDQUFSO0FBQWdCLFdBQTlCLEVBQWdDLENBQWhDLENBQVY7QUFDQSxpQkFBTyxTQUFQO0FBQ0g7QUFDSixPQWhERDtBQWtEQTs7Ozs7OztBQUtBLE1BQUEsT0FBTyxDQUFDLFNBQVIsQ0FBa0IsR0FBbEIsR0FBd0IsU0FBUyxHQUFULENBQWEsVUFBYixFQUF5QjtBQUM3QyxZQUFJLEtBQUssT0FBVCxFQUFrQjtBQUNkLGNBQUksQ0FBQyxVQUFMLEVBQWlCO0FBQ2IsaUJBQUssT0FBTCxDQUFhLElBQWIsRUFBbUIsSUFBbkIsRUFBeUIsSUFBekI7QUFDSixlQUFLLE9BQUwsR0FBZSxJQUFmO0FBQ0EsZUFBSyxJQUFMLENBQVUsS0FBVixFQUFpQixHQUFqQjtBQUNIOztBQUNELGVBQU8sSUFBUDtBQUNILE9BUkQ7QUFVQyxLQWhKZSxFQWdKZDtBQUFDLFlBQUs7QUFBTixLQWhKYyxDQXAwQ087QUFvOUNWLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDakQ7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixRQUFqQjs7QUFFQSxVQUFJLElBQUksR0FBRyxPQUFPLENBQUMsRUFBRCxDQUFsQjtBQUVBOzs7Ozs7Ozs7O0FBUUEsZUFBUyxRQUFULENBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCO0FBRXRCO0FBQ0E7O0FBRUE7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFFLEtBQUssQ0FBakI7QUFFQTs7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFFLEtBQUssQ0FBakI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsVUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsR0FBZ0IsSUFBSSxRQUFKLENBQWEsQ0FBYixFQUFnQixDQUFoQixDQUEzQjs7QUFFQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLFlBQVc7QUFBRSxlQUFPLENBQVA7QUFBVyxPQUF4Qzs7QUFDQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLElBQUksQ0FBQyxRQUFMLEdBQWdCLFlBQVc7QUFBRSxlQUFPLElBQVA7QUFBYyxPQUEzRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsWUFBVztBQUFFLGVBQU8sQ0FBUDtBQUFXLE9BQXRDO0FBRUE7Ozs7Ozs7QUFLQSxVQUFJLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBVCxHQUFvQixrQkFBbkM7QUFFQTs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsVUFBVCxHQUFzQixTQUFTLFVBQVQsQ0FBb0IsS0FBcEIsRUFBMkI7QUFDN0MsWUFBSSxLQUFLLEtBQUssQ0FBZCxFQUNJLE9BQU8sSUFBUDtBQUNKLFlBQUksSUFBSSxHQUFHLEtBQUssR0FBRyxDQUFuQjtBQUNBLFlBQUksSUFBSixFQUNJLEtBQUssR0FBRyxDQUFDLEtBQVQ7QUFDSixZQUFJLEVBQUUsR0FBRyxLQUFLLEtBQUssQ0FBbkI7QUFBQSxZQUNJLEVBQUUsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFULElBQWUsVUFBZixLQUE4QixDQUR2Qzs7QUFFQSxZQUFJLElBQUosRUFBVTtBQUNOLFVBQUEsRUFBRSxHQUFHLENBQUMsRUFBRCxLQUFRLENBQWI7QUFDQSxVQUFBLEVBQUUsR0FBRyxDQUFDLEVBQUQsS0FBUSxDQUFiOztBQUNBLGNBQUksRUFBRSxFQUFGLEdBQU8sVUFBWCxFQUF1QjtBQUNuQixZQUFBLEVBQUUsR0FBRyxDQUFMO0FBQ0EsZ0JBQUksRUFBRSxFQUFGLEdBQU8sVUFBWCxFQUNJLEVBQUUsR0FBRyxDQUFMO0FBQ1A7QUFDSjs7QUFDRCxlQUFPLElBQUksUUFBSixDQUFhLEVBQWIsRUFBaUIsRUFBakIsQ0FBUDtBQUNILE9BbEJEO0FBb0JBOzs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsSUFBVCxHQUFnQixTQUFTLElBQVQsQ0FBYyxLQUFkLEVBQXFCO0FBQ2pDLFlBQUksT0FBTyxLQUFQLEtBQWlCLFFBQXJCLEVBQ0ksT0FBTyxRQUFRLENBQUMsVUFBVCxDQUFvQixLQUFwQixDQUFQOztBQUNKLFlBQUksSUFBSSxDQUFDLFFBQUwsQ0FBYyxLQUFkLENBQUosRUFBMEI7QUFDdEI7QUFDQSxjQUFJLElBQUksQ0FBQyxJQUFULEVBQ0ksS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFMLENBQVUsVUFBVixDQUFxQixLQUFyQixDQUFSLENBREosS0FHSSxPQUFPLFFBQVEsQ0FBQyxVQUFULENBQW9CLFFBQVEsQ0FBQyxLQUFELEVBQVEsRUFBUixDQUE1QixDQUFQO0FBQ1A7O0FBQ0QsZUFBTyxLQUFLLENBQUMsR0FBTixJQUFhLEtBQUssQ0FBQyxJQUFuQixHQUEwQixJQUFJLFFBQUosQ0FBYSxLQUFLLENBQUMsR0FBTixLQUFjLENBQTNCLEVBQThCLEtBQUssQ0FBQyxJQUFOLEtBQWUsQ0FBN0MsQ0FBMUIsR0FBNEUsSUFBbkY7QUFDSCxPQVhEO0FBYUE7Ozs7Ozs7QUFLQSxNQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLFFBQW5CLEdBQThCLFNBQVMsUUFBVCxDQUFrQixRQUFsQixFQUE0QjtBQUN0RCxZQUFJLENBQUMsUUFBRCxJQUFhLEtBQUssRUFBTCxLQUFZLEVBQTdCLEVBQWlDO0FBQzdCLGNBQUksRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFOLEdBQVcsQ0FBWCxLQUFpQixDQUExQjtBQUFBLGNBQ0ksRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFOLEtBQWlCLENBRDFCO0FBRUEsY0FBSSxDQUFDLEVBQUwsRUFDSSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUwsS0FBVyxDQUFoQjtBQUNKLGlCQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxVQUFaLENBQVA7QUFDSDs7QUFDRCxlQUFPLEtBQUssRUFBTCxHQUFVLEtBQUssRUFBTCxHQUFVLFVBQTNCO0FBQ0gsT0FURDtBQVdBOzs7Ozs7O0FBS0EsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixNQUFuQixHQUE0QixTQUFTLE1BQVQsQ0FBZ0IsUUFBaEIsRUFBMEI7QUFDbEQsZUFBTyxJQUFJLENBQUMsSUFBTCxHQUNELElBQUksSUFBSSxDQUFDLElBQVQsQ0FBYyxLQUFLLEVBQUwsR0FBVSxDQUF4QixFQUEyQixLQUFLLEVBQUwsR0FBVSxDQUFyQyxFQUF3QyxPQUFPLENBQUMsUUFBRCxDQUEvQztBQUNGO0FBRkcsVUFHRDtBQUFFLFVBQUEsR0FBRyxFQUFFLEtBQUssRUFBTCxHQUFVLENBQWpCO0FBQW9CLFVBQUEsSUFBSSxFQUFFLEtBQUssRUFBTCxHQUFVLENBQXBDO0FBQXVDLFVBQUEsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFEO0FBQXhELFNBSE47QUFJSCxPQUxEOztBQU9BLFVBQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxTQUFQLENBQWlCLFVBQWxDO0FBRUE7Ozs7OztBQUtBLE1BQUEsUUFBUSxDQUFDLFFBQVQsR0FBb0IsU0FBUyxRQUFULENBQWtCLElBQWxCLEVBQXdCO0FBQ3hDLFlBQUksSUFBSSxLQUFLLFFBQWIsRUFDSSxPQUFPLElBQVA7QUFDSixlQUFPLElBQUksUUFBSixDQUNILENBQUUsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsSUFDQSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixLQUE0QixDQUQ1QixHQUVBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEtBQTRCLEVBRjVCLEdBR0EsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsS0FBNEIsRUFIOUIsTUFHc0MsQ0FKbkMsRUFNSCxDQUFFLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLElBQ0EsVUFBVSxDQUFDLElBQVgsQ0FBZ0IsSUFBaEIsRUFBc0IsQ0FBdEIsS0FBNEIsQ0FENUIsR0FFQSxVQUFVLENBQUMsSUFBWCxDQUFnQixJQUFoQixFQUFzQixDQUF0QixLQUE0QixFQUY1QixHQUdBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLENBQXRCLEtBQTRCLEVBSDlCLE1BR3NDLENBVG5DLENBQVA7QUFXSCxPQWREO0FBZ0JBOzs7Ozs7QUFJQSxNQUFBLFFBQVEsQ0FBQyxTQUFULENBQW1CLE1BQW5CLEdBQTRCLFNBQVMsTUFBVCxHQUFrQjtBQUMxQyxlQUFPLE1BQU0sQ0FBQyxZQUFQLENBQ0gsS0FBSyxFQUFMLEdBQWlCLEdBRGQsRUFFSCxLQUFLLEVBQUwsS0FBWSxDQUFaLEdBQWlCLEdBRmQsRUFHSCxLQUFLLEVBQUwsS0FBWSxFQUFaLEdBQWlCLEdBSGQsRUFJSCxLQUFLLEVBQUwsS0FBWSxFQUpULEVBS0gsS0FBSyxFQUFMLEdBQWlCLEdBTGQsRUFNSCxLQUFLLEVBQUwsS0FBWSxDQUFaLEdBQWlCLEdBTmQsRUFPSCxLQUFLLEVBQUwsS0FBWSxFQUFaLEdBQWlCLEdBUGQsRUFRSCxLQUFLLEVBQUwsS0FBWSxFQVJULENBQVA7QUFVSCxPQVhEO0FBYUE7Ozs7OztBQUlBLE1BQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsUUFBbkIsR0FBOEIsU0FBUyxRQUFULEdBQW9CO0FBQzlDLFlBQUksSUFBSSxHQUFLLEtBQUssRUFBTCxJQUFXLEVBQXhCO0FBQ0EsYUFBSyxFQUFMLEdBQVcsQ0FBQyxDQUFDLEtBQUssRUFBTCxJQUFXLENBQVgsR0FBZSxLQUFLLEVBQUwsS0FBWSxFQUE1QixJQUFrQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGFBQUssRUFBTCxHQUFXLENBQUUsS0FBSyxFQUFMLElBQVcsQ0FBWCxHQUFpQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGVBQU8sSUFBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7O0FBSUEsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixRQUFuQixHQUE4QixTQUFTLFFBQVQsR0FBb0I7QUFDOUMsWUFBSSxJQUFJLEdBQUcsRUFBRSxLQUFLLEVBQUwsR0FBVSxDQUFaLENBQVg7QUFDQSxhQUFLLEVBQUwsR0FBVyxDQUFDLENBQUMsS0FBSyxFQUFMLEtBQVksQ0FBWixHQUFnQixLQUFLLEVBQUwsSUFBVyxFQUE1QixJQUFrQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGFBQUssRUFBTCxHQUFXLENBQUUsS0FBSyxFQUFMLEtBQVksQ0FBWixHQUFpQyxJQUFuQyxNQUE2QyxDQUF4RDtBQUNBLGVBQU8sSUFBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7O0FBSUEsTUFBQSxRQUFRLENBQUMsU0FBVCxDQUFtQixNQUFuQixHQUE0QixTQUFTLE1BQVQsR0FBa0I7QUFDMUMsWUFBSSxLQUFLLEdBQUksS0FBSyxFQUFsQjtBQUFBLFlBQ0ksS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFMLEtBQVksRUFBWixHQUFpQixLQUFLLEVBQUwsSUFBVyxDQUE3QixNQUFvQyxDQURoRDtBQUFBLFlBRUksS0FBSyxHQUFJLEtBQUssRUFBTCxLQUFZLEVBRnpCO0FBR0EsZUFBTyxLQUFLLEtBQUssQ0FBVixHQUNBLEtBQUssS0FBSyxDQUFWLEdBQ0UsS0FBSyxHQUFHLEtBQVIsR0FDRSxLQUFLLEdBQUcsR0FBUixHQUFjLENBQWQsR0FBa0IsQ0FEcEIsR0FFRSxLQUFLLEdBQUcsT0FBUixHQUFrQixDQUFsQixHQUFzQixDQUgxQixHQUlFLEtBQUssR0FBRyxLQUFSLEdBQ0UsS0FBSyxHQUFHLEdBQVIsR0FBYyxDQUFkLEdBQWtCLENBRHBCLEdBRUUsS0FBSyxHQUFHLE9BQVIsR0FBa0IsQ0FBbEIsR0FBc0IsQ0FQMUIsR0FRQSxLQUFLLEdBQUcsR0FBUixHQUFjLENBQWQsR0FBa0IsRUFSekI7QUFTSCxPQWJEO0FBZUMsS0ExTWUsRUEwTWQ7QUFBQyxZQUFLO0FBQU4sS0ExTWMsQ0FwOUNPO0FBOHBEVixRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQ2pEOztBQUNBLFVBQUksSUFBSSxHQUFHLE9BQVgsQ0FGaUQsQ0FJakQ7O0FBQ0EsTUFBQSxJQUFJLENBQUMsU0FBTCxHQUFpQixPQUFPLENBQUMsQ0FBRCxDQUF4QixDQUxpRCxDQU9qRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWMsT0FBTyxDQUFDLENBQUQsQ0FBckIsQ0FSaUQsQ0FVakQ7O0FBQ0EsTUFBQSxJQUFJLENBQUMsWUFBTCxHQUFvQixPQUFPLENBQUMsQ0FBRCxDQUEzQixDQVhpRCxDQWFqRDs7QUFDQSxNQUFBLElBQUksU0FBSixHQUFhLE9BQU8sQ0FBQyxDQUFELENBQXBCLENBZGlELENBZ0JqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxPQUFMLEdBQWUsT0FBTyxDQUFDLENBQUQsQ0FBdEIsQ0FqQmlELENBbUJqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxJQUFMLEdBQVksT0FBTyxDQUFDLENBQUQsQ0FBbkIsQ0FwQmlELENBc0JqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxJQUFMLEdBQVksT0FBTyxDQUFDLENBQUQsQ0FBbkIsQ0F2QmlELENBeUJqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxRQUFMLEdBQWdCLE9BQU8sQ0FBQyxFQUFELENBQXZCO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxPQUFPLENBQUMsT0FBTyxNQUFQLEtBQWtCLFdBQWxCLElBQ0EsTUFEQSxJQUVBLE1BQU0sQ0FBQyxPQUZQLElBR0EsTUFBTSxDQUFDLE9BQVAsQ0FBZSxRQUhmLElBSUEsTUFBTSxDQUFDLE9BQVAsQ0FBZSxRQUFmLENBQXdCLElBSnpCLENBQXJCO0FBTUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxJQUFJLENBQUMsTUFBTCxJQUFlLE1BQWYsSUFDQSxPQUFPLE1BQVAsS0FBa0IsV0FBbEIsSUFBaUMsTUFEakMsSUFFQSxPQUFPLElBQVAsS0FBa0IsV0FBbEIsSUFBaUMsSUFGakMsSUFHQSxJQUhkLENBNUNpRCxDQStDN0I7O0FBRXBCOzs7Ozs7O0FBTUEsTUFBQSxJQUFJLENBQUMsVUFBTCxHQUFrQixNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLENBQUMsTUFBUCxDQUFjLEVBQWQsQ0FBaEI7QUFBb0M7QUFBMkIsUUFBakYsQ0F2RGlELENBdURvQzs7QUFFckY7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLFdBQUwsR0FBbUIsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsTUFBTSxDQUFDLE1BQVAsQ0FBYyxFQUFkLENBQWhCO0FBQW9DO0FBQTJCLFFBQWxGLENBOURpRCxDQThEcUM7O0FBRXRGOzs7Ozs7O0FBTUEsTUFBQSxJQUFJLENBQUMsU0FBTCxHQUFpQixNQUFNLENBQUMsU0FBUDtBQUFvQjtBQUEyQixlQUFTLFNBQVQsQ0FBbUIsS0FBbkIsRUFBMEI7QUFDdEYsZUFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsUUFBUSxDQUFDLEtBQUQsQ0FBckMsSUFBZ0QsSUFBSSxDQUFDLEtBQUwsQ0FBVyxLQUFYLE1BQXNCLEtBQTdFO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsUUFBTCxHQUFnQixTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsRUFBeUI7QUFDckMsZUFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsS0FBSyxZQUFZLE1BQXJEO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsUUFBTCxHQUFnQixTQUFTLFFBQVQsQ0FBa0IsS0FBbEIsRUFBeUI7QUFDckMsZUFBTyxLQUFLLElBQUksT0FBTyxLQUFQLEtBQWlCLFFBQWpDO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7Ozs7O0FBUUEsTUFBQSxJQUFJLENBQUMsS0FBTDtBQUVBOzs7Ozs7QUFNQSxNQUFBLElBQUksQ0FBQyxLQUFMLEdBQWEsU0FBUyxLQUFULENBQWUsR0FBZixFQUFvQixJQUFwQixFQUEwQjtBQUNuQyxZQUFJLEtBQUssR0FBRyxHQUFHLENBQUMsSUFBRCxDQUFmO0FBQ0EsWUFBSSxLQUFLLElBQUksSUFBVCxJQUFpQixHQUFHLENBQUMsY0FBSixDQUFtQixJQUFuQixDQUFyQixFQUErQztBQUMzQyxpQkFBTyxPQUFPLEtBQVAsS0FBaUIsUUFBakIsSUFBNkIsQ0FBQyxLQUFLLENBQUMsT0FBTixDQUFjLEtBQWQsSUFBdUIsS0FBSyxDQUFDLE1BQTdCLEdBQXNDLE1BQU0sQ0FBQyxJQUFQLENBQVksS0FBWixFQUFtQixNQUExRCxJQUFvRSxDQUF4RztBQUNKLGVBQU8sS0FBUDtBQUNILE9BYkQ7QUFlQTs7Ozs7OztBQU9BOzs7Ozs7QUFJQSxNQUFBLElBQUksQ0FBQyxNQUFMLEdBQWUsWUFBVztBQUN0QixZQUFJO0FBQ0EsY0FBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQUwsQ0FBYSxRQUFiLEVBQXVCLE1BQXBDLENBREEsQ0FFQTs7QUFDQSxpQkFBTyxNQUFNLENBQUMsU0FBUCxDQUFpQixTQUFqQixHQUE2QixNQUE3QjtBQUFzQztBQUEyQixjQUF4RTtBQUNILFNBSkQsQ0FJRSxPQUFPLENBQVAsRUFBVTtBQUNSO0FBQ0EsaUJBQU8sSUFBUDtBQUNIO0FBQ0osT0FUYSxFQUFkLENBOUhpRCxDQXlJakQ7OztBQUNBLE1BQUEsSUFBSSxDQUFDLFlBQUwsR0FBb0IsSUFBcEIsQ0ExSWlELENBNElqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxtQkFBTCxHQUEyQixJQUEzQjtBQUVBOzs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxTQUFMLEdBQWlCLFNBQVMsU0FBVCxDQUFtQixXQUFuQixFQUFnQztBQUM3QztBQUNBLGVBQU8sT0FBTyxXQUFQLEtBQXVCLFFBQXZCLEdBQ0QsSUFBSSxDQUFDLE1BQUwsR0FDSSxJQUFJLENBQUMsbUJBQUwsQ0FBeUIsV0FBekIsQ0FESixHQUVJLElBQUksSUFBSSxDQUFDLEtBQVQsQ0FBZSxXQUFmLENBSEgsR0FJRCxJQUFJLENBQUMsTUFBTCxHQUNJLElBQUksQ0FBQyxZQUFMLENBQWtCLFdBQWxCLENBREosR0FFSSxPQUFPLFVBQVAsS0FBc0IsV0FBdEIsR0FDSSxXQURKLEdBRUksSUFBSSxVQUFKLENBQWUsV0FBZixDQVJkO0FBU0gsT0FYRDtBQWFBOzs7Ozs7QUFJQSxNQUFBLElBQUksQ0FBQyxLQUFMLEdBQWEsT0FBTyxVQUFQLEtBQXNCLFdBQXRCLEdBQW9DO0FBQVc7QUFBL0MsUUFBNEUsS0FBekY7QUFFQTs7Ozs7Ozs7O0FBU0E7Ozs7O0FBSUEsTUFBQSxJQUFJLENBQUMsSUFBTDtBQUFZO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxPQUFaO0FBQXVCO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxPQUFaLENBQW9CLElBQXRFO0FBQzNCO0FBQTJCLE1BQUEsSUFBSSxDQUFDLE1BQUwsQ0FBWSxJQURaLElBRTNCLElBQUksQ0FBQyxPQUFMLENBQWEsTUFBYixDQUZaO0FBSUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE1BQUwsR0FBYyxrQkFBZDtBQUVBOzs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxPQUFMLEdBQWUsdUJBQWY7QUFFQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsT0FBTCxHQUFlLDRDQUFmO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLFVBQUwsR0FBa0IsU0FBUyxVQUFULENBQW9CLEtBQXBCLEVBQTJCO0FBQ3pDLGVBQU8sS0FBSyxHQUNOLElBQUksQ0FBQyxRQUFMLENBQWMsSUFBZCxDQUFtQixLQUFuQixFQUEwQixNQUExQixFQURNLEdBRU4sSUFBSSxDQUFDLFFBQUwsQ0FBYyxRQUZwQjtBQUdILE9BSkQ7QUFNQTs7Ozs7Ozs7QUFNQSxNQUFBLElBQUksQ0FBQyxZQUFMLEdBQW9CLFNBQVMsWUFBVCxDQUFzQixJQUF0QixFQUE0QixRQUE1QixFQUFzQztBQUN0RCxZQUFJLElBQUksR0FBRyxJQUFJLENBQUMsUUFBTCxDQUFjLFFBQWQsQ0FBdUIsSUFBdkIsQ0FBWDtBQUNBLFlBQUksSUFBSSxDQUFDLElBQVQsRUFDSSxPQUFPLElBQUksQ0FBQyxJQUFMLENBQVUsUUFBVixDQUFtQixJQUFJLENBQUMsRUFBeEIsRUFBNEIsSUFBSSxDQUFDLEVBQWpDLEVBQXFDLFFBQXJDLENBQVA7QUFDSixlQUFPLElBQUksQ0FBQyxRQUFMLENBQWMsT0FBTyxDQUFDLFFBQUQsQ0FBckIsQ0FBUDtBQUNILE9BTEQ7QUFPQTs7Ozs7Ozs7OztBQVFBLGVBQVMsS0FBVCxDQUFlLEdBQWYsRUFBb0IsR0FBcEIsRUFBeUIsUUFBekIsRUFBbUM7QUFBRTtBQUNqQyxhQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFQLENBQVksR0FBWixDQUFYLEVBQTZCLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQWxELEVBQTBELEVBQUUsQ0FBNUQ7QUFDSSxjQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQUgsS0FBaUIsU0FBakIsSUFBOEIsQ0FBQyxRQUFuQyxFQUNJLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQUgsR0FBZSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUQsQ0FBTCxDQUFsQjtBQUZSOztBQUdBLGVBQU8sR0FBUDtBQUNIOztBQUVELE1BQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxLQUFiO0FBRUE7Ozs7OztBQUtBLE1BQUEsSUFBSSxDQUFDLE9BQUwsR0FBZSxTQUFTLE9BQVQsQ0FBaUIsR0FBakIsRUFBc0I7QUFDakMsZUFBTyxHQUFHLENBQUMsTUFBSixDQUFXLENBQVgsRUFBYyxXQUFkLEtBQThCLEdBQUcsQ0FBQyxTQUFKLENBQWMsQ0FBZCxDQUFyQztBQUNILE9BRkQ7QUFJQTs7Ozs7Ozs7QUFNQSxlQUFTLFFBQVQsQ0FBa0IsSUFBbEIsRUFBd0I7QUFFcEIsaUJBQVMsV0FBVCxDQUFxQixPQUFyQixFQUE4QixVQUE5QixFQUEwQztBQUV0QyxjQUFJLEVBQUUsZ0JBQWdCLFdBQWxCLENBQUosRUFDSSxPQUFPLElBQUksV0FBSixDQUFnQixPQUFoQixFQUF5QixVQUF6QixDQUFQLENBSGtDLENBS3RDO0FBQ0E7O0FBRUEsVUFBQSxNQUFNLENBQUMsY0FBUCxDQUFzQixJQUF0QixFQUE0QixTQUE1QixFQUF1QztBQUFFLFlBQUEsR0FBRyxFQUFFLGVBQVc7QUFBRSxxQkFBTyxPQUFQO0FBQWlCO0FBQXJDLFdBQXZDO0FBRUE7O0FBQ0EsY0FBSSxLQUFLLENBQUMsaUJBQVYsRUFBNkI7QUFDekIsWUFBQSxLQUFLLENBQUMsaUJBQU4sQ0FBd0IsSUFBeEIsRUFBOEIsV0FBOUIsRUFESixLQUdJLE1BQU0sQ0FBQyxjQUFQLENBQXNCLElBQXRCLEVBQTRCLE9BQTVCLEVBQXFDO0FBQUUsWUFBQSxLQUFLLEVBQUUsSUFBSSxLQUFKLEdBQVksS0FBWixJQUFxQjtBQUE5QixXQUFyQztBQUVKLGNBQUksVUFBSixFQUNJLEtBQUssQ0FBQyxJQUFELEVBQU8sVUFBUCxDQUFMO0FBQ1A7O0FBRUQsU0FBQyxXQUFXLENBQUMsU0FBWixHQUF3QixNQUFNLENBQUMsTUFBUCxDQUFjLEtBQUssQ0FBQyxTQUFwQixDQUF6QixFQUF5RCxXQUF6RCxHQUF1RSxXQUF2RTtBQUVBLFFBQUEsTUFBTSxDQUFDLGNBQVAsQ0FBc0IsV0FBVyxDQUFDLFNBQWxDLEVBQTZDLE1BQTdDLEVBQXFEO0FBQUUsVUFBQSxHQUFHLEVBQUUsZUFBVztBQUFFLG1CQUFPLElBQVA7QUFBYztBQUFsQyxTQUFyRDs7QUFFQSxRQUFBLFdBQVcsQ0FBQyxTQUFaLENBQXNCLFFBQXRCLEdBQWlDLFNBQVMsUUFBVCxHQUFvQjtBQUNqRCxpQkFBTyxLQUFLLElBQUwsR0FBWSxJQUFaLEdBQW1CLEtBQUssT0FBL0I7QUFDSCxTQUZEOztBQUlBLGVBQU8sV0FBUDtBQUNIOztBQUVELE1BQUEsSUFBSSxDQUFDLFFBQUwsR0FBZ0IsUUFBaEI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLE1BQUEsSUFBSSxDQUFDLGFBQUwsR0FBcUIsUUFBUSxDQUFDLGVBQUQsQ0FBN0I7QUFFQTs7Ozs7O0FBTUE7Ozs7Ozs7QUFPQTs7Ozs7O0FBS0EsTUFBQSxJQUFJLENBQUMsV0FBTCxHQUFtQixTQUFTLFFBQVQsQ0FBa0IsVUFBbEIsRUFBOEI7QUFDN0MsWUFBSSxRQUFRLEdBQUcsRUFBZjs7QUFDQSxhQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUEvQixFQUF1QyxFQUFFLENBQXpDO0FBQ0ksVUFBQSxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUQsQ0FBWCxDQUFSLEdBQTBCLENBQTFCO0FBREo7QUFHQTs7Ozs7OztBQUtBLGVBQU8sWUFBVztBQUFFO0FBQ2hCLGVBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaLENBQVgsRUFBOEIsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFMLEdBQWMsQ0FBckQsRUFBd0QsQ0FBQyxHQUFHLENBQUMsQ0FBN0QsRUFBZ0UsRUFBRSxDQUFsRTtBQUNJLGdCQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBRCxDQUFMLENBQVIsS0FBc0IsQ0FBdEIsSUFBMkIsS0FBSyxJQUFJLENBQUMsQ0FBRCxDQUFULE1BQWtCLFNBQTdDLElBQTBELEtBQUssSUFBSSxDQUFDLENBQUQsQ0FBVCxNQUFrQixJQUFoRixFQUNJLE9BQU8sSUFBSSxDQUFDLENBQUQsQ0FBWDtBQUZSO0FBR0gsU0FKRDtBQUtILE9BZkQ7QUFpQkE7Ozs7Ozs7O0FBUUE7Ozs7Ozs7QUFLQSxNQUFBLElBQUksQ0FBQyxXQUFMLEdBQW1CLFNBQVMsUUFBVCxDQUFrQixVQUFsQixFQUE4QjtBQUU3Qzs7Ozs7O0FBTUEsZUFBTyxVQUFTLElBQVQsRUFBZTtBQUNsQixlQUFLLElBQUksQ0FBQyxHQUFHLENBQWIsRUFBZ0IsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUEvQixFQUF1QyxFQUFFLENBQXpDO0FBQ0ksZ0JBQUksVUFBVSxDQUFDLENBQUQsQ0FBVixLQUFrQixJQUF0QixFQUNJLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBRCxDQUFmLENBQVA7QUFGUjtBQUdILFNBSkQ7QUFLSCxPQWJEO0FBZUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxNQUFBLElBQUksQ0FBQyxhQUFMLEdBQXFCO0FBQ2pCLFFBQUEsS0FBSyxFQUFFLE1BRFU7QUFFakIsUUFBQSxLQUFLLEVBQUUsTUFGVTtBQUdqQixRQUFBLEtBQUssRUFBRSxNQUhVO0FBSWpCLFFBQUEsSUFBSSxFQUFFO0FBSlcsT0FBckIsQ0ExWWlELENBaVpqRDs7QUFDQSxNQUFBLElBQUksQ0FBQyxVQUFMLEdBQWtCLFlBQVc7QUFDekIsWUFBSSxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQWxCO0FBQ0E7O0FBQ0EsWUFBSSxDQUFDLE1BQUwsRUFBYTtBQUNULFVBQUEsSUFBSSxDQUFDLFlBQUwsR0FBb0IsSUFBSSxDQUFDLG1CQUFMLEdBQTJCLElBQS9DO0FBQ0E7QUFDSCxTQU53QixDQU96QjtBQUNBOzs7QUFDQSxRQUFBLElBQUksQ0FBQyxZQUFMLEdBQW9CLE1BQU0sQ0FBQyxJQUFQLEtBQWdCLFVBQVUsQ0FBQyxJQUEzQixJQUFtQyxNQUFNLENBQUMsSUFBMUM7QUFDaEI7QUFDQSxpQkFBUyxXQUFULENBQXFCLEtBQXJCLEVBQTRCLFFBQTVCLEVBQXNDO0FBQ2xDLGlCQUFPLElBQUksTUFBSixDQUFXLEtBQVgsRUFBa0IsUUFBbEIsQ0FBUDtBQUNILFNBSkw7O0FBS0EsUUFBQSxJQUFJLENBQUMsbUJBQUwsR0FBMkIsTUFBTSxDQUFDLFdBQVA7QUFDdkI7QUFDQSxpQkFBUyxrQkFBVCxDQUE0QixJQUE1QixFQUFrQztBQUM5QixpQkFBTyxJQUFJLE1BQUosQ0FBVyxJQUFYLENBQVA7QUFDSCxTQUpMO0FBS0gsT0FuQkQ7QUFxQkMsS0F2YWUsRUF1YWQ7QUFBQyxXQUFJLENBQUw7QUFBTyxZQUFLLEVBQVo7QUFBZSxXQUFJLENBQW5CO0FBQXFCLFdBQUksQ0FBekI7QUFBMkIsV0FBSSxDQUEvQjtBQUFpQyxXQUFJLENBQXJDO0FBQXVDLFdBQUksQ0FBM0M7QUFBNkMsV0FBSTtBQUFqRCxLQXZhYyxDQTlwRE87QUFxa0VnQyxRQUFHLENBQUMsVUFBUyxPQUFULEVBQWlCLE1BQWpCLEVBQXdCLE9BQXhCLEVBQWdDO0FBQzNGOztBQUNBLE1BQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUIsTUFBakI7O0FBRUEsVUFBSSxJQUFJLEdBQVEsT0FBTyxDQUFDLEVBQUQsQ0FBdkI7O0FBRUEsVUFBSSxZQUFKLENBTjJGLENBTXpFOztBQUVsQixVQUFJLFFBQVEsR0FBSSxJQUFJLENBQUMsUUFBckI7QUFBQSxVQUNJLE1BQU0sR0FBTSxJQUFJLENBQUMsTUFEckI7QUFBQSxVQUVJLElBQUksR0FBUSxJQUFJLENBQUMsSUFGckI7QUFJQTs7Ozs7Ozs7OztBQVNBLGVBQVMsRUFBVCxDQUFZLEVBQVosRUFBZ0IsR0FBaEIsRUFBcUIsR0FBckIsRUFBMEI7QUFFdEI7Ozs7QUFJQSxhQUFLLEVBQUwsR0FBVSxFQUFWO0FBRUE7Ozs7O0FBSUEsYUFBSyxHQUFMLEdBQVcsR0FBWDtBQUVBOzs7OztBQUlBLGFBQUssSUFBTCxHQUFZLFNBQVo7QUFFQTs7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxHQUFYLENBeEJzQixDQXdCTjtBQUNuQjtBQUVEOzs7QUFDQSxlQUFTLElBQVQsR0FBZ0IsQ0FBRSxDQWpEeUUsQ0FpRHhFOztBQUVuQjs7Ozs7Ozs7OztBQVFBLGVBQVMsS0FBVCxDQUFlLE1BQWYsRUFBdUI7QUFFbkI7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsSUFBbkI7QUFFQTs7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsSUFBbkI7QUFFQTs7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxNQUFNLENBQUMsR0FBbEI7QUFFQTs7Ozs7QUFJQSxhQUFLLElBQUwsR0FBWSxNQUFNLENBQUMsTUFBbkI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsZUFBUyxNQUFULEdBQWtCO0FBRWQ7Ozs7QUFJQSxhQUFLLEdBQUwsR0FBVyxDQUFYO0FBRUE7Ozs7O0FBSUEsYUFBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBWjtBQUVBOzs7OztBQUlBLGFBQUssSUFBTCxHQUFZLEtBQUssSUFBakI7QUFFQTs7Ozs7QUFJQSxhQUFLLE1BQUwsR0FBYyxJQUFkLENBeEJjLENBMEJkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRCxVQUFJLE1BQU0sR0FBRyxTQUFTLE1BQVQsR0FBa0I7QUFDM0IsZUFBTyxJQUFJLENBQUMsTUFBTCxHQUNELFNBQVMsbUJBQVQsR0FBK0I7QUFDN0IsaUJBQU8sQ0FBQyxNQUFNLENBQUMsTUFBUCxHQUFnQixTQUFTLGFBQVQsR0FBeUI7QUFDN0MsbUJBQU8sSUFBSSxZQUFKLEVBQVA7QUFDSCxXQUZNLEdBQVA7QUFHSDtBQUNEO0FBTkcsVUFPRCxTQUFTLFlBQVQsR0FBd0I7QUFDdEIsaUJBQU8sSUFBSSxNQUFKLEVBQVA7QUFDSCxTQVRMO0FBVUgsT0FYRDtBQWFBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsTUFBUCxHQUFnQixNQUFNLEVBQXRCO0FBRUE7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLEtBQVAsR0FBZSxTQUFTLEtBQVQsQ0FBZSxJQUFmLEVBQXFCO0FBQ2hDLGVBQU8sSUFBSSxJQUFJLENBQUMsS0FBVCxDQUFlLElBQWYsQ0FBUDtBQUNILE9BRkQsQ0FySjJGLENBeUozRjs7QUFDQTs7O0FBQ0EsVUFBSSxJQUFJLENBQUMsS0FBTCxLQUFlLEtBQW5CLEVBQ0ksTUFBTSxDQUFDLEtBQVAsR0FBZSxJQUFJLENBQUMsSUFBTCxDQUFVLE1BQU0sQ0FBQyxLQUFqQixFQUF3QixJQUFJLENBQUMsS0FBTCxDQUFXLFNBQVgsQ0FBcUIsUUFBN0MsQ0FBZjtBQUVKOzs7Ozs7Ozs7QUFRQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsSUFBVCxDQUFjLEVBQWQsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkIsRUFBNEI7QUFDakQsYUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLEVBQUosQ0FBTyxFQUFQLEVBQVcsR0FBWCxFQUFnQixHQUFoQixDQUE3QjtBQUNBLGFBQUssR0FBTCxJQUFZLEdBQVo7QUFDQSxlQUFPLElBQVA7QUFDSCxPQUpEOztBQU1BLGVBQVMsU0FBVCxDQUFtQixHQUFuQixFQUF3QixHQUF4QixFQUE2QixHQUE3QixFQUFrQztBQUM5QixRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBVyxHQUFHLEdBQUcsR0FBakI7QUFDSDs7QUFFRCxlQUFTLGFBQVQsQ0FBdUIsR0FBdkIsRUFBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsZUFBTyxHQUFHLEdBQUcsR0FBYixFQUFrQjtBQUNkLFVBQUEsR0FBRyxDQUFDLEdBQUcsRUFBSixDQUFILEdBQWEsR0FBRyxHQUFHLEdBQU4sR0FBWSxHQUF6QjtBQUNBLFVBQUEsR0FBRyxNQUFNLENBQVQ7QUFDSDs7QUFDRCxRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBVyxHQUFYO0FBQ0g7QUFFRDs7Ozs7Ozs7Ozs7QUFTQSxlQUFTLFFBQVQsQ0FBa0IsR0FBbEIsRUFBdUIsR0FBdkIsRUFBNEI7QUFDeEIsYUFBSyxHQUFMLEdBQVcsR0FBWDtBQUNBLGFBQUssSUFBTCxHQUFZLFNBQVo7QUFDQSxhQUFLLEdBQUwsR0FBVyxHQUFYO0FBQ0g7O0FBRUQsTUFBQSxRQUFRLENBQUMsU0FBVCxHQUFxQixNQUFNLENBQUMsTUFBUCxDQUFjLEVBQUUsQ0FBQyxTQUFqQixDQUFyQjtBQUNBLE1BQUEsUUFBUSxDQUFDLFNBQVQsQ0FBbUIsRUFBbkIsR0FBd0IsYUFBeEI7QUFFQTs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQ7QUFDQTtBQUNBLGFBQUssR0FBTCxJQUFZLENBQUMsS0FBSyxJQUFMLEdBQVksS0FBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLFFBQUosQ0FDdEMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQW5CLElBQ1UsR0FEVixHQUNzQixDQUR0QixHQUVFLEtBQUssR0FBRyxLQUFSLEdBQW9CLENBQXBCLEdBQ0EsS0FBSyxHQUFHLE9BQVIsR0FBb0IsQ0FBcEIsR0FDQSxLQUFLLEdBQUcsU0FBUixHQUFvQixDQUFwQixHQUNvQixDQU5nQixFQU8xQyxLQVAwQyxDQUE5QixFQU9KLEdBUFI7QUFRQSxlQUFPLElBQVA7QUFDSCxPQVpEO0FBY0E7Ozs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixTQUFTLFdBQVQsQ0FBcUIsS0FBckIsRUFBNEI7QUFDakQsZUFBTyxLQUFLLEdBQUcsQ0FBUixHQUNELEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsRUFBMUIsRUFBOEIsUUFBUSxDQUFDLFVBQVQsQ0FBb0IsS0FBcEIsQ0FBOUIsQ0FEQyxDQUN5RDtBQUR6RCxVQUVELEtBQUssTUFBTCxDQUFZLEtBQVosQ0FGTjtBQUdILE9BSkQ7QUFNQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCO0FBQ25ELGVBQU8sS0FBSyxNQUFMLENBQVksQ0FBQyxLQUFLLElBQUksQ0FBVCxHQUFhLEtBQUssSUFBSSxFQUF2QixNQUErQixDQUEzQyxDQUFQO0FBQ0gsT0FGRDs7QUFJQSxlQUFTLGFBQVQsQ0FBdUIsR0FBdkIsRUFBNEIsR0FBNUIsRUFBaUMsR0FBakMsRUFBc0M7QUFDbEMsZUFBTyxHQUFHLENBQUMsRUFBWCxFQUFlO0FBQ1gsVUFBQSxHQUFHLENBQUMsR0FBRyxFQUFKLENBQUgsR0FBYSxHQUFHLENBQUMsRUFBSixHQUFTLEdBQVQsR0FBZSxHQUE1QjtBQUNBLFVBQUEsR0FBRyxDQUFDLEVBQUosR0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFKLEtBQVcsQ0FBWCxHQUFlLEdBQUcsQ0FBQyxFQUFKLElBQVUsRUFBMUIsTUFBa0MsQ0FBM0M7QUFDQSxVQUFBLEdBQUcsQ0FBQyxFQUFKLE1BQVksQ0FBWjtBQUNIOztBQUNELGVBQU8sR0FBRyxDQUFDLEVBQUosR0FBUyxHQUFoQixFQUFxQjtBQUNqQixVQUFBLEdBQUcsQ0FBQyxHQUFHLEVBQUosQ0FBSCxHQUFhLEdBQUcsQ0FBQyxFQUFKLEdBQVMsR0FBVCxHQUFlLEdBQTVCO0FBQ0EsVUFBQSxHQUFHLENBQUMsRUFBSixHQUFTLEdBQUcsQ0FBQyxFQUFKLEtBQVcsQ0FBcEI7QUFDSDs7QUFDRCxRQUFBLEdBQUcsQ0FBQyxHQUFHLEVBQUosQ0FBSCxHQUFhLEdBQUcsQ0FBQyxFQUFqQjtBQUNIO0FBRUQ7Ozs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsQ0FBYyxLQUFkLENBQVg7QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsSUFBSSxDQUFDLE1BQUwsRUFBMUIsRUFBeUMsSUFBekMsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixLQUFqQixHQUF5QixNQUFNLENBQUMsU0FBUCxDQUFpQixNQUExQztBQUVBOzs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQVQsQ0FBYyxLQUFkLEVBQXFCLFFBQXJCLEVBQVg7QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLGFBQVgsRUFBMEIsSUFBSSxDQUFDLE1BQUwsRUFBMUIsRUFBeUMsSUFBekMsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7OztBQUtBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsSUFBakIsR0FBd0IsU0FBUyxVQUFULENBQW9CLEtBQXBCLEVBQTJCO0FBQy9DLGVBQU8sS0FBSyxLQUFMLENBQVcsU0FBWCxFQUFzQixDQUF0QixFQUF5QixLQUFLLEdBQUcsQ0FBSCxHQUFPLENBQXJDLENBQVA7QUFDSCxPQUZEOztBQUlBLGVBQVMsWUFBVCxDQUFzQixHQUF0QixFQUEyQixHQUEzQixFQUFnQyxHQUFoQyxFQUFxQztBQUNqQyxRQUFBLEdBQUcsQ0FBQyxHQUFELENBQUgsR0FBZ0IsR0FBRyxHQUFXLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssQ0FBUixHQUFjLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBUixHQUFjLEdBQTlCO0FBQ0EsUUFBQSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQVAsQ0FBSCxHQUFnQixHQUFHLEtBQUssRUFBeEI7QUFDSDtBQUVEOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixPQUFqQixHQUEyQixTQUFTLGFBQVQsQ0FBdUIsS0FBdkIsRUFBOEI7QUFDckQsZUFBTyxLQUFLLEtBQUwsQ0FBVyxZQUFYLEVBQXlCLENBQXpCLEVBQTRCLEtBQUssS0FBSyxDQUF0QyxDQUFQO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsUUFBakIsR0FBNEIsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsT0FBN0M7QUFFQTs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsT0FBakIsR0FBMkIsU0FBUyxhQUFULENBQXVCLEtBQXZCLEVBQThCO0FBQ3JELFlBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFULENBQWMsS0FBZCxDQUFYO0FBQ0EsZUFBTyxLQUFLLEtBQUwsQ0FBVyxZQUFYLEVBQXlCLENBQXpCLEVBQTRCLElBQUksQ0FBQyxFQUFqQyxFQUFxQyxLQUFyQyxDQUEyQyxZQUEzQyxFQUF5RCxDQUF6RCxFQUE0RCxJQUFJLENBQUMsRUFBakUsQ0FBUDtBQUNILE9BSEQ7QUFLQTs7Ozs7Ozs7O0FBT0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixRQUFqQixHQUE0QixNQUFNLENBQUMsU0FBUCxDQUFpQixPQUE3QztBQUVBOzs7Ozs7O0FBTUEsTUFBQSxNQUFNLENBQUMsU0FBUCxZQUF5QixTQUFTLFdBQVQsQ0FBcUIsS0FBckIsRUFBNEI7QUFDakQsZUFBTyxLQUFLLEtBQUwsQ0FBVyxJQUFJLFNBQUosQ0FBVyxZQUF0QixFQUFvQyxDQUFwQyxFQUF1QyxLQUF2QyxDQUFQO0FBQ0gsT0FGRDtBQUlBOzs7Ozs7OztBQU1BLE1BQUEsTUFBTSxDQUFDLFNBQVAsYUFBMEIsU0FBUyxZQUFULENBQXNCLEtBQXRCLEVBQTZCO0FBQ25ELGVBQU8sS0FBSyxLQUFMLENBQVcsSUFBSSxTQUFKLENBQVcsYUFBdEIsRUFBcUMsQ0FBckMsRUFBd0MsS0FBeEMsQ0FBUDtBQUNILE9BRkQ7O0FBSUEsVUFBSSxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUwsQ0FBVyxTQUFYLENBQXFCLEdBQXJCLEdBQ1gsU0FBUyxjQUFULENBQXdCLEdBQXhCLEVBQTZCLEdBQTdCLEVBQWtDLEdBQWxDLEVBQXVDO0FBQ3JDLFFBQUEsR0FBRyxDQUFDLEdBQUosQ0FBUSxHQUFSLEVBQWEsR0FBYixFQURxQyxDQUNsQjtBQUN0QjtBQUNEO0FBSmEsUUFLWCxTQUFTLGNBQVQsQ0FBd0IsR0FBeEIsRUFBNkIsR0FBN0IsRUFBa0MsR0FBbEMsRUFBdUM7QUFDckMsYUFBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBeEIsRUFBZ0MsRUFBRSxDQUFsQztBQUNJLFVBQUEsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFQLENBQUgsR0FBZSxHQUFHLENBQUMsQ0FBRCxDQUFsQjtBQURKO0FBRUgsT0FSTDtBQVVBOzs7Ozs7QUFLQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsV0FBVCxDQUFxQixLQUFyQixFQUE0QjtBQUNqRCxZQUFJLEdBQUcsR0FBRyxLQUFLLENBQUMsTUFBTixLQUFpQixDQUEzQjtBQUNBLFlBQUksQ0FBQyxHQUFMLEVBQ0ksT0FBTyxLQUFLLEtBQUwsQ0FBVyxTQUFYLEVBQXNCLENBQXRCLEVBQXlCLENBQXpCLENBQVA7O0FBQ0osWUFBSSxJQUFJLENBQUMsUUFBTCxDQUFjLEtBQWQsQ0FBSixFQUEwQjtBQUN0QixjQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsS0FBUCxDQUFhLEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBUCxDQUFjLEtBQWQsQ0FBbkIsQ0FBVjtBQUNBLFVBQUEsTUFBTSxDQUFDLE1BQVAsQ0FBYyxLQUFkLEVBQXFCLEdBQXJCLEVBQTBCLENBQTFCO0FBQ0EsVUFBQSxLQUFLLEdBQUcsR0FBUjtBQUNIOztBQUNELGVBQU8sS0FBSyxNQUFMLENBQVksR0FBWixFQUFpQixLQUFqQixDQUF1QixVQUF2QixFQUFtQyxHQUFuQyxFQUF3QyxLQUF4QyxDQUFQO0FBQ0gsT0FWRDtBQVlBOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixNQUFqQixHQUEwQixTQUFTLFlBQVQsQ0FBc0IsS0FBdEIsRUFBNkI7QUFDbkQsWUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQUwsQ0FBWSxLQUFaLENBQVY7QUFDQSxlQUFPLEdBQUcsR0FDSixLQUFLLE1BQUwsQ0FBWSxHQUFaLEVBQWlCLEtBQWpCLENBQXVCLElBQUksQ0FBQyxLQUE1QixFQUFtQyxHQUFuQyxFQUF3QyxLQUF4QyxDQURJLEdBRUosS0FBSyxLQUFMLENBQVcsU0FBWCxFQUFzQixDQUF0QixFQUF5QixDQUF6QixDQUZOO0FBR0gsT0FMRDtBQU9BOzs7Ozs7O0FBS0EsTUFBQSxNQUFNLENBQUMsU0FBUCxDQUFpQixJQUFqQixHQUF3QixTQUFTLElBQVQsR0FBZ0I7QUFDcEMsYUFBSyxNQUFMLEdBQWMsSUFBSSxLQUFKLENBQVUsSUFBVixDQUFkO0FBQ0EsYUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBeEI7QUFDQSxhQUFLLEdBQUwsR0FBVyxDQUFYO0FBQ0EsZUFBTyxJQUFQO0FBQ0gsT0FMRDtBQU9BOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLEtBQWpCLEdBQXlCLFNBQVMsS0FBVCxHQUFpQjtBQUN0QyxZQUFJLEtBQUssTUFBVCxFQUFpQjtBQUNiLGVBQUssSUFBTCxHQUFjLEtBQUssTUFBTCxDQUFZLElBQTFCO0FBQ0EsZUFBSyxJQUFMLEdBQWMsS0FBSyxNQUFMLENBQVksSUFBMUI7QUFDQSxlQUFLLEdBQUwsR0FBYyxLQUFLLE1BQUwsQ0FBWSxHQUExQjtBQUNBLGVBQUssTUFBTCxHQUFjLEtBQUssTUFBTCxDQUFZLElBQTFCO0FBQ0gsU0FMRCxNQUtPO0FBQ0gsZUFBSyxJQUFMLEdBQVksS0FBSyxJQUFMLEdBQVksSUFBSSxFQUFKLENBQU8sSUFBUCxFQUFhLENBQWIsRUFBZ0IsQ0FBaEIsQ0FBeEI7QUFDQSxlQUFLLEdBQUwsR0FBWSxDQUFaO0FBQ0g7O0FBQ0QsZUFBTyxJQUFQO0FBQ0gsT0FYRDtBQWFBOzs7Ozs7QUFJQSxNQUFBLE1BQU0sQ0FBQyxTQUFQLENBQWlCLE1BQWpCLEdBQTBCLFNBQVMsTUFBVCxHQUFrQjtBQUN4QyxZQUFJLElBQUksR0FBRyxLQUFLLElBQWhCO0FBQUEsWUFDSSxJQUFJLEdBQUcsS0FBSyxJQURoQjtBQUFBLFlBRUksR0FBRyxHQUFJLEtBQUssR0FGaEI7QUFHQSxhQUFLLEtBQUwsR0FBYSxNQUFiLENBQW9CLEdBQXBCOztBQUNBLFlBQUksR0FBSixFQUFTO0FBQ0wsZUFBSyxJQUFMLENBQVUsSUFBVixHQUFpQixJQUFJLENBQUMsSUFBdEIsQ0FESyxDQUN1Qjs7QUFDNUIsZUFBSyxJQUFMLEdBQVksSUFBWjtBQUNBLGVBQUssR0FBTCxJQUFZLEdBQVo7QUFDSDs7QUFDRCxlQUFPLElBQVA7QUFDSCxPQVhEO0FBYUE7Ozs7OztBQUlBLE1BQUEsTUFBTSxDQUFDLFNBQVAsQ0FBaUIsTUFBakIsR0FBMEIsU0FBUyxNQUFULEdBQWtCO0FBQ3hDLFlBQUksSUFBSSxHQUFHLEtBQUssSUFBTCxDQUFVLElBQXJCO0FBQUEsWUFBMkI7QUFDdkIsUUFBQSxHQUFHLEdBQUksS0FBSyxXQUFMLENBQWlCLEtBQWpCLENBQXVCLEtBQUssR0FBNUIsQ0FEWDtBQUFBLFlBRUksR0FBRyxHQUFJLENBRlg7O0FBR0EsZUFBTyxJQUFQLEVBQWE7QUFDVCxVQUFBLElBQUksQ0FBQyxFQUFMLENBQVEsSUFBSSxDQUFDLEdBQWIsRUFBa0IsR0FBbEIsRUFBdUIsR0FBdkI7QUFDQSxVQUFBLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBWjtBQUNBLFVBQUEsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFaO0FBQ0gsU0FSdUMsQ0FTeEM7OztBQUNBLGVBQU8sR0FBUDtBQUNILE9BWEQ7O0FBYUEsTUFBQSxNQUFNLENBQUMsVUFBUCxHQUFvQixVQUFTLGFBQVQsRUFBd0I7QUFDeEMsUUFBQSxZQUFZLEdBQUcsYUFBZjtBQUNBLFFBQUEsTUFBTSxDQUFDLE1BQVAsR0FBZ0IsTUFBTSxFQUF0Qjs7QUFDQSxRQUFBLFlBQVksQ0FBQyxVQUFiO0FBQ0gsT0FKRDtBQU1DLEtBbmR5RCxFQW1keEQ7QUFBQyxZQUFLO0FBQU4sS0FuZHdELENBcmtFbkM7QUF3aEZWLFFBQUcsQ0FBQyxVQUFTLE9BQVQsRUFBaUIsTUFBakIsRUFBd0IsT0FBeEIsRUFBZ0M7QUFDakQ7O0FBQ0EsTUFBQSxNQUFNLENBQUMsT0FBUCxHQUFpQixZQUFqQixDQUZpRCxDQUlqRDs7QUFDQSxVQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsRUFBRCxDQUFwQjs7QUFDQSxPQUFDLFlBQVksQ0FBQyxTQUFiLEdBQXlCLE1BQU0sQ0FBQyxNQUFQLENBQWMsTUFBTSxDQUFDLFNBQXJCLENBQTFCLEVBQTJELFdBQTNELEdBQXlFLFlBQXpFOztBQUVBLFVBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxFQUFELENBQWxCO0FBRUE7Ozs7Ozs7O0FBTUEsZUFBUyxZQUFULEdBQXdCO0FBQ3BCLFFBQUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxJQUFaO0FBQ0g7O0FBRUQsTUFBQSxZQUFZLENBQUMsVUFBYixHQUEwQixZQUFZO0FBQ2xDOzs7Ozs7QUFNQSxRQUFBLFlBQVksQ0FBQyxLQUFiLEdBQXFCLElBQUksQ0FBQyxtQkFBMUI7QUFFQSxRQUFBLFlBQVksQ0FBQyxnQkFBYixHQUFnQyxJQUFJLENBQUMsTUFBTCxJQUFlLElBQUksQ0FBQyxNQUFMLENBQVksU0FBWixZQUFpQyxVQUFoRCxJQUE4RCxJQUFJLENBQUMsTUFBTCxDQUFZLFNBQVosQ0FBc0IsR0FBdEIsQ0FBMEIsSUFBMUIsS0FBbUMsS0FBakcsR0FDMUIsU0FBUyxvQkFBVCxDQUE4QixHQUE5QixFQUFtQyxHQUFuQyxFQUF3QyxHQUF4QyxFQUE2QztBQUM3QyxVQUFBLEdBQUcsQ0FBQyxHQUFKLENBQVEsR0FBUixFQUFhLEdBQWIsRUFENkMsQ0FDMUI7QUFDbkI7QUFDRDtBQUNEO0FBTDRCLFVBTTFCLFNBQVMscUJBQVQsQ0FBK0IsR0FBL0IsRUFBb0MsR0FBcEMsRUFBeUMsR0FBekMsRUFBOEM7QUFDOUMsY0FBSSxHQUFHLENBQUMsSUFBUixFQUFjO0FBQ1osWUFBQSxHQUFHLENBQUMsSUFBSixDQUFTLEdBQVQsRUFBYyxHQUFkLEVBQW1CLENBQW5CLEVBQXNCLEdBQUcsQ0FBQyxNQUExQixFQURGLEtBRUssS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFiLEVBQWdCLENBQUMsR0FBRyxHQUFHLENBQUMsTUFBeEI7QUFBaUM7QUFDcEMsWUFBQSxHQUFHLENBQUMsR0FBRyxFQUFKLENBQUgsR0FBYSxHQUFHLENBQUMsQ0FBQyxFQUFGLENBQWhCO0FBREc7QUFFTixTQVhMO0FBWUgsT0FyQkQ7QUF3QkE7Ozs7O0FBR0EsTUFBQSxZQUFZLENBQUMsU0FBYixDQUF1QixLQUF2QixHQUErQixTQUFTLGtCQUFULENBQTRCLEtBQTVCLEVBQW1DO0FBQzlELFlBQUksSUFBSSxDQUFDLFFBQUwsQ0FBYyxLQUFkLENBQUosRUFDSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsS0FBbEIsRUFBeUIsUUFBekIsQ0FBUjtBQUNKLFlBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFOLEtBQWlCLENBQTNCO0FBQ0EsYUFBSyxNQUFMLENBQVksR0FBWjtBQUNBLFlBQUksR0FBSixFQUNJLEtBQUssS0FBTCxDQUFXLFlBQVksQ0FBQyxnQkFBeEIsRUFBMEMsR0FBMUMsRUFBK0MsS0FBL0M7QUFDSixlQUFPLElBQVA7QUFDSCxPQVJEOztBQVVBLGVBQVMsaUJBQVQsQ0FBMkIsR0FBM0IsRUFBZ0MsR0FBaEMsRUFBcUMsR0FBckMsRUFBMEM7QUFDdEMsWUFBSSxHQUFHLENBQUMsTUFBSixHQUFhLEVBQWpCLEVBQXFCO0FBQ2pCLFVBQUEsSUFBSSxDQUFDLElBQUwsQ0FBVSxLQUFWLENBQWdCLEdBQWhCLEVBQXFCLEdBQXJCLEVBQTBCLEdBQTFCLEVBREosS0FFSyxJQUFJLEdBQUcsQ0FBQyxTQUFSLEVBQ0QsR0FBRyxDQUFDLFNBQUosQ0FBYyxHQUFkLEVBQW1CLEdBQW5CLEVBREMsS0FHRCxHQUFHLENBQUMsS0FBSixDQUFVLEdBQVYsRUFBZSxHQUFmO0FBQ1A7QUFFRDs7Ozs7QUFHQSxNQUFBLFlBQVksQ0FBQyxTQUFiLENBQXVCLE1BQXZCLEdBQWdDLFNBQVMsbUJBQVQsQ0FBNkIsS0FBN0IsRUFBb0M7QUFDaEUsWUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQUwsQ0FBWSxVQUFaLENBQXVCLEtBQXZCLENBQVY7QUFDQSxhQUFLLE1BQUwsQ0FBWSxHQUFaO0FBQ0EsWUFBSSxHQUFKLEVBQ0ksS0FBSyxLQUFMLENBQVcsaUJBQVgsRUFBOEIsR0FBOUIsRUFBbUMsS0FBbkM7QUFDSixlQUFPLElBQVA7QUFDSCxPQU5EO0FBU0E7Ozs7Ozs7O0FBT0EsTUFBQSxZQUFZLENBQUMsVUFBYjtBQUVDLEtBdkZlLEVBdUZkO0FBQUMsWUFBSyxFQUFOO0FBQVMsWUFBSztBQUFkLEtBdkZjO0FBeGhGTyxHQWpDVyxFQWdwRlosRUFocEZZLEVBZ3BGVCxDQUFDLENBQUQsQ0FocEZTO0FBa3BGakMsQ0FscEZELEtBbXBGQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOltudWxsXX0=