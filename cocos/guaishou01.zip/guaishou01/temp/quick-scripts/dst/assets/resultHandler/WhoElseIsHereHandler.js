
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/WhoElseIsHereHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '26c6aE+vLVIZIyZI+yQVbXX', 'WhoElseIsHereHandler');
// resultHandler/WhoElseIsHereHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var Common_1 = require("../script/xiaojingling/Common");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var WhoElseIsHereHandler = /** @class */ (function () {
    function WhoElseIsHereHandler() {
    }
    WhoElseIsHereHandler.prototype.handle = function (oResult) {
        var oUserInfoArray = oResult.userInfo;
        var _loop_1 = function (oUserInfo) {
            if (oUserInfo == null) {
                return "continue";
            }
            var heroAvatar = oUserInfo.heroAvatar;
            HeroFactory_1.default.createAsync(heroAvatar, function (heroNode) {
                if (heroNode == null) {
                    return;
                }
                cc.Canvas.instance.node.addChild(heroNode);
                // heroNode.x = 300 * Math.random();
                // heroNode.y = 300 * Math.random();
                // heroNode.x = -200;
                // heroNode.y = 0;
                // heroNode.active = true;
                var skeleton = heroNode.getComponent(sp.Skeleton);
                skeleton.setAnimation(1, 'stand', true);
                UserManager_1.default.putMyHeroComp(oUserInfo.userId, heroNode.getComponent(Common_1.default));
            });
        };
        for (var _i = 0, oUserInfoArray_1 = oUserInfoArray; _i < oUserInfoArray_1.length; _i++) {
            var oUserInfo = oUserInfoArray_1[_i];
            _loop_1(oUserInfo);
        }
    };
    return WhoElseIsHereHandler;
}());
exports.default = WhoElseIsHereHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcV2hvRWxzZUlzSGVyZUhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxrRUFBNkQ7QUFFN0Qsd0RBQW1EO0FBRW5ELGtFQUE2RDtBQUU3RDtJQUFBO0lBMEJBLENBQUM7SUF6QkcscUNBQU0sR0FBTixVQUFPLE9BQW1EO1FBQ3RELElBQUksY0FBYyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7Z0NBQzdCLFNBQVM7WUFDZCxJQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUU7O2FBRXRCO1lBQ0QsSUFBSSxVQUFVLEdBQUcsU0FBUyxDQUFDLFVBQVUsQ0FBQztZQUN0QyxxQkFBVyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsVUFBQyxRQUFRO2dCQUN6QyxJQUFHLFFBQVEsSUFBRSxJQUFJLEVBQUM7b0JBQ2QsT0FBTztpQkFDVjtnQkFFRCxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQyxvQ0FBb0M7Z0JBQ3BDLG9DQUFvQztnQkFDcEMscUJBQXFCO2dCQUNyQixrQkFBa0I7Z0JBQ2xCLDBCQUEwQjtnQkFDMUIsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2xELFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDeEMscUJBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxRQUFRLENBQUMsWUFBWSxDQUFDLGdCQUFNLENBQUMsQ0FBQyxDQUFDO1lBQzlFLENBQUMsQ0FBQyxDQUFDOztRQW5CUCxLQUFzQixVQUFjLEVBQWQsaUNBQWMsRUFBZCw0QkFBYyxFQUFkLElBQWM7WUFBL0IsSUFBSSxTQUFTLHVCQUFBO29CQUFULFNBQVM7U0FvQmpCO0lBQ0wsQ0FBQztJQUVMLDJCQUFDO0FBQUQsQ0ExQkEsQUEwQkMsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb3RvY29sID0gcmVxdWlyZSgnLi4vbXNnL0dhbWVNc2dQcm90b2NvbCcpO1xyXG5pbXBvcnQgSGVyb0ZhY3RvcnkgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvSGVyb0ZhY3RvcnlcIjtcclxuaW1wb3J0IFdlYlV0aWwgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvV2ViVXRpbFwiO1xyXG5pbXBvcnQgQ29tbW9uIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL0NvbW1vblwiO1xyXG5pbXBvcnQgRmlnaHRTY2VuZSBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9GaWdodFNjZW5lXCI7XHJcbmltcG9ydCBVc2VyTWFuYWdlciBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9Vc2VyTWFuYWdlclwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgV2hvRWxzZUlzSGVyZUhhbmRsZXIgIHtcclxuICAgIGhhbmRsZShvUmVzdWx0Om1vZF9HYW1lTXNnUHJvdG9jb2wubXNnLldob0Vsc2VJc0hlcmVSZXN1bHQpOnZvaWR7XHJcbiAgICAgICAgbGV0IG9Vc2VySW5mb0FycmF5ID0gb1Jlc3VsdC51c2VySW5mbztcclxuICAgICAgICBmb3IgKGxldCBvVXNlckluZm8gb2Ygb1VzZXJJbmZvQXJyYXkpIHtcclxuICAgICAgICAgICAgaWYgKG9Vc2VySW5mbyA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgaGVyb0F2YXRhciA9IG9Vc2VySW5mby5oZXJvQXZhdGFyO1xyXG4gICAgICAgICAgICBIZXJvRmFjdG9yeS5jcmVhdGVBc3luYyhoZXJvQXZhdGFyLCAoaGVyb05vZGUpID0+IHtcclxuICAgICAgICAgICAgICAgIGlmKGhlcm9Ob2RlPT1udWxsKXtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgY2MuQ2FudmFzLmluc3RhbmNlLm5vZGUuYWRkQ2hpbGQoaGVyb05vZGUpO1xyXG4gICAgICAgICAgICAgICAgLy8gaGVyb05vZGUueCA9IDMwMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgICAgICAgICAvLyBoZXJvTm9kZS55ID0gMzAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICAgICAgICAgIC8vIGhlcm9Ob2RlLnggPSAtMjAwO1xyXG4gICAgICAgICAgICAgICAgLy8gaGVyb05vZGUueSA9IDA7XHJcbiAgICAgICAgICAgICAgICAvLyBoZXJvTm9kZS5hY3RpdmUgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgbGV0IHNrZWxldG9uID0gaGVyb05vZGUuZ2V0Q29tcG9uZW50KHNwLlNrZWxldG9uKTtcclxuICAgICAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCAnc3RhbmQnLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgIFVzZXJNYW5hZ2VyLnB1dE15SGVyb0NvbXAob1VzZXJJbmZvLnVzZXJJZCxoZXJvTm9kZS5nZXRDb21wb25lbnQoQ29tbW9uKSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19