
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserEntryResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '34a19lm1H9JGbAT609CM1c5', 'UserEntryResultHandler');
// resultHandler/UserEntryResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var HeroFactory_1 = require("../script/xiaojingling/HeroFactory");
var WebUtil_1 = require("../script/xiaojingling/WebUtil");
var Common_1 = require("../script/xiaojingling/Common");
var FightScene_1 = require("../script/xiaojingling/FightScene");
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserEntryResultHandler = /** @class */ (function () {
    function UserEntryResultHandler() {
    }
    UserEntryResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.heroAvatar + ",id=" + oResult.userId + "\u5165\u573A");
        HeroFactory_1.default.createAsync(oResult.heroAvatar, function (heroNode) {
            if (heroNode == null) {
                return;
            }
            var nMyUserId = Number.parseInt(WebUtil_1.default.getQueryParam("userId"));
            //oResult是后台传的英雄对象，nMyUserId是url地址里写的用户id，oMyHeroComp是通过后台传入的oResult的名称加载出来的预制体
            var oMyHeroComp = heroNode.getComponent(Common_1.default);
            if (oResult.userId == nMyUserId) {
                cc.Canvas.instance.node.getComponent(FightScene_1.default)._oMyHreo = oMyHeroComp;
            }
            cc.Canvas.instance.node.addChild(heroNode);
            // heroNode.x = 300 * Math.random();
            // heroNode.y = 300 * Math.random();
            // heroNode.x = -200;
            // heroNode.y = 0;
            // heroNode.active = true;
            var skeleton = heroNode.getComponent(sp.Skeleton);
            skeleton.setAnimation(1, 'stand', true);
            UserManager_1.default.putMyHeroComp(oResult.userId, oMyHeroComp);
        });
    };
    return UserEntryResultHandler;
}());
exports.default = UserEntryResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlckVudHJ5UmVzdWx0SGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLGtFQUE2RDtBQUM3RCwwREFBcUQ7QUFDckQsd0RBQW1EO0FBQ25ELGdFQUEyRDtBQUMzRCxrRUFBNkQ7QUFFN0Q7SUFBQTtJQTRCQSxDQUFDO0lBM0JHLHVDQUFNLEdBQU4sVUFBTyxPQUErQztRQUNsRCxFQUFFLENBQUMsR0FBRyxDQUFDLHVCQUFNLE9BQU8sQ0FBQyxVQUFVLFlBQU8sT0FBTyxDQUFDLE1BQU0saUJBQUksQ0FBQyxDQUFDO1FBQzFELHFCQUFXLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsVUFBQyxRQUFRO1lBQ2pELElBQUcsUUFBUSxJQUFFLElBQUksRUFBQztnQkFDZCxPQUFPO2FBQ1Y7WUFFRCxJQUFJLFNBQVMsR0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFPLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDL0QsK0VBQStFO1lBQy9FLElBQUksV0FBVyxHQUFHLFFBQVEsQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDO1lBQ2hELElBQUcsT0FBTyxDQUFDLE1BQU0sSUFBRSxTQUFTLEVBQUM7Z0JBQ3pCLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsb0JBQVUsQ0FBQyxDQUFDLFFBQVEsR0FBQyxXQUFXLENBQUM7YUFDekU7WUFHRCxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQzNDLG9DQUFvQztZQUNwQyxvQ0FBb0M7WUFDcEMscUJBQXFCO1lBQ3JCLGtCQUFrQjtZQUNsQiwwQkFBMEI7WUFDMUIsSUFBSSxRQUFRLEdBQUcsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDbEQsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1lBQ3hDLHFCQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUMsV0FBVyxDQUFDLENBQUM7UUFDMUQsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUwsNkJBQUM7QUFBRCxDQTVCQSxBQTRCQyxJQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vZF9HYW1lTXNnUHJvdG9jb2wgPSByZXF1aXJlKCcuLi9tc2cvR2FtZU1zZ1Byb3RvY29sJyk7XHJcbmltcG9ydCBIZXJvRmFjdG9yeSBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9IZXJvRmFjdG9yeVwiO1xyXG5pbXBvcnQgV2ViVXRpbCBmcm9tIFwiLi4vc2NyaXB0L3hpYW9qaW5nbGluZy9XZWJVdGlsXCI7XHJcbmltcG9ydCBDb21tb24gZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvQ29tbW9uXCI7XHJcbmltcG9ydCBGaWdodFNjZW5lIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL0ZpZ2h0U2NlbmVcIjtcclxuaW1wb3J0IFVzZXJNYW5hZ2VyIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL1VzZXJNYW5hZ2VyXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyRW50cnlSZXN1bHRIYW5kbGVyICB7XHJcbiAgICBoYW5kbGUob1Jlc3VsdDptb2RfR2FtZU1zZ1Byb3RvY29sLm1zZy5Vc2VyRW50cnlSZXN1bHQpOnZvaWR7XHJcbiAgICAgICAgY2MubG9nKGDnlKjmiLfvvJoke29SZXN1bHQuaGVyb0F2YXRhcn0saWQ9JHtvUmVzdWx0LnVzZXJJZH3lhaXlnLpgKTtcclxuICAgICAgICBIZXJvRmFjdG9yeS5jcmVhdGVBc3luYyhvUmVzdWx0Lmhlcm9BdmF0YXIsIChoZXJvTm9kZSkgPT4ge1xyXG4gICAgICAgICAgICBpZihoZXJvTm9kZT09bnVsbCl7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGxldCBuTXlVc2VySWQ9TnVtYmVyLnBhcnNlSW50KFdlYlV0aWwuZ2V0UXVlcnlQYXJhbShcInVzZXJJZFwiKSk7XHJcbiAgICAgICAgICAgIC8vb1Jlc3VsdOaYr+WQjuWPsOS8oOeahOiLsembhOWvueixoe+8jG5NeVVzZXJJZOaYr3VybOWcsOWdgOmHjOWGmeeahOeUqOaIt2lk77yMb015SGVyb0NvbXDmmK/pgJrov4flkI7lj7DkvKDlhaXnmoRvUmVzdWx055qE5ZCN56ew5Yqg6L295Ye65p2l55qE6aKE5Yi25L2TXHJcbiAgICAgICAgICAgIGxldCBvTXlIZXJvQ29tcCA9IGhlcm9Ob2RlLmdldENvbXBvbmVudChDb21tb24pO1xyXG4gICAgICAgICAgICBpZihvUmVzdWx0LnVzZXJJZD09bk15VXNlcklkKXtcclxuICAgICAgICAgICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLmdldENvbXBvbmVudChGaWdodFNjZW5lKS5fb015SHJlbz1vTXlIZXJvQ29tcDtcclxuICAgICAgICAgICAgfVxyXG5cclxuXHJcbiAgICAgICAgICAgIGNjLkNhbnZhcy5pbnN0YW5jZS5ub2RlLmFkZENoaWxkKGhlcm9Ob2RlKTtcclxuICAgICAgICAgICAgLy8gaGVyb05vZGUueCA9IDMwMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgICAgIC8vIGhlcm9Ob2RlLnkgPSAzMDAgKiBNYXRoLnJhbmRvbSgpO1xyXG4gICAgICAgICAgICAvLyBoZXJvTm9kZS54ID0gLTIwMDtcclxuICAgICAgICAgICAgLy8gaGVyb05vZGUueSA9IDA7XHJcbiAgICAgICAgICAgIC8vIGhlcm9Ob2RlLmFjdGl2ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIGxldCBza2VsZXRvbiA9IGhlcm9Ob2RlLmdldENvbXBvbmVudChzcC5Ta2VsZXRvbik7XHJcbiAgICAgICAgICAgIHNrZWxldG9uLnNldEFuaW1hdGlvbigxLCAnc3RhbmQnLCB0cnVlKTtcclxuICAgICAgICAgICAgVXNlck1hbmFnZXIucHV0TXlIZXJvQ29tcChvUmVzdWx0LnVzZXJJZCxvTXlIZXJvQ29tcCk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==