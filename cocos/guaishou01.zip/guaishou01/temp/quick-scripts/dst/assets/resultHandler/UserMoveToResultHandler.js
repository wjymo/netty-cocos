
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserMoveToResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '743f3GBFqFEgYbAE+WsIG/e', 'UserMoveToResultHandler');
// resultHandler/UserMoveToResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserMoveToResultHandler = /** @class */ (function () {
    function UserMoveToResultHandler() {
    }
    UserMoveToResultHandler.prototype.handle = function (oResult) {
        if (oResult == null) {
            return;
        }
        var userId = oResult.moveUserId;
        var oHreoComp = UserManager_1.default.getMyHeroComp(userId);
        // let oHreoComp =find();
        oHreoComp.moveTo(oResult.moveToPosX, oResult.moveToPosY);
    };
    return UserMoveToResultHandler;
}());
exports.default = UserMoveToResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlck1vdmVUb1Jlc3VsdEhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxrRUFBNkQ7QUFFN0Q7SUFBQTtJQWNBLENBQUM7SUFiRyx3Q0FBTSxHQUFOLFVBQU8sT0FBZ0Q7UUFDbkQsSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO1lBQ2pCLE9BQU87U0FDVjtRQUNELElBQUksTUFBTSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7UUFFaEMsSUFBSSxTQUFTLEdBQUcscUJBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbEQseUJBQXlCO1FBR3pCLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7SUFDM0QsQ0FBQztJQUVMLDhCQUFDO0FBQUQsQ0FkQSxBQWNDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX0dhbWVNc2dQcm90b2NvbCA9IHJlcXVpcmUoJy4uL21zZy9HYW1lTXNnUHJvdG9jb2wnKTtcclxuaW1wb3J0IFVzZXJNYW5hZ2VyIGZyb20gXCIuLi9zY3JpcHQveGlhb2ppbmdsaW5nL1VzZXJNYW5hZ2VyXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyTW92ZVRvUmVzdWx0SGFuZGxlciAge1xyXG4gICAgaGFuZGxlKG9SZXN1bHQ6bW9kX0dhbWVNc2dQcm90b2NvbC5tc2cuVXNlck1vdmVUb1Jlc3VsdCk6dm9pZHtcclxuICAgICAgICBpZiAob1Jlc3VsdCA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgbGV0IHVzZXJJZCA9IG9SZXN1bHQubW92ZVVzZXJJZDtcclxuXHJcbiAgICAgICAgbGV0IG9IcmVvQ29tcCA9IFVzZXJNYW5hZ2VyLmdldE15SGVyb0NvbXAodXNlcklkKTtcclxuICAgICAgICAvLyBsZXQgb0hyZW9Db21wID1maW5kKCk7XHJcblxyXG5cclxuICAgICAgICBvSHJlb0NvbXAubW92ZVRvKG9SZXN1bHQubW92ZVRvUG9zWCxvUmVzdWx0Lm1vdmVUb1Bvc1kpXHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==