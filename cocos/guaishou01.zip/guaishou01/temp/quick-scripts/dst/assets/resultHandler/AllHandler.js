
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/AllHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9f8efav/TRDiIt8ruVLlakl', 'AllHandler');
// resultHandler/AllHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mod_GameMsgProtocol = require("../msg/GameMsgProtocol");
var UserEntryResultHandler_1 = require("./UserEntryResultHandler");
var WhoElseIsHereHandler_1 = require("./WhoElseIsHereHandler");
var UserQuitResultHandler_1 = require("./UserQuitResultHandler");
var UserMoveToResultHandler_1 = require("./UserMoveToResultHandler");
var AllHandler = /** @class */ (function () {
    function AllHandler() {
        this._oHandlerMap = {};
        var oMsgCode = mod_GameMsgProtocol.msg.MsgCode;
        this._oHandlerMap[oMsgCode.USER_ENTRY_RESULT] = new UserEntryResultHandler_1.default();
        this._oHandlerMap[oMsgCode.WHO_ELSE_IS_HERE_RESULT] = new WhoElseIsHereHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_MOVE_TO_RESULT] = new UserMoveToResultHandler_1.default();
        this._oHandlerMap[oMsgCode.USER_QUIT_RESULT] = new UserQuitResultHandler_1.default();
    }
    AllHandler.prototype.handle = function (nMsgCode, oMsgBody) {
        if (nMsgCode < 0 || oMsgBody == null) {
            return;
        }
        var oHandler = this._oHandlerMap[nMsgCode];
        if (oHandler == null) {
            cc.error("nMsgCode:" + nMsgCode + "\u627E\u4E0D\u5230\u5BF9\u5E94handler");
            return;
        }
        oHandler.handle(oMsgBody);
    };
    return AllHandler;
}());
exports.default = AllHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcQWxsSGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDREQUErRDtBQUMvRCxtRUFBOEQ7QUFDOUQsK0RBQTBEO0FBQzFELGlFQUE0RDtBQUM1RCxxRUFBZ0U7QUFFaEU7SUFFSTtRQURpQixpQkFBWSxHQUF5QixFQUFFLENBQUM7UUFFckQsSUFBSSxRQUFRLEdBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUM3QyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxHQUFDLElBQUksZ0NBQXNCLEVBQUUsQ0FBQztRQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFDLElBQUksOEJBQW9CLEVBQUUsQ0FBQztRQUMvRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFDLElBQUksaUNBQXVCLEVBQUUsQ0FBQztRQUM5RSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFDLElBQUksK0JBQXFCLEVBQUUsQ0FBQztJQUU3RSxDQUFDO0lBQ0QsMkJBQU0sR0FBTixVQUFPLFFBQWUsRUFBQyxRQUFZO1FBQy9CLElBQUcsUUFBUSxHQUFDLENBQUMsSUFBRSxRQUFRLElBQUUsSUFBSSxFQUFDO1lBQzFCLE9BQU87U0FDVjtRQUNELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDM0MsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO1lBQ2xCLEVBQUUsQ0FBQyxLQUFLLENBQUMsY0FBWSxRQUFRLDBDQUFjLENBQUMsQ0FBQztZQUM3QyxPQUFPO1NBQ1Y7UUFFRCxRQUFRLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzlCLENBQUM7SUFFTCxpQkFBQztBQUFELENBdkJBLEFBdUJDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9kX0dhbWVNc2dQcm90b2NvbCA9IHJlcXVpcmUoJy4uL21zZy9HYW1lTXNnUHJvdG9jb2wnKTtcclxuaW1wb3J0IFVzZXJFbnRyeVJlc3VsdEhhbmRsZXIgZnJvbSAnLi9Vc2VyRW50cnlSZXN1bHRIYW5kbGVyJztcclxuaW1wb3J0IFdob0Vsc2VJc0hlcmVIYW5kbGVyIGZyb20gXCIuL1dob0Vsc2VJc0hlcmVIYW5kbGVyXCI7XHJcbmltcG9ydCBVc2VyUXVpdFJlc3VsdEhhbmRsZXIgZnJvbSBcIi4vVXNlclF1aXRSZXN1bHRIYW5kbGVyXCI7XHJcbmltcG9ydCBVc2VyTW92ZVRvUmVzdWx0SGFuZGxlciBmcm9tIFwiLi9Vc2VyTW92ZVRvUmVzdWx0SGFuZGxlclwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQWxsSGFuZGxlciAge1xyXG4gICAgcHJpdmF0ZSByZWFkb25seSBfb0hhbmRsZXJNYXA6e1tuTXNnQ29kZTpudW1iZXJdOmFueX09e307XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBsZXQgb01zZ0NvZGU9bW9kX0dhbWVNc2dQcm90b2NvbC5tc2cuTXNnQ29kZTtcclxuICAgICAgICB0aGlzLl9vSGFuZGxlck1hcFtvTXNnQ29kZS5VU0VSX0VOVFJZX1JFU1VMVF09bmV3IFVzZXJFbnRyeVJlc3VsdEhhbmRsZXIoKTtcclxuICAgICAgICB0aGlzLl9vSGFuZGxlck1hcFtvTXNnQ29kZS5XSE9fRUxTRV9JU19IRVJFX1JFU1VMVF09bmV3IFdob0Vsc2VJc0hlcmVIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fb0hhbmRsZXJNYXBbb01zZ0NvZGUuVVNFUl9NT1ZFX1RPX1JFU1VMVF09bmV3IFVzZXJNb3ZlVG9SZXN1bHRIYW5kbGVyKCk7XHJcbiAgICAgICAgdGhpcy5fb0hhbmRsZXJNYXBbb01zZ0NvZGUuVVNFUl9RVUlUX1JFU1VMVF09bmV3IFVzZXJRdWl0UmVzdWx0SGFuZGxlcigpO1xyXG5cclxuICAgIH1cclxuICAgIGhhbmRsZShuTXNnQ29kZTpudW1iZXIsb01zZ0JvZHk6YW55KTp2b2lke1xyXG4gICAgICAgIGlmKG5Nc2dDb2RlPDB8fG9Nc2dCb2R5PT1udWxsKXtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQgb0hhbmRsZXIgPSB0aGlzLl9vSGFuZGxlck1hcFtuTXNnQ29kZV07XHJcbiAgICAgICAgaWYgKG9IYW5kbGVyID09IG51bGwpIHtcclxuICAgICAgICAgICAgY2MuZXJyb3IoYG5Nc2dDb2RlOiR7bk1zZ0NvZGV95om+5LiN5Yiw5a+55bqUaGFuZGxlcmApO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBvSGFuZGxlci5oYW5kbGUob01zZ0JvZHkpO1xyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=