
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resultHandler/UserQuitResultHandler.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e7d6c5P7VBHVa9cf53adggG', 'UserQuitResultHandler');
// resultHandler/UserQuitResultHandler.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserManager_1 = require("../script/xiaojingling/UserManager");
var UserQuitResultHandler = /** @class */ (function () {
    function UserQuitResultHandler() {
    }
    UserQuitResultHandler.prototype.handle = function (oResult) {
        cc.log("\u7528\u6237\uFF1A" + oResult.quitUserId + "\u79BB\u573A");
        var myHeroComp = UserManager_1.default.getMyHeroComp(oResult.quitUserId);
    };
    return UserQuitResultHandler;
}());
exports.default = UserQuitResultHandler;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzdWx0SGFuZGxlclxcVXNlclF1aXRSZXN1bHRIYW5kbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0Esa0VBQTZEO0FBRzdEO0lBQUE7SUFPQSxDQUFDO0lBTkcsc0NBQU0sR0FBTixVQUFPLE9BQThDO1FBQ2pELEVBQUUsQ0FBQyxHQUFHLENBQUMsdUJBQU0sT0FBTyxDQUFDLFVBQVUsaUJBQUksQ0FBQyxDQUFDO1FBQ3JDLElBQUksVUFBVSxHQUFHLHFCQUFXLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUVuRSxDQUFDO0lBRUwsNEJBQUM7QUFBRCxDQVBBLEFBT0MsSUFBQSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb2RfR2FtZU1zZ1Byb3RvY29sID0gcmVxdWlyZSgnLi4vbXNnL0dhbWVNc2dQcm90b2NvbCcpO1xyXG5pbXBvcnQgVXNlck1hbmFnZXIgZnJvbSBcIi4uL3NjcmlwdC94aWFvamluZ2xpbmcvVXNlck1hbmFnZXJcIjtcclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBVc2VyUXVpdFJlc3VsdEhhbmRsZXIgIHtcclxuICAgIGhhbmRsZShvUmVzdWx0Om1vZF9HYW1lTXNnUHJvdG9jb2wubXNnLlVzZXJRdWl0UmVzdWx0KTp2b2lke1xyXG4gICAgICAgIGNjLmxvZyhg55So5oi377yaJHtvUmVzdWx0LnF1aXRVc2VySWR956a75Zy6YCk7XHJcbiAgICAgICAgbGV0IG15SGVyb0NvbXAgPSBVc2VyTWFuYWdlci5nZXRNeUhlcm9Db21wKG9SZXN1bHQucXVpdFVzZXJJZCk7XHJcblxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=